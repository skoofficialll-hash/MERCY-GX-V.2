package com.skinventor.mercygx;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Checks GitHub Releases for a newer build and installs it.
 *
 * Flow: GET /releases/latest -> compare tag (v0.9.0) with the installed versionName
 *       -> if newer, show a dialog -> DownloadManager downloads the APK
 *       -> on completion, open the system installer with the downloaded content URI.
 *
 * No third-party libraries, no Play Services, works for sideloaded builds too.
 */
public class Updater {

    private static final String API =
            "https://api.github.com/repos/skoofficialll-hash/MERCY-GX-V.2/releases/latest";
    private static final String PREFS = "mercy_gx";
    private static final String LAST_CHECK = "lastUpdateCheck";
    private static final long DAY_MS = 24L * 60L * 60L * 1000L;

    /* ---------------- public entry points ---------------- */

    /** Silent = no dialog when the app is already up to date. */
    public static void check(final Activity act, final boolean silent) {
        new Thread(new Runnable() {
            @Override public void run() {
                final String body = fetch();
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    @Override public void run() {
                        handle(act, body, silent);
                    }
                });
            }
        }).start();
    }

    /** Called once per launch; hits the network at most once a day. */
    public static void autoCheck(Activity act) {
        SharedPreferences p = act.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        long last = p.getLong(LAST_CHECK, 0L);
        if (System.currentTimeMillis() - last < DAY_MS) return;
        p.edit().putLong(LAST_CHECK, System.currentTimeMillis()).apply();
        check(act, true);
    }

    /* ---------------- network ---------------- */

    private static String fetch() {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(API).openConnection();
            c.setRequestProperty("Accept", "application/vnd.github+json");
            c.setRequestProperty("User-Agent", "MercyGX-App");
            c.setConnectTimeout(9000);
            c.setReadTimeout(9000);
            if (c.getResponseCode() != 200) return null;
            BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line);
            r.close();
            return sb.toString();
        } catch (Exception e) {
            return null;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    /* ---------------- decision ---------------- */

    private static void handle(final Activity act, String body, boolean silent) {
        if (body == null) {
            if (!silent) toast(act, "Could not reach the update server");
            return;
        }
        String tag = null, apkUrl = null, notes = "";
        try {
            JSONObject o = new JSONObject(body);
            tag = o.optString("tag_name", "");
            notes = o.optString("body", "");
            JSONArray assets = o.optJSONArray("assets");
            if (assets != null) {
                for (int i = 0; i < assets.length(); i++) {
                    JSONObject a = assets.getJSONObject(i);
                    String name = a.optString("name", "");
                    if (name.toLowerCase().endsWith(".apk")) {
                        apkUrl = a.optString("browser_download_url", null);
                        break;
                    }
                }
            }
        } catch (Exception e) {
            if (!silent) toast(act, "Update check failed");
            return;
        }

        final String latest = clean(tag);
        String current = currentVersion(act);

        if (latest.isEmpty() || apkUrl == null) {
            if (!silent) toast(act, "No release published yet");
            return;
        }
        if (compare(latest, current) <= 0) {
            if (!silent) toast(act, "You are on the latest version (" + current + ")");
            return;
        }

        final String url = apkUrl;
        String message = "Version " + latest + " is available. You have " + current + ".";
        if (notes != null && notes.trim().length() > 0) {
            String shortNotes = notes.trim();
            if (shortNotes.length() > 320) shortNotes = shortNotes.substring(0, 320) + "…";
            message += "\n\n" + shortNotes;
        }

        new AlertDialog.Builder(act)
                .setTitle("Update available")
                .setMessage(message)
                .setPositiveButton("Download", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        download(act, url, latest);
                    }
                })
                .setNegativeButton("Later", null)
                .show();
    }

    /* ---------------- download + install ---------------- */

    private static void download(final Activity act, String url, String version) {
        try {
            DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
            req.setMimeType("application/vnd.android.package-archive");
            req.setTitle("Mercy GX " + version);
            req.setDescription("Downloading the update…");
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            req.setDestinationInExternalPublicDir(
                    Environment.DIRECTORY_DOWNLOADS, "MercyGX-" + version + ".apk");

            final DownloadManager dm = (DownloadManager) act.getSystemService(Context.DOWNLOAD_SERVICE);
            if (dm == null) { toast(act, "Download manager unavailable"); return; }

            final long id = dm.enqueue(req);
            toast(act, "Downloading update…");

            final BroadcastReceiver receiver = new BroadcastReceiver() {
                @Override public void onReceive(Context ctx, Intent intent) {
                    long done = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1);
                    if (done != id) return;
                    try { act.unregisterReceiver(this); } catch (Exception ignored) { }
                    install(act, dm, id);
                }
            };

            IntentFilter filter = new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE);
            if (Build.VERSION.SDK_INT >= 33) {
                act.registerReceiver(receiver, filter, Context.RECEIVER_EXPORTED);
            } else {
                act.registerReceiver(receiver, filter);
            }
        } catch (Exception e) {
            toast(act, "Update download failed");
        }
    }

    private static void install(Activity act, DownloadManager dm, long id) {
        try {
            Uri apk = dm.getUriForDownloadedFile(id);
            if (apk == null) { toast(act, "Update file not found"); return; }
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(apk, "application/vnd.android.package-archive");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            act.startActivity(i);
        } catch (Exception e) {
            toast(act, "Open Downloads and tap the APK to finish installing");
        }
    }

    /* ---------------- version helpers ---------------- */

    private static String currentVersion(Activity act) {
        try {
            return act.getPackageManager().getPackageInfo(act.getPackageName(), 0).versionName;
        } catch (Exception e) {
            return "0.0.0";
        }
    }

    private static String clean(String tag) {
        if (tag == null) return "";
        String t = tag.trim();
        if (t.startsWith("v") || t.startsWith("V")) t = t.substring(1);
        return t;
    }

    /** Returns > 0 when a is newer than b. */
    private static int compare(String a, String b) {
        String[] x = a.split("[.\\-+]");
        String[] y = b.split("[.\\-+]");
        int n = Math.max(x.length, y.length);
        for (int i = 0; i < n; i++) {
            int xi = i < x.length ? num(x[i]) : 0;
            int yi = i < y.length ? num(y[i]) : 0;
            if (xi != yi) return xi > yi ? 1 : -1;
        }
        return 0;
    }

    private static int num(String s) {
        StringBuilder digits = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c >= '0' && c <= '9') digits.append(c); else break;
        }
        if (digits.length() == 0) return 0;
        try { return Integer.parseInt(digits.toString()); } catch (Exception e) { return 0; }
    }

    private static void toast(Activity act, String m) {
        Toast.makeText(act, m, Toast.LENGTH_SHORT).show();
    }
}
