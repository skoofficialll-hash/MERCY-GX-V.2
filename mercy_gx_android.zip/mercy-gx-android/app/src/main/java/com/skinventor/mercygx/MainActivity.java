package com.skinventor.mercygx;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Mercy GX 1.0 — tabs, ad-block, live suggestions, HTTPS-only.
 * Platform WebView only; no third-party libraries.
 */
public class MainActivity extends Activity {

    private static final String HOME = "file:///android_asset/newtab.html";
    private static final String PREFS = "mercy_gx";

    /* ---------------- ad / tracker blocklist ---------------- */
    private static final Set<String> BLOCK = new HashSet<>(Arrays.asList(
            "doubleclick.net", "googlesyndication.com", "googleadservices.com",
            "adservice.google.com", "google-analytics.com", "googletagmanager.com",
            "googletagservices.com", "scorecardresearch.com", "criteo.com",
            "criteo.net", "taboola.com", "outbrain.com", "adnxs.com",
            "quantserve.com", "moatads.com", "rubiconproject.com", "pubmatic.com",
            "openx.net", "casalemedia.com", "smartadserver.com", "yieldmo.com",
            "amazon-adsystem.com", "adsrvr.org", "bidswitch.net", "sharethrough.com",
            "hotjar.com", "segment.io", "segment.com", "amplitude.com", "mixpanel.com",
            "fullstory.com", "mouseflow.com", "clarity.ms", "branch.io", "appsflyer.com",
            "adjust.com", "kochava.com", "onesignal.com", "inmobi.com", "unityads.unity3d.com",
            "chartboost.com", "vungle.com", "applovin.com", "ironsrc.com", "supersonicads.com",
            "mopub.com", "flurry.com", "umeng.com", "bugsnag.com", "sentry-cdn.com",
            "facebook.net", "fbcdn-ads.com", "analytics.tiktok.com", "ads.tiktok.com"
    ));

    /* ---------------- state ---------------- */
    private final List<Tab> tabs = new ArrayList<>();
    private Tab active;
    private int tabSeq = 1;
    private SharedPreferences prefs;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private Runnable suggestJob;
    private long blockedCount = 0;

    /* ---------------- views ---------------- */
    private FrameLayout container;
    private LinearLayout strip;
    private HorizontalScrollView stripScroll;
    private LinearLayout suggestPanel;
    private EditText urlBar;
    private ProgressBar progress;
    private Button btnBack, btnFwd;
    private TextView tabCount;

    private static class Tab {
        String id;
        WebView web;
        String url = HOME;
        String title = "New tab";
        View chip;
    }

    /* =========================================================
       lifecycle
    ========================================================= */
    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        container = findViewById(R.id.container);
        strip = findViewById(R.id.tabstrip);
        stripScroll = findViewById(R.id.tabscroll);
        suggestPanel = findViewById(R.id.suggestions);
        urlBar = findViewById(R.id.url);
        progress = findViewById(R.id.progress);
        btnBack = findViewById(R.id.btnBack);
        btnFwd = findViewById(R.id.btnForward);
        tabCount = findViewById(R.id.tabCount);

        if (Build.VERSION.SDK_INT <= 28
                && checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, 100);
        }

        wireToolbar();

        Uri incoming = getIntent() == null ? null : getIntent().getData();
        String scheme = incoming == null || incoming.getScheme() == null ? "" : incoming.getScheme();
        if (scheme.equals("http") || scheme.equals("https")) {
            newTab(incoming.toString());   // opened from a link in another app
        } else {
            newTab(HOME);
        }

        Updater.autoCheck(this);
    }

    private void wireToolbar() {
        findViewById(R.id.btnGo).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { go(urlBar.getText().toString()); }
        });
        findViewById(R.id.btnHome).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { newTab(HOME); }
        });
        findViewById(R.id.btnReload).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { if(active != null) active.web.reload(); }
        });
        findViewById(R.id.btnNewTab).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { newTab(HOME); }
        });
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { if(active != null && active.web.canGoBack()) active.web.goBack(); }
        });
        btnFwd.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { if(active != null && active.web.canGoForward()) active.web.goForward(); }
        });
        findViewById(R.id.btnMenu).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showMenu(); }
        });

        urlBar.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_DONE
                        || (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                    hideSuggestions();
                    go(urlBar.getText().toString());
                    return true;
                }
                return false;
            }
        });
        urlBar.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable s) { queueSuggestions(s.toString()); }
        });
    }

    /* =========================================================
       tabs
    ========================================================= */
    private void newTab(String url) {
        final Tab t = new Tab();
        t.id = "t" + (tabSeq++);
        t.web = buildWebView();
        t.url = url;
        container.addView(t.web, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        tabs.add(t);
        select(t);
        t.web.loadUrl(url);
    }

    private WebView buildWebView() {
        WebView w = new WebView(this);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setUserAgentString(s.getUserAgentString() + " MercyGX/1.0");
        if (Build.VERSION.SDK_INT >= 26) s.setSafeBrowsingEnabled(true);

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, false);

        w.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri u = req.getUrl();
                String scheme = u.getScheme() == null ? "" : u.getScheme();
                if (scheme.equals("http")) {
                    if (httpsOnly()) {
                        view.loadUrl(u.toString().replaceFirst("^http://", "https://"));
                        toast("Upgraded to HTTPS");
                        return true;
                    }
                    return false;
                }
                if (scheme.equals("https") || scheme.equals("file")) return false;
                try { startActivity(new android.content.Intent(android.content.Intent.ACTION_VIEW, u)); }
                catch (Exception ignored) { }
                return true;
            }

            /* the ad-blocker: cancel the request before it leaves the phone */
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
                if (adblockOn() && isBlocked(req.getUrl())) {
                    blockedCount++;
                    if (blockedCount % 10 == 0) runOnUiThread(new Runnable() {
                        @Override public void run() { tabCount.setText(blockedCount + " blocked"); }
                    });
                    return new WebResourceResponse("text/plain", "utf-8",
                            new ByteArrayInputStream(new byte[0]));
                }
                return null;
            }

            @Override public void onPageFinished(WebView view, String url) {
                progress.setVisibility(View.GONE);
                Tab t = tabOf(view);
                if (t == null) return;
                t.url = url;
                t.title = view.getTitle() == null ? url : view.getTitle();
                if (t == active) {
                    urlBar.setText(url);
                    updateNav();
                }
                renderStrip();
                addHistory(url, t.title);
            }
        });

        w.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int p) {
                progress.setVisibility(p >= 100 ? View.GONE : View.VISIBLE);
                progress.setProgress(p);
            }
            @Override public void onReceivedTitle(WebView view, String title) {
                Tab t = tabOf(view);
                if (t != null && title != null) { t.title = title; renderStrip(); }
            }
        });

        w.setDownloadListener(new DownloadListener() {
            @Override public void onDownloadStart(String url, String ua, String cd, String mime, long size) {
                try {
                    String name = URLUtil.guessFileName(url, cd, mime);
                    DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
                    r.setMimeType(mime);
                    r.addRequestHeader("User-Agent", ua);
                    r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
                    DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
                    if (dm != null) dm.enqueue(r);
                    toast("Downloading " + name);
                } catch (Exception e) { toast("Download failed"); }
            }
        });
        return w;
    }

    private Tab tabOf(WebView w) {
        for (Tab t : tabs) if (t.web == w) return t;
        return null;
    }

    private void select(Tab t) {
        active = t;
        for (Tab x : tabs) x.web.setVisibility(x == t ? View.VISIBLE : View.GONE);
        urlBar.setText(t.url);
        updateNav();
        renderStrip();
    }

    private void closeTab(Tab t) {
        container.removeView(t.web);
        t.web.destroy();
        tabs.remove(t);
        if (tabs.isEmpty()) { newTab(HOME); return; }
        if (t == active) select(tabs.get(tabs.size() - 1));
        else renderStrip();
    }

    private void renderStrip() {
        strip.removeAllViews();
        for (final Tab t : tabs) {
            LinearLayout chip = new LinearLayout(this);
            chip.setOrientation(LinearLayout.HORIZONTAL);
            chip.setGravity(Gravity.CENTER_VERTICAL);
            chip.setPadding(dp(10), dp(6), dp(6), dp(6));
            chip.setBackgroundColor(t == active ? Color.parseColor("#232830") : Color.parseColor("#15181e"));

            TextView label = new TextView(this);
            String title = t.title == null ? "New tab" : t.title;
            if (title.length() > 16) title = title.substring(0, 16) + "…";
            label.setText(title);
            label.setTextSize(11);
            label.setTextColor(t == active ? Color.parseColor("#eceef1") : Color.parseColor("#98a1ac"));
            label.setSingleLine(true);
            chip.addView(label);

            TextView x = new TextView(this);
            x.setText("  ✕");
            x.setTextSize(11);
            x.setTextColor(Color.parseColor("#68717c"));
            x.setPadding(dp(6), 0, dp(2), 0);
            x.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { closeTab(t); }
            });
            chip.addView(x);

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, 0, dp(5), 0);
            chip.setLayoutParams(lp);
            chip.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { select(t); }
            });
            strip.addView(chip);
            t.chip = chip;
        }
        tabCount.setText(tabs.size() + (blockedCount > 0 ? " · " + blockedCount + " blocked" : ""));
        stripScroll.post(new Runnable() {
            @Override public void run() { stripScroll.fullScroll(View.FOCUS_RIGHT); }
        });
    }

    /* =========================================================
       navigation
    ========================================================= */
    private boolean looksLikeUrl(String s) {
        if (s.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*")) return true;
        if (s.matches("^localhost(:\\d+)?(/.*)?$")) return true;
        return s.matches("^[^\\s]+\\.[a-zA-Z]{2,}([/?#].*)?$");
    }

    private void go(String input) {
        String s = input == null ? "" : input.trim();
        if (s.isEmpty() || active == null) return;
        hideSuggestions();
        if (looksLikeUrl(s)) {
            String url = s.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*") ? s
                    : (s.startsWith("localhost") ? "http://" + s : "https://" + s);
            active.web.loadUrl(url);
        } else {
            active.web.loadUrl("https://duckduckgo.com/?q=" + Uri.encode(s));
        }
        hideKeyboard();
    }

    private void updateNav() {
        boolean canBack = active != null && active.web.canGoBack();
        boolean canFwd = active != null && active.web.canGoForward();
        btnBack.setEnabled(canBack); btnBack.setAlpha(canBack ? 1f : 0.3f);
        btnFwd.setEnabled(canFwd); btnFwd.setAlpha(canFwd ? 1f : 0.3f);
    }

    /* =========================================================
       suggestions (DuckDuckGo autocomplete, no key, no account)
    ========================================================= */
    private void queueSuggestions(final String q) {
        if (suggestJob != null) ui.removeCallbacks(suggestJob);
        if (q == null || q.trim().length() < 2) { hideSuggestions(); return; }
        suggestJob = new Runnable() {
            @Override public void run() { fetchSuggestions(q.trim()); }
        };
        ui.postDelayed(suggestJob, 220);
    }

    private void fetchSuggestions(final String q) {
        new Thread(new Runnable() {
            @Override public void run() {
                final List<String> out = new ArrayList<>();
                HttpURLConnection c = null;
                try {
                    String url = "https://duckduckgo.com/ac/?q=" + URLEncoder.encode(q, "UTF-8") + "&type=list";
                    c = (HttpURLConnection) new URL(url).openConnection();
                    c.setRequestProperty("User-Agent", "MercyGX/1.0");
                    c.setConnectTimeout(6000);
                    c.setReadTimeout(6000);
                    if (c.getResponseCode() == 200) {
                        BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"));
                        StringBuilder sb = new StringBuilder();
                        String line;
                        while ((line = r.readLine()) != null) sb.append(line);
                        r.close();
                        JSONArray arr = new JSONArray(sb.toString());
                        for (int i = 1; i < arr.length() && out.size() < 6; i++) {
                            out.add(arr.getString(i));
                        }
                    }
                } catch (Exception ignored) {
                } finally {
                    if (c != null) c.disconnect();
                }
                ui.post(new Runnable() {
                    @Override public void run() { showSuggestions(out); }
                });
            }
        }).start();
    }

    private void showSuggestions(List<String> items) {
        suggestPanel.removeAllViews();
        if (items.isEmpty()) { hideSuggestions(); return; }
        for (final String s : items) {
            TextView row = new TextView(this);
            row.setText(s);
            row.setTextSize(14);
            row.setTextColor(Color.parseColor("#eceef1"));
            row.setPadding(dp(16), dp(12), dp(16), dp(12));
            row.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    urlBar.setText(s);
                    urlBar.setSelection(s.length());
                    hideSuggestions();
                    go(s);
                }
            });
            suggestPanel.addView(row);
        }
        suggestPanel.setVisibility(View.VISIBLE);
    }

    private void hideSuggestions() {
        suggestPanel.setVisibility(View.GONE);
        suggestPanel.removeAllViews();
    }

    /* =========================================================
       history / bookmarks
    ========================================================= */
    private JSONArray readArray(String key) {
        try { return new JSONArray(prefs.getString(key, "[]")); }
        catch (Exception e) { return new JSONArray(); }
    }

    private void addHistory(String url, String title) {
        if (url == null || url.equals("about:blank") || url.startsWith("file://")) return;
        try {
            JSONArray arr = readArray("history");
            JSONArray out = new JSONArray();
            JSONObject o = new JSONObject();
            o.put("url", url);
            o.put("title", title == null ? url : title);
            out.put(o);
            for (int i = 0; i < arr.length() && i < 199; i++) {
                JSONObject old = arr.getJSONObject(i);
                if (!url.equals(old.optString("url"))) out.put(old);
            }
            prefs.edit().putString("history", out.toString()).apply();
        } catch (Exception ignored) { }
    }

    private void toggleBookmark() {
        if (active == null) return;
        try {
            JSONArray arr = readArray("bookmarks");
            for (int i = 0; i < arr.length(); i++) {
                if (active.url.equals(arr.getJSONObject(i).optString("url"))) {
                    toast("Already bookmarked");
                    return;
                }
            }
            JSONObject o = new JSONObject();
            o.put("url", active.url);
            o.put("title", active.title);
            arr.put(o);
            prefs.edit().putString("bookmarks", arr.toString()).apply();
            toast("Bookmarked");
        } catch (Exception e) { toast("Bookmark failed"); }
    }

    private void showList(final String key, String emptyMsg) {
        JSONArray arr = readArray(key);
        if (arr.length() == 0) { toast(emptyMsg); return; }
        final String[] urls = new String[arr.length()];
        final String[] titles = new String[arr.length()];
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            urls[i] = o == null ? "" : o.optString("url");
            titles[i] = o == null ? "" : o.optString("title");
        }
        new AlertDialog.Builder(this)
                .setTitle(key.equals("bookmarks") ? "Bookmarks" : "History")
                .setItems(titles, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) { go(urls[which]); }
                })
                .setNegativeButton("Close", null)
                .show();
    }

    /* =========================================================
       menu
    ========================================================= */
    private void showMenu() {
        String[] items = {"New tab", "Bookmark this page", "Bookmarks", "History",
                "Ad-block: " + (adblockOn() ? "on" : "off"),
                "HTTPS-only: " + (httpsOnly() ? "on" : "off"),
                "Check for updates", "Clear browsing data", "About Mercy GX"};
        new AlertDialog.Builder(this)
                .setTitle("Mercy GX")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        switch (which) {
                            case 0: newTab(HOME); break;
                            case 1: toggleBookmark(); break;
                            case 2: showList("bookmarks", "No bookmarks yet"); break;
                            case 3: showList("history", "History is empty"); break;
                            case 4: prefs.edit().putBoolean("adblock", !adblockOn()).apply();
                                    toast("Ad-block " + (adblockOn() ? "on" : "off")); break;
                            case 5: prefs.edit().putBoolean("httpsOnly", !httpsOnly()).apply();
                                    toast("HTTPS-only " + (httpsOnly() ? "on" : "off")); break;
                            case 6: Updater.check(MainActivity.this, false); break;
                            case 7: clearData(); break;
                            case 8: about(); break;
                        }
                    }
                })
                .setNegativeButton("Close", null)
                .show();
    }

    private void clearData() {
        new AlertDialog.Builder(this)
                .setTitle("Clear browsing data?")
                .setMessage("History, bookmarks, cookies and cache will be removed.")
                .setPositiveButton("Clear", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        prefs.edit().clear().apply();
                        CookieManager.getInstance().removeAllCookies(null);
                        for (Tab t : tabs) { t.web.clearHistory(); t.web.clearCache(true); }
                        toast("Cleared");
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void about() {
        new AlertDialog.Builder(this)
                .setTitle("Mercy GX 1.0")
                .setMessage("A small gaming browser for Android.\n\n"
                        + "Engine: the WebView (Chromium) already on your phone.\n"
                        + "Tabs, ad-block, live search suggestions, HTTPS-only.\n"
                        + "New tab: gamehub with five games.\n"
                        + "Everything stays on this device.")
                .setPositiveButton("OK", null)
                .show();
    }

    /* =========================================================
       helpers
    ========================================================= */
    private boolean adblockOn() { return prefs.getBoolean("adblock", true); }
    private boolean httpsOnly() { return prefs.getBoolean("httpsOnly", true); }

    private boolean isBlocked(Uri u) {
        if (u == null || u.getHost() == null) return false;
        String host = u.getHost().toLowerCase();
        for (String h : BLOCK) {
            if (host.equals(h) || host.endsWith("." + h)) return true;
        }
        return false;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private void toast(String m) { Toast.makeText(this, m, Toast.LENGTH_SHORT).show(); }

    private void hideKeyboard() {
        InputMethodManager im = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (im != null) im.hideSoftInputFromWindow(urlBar.getWindowToken(), 0);
        urlBar.clearFocus();
    }

    /* =========================================================
       system back
    ========================================================= */
    @Override
    public void onBackPressed() {
        if (suggestPanel.getVisibility() == View.VISIBLE) { hideSuggestions(); return; }
        if (active != null && active.web.canGoBack()) { active.web.goBack(); return; }
        if (tabs.size() > 1) { closeTab(active); return; }
        if (active != null && !active.url.equals(HOME)) { active.web.loadUrl(HOME); return; }
        super.onBackPressed();
    }

    @Override protected void onPause() { super.onPause(); if (active != null) active.web.onPause(); }
    @Override protected void onResume() { super.onResume(); if (active != null) active.web.onResume(); }

    @Override
    protected void onDestroy() {
        for (Tab t : tabs) {
            container.removeView(t.web);
            t.web.destroy();
        }
        tabs.clear();
        super.onDestroy();
    }
}
