package com.skinventor.mercygx;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Mercy GX — a small but real Android browser.
 * Platform WebView (Chromium) does the rendering; this class is the shell:
 * address bar, back/forward, reload, bookmarks, history, downloads, gamehub new tab.
 */
public class MainActivity extends Activity {

    private static final String HOME = "file:///android_asset/newtab.html";
    private static final String PREFS = "mercy_gx";

    private WebView web;
    private EditText urlBar;
    private ProgressBar progress;
    private Button btnBack, btnForward;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);

        // Android 9 and below needs a runtime permission to save downloads
        if (Build.VERSION.SDK_INT <= 28
                && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 100);
        }
        web = findViewById(R.id.web);
        urlBar = findViewById(R.id.url);
        progress = findViewById(R.id.progress);
        btnBack = findViewById(R.id.btnBack);
        btnForward = findViewById(R.id.btnForward);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setUserAgentString(s.getUserAgentString() + " MercyGX/0.8");

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, false);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                String scheme = u.getScheme() == null ? "" : u.getScheme();
                if (scheme.equals("http") || scheme.equals("https") || scheme.equals("file")) {
                    return false; // load inside the browser
                }
                try {
                    startActivity(new android.content.Intent(android.content.Intent.ACTION_VIEW, u));
                } catch (Exception ignored) { }
                return true; // mailto:, intent:, etc. go to other apps
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                progress.setVisibility(View.GONE);
                urlBar.setText(url);
                addHistory(url, view.getTitle());
                updateNav();
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int p) {
                progress.setVisibility(p >= 100 ? View.GONE : View.VISIBLE);
                progress.setProgress(p);
            }

            @Override
            public void onReceivedTitle(WebView view, String title) {
                if (title != null && !title.isEmpty()) setTitle(title);
            }
        });

        web.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String userAgent, String disposition,
                                        String mime, long size) {
                try {
                    String name = URLUtil.guessFileName(url, disposition, mime);
                    DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
                    req.setMimeType(mime);
                    req.addRequestHeader("User-Agent", userAgent);
                    req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
                    DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
                    if (dm != null) dm.enqueue(req);
                    toast("Downloading " + name);
                } catch (Exception e) {
                    toast("Download failed");
                }
            }
        });

        urlBar.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_DONE
                        || (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                    go(urlBar.getText().toString());
                    hideKeyboard();
                    return true;
                }
                return false;
            }
        });

        findViewById(R.id.btnGo).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                go(urlBar.getText().toString());
                hideKeyboard();
            }
        });
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { if (web.canGoBack()) web.goBack(); }
        });
        btnForward.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { if (web.canGoForward()) web.goForward(); }
        });
        findViewById(R.id.btnReload).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { web.reload(); }
        });
        findViewById(R.id.btnMenu).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showMenu(); }
        });
        findViewById(R.id.btnHome).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { web.loadUrl(HOME); }
        });

        if (saved != null) {
            web.restoreState(saved);
        } else {
            Uri incoming = getIntent() == null ? null : getIntent().getData();
            if (incoming != null && incoming.getScheme() != null
                    && (incoming.getScheme().equals("http") || incoming.getScheme().equals("https"))) {
                web.loadUrl(incoming.toString());   // opened from another app's link
            } else {
                web.loadUrl(HOME);
            }
        }

        // quiet check once a day; shows a dialog only when a newer release exists
        Updater.autoCheck(this);
    }

    /* ---------------- navigation ---------------- */

    private boolean looksLikeUrl(String s) {
        if (s.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*")) return true;
        if (s.matches("^localhost(:\\d+)?(/.*)?$")) return true;
        return s.matches("^[^\\s]+\\.[a-zA-Z]{2,}([/?#].*)?$");
    }

    private String normalize(String s) {
        if (s.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*")) return s;
        if (s.startsWith("localhost")) return "http://" + s;
        return "https://" + s;
    }

    private void go(String input) {
        String s = input == null ? "" : input.trim();
        if (s.isEmpty()) return;
        if (looksLikeUrl(s)) {
            web.loadUrl(normalize(s));
        } else {
            web.loadUrl("https://www.google.com/search?q=" + Uri.encode(s));
        }
    }

    private void updateNav() {
        btnBack.setEnabled(web.canGoBack());
        btnForward.setEnabled(web.canGoForward());
        btnBack.setAlpha(web.canGoBack() ? 1f : 0.35f);
        btnForward.setAlpha(web.canGoForward() ? 1f : 0.35f);
    }

    private void hideKeyboard() {
        InputMethodManager im = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (im != null) im.hideSoftInputFromWindow(urlBar.getWindowToken(), 0);
        urlBar.clearFocus();
    }

    private void toast(String m) {
        Toast.makeText(this, m, Toast.LENGTH_SHORT).show();
    }

    /* ---------------- history + bookmarks (SharedPreferences, JSON) ---------------- */

    private JSONArray readArray(String key) {
        try {
            return new JSONArray(prefs.getString(key, "[]"));
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    private void writeArray(String key, JSONArray arr) {
        prefs.edit().putString(key, arr.toString()).apply();
    }

    private void addHistory(String url, String title) {
        if (url == null || url.equals("about:blank")) return;
        try {
            JSONArray arr = readArray("history");
            JSONArray out = new JSONArray();
            JSONObject entry = new JSONObject();
            entry.put("url", url);
            entry.put("title", title == null ? url : title);
            entry.put("at", System.currentTimeMillis());
            out.put(entry);
            for (int i = 0; i < arr.length() && i < 199; i++) {
                JSONObject o = arr.getJSONObject(i);
                if (!url.equals(o.optString("url"))) out.put(o);
            }
            writeArray("history", out);
        } catch (Exception ignored) { }
    }

    private void toggleBookmark() {
        String url = web.getUrl();
        if (url == null) return;
        try {
            JSONArray arr = readArray("bookmarks");
            for (int i = 0; i < arr.length(); i++) {
                if (url.equals(arr.getJSONObject(i).optString("url"))) {
                    toast("Already bookmarked");
                    return;
                }
            }
            JSONObject o = new JSONObject();
            o.put("url", url);
            o.put("title", web.getTitle() == null ? url : web.getTitle());
            arr.put(o);
            writeArray("bookmarks", arr);
            toast("Bookmarked");
        } catch (Exception e) {
            toast("Bookmark failed");
        }
    }

    private void showList(final String key, String emptyMsg) {
        JSONArray arr = readArray(key);
        if (arr.length() == 0) {
            toast(emptyMsg);
            return;
        }
        final String[] urls = new String[arr.length()];
        final String[] titles = new String[arr.length()];
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            urls[i] = o == null ? "" : o.optString("url");
            titles[i] = o == null ? "" : o.optString("title");
        }
        new AlertDialog.Builder(this)
                .setTitle(key.equals("bookmarks") ? "Bookmarks" : "History")
                .setItems(titles, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        web.loadUrl(urls[which]);
                    }
                })
                .setNegativeButton("Close", null)
                .show();
    }

    /* ---------------- menu ---------------- */

    private void showMenu() {
        String[] items = {"Bookmark this page", "Bookmarks", "History", "Go to gamehub",
                          "Clear browsing data", "Check for updates", "About Mercy GX"};
        new AlertDialog.Builder(this)
                .setTitle("Mercy GX")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        switch (which) {
                            case 0: toggleBookmark(); break;
                            case 1: showList("bookmarks", "No bookmarks yet"); break;
                            case 2: showList("history", "History is empty"); break;
                            case 3: web.loadUrl(HOME); break;
                            case 4: clearData(); break;
                            case 5: Updater.check(MainActivity.this, false); break;
                            case 6: about(); break;
                        }
                    }
                })
                .setNegativeButton("Close", null)
                .show();
    }

    private void clearData() {
        new AlertDialog.Builder(this)
                .setTitle("Clear browsing data?")
                .setMessage("History, bookmarks, cookies and cache will be removed. This cannot be undone.")
                .setPositiveButton("Clear", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        prefs.edit().clear().apply();
                        CookieManager.getInstance().removeAllCookies(null);
                        web.clearHistory();
                        web.clearCache(true);
                        web.clearFormData();
                        web.loadUrl(HOME);
                        toast("Cleared");
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void about() {
        new AlertDialog.Builder(this)
                .setTitle("Mercy GX 0.8")
                .setMessage("A gaming browser for Android.\n\n"
                        + "Engine: the WebView (Chromium) already on your phone.\n"
                        + "New tab: gamehub with five games.\n"
                        + "Everything (history, bookmarks, scores) stays on this device.\n\n"
                        + "Built with the platform WebView — no third-party libraries.")
                .setPositiveButton("OK", null)
                .show();
    }

    /* ---------------- lifecycle ---------------- */

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) {
            web.goBack();
        } else if (!web.getUrl().equals(HOME)) {
            web.loadUrl(HOME);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override
    protected void onPause() {
        super.onPause();
        web.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            web.loadUrl("about:blank");
            web.destroy();
        }
        super.onDestroy();
    }
}
