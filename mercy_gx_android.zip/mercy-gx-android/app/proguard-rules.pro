# keep it simple - nothing to strip
