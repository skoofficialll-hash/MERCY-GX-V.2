# Mercy GX — Android browser

Asli browser, phone ke liye. Rendering phone ka **WebView (Chromium)** karta hai, aur ye
project uska shell hai: address bar, back/forward, reload, bookmarks, history, downloads,
aur gamehub new tab.

## Andar kya hai

| Feature | Kaise |
|---|---|
| Koi bhi website khulti hai | WebView (Chromium engine) |
| Address bar | URL ya search — dono samajhta hai |
| Back / forward / reload / home | toolbar buttons |
| Bookmarks | ⋮ menu → Bookmark this page |
| History | ⋮ menu → History (200 entries, device par) |
| Downloads | DownloadManager se phone ke Downloads folder mein |
| Gamehub new tab | `assets/newtab.html` — wahi 5 games |
| Link se kholna | dusri app se link "Open with Mercy GX" par khulega |
| Data | sab device par, koi telemetry nahi |

Dependencies: **zero**. Sirf platform WebView — koi AndroidX, koi library nahi.

## APK kaise banaye (Android Studio ke bina)

APK banane ke liye Android SDK chahiye, par wo aapke phone par nahi — GitHub ke free
runner par banega. `.github/workflows/android.yml` isi kaam ke liye hai.

1. GitHub par naya repo banao: `mercy-gx-android` (public).
2. Ye poora folder repo mein daalo (structure same rehna chahiye — `app/src/main/...`).
   PC par: `git init && git add . && git commit -m "android browser" && git push`.
3. Repo → **Actions** tab → `build-apk` workflow → **Run workflow**.
   (push karne par apne aap bhi chal jayega.)
4. ~3-4 minute baad workflow khatam → us run ke neeche **Artifacts → MercyGX-apk** download karo.
   Zip ke andar `MercyGX-0.8.0.apk` milega.
5. Phone par APK kholo → "Install unknown apps" allow karo → install.

Android Studio wale: folder kholo → **Run ▶** — bas.

## Files

```
app/src/main/java/com/skinventor/mercygx/MainActivity.java   browser shell (Java, 400 lines)
app/src/main/res/layout/activity_main.xml                    toolbar + progress + WebView
app/src/main/assets/newtab.html                              gamehub (5 games)
app/src/main/AndroidManifest.xml                             internet + link handling
.github/workflows/android.yml                                APK build on GitHub
```

## Agla kaam (v0.9)

- Tabs (WebView ke saath multiple instances ya Fragment)
- Ad-block — `shouldInterceptRequest()` se host blocklist, bilkul possible
- Desktop mode / text zoom
- Incognito (separate WebView + no history)
- Play Store: `.aab` build + privacy policy + target SDK rules

## Sach

Ye code likha hua aur parse-check kiya hua hai, par is sandbox mein JDK/Android SDK nahi hai,
isliye **compile nahi kiya gaya**. Agar Actions par build fail ho to error log bhejo —
turant fix kar dunga.
