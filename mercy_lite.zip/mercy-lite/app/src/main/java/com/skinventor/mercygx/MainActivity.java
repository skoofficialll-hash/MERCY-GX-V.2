package com.skinventor.mercygx;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.PermissionRequest;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.SslErrorHandler;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Mercy Lite — a small, fast WebView browser: tabs, ad-block,
 * live suggestions, HTTPS-only. No third-party libraries.
 * Platform WebView only; no third-party libraries.
 */
public class MainActivity extends Activity {

    private static final String HOME = "file:///android_asset/newtab.html";
    private static final String PREFS = "mercy_gx";

    /* ---------------- ad / tracker blocklist ---------------- */
    private static final Set<String> BLOCK = new HashSet<>(Arrays.asList(
            "doubleclick.net", "googlesyndication.com", "googleadservices.com",
            "adservice.google.com", "google-analytics.com", "googletagmanager.com",
            "googletagservices.com", "scorecardresearch.com", "criteo.com",
            "criteo.net", "taboola.com", "outbrain.com", "adnxs.com",
            "quantserve.com", "moatads.com", "rubiconproject.com", "pubmatic.com",
            "openx.net", "casalemedia.com", "smartadserver.com", "yieldmo.com",
            "amazon-adsystem.com", "adsrvr.org", "bidswitch.net", "sharethrough.com",
            "hotjar.com", "segment.io", "segment.com", "amplitude.com", "mixpanel.com",
            "fullstory.com", "mouseflow.com", "clarity.ms", "branch.io", "appsflyer.com",
            "adjust.com", "kochava.com", "onesignal.com", "inmobi.com", "unityads.unity3d.com",
            "chartboost.com", "vungle.com", "applovin.com", "ironsrc.com", "supersonicads.com",
            "mopub.com", "flurry.com", "umeng.com", "bugsnag.com", "sentry-cdn.com",
            "facebook.net", "fbcdn-ads.com", "analytics.tiktok.com", "ads.tiktok.com",
            "adcolony.com", "vungle.com", "startapp.com", "tapjoy.com", "smaato.net",
            "fyber.com", "digitalturbine.com", "adform.net", "teads.tv", "loopme.me",
            "ogury.com", "sizmek.com", "adsafeprotected.com", "doubleverify.com",
            "adloox.com", "comscore.com", "quantcast.com", "nielsen.com", "chartbeat.com",
            "parsely.com", "newrelic.com", "bugsnag.com", "mparticle.com", "tealiumiq.com",
            "heapanalytics.com", "kissmetrics.com", "crazyegg.com", "clicktale.net",
            "luckyorange.com", "inspectlet.com", "smartlook.com", "logrocket.com",
            "braze.com", "iterable.com", "leanplum.com", "clevertap.com", "moengage.com",
            "webengage.com", "singular.net", "appmetrica.yandex.com", "mc.yandex.ru",
            "an.yandex.ru", "talkingdata.com", "pubnub.com", "gumgum.com",
            "indexexchange.com", "33across.com", "triplelift.com", "sovrn.com",
            "adroll.com", "revcontent.com", "mgid.com", "zergnet.com", "plista.com",
            "ligatus.com", "thetradedesk.com", "mediamath.com", "advertising.com",
            "yieldlab.net", "emxdgt.com", "district-m.net", "spotxchange.com",
            "tremorhub.com", "conversantmedia.com", "zedo.com", "exponential.com",
            "undertone.com", "serving-sys.com", "flashtalking.com", "innovid.com",
            "extremereach.com", "yieldmanager.com", "2mdn.net", "everesttech.net",
            "demdex.net", "omtrdc.net", "krxd.net", "bluekai.com", "exelator.com",
            "rlcdn.com", "agkn.com", "mathtag.com", "turn.com", "tapad.com",
            "adsymptotic.com", "crwdcntrl.net", "narrative.io", "liveramp.com",
            "ads.linkedin.com", "analytics.twitter.com", "static.ads-twitter.com",
            "sc-static.net", "snapchat.com", "tr.snapchat.com", "ads.pinterest.com",
            "ct.pinterest.com", "analytics.tiktok.com", "business-api.tiktok.com",
            "adsrvr.org"
    ));

    /* ---------------- state ---------------- */
    private final List<Tab> tabs = new ArrayList<>();
    private Tab active;
    private int tabSeq = 1;
    private SharedPreferences prefs;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private Runnable suggestJob;
    private long blockedCount = 0;

    /* ---------------- views ---------------- */
    private FrameLayout container;
    private LinearLayout strip;
    private HorizontalScrollView stripScroll;
    private LinearLayout suggestPanel;
    private EditText urlBar;
    private ProgressBar progress;
    private Button btnBack, btnFwd;
    private TextView tabCount;
    private TextView engineBtn;

    private static class Tab {
        String id;
        WebView web;
        String url = HOME;
        String title = "New tab";
        View chip;
        boolean incognito = false;
        boolean desktop = false;
    }

    /* =========================================================
       lifecycle
    ========================================================= */
    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        container = findViewById(R.id.container);
        strip = findViewById(R.id.tabstrip);
        stripScroll = findViewById(R.id.tabscroll);
        suggestPanel = findViewById(R.id.suggestions);
        urlBar = findViewById(R.id.url);
        progress = findViewById(R.id.progress);
        btnBack = findViewById(R.id.btnBack);
        btnFwd = findViewById(R.id.btnForward);
        tabCount = findViewById(R.id.tabCount);
        engineBtn = findViewById(R.id.engineBtn);
        tabCount.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showSiteInfo(); }
        });

        if (Build.VERSION.SDK_INT <= 28
                && checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, 100);
        }

        wireToolbar();
        paintEngine();

        Uri incoming = getIntent() == null ? null : getIntent().getData();
        String scheme = incoming == null || incoming.getScheme() == null ? "" : incoming.getScheme();
        if (scheme.equals("http") || scheme.equals("https")) {
            newTab(incoming.toString());   // opened from a link in another app
        } else {
            newTab(HOME);
        }

        Updater.autoCheck(this);
    }

    private void wireToolbar() {
        findViewById(R.id.btnGo).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { go(urlBar.getText().toString()); }
        });
        findViewById(R.id.btnHome).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { newTab(HOME); }
        });
        findViewById(R.id.btnReload).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { if(active != null) active.web.reload(); }
        });
        findViewById(R.id.btnNewTab).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { newTab(HOME); }
        });
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { if(active != null && active.web.canGoBack()) active.web.goBack(); }
        });
        btnFwd.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { if(active != null && active.web.canGoForward()) active.web.goForward(); }
        });
        findViewById(R.id.btnMenu).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showMenu(); }
        });
        engineBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showEnginePicker(); }
        });

        urlBar.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_DONE
                        || (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                    hideSuggestions();
                    go(urlBar.getText().toString());
                    return true;
                }
                return false;
            }
        });
        urlBar.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable s) { queueSuggestions(s.toString()); }
        });
    }

    /* =========================================================
       tabs
    ========================================================= */
    private void newTab(String url) { newTab(url, false); }

    private void newTab(String url, boolean incognito) {
        final Tab t = new Tab();
        t.id = "t" + (tabSeq++);
        t.incognito = incognito;
        t.title = incognito ? "Incognito" : "New tab";
        t.web = buildWebView(t);
        t.url = url;
        container.addView(t.web, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        tabs.add(t);
        select(t);
        t.web.loadUrl(url);
    }

    private WebView buildWebView(final Tab tab) {
        WebView w = new WebView(this);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(jsOn());
        s.setDomStorageEnabled(!tab.incognito);
        s.setDatabaseEnabled(!tab.incognito);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        // hardening
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setSaveFormData(false);
        s.setGeolocationEnabled(false);
        s.setSupportMultipleWindows(false);
        if (Build.VERSION.SDK_INT >= 26) s.setSafeBrowsingEnabled(true);
        if (tab.incognito) s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        if (tab.desktop) {
            s.setUserAgentString("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
                    + "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36");
            s.setUseWideViewPort(true);
            s.setLoadWithOverviewMode(true);
        }
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        // Plain mobile Chrome UA: no "wv" token, no app name. Without this, Google
        // shows "This browser or app may not be secure" and blocks sign-in.
        s.setUserAgentString("Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 "
                + "(KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36");
        if (Build.VERSION.SDK_INT >= 26) s.setSafeBrowsingEnabled(true);

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, false);

        w.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri u = req.getUrl();
                String scheme = u.getScheme() == null ? "" : u.getScheme();
                if (scheme.equals("http")) {
                    if (httpsOnly()) {
                        view.loadUrl(u.toString().replaceFirst("^http://", "https://"));
                        toast("Upgraded to HTTPS");
                        return true;
                    }
                    return false;
                }
                if (scheme.equals("https") || scheme.equals("file")) return false;
                if (scheme.equals("mailto") || scheme.equals("tel")) {
                    try { startActivity(new android.content.Intent(android.content.Intent.ACTION_VIEW, u)); }
                    catch (Exception ignored) { toast("No app can handle this link"); }
                    return true;
                }
                // intent://, market://, app links — a page must not launch other apps
                toast("Blocked an unsafe link (" + scheme + ")");
                return true;
            }

            /* the ad-blocker: cancel the request before it leaves the phone */
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
                if (adblockOn() && isBlocked(req.getUrl())) {
                    blockedCount++;
                    if (blockedCount % 10 == 0) runOnUiThread(new Runnable() {
                        @Override public void run() { tabCount.setText(blockedCount + " blocked"); }
                    });
                    return new WebResourceResponse("text/plain", "utf-8",
                            new ByteArrayInputStream(new byte[0]));
                }
                return null;
            }

            @Override public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                handler.cancel();
                toast("Blocked an insecure connection");
            }

            @Override public void onPageFinished(WebView view, String url) {
                progress.setVisibility(View.GONE);
                Tab t = tabOf(view);
                if (t == null) return;
                t.url = url;
                t.title = view.getTitle() == null ? url : view.getTitle();
                if (t == active) {
                    urlBar.setText(url);
                    updateNav();
                }
                renderStrip();
                if (!t.incognito) addHistory(url, t.title);
            }
        });

        w.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int p) {
                progress.setVisibility(p >= 100 ? View.GONE : View.VISIBLE);
                progress.setProgress(p);
            }
            @Override public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        request.deny();
                        toast("Blocked a device permission request");
                    }
                });
            }

            @Override public void onReceivedTitle(WebView view, String title) {
                Tab t = tabOf(view);
                if (t != null && title != null) { t.title = title; renderStrip(); }
            }
        });

        w.setDownloadListener(new DownloadListener() {
            @Override public void onDownloadStart(String url, String ua, String cd, String mime, long size) {
                if (url != null && url.startsWith("http://")) {
                    toast("Download blocked — not encrypted");
                    return;
                }
                try {
                    String name = URLUtil.guessFileName(url, cd, mime);
                    DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
                    r.setMimeType(mime);
                    r.addRequestHeader("User-Agent", ua);
                    r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
                    DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
                    if (dm != null) dm.enqueue(r);
                    toast("Downloading " + name);
                } catch (Exception e) { toast("Download failed"); }
            }
        });
        return w;
    }

    private Tab tabOf(WebView w) {
        for (Tab t : tabs) if (t.web == w) return t;
        return null;
    }

    private void select(Tab t) {
        active = t;
        for (Tab x : tabs) x.web.setVisibility(x == t ? View.VISIBLE : View.GONE);
        urlBar.setText(t.url);
        updateNav();
        renderStrip();
    }

    private void closeTab(Tab t) {
        boolean wasPrivate = t.incognito;
        container.removeView(t.web);
        t.web.clearHistory();
        t.web.destroy();
        if (wasPrivate) {
            CookieManager.getInstance().removeAllCookies(null);
            CookieManager.getInstance().flush();
        }
        tabs.remove(t);
        if (tabs.isEmpty()) { newTab(HOME); return; }
        if (t == active) select(tabs.get(tabs.size() - 1));
        else renderStrip();
    }

    private void renderStrip() {
        strip.removeAllViews();
        for (final Tab t : tabs) {
            LinearLayout chip = new LinearLayout(this);
            chip.setOrientation(LinearLayout.HORIZONTAL);
            chip.setGravity(Gravity.CENTER_VERTICAL);
            chip.setPadding(dp(10), dp(6), dp(6), dp(6));
            chip.setBackgroundColor(t == active ? Color.parseColor("#232830") : Color.parseColor("#15181e"));

            TextView label = new TextView(this);
            String title = t.title == null ? "New tab" : t.title;
            if (title.length() > 16) title = title.substring(0, 16) + "…";
            label.setText(title);
            label.setTextSize(11);
            label.setTextColor(t == active ? Color.parseColor("#eceef1") : Color.parseColor("#98a1ac"));
            label.setSingleLine(true);
            chip.addView(label);

            TextView x = new TextView(this);
            x.setText("  ✕");
            x.setTextSize(11);
            x.setTextColor(Color.parseColor("#68717c"));
            x.setPadding(dp(6), 0, dp(2), 0);
            x.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { closeTab(t); }
            });
            chip.addView(x);

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, 0, dp(5), 0);
            chip.setLayoutParams(lp);
            chip.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { select(t); }
            });
            strip.addView(chip);
            t.chip = chip;
        }
        tabCount.setText(tabs.size() + (blockedCount > 0 ? " · \u26E8 " + blockedCount : ""));
        stripScroll.post(new Runnable() {
            @Override public void run() { stripScroll.fullScroll(View.FOCUS_RIGHT); }
        });
    }

    /* =========================================================
       navigation
    ========================================================= */
    private boolean looksLikeUrl(String s) {
        if (s.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*")) return true;
        if (s.matches("^localhost(:\\d+)?(/.*)?$")) return true;
        return s.matches("^[^\\s]+\\.[a-zA-Z]{2,}([/?#].*)?$");
    }

    private void go(String input) {
        String s = input == null ? "" : input.trim();
        if (s.isEmpty() || active == null) return;
        hideSuggestions();
        if (looksLikeUrl(s)) {
            String url = s.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*") ? s
                    : (s.startsWith("localhost") ? "http://" + s : "https://" + s);
            active.web.loadUrl(url);
        } else {
            active.web.loadUrl(searchUrl(s));
        }
        hideKeyboard();
    }


    /* =========================================================
       search engine chooser (Mercy + the usual suspects)
    ========================================================= */
    private static final String[] ENGINE_IDS = {"mercy", "ddg", "brave", "bing", "startpage", "ecosia", "google"};

    private String engineLabel(String id) {
        switch (id) {
            case "mercy": return "Mercy — own index";
            case "brave": return "Brave Search";
            case "bing": return "Bing";
            case "startpage": return "Startpage";
            case "ecosia": return "Ecosia";
            case "google": return "Google";
            default: return "DuckDuckGo";
        }
    }

    private String engineLetter(String id) {
        switch (id) {
            case "mercy": return "M";
            case "brave": return "B";
            case "bing": return "b";
            case "startpage": return "S";
            case "ecosia": return "E";
            case "google": return "G";
            default: return "D";
        }
    }

    private String engineColor(String id) {
        switch (id) {
            case "mercy": return "#e08a3c";
            case "brave": return "#fb542b";
            case "bing": return "#00a4ef";
            case "startpage": return "#6b7f8f";
            case "ecosia": return "#2f9e5f";
            case "google": return "#4285f4";
            default: return "#de5833";
        }
    }

    private String currentEngine() {
        String id = prefs.getString("engine", "ddg");
        for (String e : ENGINE_IDS) if (e.equals(id)) return id;
        return "ddg";
    }

    private void paintEngine() {
        String id = currentEngine();
        engineBtn.setText(engineLetter(id) + " \u25BE");
        try { engineBtn.setTextColor(android.graphics.Color.parseColor(engineColor(id))); }
        catch (Exception ignored) { }
    }

    private void showEnginePicker() {
        final String[] labels = new String[ENGINE_IDS.length];
        String cur = currentEngine();
        int checked = 0;
        for (int i = 0; i < ENGINE_IDS.length; i++) {
            labels[i] = engineLabel(ENGINE_IDS[i]);
            if (ENGINE_IDS[i].equals(cur)) checked = i;
        }
        new android.app.AlertDialog.Builder(this)
                .setTitle("Search engine")
                .setSingleChoiceItems(labels, checked, new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int which) {
                        prefs.edit().putString("engine", ENGINE_IDS[which]).apply();
                        paintEngine();
                        d.dismiss();
                        if (ENGINE_IDS[which].equals("mercy") && prefs.getString("mercyUrl", "").isEmpty()) {
                            askMercyUrl();
                        }
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void askMercyUrl() {
        final android.widget.EditText input = new android.widget.EditText(this);
        input.setHint("https://your-search.onrender.com/search");
        input.setText(prefs.getString("mercyUrl", ""));
        input.setTextSize(13);
        new android.app.AlertDialog.Builder(this)
                .setTitle("Mercy engine URL")
                .setMessage("Apne search server ka /search endpoint daalo. Khali chhodo to DuckDuckGo use hoga.")
                .setView(input)
                .setPositiveButton("Save", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int w) {
                        prefs.edit().putString("mercyUrl", input.getText().toString().trim()).apply();
                        toast("Saved");
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private String searchUrl(String q) {
        String enc = android.net.Uri.encode(q);
        String id = currentEngine();
        switch (id) {
            case "mercy": {
                String base = prefs.getString("mercyUrl", "").trim();
                if (base.isEmpty()) {
                    toast("Mercy engine URL set nahi hai — DuckDuckGo use ho raha hai");
                    return "https://duckduckgo.com/?q=" + enc;
                }
                return base + (base.contains("?") ? "&q=" : "?q=") + enc;
            }
            case "brave": return "https://search.brave.com/search?q=" + enc;
            case "bing": return "https://www.bing.com/search?q=" + enc;
            case "startpage": return "https://www.startpage.com/sp/search?query=" + enc;
            case "ecosia": return "https://www.ecosia.org/search?q=" + enc;
            case "google": return "https://www.google.com/search?q=" + enc;
            default: return "https://duckduckgo.com/?q=" + enc;
        }
    }

    private void updateNav() {
        boolean canBack = active != null && active.web.canGoBack();
        boolean canFwd = active != null && active.web.canGoForward();
        btnBack.setEnabled(canBack); btnBack.setAlpha(canBack ? 1f : 0.3f);
        btnFwd.setEnabled(canFwd); btnFwd.setAlpha(canFwd ? 1f : 0.3f);
    }

    /* =========================================================
       suggestions (DuckDuckGo autocomplete, no key, no account)
    ========================================================= */
    private void queueSuggestions(final String q) {
        if (suggestJob != null) ui.removeCallbacks(suggestJob);
        if (q == null || q.trim().length() < 2) { hideSuggestions(); return; }
        suggestJob = new Runnable() {
            @Override public void run() { fetchSuggestions(q.trim()); }
        };
        ui.postDelayed(suggestJob, 220);
    }

    private void fetchSuggestions(final String q) {
        new Thread(new Runnable() {
            @Override public void run() {
                final List<String> out = new ArrayList<>();
                HttpURLConnection c = null;
                try {
                    String url = "https://duckduckgo.com/ac/?q=" + URLEncoder.encode(q, "UTF-8") + "&type=list";
                    c = (HttpURLConnection) new URL(url).openConnection();
                    c.setRequestProperty("User-Agent", "MercyGX/1.0");
                    c.setConnectTimeout(6000);
                    c.setReadTimeout(6000);
                    if (c.getResponseCode() == 200) {
                        BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"));
                        StringBuilder sb = new StringBuilder();
                        String line;
                        while ((line = r.readLine()) != null) sb.append(line);
                        r.close();
                        JSONArray arr = new JSONArray(sb.toString());
                        for (int i = 1; i < arr.length() && out.size() < 6; i++) {
                            out.add(arr.getString(i));
                        }
                    }
                } catch (Exception ignored) {
                } finally {
                    if (c != null) c.disconnect();
                }
                ui.post(new Runnable() {
                    @Override public void run() { showSuggestions(out); }
                });
            }
        }).start();
    }

    private void showSuggestions(List<String> items) {
        suggestPanel.removeAllViews();
        if (items.isEmpty()) { hideSuggestions(); return; }
        for (final String s : items) {
            TextView row = new TextView(this);
            row.setText(s);
            row.setTextSize(14);
            row.setTextColor(Color.parseColor("#eceef1"));
            row.setPadding(dp(16), dp(12), dp(16), dp(12));
            row.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    urlBar.setText(s);
                    urlBar.setSelection(s.length());
                    hideSuggestions();
                    go(s);
                }
            });
            suggestPanel.addView(row);
        }
        suggestPanel.setVisibility(View.VISIBLE);
    }

    private void hideSuggestions() {
        suggestPanel.setVisibility(View.GONE);
        suggestPanel.removeAllViews();
    }

    /* =========================================================
       history / bookmarks
    ========================================================= */
    private JSONArray readArray(String key) {
        try { return new JSONArray(prefs.getString(key, "[]")); }
        catch (Exception e) { return new JSONArray(); }
    }

    private void addHistory(String url, String title) {
        if (url == null || url.equals("about:blank") || url.startsWith("file://")) return;
        try {
            JSONArray arr = readArray("history");
            JSONArray out = new JSONArray();
            JSONObject o = new JSONObject();
            o.put("url", url);
            o.put("title", title == null ? url : title);
            out.put(o);
            for (int i = 0; i < arr.length() && i < 199; i++) {
                JSONObject old = arr.getJSONObject(i);
                if (!url.equals(old.optString("url"))) out.put(old);
            }
            prefs.edit().putString("history", out.toString()).apply();
        } catch (Exception ignored) { }
    }

    private void toggleBookmark() {
        if (active == null) return;
        try {
            JSONArray arr = readArray("bookmarks");
            for (int i = 0; i < arr.length(); i++) {
                if (active.url.equals(arr.getJSONObject(i).optString("url"))) {
                    toast("Already bookmarked");
                    return;
                }
            }
            JSONObject o = new JSONObject();
            o.put("url", active.url);
            o.put("title", active.title);
            arr.put(o);
            prefs.edit().putString("bookmarks", arr.toString()).apply();
            toast("Bookmarked");
        } catch (Exception e) { toast("Bookmark failed"); }
    }


    private void showSiteInfo() {
        String url = active == null ? "" : active.url;
        boolean https = url.startsWith("https://");
        boolean plain = url.startsWith("http://");
        String level = secLevel().toUpperCase();

        String security = https ? "\uD83D\uDD12 HTTPS — this page is encrypted"
                : plain ? "\u26A0 Not encrypted — HTTPS-only is upgrading it"
                : "Internal page";

        String msg = security
                + "\n\nAddress\n" + url
                + "\n\nSecurity level: " + level
                + (active != null && active.incognito ? "\nThis tab: INCOGNITO — nothing is saved" : "")
                + (active != null && active.desktop ? "\nMode: desktop site" : "")
                + "\n\nBlocked in this session\n" + blockedCount + " ad & tracker requests"
                + "\n\nProtection"
                + "\n• Ad & tracker blocking: " + (adblockOn() ? "ON" : "OFF")
                + "\n• HTTPS-only: " + (httpsOnly() ? "ON" : "OFF")
                + "\n• JavaScript: " + (jsOn() ? "ON" : "OFF")
                + "\n• Third-party cookies: " + (secLevel().equals("off") ? "allowed" : "blocked")
                + "\n• Mixed content: blocked"
                + "\n• Camera / microphone: blocked"
                + "\n• Filter list: " + BLOCK.size() + " networks";

        new AlertDialog.Builder(this)
                .setTitle("Site information")
                .setMessage(msg)
                .setPositiveButton("Close", null)
                .setNeutralButton(jsOn() ? "Turn JS off" : "Turn JS on",
                        new DialogInterface.OnClickListener() {
                            @Override public void onClick(DialogInterface d, int w) {
                                prefs.edit().putBoolean("jsForceOn", !jsOn()).apply();
                                toast("JavaScript " + (jsOn() ? "on" : "off"));
                                if (active != null) active.web.reload();
                            }
                        })
                .show();
    }

    private void showList(final String key, String emptyMsg) {
        JSONArray arr = readArray(key);
        if (arr.length() == 0) { toast(emptyMsg); return; }
        final String[] urls = new String[arr.length()];
        final String[] titles = new String[arr.length()];
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            urls[i] = o == null ? "" : o.optString("url");
            titles[i] = o == null ? "" : o.optString("title");
        }
        new AlertDialog.Builder(this)
                .setTitle(key.equals("bookmarks") ? "Bookmarks" : "History")
                .setItems(titles, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) { go(urls[which]); }
                })
                .setNegativeButton("Close", null)
                .show();
    }

    /* =========================================================
       menu
    ========================================================= */
    private void showMenu() {
        String[] items = {"New tab", "New incognito tab", "Bookmark this page", "Bookmarks",
                "History", "Security level: " + secLevel().toUpperCase(),
                "Desktop site: " + (active != null && active.desktop ? "ON" : "OFF"),
                "Check for updates", "Clear browsing data", "About Mercy GX"};
        new AlertDialog.Builder(this)
                .setTitle("Mercy GX")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        switch (which) {
                            case 0: newTab(HOME); break;
                            case 1: newTab(HOME, true); break;
                            case 2: toggleBookmark(); break;
                            case 3: showList("bookmarks", "No bookmarks yet"); break;
                            case 4: showList("history", "History is empty"); break;
                            case 5: pickSecurityLevel(); break;
                            case 6: toggleDesktop(); break;
                            case 7: Updater.check(MainActivity.this, false); break;
                            case 8: clearData(); break;
                            case 9: about(); break;
                        }
                    }
                })
                .setNegativeButton("Close", null)
                .show();
    }

    private void clearData() {
        new AlertDialog.Builder(this)
                .setTitle("Clear browsing data?")
                .setMessage("History, bookmarks, cookies and cache will be removed.")
                .setPositiveButton("Clear", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        prefs.edit().clear().apply();
                        CookieManager.getInstance().removeAllCookies(null);
                        for (Tab t : tabs) { t.web.clearHistory(); t.web.clearCache(true); }
                        toast("Cleared");
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void about() {
        new AlertDialog.Builder(this)
                .setTitle("Mercy GX 1.0")
                .setMessage("A small, fast browser for Android.\n\n"
                        + "Engine: the WebView (Chromium) already on your phone.\n"
                        + "Tabs, ad-block, live search suggestions, HTTPS-only.\n"
                        + "No account, no ads, no telemetry.\n"
                        + "Everything stays on this device.")
                .setPositiveButton("OK", null)
                .show();
    }

    /* =========================================================
       helpers
    ========================================================= */
    /** "off", "on" or "pro" — one switch for the whole protection stack. */
    private String secLevel() {
        String v = prefs.getString("secLevel", "on");
        return (v.equals("off") || v.equals("on") || v.equals("pro")) ? v : "on";
    }
    private boolean adblockOn() { return !secLevel().equals("off"); }
    private boolean httpsOnly() { return !secLevel().equals("off"); }
    private boolean jsOn() { return !secLevel().equals("pro") || prefs.getBoolean("jsForceOn", false); }

    private void pickSecurityLevel() {
        final String[] levels = {"off", "on", "pro"};
        String[] labels = {
                "Off — no blocking at all",
                "On — ad-block, HTTPS-only, cookies isolated (recommended)",
                "Pro — everything in On, plus JavaScript off"};
        int checked = secLevel().equals("off") ? 0 : secLevel().equals("pro") ? 2 : 1;
        new AlertDialog.Builder(this)
                .setTitle("Security level")
                .setSingleChoiceItems(labels, checked, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        prefs.edit().putString("secLevel", levels[which])
                                .putBoolean("jsForceOn", false).apply();
                        d.dismiss();
                        toast("Security level: " + levels[which].toUpperCase());
                        for (Tab t : tabs) t.web.reload();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void toggleDesktop() {
        if (active == null) return;
        active.desktop = !active.desktop;
        WebSettings st = active.web.getSettings();
        if (active.desktop) {
            st.setUserAgentString("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
                    + "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36");
            st.setUseWideViewPort(true);
            st.setLoadWithOverviewMode(true);
        } else {
            st.setUserAgentString("Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 "
                    + "(KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36");
        }
        active.web.reload();
        toast("Desktop site " + (active.desktop ? "on" : "off"));
    }

    private boolean isBlocked(Uri u) {
        if (u == null || u.getHost() == null) return false;
        String host = u.getHost().toLowerCase();
        for (String h : BLOCK) {
            if (host.equals(h) || host.endsWith("." + h)) return true;
        }
        return false;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private void toast(String m) { Toast.makeText(this, m, Toast.LENGTH_SHORT).show(); }

    private void hideKeyboard() {
        InputMethodManager im = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (im != null) im.hideSoftInputFromWindow(urlBar.getWindowToken(), 0);
        urlBar.clearFocus();
    }

    /* =========================================================
       system back
    ========================================================= */
    @Override
    public void onBackPressed() {
        if (suggestPanel.getVisibility() == View.VISIBLE) { hideSuggestions(); return; }
        if (active != null && active.web.canGoBack()) { active.web.goBack(); return; }
        if (tabs.size() > 1) { closeTab(active); return; }
        if (active != null && !active.url.equals(HOME)) { active.web.loadUrl(HOME); return; }
        super.onBackPressed();
    }

    @Override protected void onPause() { super.onPause(); if (active != null) active.web.onPause(); }
    @Override protected void onResume() { super.onResume(); if (active != null) active.web.onResume(); }

    @Override
    protected void onDestroy() {
        for (Tab t : tabs) {
            container.removeView(t.web);
            t.web.destroy();
        }
        tabs.clear();
        super.onDestroy();
    }
}
