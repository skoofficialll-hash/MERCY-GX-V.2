package com.skinventor.mercygx;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.TrafficStats;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Build;
import android.os.Bundle;
import android.os.Process;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.PermissionRequest;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.SslErrorHandler;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Mercy Lite — a small, fast WebView browser: tabs, ad-block,
 * live suggestions, HTTPS-only. No third-party libraries.
 * Platform WebView only; no third-party libraries.
 */
public class MainActivity extends Activity {

    private static final String HOME = "file:///android_asset/newtab.html";
    private static final String PREFS = "mercy_gx";

    /* ---------------- ad / tracker blocklist ---------------- */
    private static final Set<String> BLOCK = new HashSet<>(Arrays.asList(
            "doubleclick.net", "googlesyndication.com", "googleadservices.com",
            "adservice.google.com", "google-analytics.com", "googletagmanager.com",
            "googletagservices.com", "scorecardresearch.com", "criteo.com",
            "criteo.net", "taboola.com", "outbrain.com", "adnxs.com",
            "quantserve.com", "moatads.com", "rubiconproject.com", "pubmatic.com",
            "openx.net", "casalemedia.com", "smartadserver.com", "yieldmo.com",
            "amazon-adsystem.com", "adsrvr.org", "bidswitch.net", "sharethrough.com",
            "hotjar.com", "segment.io", "segment.com", "amplitude.com", "mixpanel.com",
            "fullstory.com", "mouseflow.com", "clarity.ms", "branch.io", "appsflyer.com",
            "adjust.com", "kochava.com", "onesignal.com", "inmobi.com", "unityads.unity3d.com",
            "chartboost.com", "vungle.com", "applovin.com", "ironsrc.com", "supersonicads.com",
            "mopub.com", "flurry.com", "umeng.com", "bugsnag.com", "sentry-cdn.com",
            "facebook.net", "fbcdn-ads.com", "analytics.tiktok.com", "ads.tiktok.com",
            "adcolony.com", "vungle.com", "startapp.com", "tapjoy.com", "smaato.net",
            "fyber.com", "digitalturbine.com", "adform.net", "teads.tv", "loopme.me",
            "ogury.com", "sizmek.com", "adsafeprotected.com", "doubleverify.com",
            "adloox.com", "comscore.com", "quantcast.com", "nielsen.com", "chartbeat.com",
            "parsely.com", "newrelic.com", "bugsnag.com", "mparticle.com", "tealiumiq.com",
            "heapanalytics.com", "kissmetrics.com", "crazyegg.com", "clicktale.net",
            "luckyorange.com", "inspectlet.com", "smartlook.com", "logrocket.com",
            "braze.com", "iterable.com", "leanplum.com", "clevertap.com", "moengage.com",
            "webengage.com", "singular.net", "appmetrica.yandex.com", "mc.yandex.ru",
            "an.yandex.ru", "talkingdata.com", "pubnub.com", "gumgum.com",
            "indexexchange.com", "33across.com", "triplelift.com", "sovrn.com",
            "adroll.com", "revcontent.com", "mgid.com", "zergnet.com", "plista.com",
            "ligatus.com", "thetradedesk.com", "mediamath.com", "advertising.com",
            "yieldlab.net", "emxdgt.com", "district-m.net", "spotxchange.com",
            "tremorhub.com", "conversantmedia.com", "zedo.com", "exponential.com",
            "undertone.com", "serving-sys.com", "flashtalking.com", "innovid.com",
            "extremereach.com", "yieldmanager.com", "2mdn.net", "everesttech.net",
            "demdex.net", "omtrdc.net", "krxd.net", "bluekai.com", "exelator.com",
            "rlcdn.com", "agkn.com", "mathtag.com", "turn.com", "tapad.com",
            "adsymptotic.com", "crwdcntrl.net", "narrative.io", "liveramp.com",
            "ads.linkedin.com", "analytics.twitter.com", "static.ads-twitter.com",
            "sc-static.net", "snapchat.com", "tr.snapchat.com", "ads.pinterest.com",
            "ct.pinterest.com", "analytics.tiktok.com", "business-api.tiktok.com",
            "adsrvr.org"
    ));

    /* ---------------- state ---------------- */
    private final List<Tab> tabs = new ArrayList<>();
    private Tab active;
    private int tabSeq = 1;
    private SharedPreferences prefs;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private Runnable suggestJob;
    private long blockedCount = 0;
    private android.speech.tts.TextToSpeech tts;
    private boolean ttsReady = false;
    /* data ledger: per-page bytes, time and trackers, per host */
    private long rxAtPageStart = -1;
    private long pageStartMs = 0;
    private final java.util.Set<String> pageTrackers =
            java.util.Collections.newSetFromMap(new java.util.concurrent.ConcurrentHashMap<String, Boolean>());
    /* every host this page talked to: name -> {requests, blocked} */
    private final java.util.Map<String, int[]> pageHosts =
            new java.util.concurrent.ConcurrentHashMap<>();

    /* ---------------- views ---------------- */
    private FrameLayout container;
    private LinearLayout strip;
    private HorizontalScrollView stripScroll;
    private WebView chromeWeb;
    private String pendingQuery = "";
    private ProgressBar progress;
    private androidx.swiperefreshlayout.widget.SwipeRefreshLayout swipe;
    private TextView tabCount;

    private static class Tab {
        String id;
        WebView web;
        String url = HOME;
        String title = "New tab";
        View chip;
        boolean incognito = false;
        boolean desktop = false;
    }

    /* =========================================================
       lifecycle
    ========================================================= */
    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        container = findViewById(R.id.container);
        strip = findViewById(R.id.tabstrip);
        stripScroll = findViewById(R.id.tabscroll);
        chromeWeb = findViewById(R.id.chrome);
        progress = findViewById(R.id.progress);
        swipe = findViewById(R.id.swipe);
        swipe.setColorSchemeColors(android.graphics.Color.parseColor("#4f8cff"));
        swipe.setOnRefreshListener(new androidx.swiperefreshlayout.widget.SwipeRefreshLayout.OnRefreshListener() {
            @Override public void onRefresh() {
                if (active != null) active.web.reload();
                else swipe.setRefreshing(false);
            }
        });
        tabCount = findViewById(R.id.tabCount);
        tabCount.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showSiteInfo(); }
        });
        tabCount.setOnLongClickListener(new View.OnLongClickListener() {
            @Override public boolean onLongClick(View v) { openSiteRules(); return true; }
        });

        if (Build.VERSION.SDK_INT <= 28
                && checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, 100);
        }

        wireToolbar();
        paintEngine();

        Uri incoming = getIntent() == null ? null : getIntent().getData();
        String scheme = incoming == null || incoming.getScheme() == null ? "" : incoming.getScheme();
        if (scheme.equals("http") || scheme.equals("https")) {
            newTab(incoming.toString());   // opened from a link in another app
        } else {
            newTab(HOME);
        }

        tts = new android.speech.tts.TextToSpeech(this,
                new android.speech.tts.TextToSpeech.OnInitListener() {
                    @Override public void onInit(int status) {
                        ttsReady = status == android.speech.tts.TextToSpeech.SUCCESS;
                    }
                });

        Updater.autoCheck(this);
    }

    private void wireToolbar() {
        findViewById(R.id.btnHome).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { newTab(HOME); }
        });
        findViewById(R.id.btnNewTab).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { newTab(HOME); }
        });
        findViewById(R.id.btnMenu).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showMenu(); }
        });
        wireChrome();
    }

    /* ---------------- voice search ---------------- */
    private String voiceLang() { return prefs.getString("voiceLang", "hi-IN"); }

    private void startVoiceSearch() {
        try {
            Intent i = new Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE, voiceLang());
            i.putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, voiceLang());
            i.putExtra(android.speech.RecognizerIntent.EXTRA_PROMPT,
                    voiceLang().startsWith("hi") ? "\u0939\u093F\u0902\u0926\u0940 \u092E\u0947\u0902 \u092C\u094B\u0932\u093F\u090F"
                            : "Speak your search");
            startActivityForResult(i, 101);
        } catch (Exception e) {
            toast("No voice input app found");
        }
    }

    /* ---------------- read aloud ---------------- */
    private void readAloud() {
        if (active == null) return;
        if (!ttsReady) { toast("Speech engine not ready yet"); return; }
        active.web.evaluateJavascript("(function(){try{return document.body.innerText||''}catch(e){return ''}})()",
                new android.webkit.ValueCallback<String>() {
                    @Override public void onReceiveValue(String value) {
                        String text = "";
                        try {
                            text = value == null ? "" : value;
                            if (text.startsWith("\"")) {
                                text = new org.json.JSONArray("[" + text + "]").getString(0);
                            }
                        } catch (Exception e) { text = ""; }
                        text = text.replaceAll("\\s+", " ").trim();
                        if (text.length() < 40) { toast("Nothing to read on this page"); return; }

                        boolean hindi = text.matches(".*[\\u0900-\\u097F].*");
                        java.util.Locale loc = hindi ? new java.util.Locale("hi", "IN")
                                : new java.util.Locale("en", "IN");
                        int res = tts.setLanguage(loc);
                        if (res == android.speech.tts.TextToSpeech.LANG_MISSING_DATA
                                || res == android.speech.tts.TextToSpeech.LANG_NOT_SUPPORTED) {
                            tts.setLanguage(java.util.Locale.US);
                        }
                        tts.stop();
                        int chunk = 2800;
                        for (int i = 0; i < text.length(); i += chunk) {
                            String part = text.substring(i, Math.min(text.length(), i + chunk));
                            tts.speak(part, android.speech.tts.TextToSpeech.QUEUE_ADD, null, "mercy" + i);
                        }
                        toast(hindi ? "\u0939\u093F\u0902\u0926\u0940 \u092E\u0947\u0902 \u092A\u0922\u093C \u0930\u0939\u093E \u0939\u0948" : "Reading aloud");
                    }
                });
    }

    private void stopReading() {
        try { if (tts != null) tts.stop(); } catch (Exception ignored) { }
        toast("Stopped");
    }

    private void toggleVoiceLang() {
        String now = voiceLang().startsWith("hi") ? "en-IN" : "hi-IN";
        prefs.edit().putString("voiceLang", now).apply();
        toast("Voice: " + (now.startsWith("hi") ? "Hindi" : "English"));
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == 101 && res == RESULT_OK && data != null) {
            java.util.ArrayList<String> r = data.getStringArrayListExtra(
                    android.speech.RecognizerIntent.EXTRA_RESULTS);
            if (r != null && !r.isEmpty()) {
                String q = r.get(0);
                setChromeQuery(q);
                go(q);
            }
        }
    }

    /* =========================================================
       tabs
    ========================================================= */
    private void newTab(String url) { newTab(url, false); }

    private void newTab(String url, boolean incognito) {
        final Tab t = new Tab();
        t.id = "t" + (tabSeq++);
        t.incognito = incognito;
        t.title = incognito ? "Incognito" : "New tab";
        t.web = buildWebView(t);
        t.url = url;
        container.addView(t.web, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        tabs.add(t);
        select(t);
        t.web.loadUrl(url);
    }

    private WebView buildWebView(final Tab tab) {
        WebView w = new WebView(this);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(jsOn());
        s.setDomStorageEnabled(!tab.incognito);
        s.setDatabaseEnabled(!tab.incognito);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        // hardening
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setSaveFormData(false);
        s.setGeolocationEnabled(false);
        s.setSupportMultipleWindows(false);
        if (Build.VERSION.SDK_INT >= 26) s.setSafeBrowsingEnabled(true);
        if (prefs.getBoolean("noImages", false)) s.setBlockNetworkImage(true);
        if (tab.incognito) s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        if (tab.desktop) {
            s.setUserAgentString("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
                    + "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36");
            s.setUseWideViewPort(true);
            s.setLoadWithOverviewMode(true);
        }
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        // Plain mobile Chrome UA: no "wv" token, no app name. Without this, Google
        // shows "This browser or app may not be secure" and blocks sign-in.
        s.setUserAgentString("Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 "
                + "(KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36");
        if (Build.VERSION.SDK_INT >= 26) s.setSafeBrowsingEnabled(true);

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, false);

        w.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri u = req.getUrl();
                String scheme = u.getScheme() == null ? "" : u.getScheme();
                if (scheme.equals("http")) {
                    if (httpsOnly()) {
                        view.loadUrl(u.toString().replaceFirst("^http://", "https://"));
                        toast("Upgraded to HTTPS");
                        return true;
                    }
                    return false;
                }
                if (scheme.equals("https") || scheme.equals("file")) return false;
                if (scheme.equals("mailto") || scheme.equals("tel")) {
                    try { startActivity(new android.content.Intent(android.content.Intent.ACTION_VIEW, u)); }
                    catch (Exception ignored) { toast("No app can handle this link"); }
                    return true;
                }
                // intent://, market://, app links — a page must not launch other apps
                toast("Blocked an unsafe link (" + scheme + ")");
                return true;
            }

            /* the ad-blocker: cancel the request before it leaves the phone */
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
                String reqHost = req.getUrl() == null ? null : req.getUrl().getHost();
                boolean blocked = adblockOn() && isBlocked(req.getUrl());
                if (reqHost != null) {
                    int[] v = pageHosts.get(reqHost);
                    if (v == null) { v = new int[]{0, 0}; pageHosts.put(reqHost, v); }
                    synchronized (v) { v[0]++; if (blocked) v[1]++; }
                }
                if (blocked) {
                    blockedCount++;
                    if (req.getUrl().getHost() != null) pageTrackers.add(req.getUrl().getHost());
                    if (blockedCount % 10 == 0) runOnUiThread(new Runnable() {
                        @Override public void run() { tabCount.setText(blockedCount + " blocked"); }
                    });
                    return new WebResourceResponse("text/plain", "utf-8",
                            new ByteArrayInputStream(new byte[0]));
                }
                return null;
            }

            @Override public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                handler.cancel();
                toast("Blocked an insecure connection");
            }

            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                pageStartMs = System.currentTimeMillis();
                rxAtPageStart = rxBytes();
                pageTrackers.clear();
                pageHosts.clear();
                applySiteRules(view, url);
            }

            @Override public void onPageFinished(WebView view, String url) {
                progress.setVisibility(View.GONE);
                swipe.setRefreshing(false);
                Tab t = tabOf(view);
                if (t == null) return;
                t.url = url;
                t.title = view.getTitle() == null ? url : view.getTitle();
                if (t == active) {
                    setChromeUrl(url);
                    updateNav();
                }
                renderStrip();
                if (!t.incognito) {
                    addHistory(url, t.title);
                    recordLedger(url, System.currentTimeMillis() - pageStartMs);
                }
            }
        });

        w.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int p) {
                progress.setVisibility(p >= 100 ? View.GONE : View.VISIBLE);
                progress.setProgress(p);
            }
            @Override public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        request.deny();
                        toast("Blocked a device permission request");
                    }
                });
            }

            @Override public void onReceivedTitle(WebView view, String title) {
                Tab t = tabOf(view);
                if (t != null && title != null) { t.title = title; renderStrip(); }
            }
        });

        w.setDownloadListener(new DownloadListener() {
            @Override public void onDownloadStart(String url, String ua, String cd, String mime, long size) {
                if (url != null && url.startsWith("http://")) {
                    toast("Download blocked — not encrypted");
                    return;
                }
                try {
                    String name = URLUtil.guessFileName(url, cd, mime);
                    DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
                    r.setMimeType(mime);
                    r.addRequestHeader("User-Agent", ua);
                    r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
                    DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
                    if (dm != null) dm.enqueue(r);
                    toast("Downloading " + name);
                } catch (Exception e) { toast("Download failed"); }
            }
        });
        return w;
    }

    private Tab tabOf(WebView w) {
        for (Tab t : tabs) if (t.web == w) return t;
        return null;
    }

    private void select(Tab t) {
        active = t;
        for (Tab x : tabs) x.web.setVisibility(x == t ? View.VISIBLE : View.GONE);
        setChromeUrl(t.url);
        updateNav();
        renderStrip();
    }

    private void closeTab(Tab t) {
        boolean wasPrivate = t.incognito;
        container.removeView(t.web);
        t.web.clearHistory();
        t.web.destroy();
        if (wasPrivate) {
            CookieManager.getInstance().removeAllCookies(null);
            CookieManager.getInstance().flush();
        }
        tabs.remove(t);
        if (tabs.isEmpty()) { newTab(HOME); return; }
        if (t == active) select(tabs.get(tabs.size() - 1));
        else renderStrip();
    }

    private void renderStrip() {
        strip.removeAllViews();
        for (final Tab t : tabs) {
            LinearLayout chip = new LinearLayout(this);
            chip.setOrientation(LinearLayout.HORIZONTAL);
            chip.setGravity(Gravity.CENTER_VERTICAL);
            chip.setPadding(dp(10), dp(6), dp(6), dp(6));
            chip.setBackgroundColor(t == active ? Color.parseColor("#232830") : Color.parseColor("#15181e"));

            TextView label = new TextView(this);
            String title = t.title == null ? "New tab" : t.title;
            if (title.length() > 16) title = title.substring(0, 16) + "…";
            label.setText(title);
            label.setTextSize(11);
            label.setTextColor(t == active ? Color.parseColor("#eceef1") : Color.parseColor("#98a1ac"));
            label.setSingleLine(true);
            chip.addView(label);

            TextView x = new TextView(this);
            x.setText("  ✕");
            x.setTextSize(11);
            x.setTextColor(Color.parseColor("#68717c"));
            x.setPadding(dp(6), 0, dp(2), 0);
            x.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { closeTab(t); }
            });
            chip.addView(x);

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, 0, dp(5), 0);
            chip.setLayoutParams(lp);
            chip.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { select(t); }
            });
            strip.addView(chip);
            t.chip = chip;
        }
        tabCount.setText(tabs.size() + (blockedCount > 0 ? " · \u26E8 " + blockedCount : ""));
        stripScroll.post(new Runnable() {
            @Override public void run() { stripScroll.fullScroll(View.FOCUS_RIGHT); }
        });
    }

    /* =========================================================
       navigation
    ========================================================= */
    private boolean looksLikeUrl(String s) {
        if (s.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*")) return true;
        if (s.matches("^localhost(:\\d+)?(/.*)?$")) return true;
        return s.matches("^[^\\s]+\\.[a-zA-Z]{2,}([/?#].*)?$");
    }

    private void go(String input) {
        String s = input == null ? "" : input.trim();
        if (s.isEmpty() || active == null) return;
        pendingQuery = s;
        if (looksLikeUrl(s)) {
            String url = s.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*") ? s
                    : (s.startsWith("localhost") ? "http://" + s : "https://" + s);
            active.web.loadUrl(url);
        } else {
            active.web.loadUrl(searchUrl(s));
        }
        hideKeyboard();
    }


    /* =========================================================
       search engine chooser (Mercy + the usual suspects)
    ========================================================= */
    private static final String[] ENGINE_IDS =
            {"mercy", "google", "ddg", "brave", "ecosia", "startpage", "bing", "yahoo"};

    private String engineLabel(String id) {
        switch (id) {
            case "mercy": return "Mercy (own index)";
            case "brave": return "Brave Search";
            case "bing": return "Bing";
            case "startpage": return "Startpage";
            case "ecosia": return "Ecosia";
            case "google": return "Google";
            case "yahoo": return "Yahoo";
            default: return "DuckDuckGo";
        }
    }

    private String engineLetter(String id) {
        switch (id) {
            case "mercy": return "M";
            case "brave": return "B";
            case "bing": return "b";
            case "startpage": return "S";
            case "ecosia": return "E";
            case "google": return "G";
            default: return "D";
        }
    }

    private String engineColor(String id) {
        switch (id) {
            case "mercy": return "#e08a3c";
            case "brave": return "#fb542b";
            case "bing": return "#00a4ef";
            case "startpage": return "#6b7f8f";
            case "ecosia": return "#2f9e5f";
            case "google": return "#4285f4";
            case "yahoo": return "#6001d2";
            default: return "#de5833";
        }
    }

    private String currentEngine() {
        String id = prefs.getString("engine", "ddg");
        for (String e : ENGINE_IDS) if (e.equals(id)) return id;
        return "ddg";
    }

    private void paintEngine() {
        pushChromeConfig();
    }

    private void showEnginePicker() {
        final String[] labels = new String[ENGINE_IDS.length];
        String cur = currentEngine();
        int checked = 0;
        for (int i = 0; i < ENGINE_IDS.length; i++) {
            labels[i] = engineLabel(ENGINE_IDS[i]);
            if (ENGINE_IDS[i].equals(cur)) checked = i;
        }
        new android.app.AlertDialog.Builder(this)
                .setTitle("Search engine")
                .setSingleChoiceItems(labels, checked, new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int which) {
                        prefs.edit().putString("engine", ENGINE_IDS[which]).apply();
                        paintEngine();
                        d.dismiss();
                        if (ENGINE_IDS[which].equals("mercy") && prefs.getString("mercyUrl", "").isEmpty()) {
                            askMercyUrl();
                        }
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void askMercyUrl() {
        final android.widget.EditText input = new android.widget.EditText(this);
        input.setHint("https://your-search.onrender.com/search");
        input.setText(prefs.getString("mercyUrl", ""));
        input.setTextSize(13);
        new android.app.AlertDialog.Builder(this)
                .setTitle("Mercy engine URL")
                .setMessage("Apne search server ka /search endpoint daalo. Khali chhodo to DuckDuckGo use hoga.")
                .setView(input)
                .setPositiveButton("Save", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int w) {
                        prefs.edit().putString("mercyUrl", input.getText().toString().trim()).apply();
                        toast("Saved");
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private String searchUrl(String q) {
        String enc = android.net.Uri.encode(q);
        String id = currentEngine();
        switch (id) {
            case "mercy": {
                String base = prefs.getString("mercyUrl", "").trim();
                if (base.isEmpty()) {
                    toast("Mercy engine URL set nahi hai — DuckDuckGo use ho raha hai");
                    return "https://duckduckgo.com/?q=" + enc;
                }
                return base + (base.contains("?") ? "&q=" : "?q=") + enc;
            }
            case "brave": return "https://search.brave.com/search?q=" + enc;
            case "bing": return "https://www.bing.com/search?q=" + enc;
            case "startpage": return "https://www.startpage.com/sp/search?query=" + enc;
            case "ecosia": return "https://www.ecosia.org/search?q=" + enc;
            case "google": return "https://www.google.com/search?q=" + enc;
            case "yahoo": return "https://search.yahoo.com/search?p=" + enc;
            default: return "https://duckduckgo.com/?q=" + enc;
        }
    }

    private void goForward() {
        if (active != null && active.web.canGoForward()) active.web.goForward();
        else toast("Nothing to go forward to");
    }

    private void updateNav() {
        // no arrow in the header any more; the system back button drives navigation
    }

    /* =========================================================
       the header is the HTML chrome — native talks to it over a bridge
    ========================================================= */
    private void wireChrome() {
        WebSettings st = chromeWeb.getSettings();
        st.setJavaScriptEnabled(true);
        st.setDomStorageEnabled(true);
        chromeWeb.setBackgroundColor(android.graphics.Color.TRANSPARENT);
        chromeWeb.setVerticalScrollBarEnabled(false);
        chromeWeb.setHorizontalScrollBarEnabled(false);
        chromeWeb.setOverScrollMode(View.OVER_SCROLL_NEVER);
        chromeWeb.addJavascriptInterface(new Bridge(), "MercyNative");
        chromeWeb.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView v, String url) { pushChromeConfig(); }
        });
        chromeWeb.loadUrl("file:///android_asset/chrome.html");
    }

    public class Bridge {
        @JavascriptInterface public void search(final String url) {
            runOnUiThread(new Runnable() { @Override public void run() { loadFromChrome(url); } });
        }
        @JavascriptInterface public void voice() {
            runOnUiThread(new Runnable() { @Override public void run() { startVoiceSearch(); } });
        }
        @JavascriptInterface public void scan() {
            runOnUiThread(new Runnable() { @Override public void run() {
                toast("QR scanning is in Mercy Pro");
            }});
        }
        @JavascriptInterface public void setEngine(final String id) {
            prefs.edit().putString("engine", id).apply();
        }
        @JavascriptInterface public void expand(final boolean open) {
            runOnUiThread(new Runnable() { @Override public void run() { setChromeHeight(open); } });
        }
        @JavascriptInterface public void height(final float cssPx) {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    View v = findViewById(R.id.chrome);
                    android.view.ViewGroup.LayoutParams lp = v.getLayoutParams();
                    int px = Math.max(dp(48), Math.round(cssPx * getResources().getDisplayMetrics().density));
                    if (lp.height != px) { lp.height = px; v.setLayoutParams(lp); }
                }
            });
        }
        @JavascriptInterface public void ready() {
            runOnUiThread(new Runnable() { @Override public void run() { pushChromeConfig(); } });
        }
    }

    private void setChromeHeight(boolean open) {
        View v = findViewById(R.id.chrome);
        android.view.ViewGroup.LayoutParams lp = v.getLayoutParams();
        lp.height = dp(open ? 300 : 60);
        v.setLayoutParams(lp);
    }

    private void pushChromeConfig() {
        try {
            org.json.JSONObject cfg = new org.json.JSONObject();
            cfg.put("engine", currentEngine());
            cfg.put("mercyUrl", prefs.getString("mercyUrl", ""));
            chromeWeb.evaluateJavascript("Mercy.init(" + cfg.toString() + ");", null);
            if (active != null) setChromeUrl(active.url);
        } catch (Exception ignored) { }
    }

    private void setChromeUrl(String url) {
        try {
            chromeWeb.evaluateJavascript("Mercy.setUrl(" + org.json.JSONObject.quote(url) + ");", null);
        } catch (Exception ignored) { }
    }

    private void setChromeQuery(String text) {
        try {
            chromeWeb.evaluateJavascript("Mercy.setQuery(" + org.json.JSONObject.quote(text) + ");", null);
        } catch (Exception ignored) { }
    }

    private void loadFromChrome(String url) {
        if (active == null) return;
        hideKeyboard();
        active.web.loadUrl(url);
    }

    /* =========================================================
       history / bookmarks
    ========================================================= */
    private JSONArray readArray(String key) {
        try { return new JSONArray(prefs.getString(key, "[]")); }
        catch (Exception e) { return new JSONArray(); }
    }

    private void addHistory(String url, String title) {
        if (url == null || url.equals("about:blank") || url.startsWith("file://")) return;
        try {
            JSONArray arr = readArray("history");
            JSONArray out = new JSONArray();
            JSONObject o = new JSONObject();
            o.put("url", url);
            o.put("title", title == null ? url : title);
            out.put(o);
            for (int i = 0; i < arr.length() && i < 199; i++) {
                JSONObject old = arr.getJSONObject(i);
                if (!url.equals(old.optString("url"))) out.put(old);
            }
            prefs.edit().putString("history", out.toString()).apply();
        } catch (Exception ignored) { }
    }

    private void toggleBookmark() {
        if (active == null) return;
        try {
            JSONArray arr = readArray("bookmarks");
            for (int i = 0; i < arr.length(); i++) {
                if (active.url.equals(arr.getJSONObject(i).optString("url"))) {
                    toast("Already bookmarked");
                    return;
                }
            }
            JSONObject o = new JSONObject();
            o.put("url", active.url);
            o.put("title", active.title);
            arr.put(o);
            prefs.edit().putString("bookmarks", arr.toString()).apply();
            toast("Bookmarked");
        } catch (Exception e) { toast("Bookmark failed"); }
    }



    /* ---------------- image search ---------------- */
    /** Images tab of whichever engine is selected. */
    private String imageSearchUrl(String q) {
        String enc = Uri.encode(q == null ? "" : q);
        switch (currentEngine()) {
            case "google": return "https://www.google.com/search?tbm=isch&q=" + enc;
            case "brave":  return "https://search.brave.com/images?q=" + enc;
            case "bing":   return "https://www.bing.com/images/search?q=" + enc;
            case "yahoo":  return "https://images.search.yahoo.com/search/images?p=" + enc;
            case "ecosia": return "https://www.ecosia.org/images?q=" + enc;
            case "startpage": return "https://www.startpage.com/sp/search?query=" + enc + "&cat=images";
            case "mercy": {
                String base = prefs.getString("mercyUrl", "").trim();
                if (!base.isEmpty()) return base + (base.contains("?") ? "&q=" : "?q=") + enc;
                return "https://duckduckgo.com/?q=" + enc + "&iax=images&ia=images";
            }
            default: return "https://duckduckgo.com/?q=" + enc + "&iax=images&ia=images";
        }
    }

    /** Reverse image search: opens the engine's visual-search page, where the
     *  user can upload a photo or point the camera. No API key needed. */
    private String visualSearchUrl() {
        switch (currentEngine()) {
            case "google": return "https://lens.google.com/";
            case "bing":   return "https://www.bing.com/visualsearch";
            case "yahoo":  return "https://images.search.yahoo.com/";
            default:       return "https://lens.google.com/";
        }
    }

    private void openImageSearch() {
        if (active == null) return;
        String q = pendingQuery;
        String url = imageSearchUrl(q);
        setChromeUrl(url);
        active.web.loadUrl(url);
    }

    private void openVisualSearch() {
        if (active == null) return;
        String url = visualSearchUrl();
        setChromeUrl(url);
        active.web.loadUrl(url);
    }


    /* =========================================================
       data ledger — what a page actually cost you
    ========================================================= */
    private long rxBytes() {
        long v = TrafficStats.getUidRxBytes(Process.myUid());
        return v == TrafficStats.UNSUPPORTED ? -1 : v;
    }

    private double tariffPerMb() {
        try { return Double.parseDouble(prefs.getString("tariff", "0.01")); }
        catch (Exception e) { return 0.01; }
    }

    private String hostOf(String url) {
        try {
            String h = Uri.parse(url).getHost();
            if (h == null) return null;
            return h.startsWith("www.") ? h.substring(4) : h;
        } catch (Exception e) { return null; }
    }

    private void recordLedger(String url, long ms) {
        String host = hostOf(url);
        if (host == null) return;
        long bytes = 0;
        if (rxAtPageStart > 0) {
            long now = rxBytes();
            if (now > rxAtPageStart) bytes = now - rxAtPageStart;
        }
        try {
            org.json.JSONObject all = new org.json.JSONObject(prefs.getString("ledger", "{}"));
            org.json.JSONObject row = all.optJSONObject(host);
            if (row == null) row = new org.json.JSONObject();
            row.put("bytes", row.optLong("bytes") + Math.max(0, bytes));
            row.put("ms", row.optLong("ms") + Math.max(0, ms));
            row.put("visits", row.optLong("visits") + 1);
            row.put("trackers", row.optLong("trackers") + pageTrackers.size());
            all.put(host, row);
            prefs.edit().putString("ledger", all.toString()).apply();
        } catch (Exception ignored) { }
    }

    private org.json.JSONObject ledgerRow(String host) {
        try {
            org.json.JSONObject all = new org.json.JSONObject(prefs.getString("ledger", "{}"));
            return all.optJSONObject(host);
        } catch (Exception e) { return null; }
    }

    private String human(long b) {
        if (b < 1024) return b + " B";
        if (b < 1024 * 1024) return String.format("%.0f KB", b / 1024.0);
        if (b < 1024L * 1024 * 1024) return String.format("%.1f MB", b / 1048576.0);
        return String.format("%.2f GB", b / 1073741824.0);
    }

    private String money(long bytes) {
        double mb = bytes / 1048576.0;
        double rupees = mb * tariffPerMb();
        if (rupees < 1) return String.format("%.0f paise", rupees * 100);
        return String.format("\u20B9%.2f", rupees);
    }

    private String humanTime(long ms) {
        long s = ms / 1000;
        if (s < 60) return s + "s";
        if (s < 3600) return (s / 60) + "m";
        return (s / 3600) + "h " + ((s % 3600) / 60) + "m";
    }



    /* =========================================================
       "what this page loaded" — every host behind the page
    ========================================================= */

    /* =========================================================
       per-site rules — remembered per host, applied on every visit
    ========================================================= */
    private org.json.JSONObject siteRule(String host) {
        if (host == null) return null;
        try {
            return new org.json.JSONObject(prefs.getString("rules", "{}")).optJSONObject(host);
        } catch (Exception e) { return null; }
    }

    private void applySiteRules(WebView view, String url) {
        String host = hostOf(url);
        if (host == null) return;
        org.json.JSONObject r = siteRule(host);
        if (r == null) return;
        WebSettings st = view.getSettings();
        if (r.has("js")) st.setJavaScriptEnabled(r.optInt("js") == 1);
        if (r.has("img")) st.setBlockNetworkImage(r.optInt("img") == 0);
        if (r.has("desk")) {
            boolean desk = r.optInt("desk") == 1;
            st.setUserAgentString(desk
                    ? "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
                    : "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36");
        }
    }


    /* =========================================================
       offline pages — a full snapshot (MHTML) on the device
    ========================================================= */
    private java.io.File offlineDir() {
        java.io.File d = new java.io.File(getFilesDir(), "offline");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    private void saveOffline() {
        if (active == null) return;
        final String url = active.url;
        final String title = active.title == null ? url : active.title;
        try {
            java.io.File f = new java.io.File(offlineDir(),
                    "page-" + System.currentTimeMillis() + ".mhtml");
            final String path = f.getAbsolutePath();
            active.web.saveWebArchive(path, false, new android.webkit.ValueCallback<String>() {
                @Override public void onReceiveValue(String value) {
                    java.io.File saved = new java.io.File(path);
                    if (!saved.exists() || saved.length() == 0) {
                        toast("Could not save this page");
                        return;
                    }
                    try {
                        org.json.JSONArray arr = new org.json.JSONArray(prefs.getString("offline", "[]"));
                        org.json.JSONObject o = new org.json.JSONObject();
                        o.put("title", title);
                        o.put("url", url);
                        o.put("path", path);
                        o.put("ts", System.currentTimeMillis());
                        o.put("size", saved.length());
                        arr.put(o);
                        prefs.edit().putString("offline", arr.toString()).apply();
                        toast("Saved offline — " + human(saved.length()));
                    } catch (Exception e) { toast("Saved, but the index failed"); }
                }
            });
        } catch (Exception e) { toast("Save failed"); }
    }

    private void showOffline() {
        try {
            final org.json.JSONArray arr = new org.json.JSONArray(prefs.getString("offline", "[]"));
            if (arr.length() == 0) { toast("No offline pages yet"); return; }

            final String[] titles = new String[arr.length()];
            final String[] paths = new String[arr.length()];
            long total = 0;
            for (int i = 0; i < arr.length(); i++) {
                org.json.JSONObject o = arr.getJSONObject(i);
                long size = o.optLong("size");
                total += size;
                titles[i] = o.optString("title") + "  \u00B7  " + human(size);
                paths[i] = o.optString("path");
            }

            new AlertDialog.Builder(this)
                    .setTitle("Offline pages  \u00B7  " + human(total))
                    .setItems(titles, new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface d, int which) {
                            newTab("file://" + paths[which]);
                        }
                    })
                    .setNeutralButton("Delete all", new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface d, int w) {
                            for (String path : paths) {
                                try { new java.io.File(path).delete(); } catch (Exception ignored) { }
                            }
                            prefs.edit().putString("offline", "[]").apply();
                            toast("Offline pages deleted");
                        }
                    })
                    .setNegativeButton("Close", null)
                    .show();
        } catch (Exception e) { toast("Offline list unavailable"); }
    }

    private void openSiteRules() {
        if (active == null) return;
        final String host = hostOf(active.url);
        if (host == null) { toast("No site to configure"); return; }
        org.json.JSONObject r = siteRule(host);

        final String[] labels = {"JavaScript", "Load images", "Desktop site", "Block trackers"};
        final boolean[] checked = {
                r == null || !r.has("js") ? jsOn() : r.optInt("js") == 1,
                r == null || !r.has("img") ? !prefs.getBoolean("noImages", false) : r.optInt("img") == 1,
                r != null && r.optInt("desk") == 1,
                r == null || !r.has("blk") ? adblockOn() : r.optInt("blk") == 1
        };

        new AlertDialog.Builder(this)
                .setTitle(host)
                .setMultiChoiceItems(labels, checked, new DialogInterface.OnMultiChoiceClickListener() {
                    @Override public void onClick(DialogInterface d, int which, boolean isChecked) {
                        checked[which] = isChecked;
                    }
                })
                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        try {
                            org.json.JSONObject all = new org.json.JSONObject(prefs.getString("rules", "{}"));
                            org.json.JSONObject row = new org.json.JSONObject();
                            row.put("js", checked[0] ? 1 : 0);
                            row.put("img", checked[1] ? 1 : 0);
                            row.put("desk", checked[2] ? 1 : 0);
                            row.put("blk", checked[3] ? 1 : 0);
                            all.put(host, row);
                            prefs.edit().putString("rules", all.toString()).apply();
                            toast("Rules saved for " + host);
                            if (active != null) active.web.reload();
                        } catch (Exception e) { toast("Could not save"); }
                    }
                })
                .setNeutralButton("Forget", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        try {
                            org.json.JSONObject all = new org.json.JSONObject(prefs.getString("rules", "{}"));
                            all.remove(host);
                            prefs.edit().putString("rules", all.toString()).apply();
                            toast("Rules cleared for " + host);
                            if (active != null) active.web.reload();
                        } catch (Exception ignored) { }
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showPageTruth() {
        if (pageHosts.isEmpty()) { toast("Open a page first"); return; }

        final java.util.List<String> hosts = new java.util.ArrayList<>(pageHosts.keySet());
        java.util.Collections.sort(hosts, new java.util.Comparator<String>() {
            @Override public int compare(String a, String b) {
                int[] va = pageHosts.get(a), vb = pageHosts.get(b);
                return Integer.compare(vb == null ? 0 : vb[0], va == null ? 0 : va[0]);
            }
        });

        String pageHost = active == null ? null : hostOf(active.url);
        int totalReq = 0, totalBlocked = 0, thirdParty = 0;
        StringBuilder sb = new StringBuilder();
        int shown = 0;
        for (String h : hosts) {
            int[] v = pageHosts.get(h);
            if (v == null) continue;
            totalReq += v[0];
            totalBlocked += v[1];
            boolean party3 = pageHost != null && !h.endsWith(pageHost) && !pageHost.endsWith(h);
            if (party3) thirdParty++;
            if (shown++ < 18) {
                sb.append(v[1] > 0 ? "\u2716 " : "\u2714 ")
                  .append(h)
                  .append("   ").append(v[0]).append(" req")
                  .append(v[1] > 0 ? "  ·  " + v[1] + " blocked" : "")
                  .append("\n");
            }
        }

        String head = (pageHost == null ? "This page" : pageHost) + "\n"
                + totalReq + " requests  ·  " + hosts.size() + " servers"
                + "  ·  " + thirdParty + " third-party\n"
                + totalBlocked + " blocked\n"
                + "————————————————\n\n";

        new AlertDialog.Builder(this)
                .setTitle("What this page loaded")
                .setMessage(head + sb.toString().trim())
                .setPositiveButton("Close", null)
                .show();
    }

    private void showReportCard() {
        try {
            org.json.JSONObject all = new org.json.JSONObject(prefs.getString("ledger", "{}"));
            if (all.length() == 0) { toast("Nothing recorded yet"); return; }
            long total = 0, totalMs = 0, totalTrackers = 0, totalVisits = 0;
            java.util.List<String> hosts = new java.util.ArrayList<>();
            for (java.util.Iterator<String> it = all.keys(); it.hasNext(); ) hosts.add(it.next());
            final java.util.Map<String, Long> bytes = new java.util.HashMap<>();
            for (String h : hosts) {
                org.json.JSONObject r = all.optJSONObject(h);
                long b = r.optLong("bytes");
                bytes.put(h, b);
                total += b;
                totalMs += r.optLong("ms");
                totalTrackers += r.optLong("trackers");
                totalVisits += r.optLong("visits");
            }
            java.util.Collections.sort(hosts, new java.util.Comparator<String>() {
                @Override public int compare(String a, String b) {
                    return Long.compare(bytes.get(b), bytes.get(a));
                }
            });

            StringBuilder sb = new StringBuilder();
            sb.append("You spent ").append(human(total)).append(" and ")
              .append(money(total)).append(" on ").append(totalVisits)
              .append(" page loads.\n")
              .append(humanTime(totalMs)).append(" of browsing, ")
              .append(totalTrackers).append(" trackers blocked.\n\n");

            int top = 0;
            for (String h : hosts) {
                if (top++ >= 5) break;
                long b = bytes.get(h);
                int pct = total > 0 ? (int) Math.round(b * 100.0 / total) : 0;
                sb.append(h).append("  ").append(pct).append("%  \u00B7  ")
                  .append(human(b)).append("\n");
            }
            if (total > 0 && !hosts.isEmpty()) {
                long first = bytes.get(hosts.get(0));
                int pct = (int) Math.round(first * 100.0 / total);
                sb.append("\n");
                if (pct >= 40) {
                    sb.append("One site is eating ").append(pct)
                      .append("% of your data. Blocking images there would save the most.");
                } else {
                    sb.append("Your data is spread out — no single site dominates.");
                }
            }

            new AlertDialog.Builder(this)
                    .setTitle("Report card")
                    .setMessage(sb.toString())
                    .setPositiveButton("Close", null)
                    .setNeutralButton("Save data mode", new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface d, int w) { toggleNoImages(); }
                    })
                    .show();
        } catch (Exception e) { toast("Report unavailable"); }
    }

    private void toggleNoImages() {
        boolean now = !prefs.getBoolean("noImages", false);
        prefs.edit().putBoolean("noImages", now).apply();
        toast("Save data mode " + (now ? "ON — images blocked" : "OFF"));
        if (active != null) active.web.reload();
    }

    private void showLedger() {
        try {
            org.json.JSONObject all = new org.json.JSONObject(prefs.getString("ledger", "{}"));
            if (all.length() == 0) { toast("No pages recorded yet"); return; }

            java.util.List<String> hosts = new java.util.ArrayList<>();
            for (java.util.Iterator<String> it = all.keys(); it.hasNext(); ) hosts.add(it.next());
            final long[] bytesArr = new long[hosts.size()];
            final String[] rows = new String[hosts.size()];
            long totalBytes = 0, totalMs = 0, totalTrackers = 0;

            java.util.List<Integer> order = new java.util.ArrayList<>();
            for (int i = 0; i < hosts.size(); i++) order.add(i);
            for (int i = 0; i < hosts.size(); i++) {
                bytesArr[i] = all.optJSONObject(hosts.get(i)).optLong("bytes");
            }
            java.util.Collections.sort(order, new java.util.Comparator<Integer>() {
                @Override public int compare(Integer a, Integer b) {
                    return Long.compare(bytesArr[b], bytesArr[a]);
                }
            });

            StringBuilder sb = new StringBuilder();
            int shown = 0;
            for (int k = 0; k < order.size(); k++) {
                int i = order.get(k);
                org.json.JSONObject row = all.optJSONObject(hosts.get(i));
                long b = row.optLong("bytes"), m = row.optLong("ms"),
                     v = row.optLong("visits"), tr = row.optLong("trackers");
                totalBytes += b; totalMs += m; totalTrackers += tr;
                if (shown < 12) {
                    sb.append(hosts.get(i)).append("\n   ")
                      .append(human(b)).append(" · ").append(money(b))
                      .append(" · ").append(humanTime(m))
                      .append(" · ").append(v).append(" visits")
                      .append(" · ").append(tr).append(" trackers\n\n");
                    shown++;
                }
            }

            String header = "Total " + human(totalBytes) + "  ·  " + money(totalBytes)
                    + "\n" + humanTime(totalMs) + " browsing  ·  " + totalTrackers
                    + " trackers blocked\n\n"
                    + "Tariff: \u20B9" + tariffPerMb() + " per MB\n"
                    + "————————————————\n\n";

            new AlertDialog.Builder(this)
                    .setTitle("Data ledger")
                    .setMessage(header + sb.toString().trim())
                    .setPositiveButton("Close", null)
                    .setNeutralButton("Set tariff", new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface d, int w) { askTariff(); }
                    })
                    .show();
        } catch (Exception e) { toast("Ledger unavailable"); }
    }

    private void askTariff() {
        final EditText input = new EditText(this);
        input.setText(String.valueOf(tariffPerMb()));
        input.setHint("rupees per MB, e.g. 0.01");
        input.setTextSize(14);
        new AlertDialog.Builder(this)
                .setTitle("Data tariff")
                .setMessage("Your plan's price per MB. \u20B910/GB = 0.01")
                .setView(input)
                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        prefs.edit().putString("tariff", input.getText().toString().trim()).apply();
                        toast("Tariff saved");
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showSiteInfo() {
        String url = active == null ? "" : active.url;
        boolean https = url.startsWith("https://");
        boolean plain = url.startsWith("http://");
        String level = secLevel().toUpperCase();

        String security = https ? "\uD83D\uDD12 HTTPS — this page is encrypted"
                : plain ? "\u26A0 Not encrypted — HTTPS-only is upgrading it"
                : "Internal page";

        String msg = security
                + "\n\nAddress\n" + url
                + "\n\nSecurity level: " + level
                + (active != null && active.incognito ? "\nThis tab: INCOGNITO — nothing is saved" : "")
                + (active != null && active.desktop ? "\nMode: desktop site" : "")
                + "\n\nThis page\n"
                + (rxAtPageStart > 0 && rxBytes() > rxAtPageStart
                        ? human(rxBytes() - rxAtPageStart) + " · " + money(rxBytes() - rxAtPageStart)
                        : "measuring…")
                + " · " + pageTrackers.size() + " trackers here"
                + "\n\nBlocked in this session\n" + blockedCount + " ad & tracker requests"
                + "\n\nProtection"
                + "\n• Ad & tracker blocking: " + (adblockOn() ? "ON" : "OFF")
                + "\n• HTTPS-only: " + (httpsOnly() ? "ON" : "OFF")
                + "\n• JavaScript: " + (jsOn() ? "ON" : "OFF")
                + "\n• Third-party cookies: " + (secLevel().equals("off") ? "allowed" : "blocked")
                + "\n• Mixed content: blocked"
                + "\n• Camera / microphone: blocked"
                + "\n• Filter list: " + BLOCK.size() + " networks";

        new AlertDialog.Builder(this)
                .setTitle("Site information")
                .setMessage(msg)
                .setPositiveButton("Close", null)
                .setNeutralButton(jsOn() ? "Turn JS off" : "Turn JS on",
                        new DialogInterface.OnClickListener() {
                            @Override public void onClick(DialogInterface d, int w) {
                                prefs.edit().putBoolean("jsForceOn", !jsOn()).apply();
                                toast("JavaScript " + (jsOn() ? "on" : "off"));
                                if (active != null) active.web.reload();
                            }
                        })
                .show();
    }

    private void showList(final String key, String emptyMsg) {
        JSONArray arr = readArray(key);
        if (arr.length() == 0) { toast(emptyMsg); return; }
        final String[] urls = new String[arr.length()];
        final String[] titles = new String[arr.length()];
        long listBytes = 0;
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            urls[i] = o == null ? "" : o.optString("url");
            titles[i] = o == null ? "" : o.optString("title");
            String host = hostOf(urls[i]);
            org.json.JSONObject row = host == null ? null : ledgerRow(host);
            if (row != null) {
                long b = row.optLong("bytes");
                if (b > 0) {
                    titles[i] = titles[i] + "  \u00B7  " + human(b) + "  \u00B7  " + money(b);
                    listBytes += b;
                }
            }
        }
        new AlertDialog.Builder(this)
                .setTitle((key.equals("bookmarks") ? "Bookmarks" : "History")
                        + (listBytes > 0 ? "  \u00B7  " + human(listBytes) + "  \u00B7  " + money(listBytes) : ""))
                .setItems(titles, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) { go(urls[which]); }
                })
                .setNegativeButton("Close", null)
                .show();
    }

    /* =========================================================
       menu
    ========================================================= */
    private void showMenu() {
        String[] items = {"New tab", "New incognito tab", "Bookmark this page", "Bookmarks",
                "History", "Image search", "Search by image", "Data ledger", "Report card",
                "Save data: " + (prefs.getBoolean("noImages", false) ? "ON" : "OFF"),
                "What this page loaded", "Save page offline", "Offline pages",
                "Security level: " + secLevel().toUpperCase(),
                "Desktop site: " + (active != null && active.desktop ? "ON" : "OFF"),
                "Read this page aloud", "Stop reading",
                "Voice language: " + (voiceLang().startsWith("hi") ? "Hindi" : "English"),
                "Check for updates", "Clear browsing data", "About Mercy GX"};
        new AlertDialog.Builder(this)
                .setTitle("Mercy GX")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        switch (which) {
                            case 0: newTab(HOME); break;
                            case 1: newTab(HOME, true); break;
                            case 2: toggleBookmark(); break;
                            case 3: showList("bookmarks", "No bookmarks yet"); break;
                            case 4: showList("history", "History is empty"); break;
                            case 5: openImageSearch(); break;
                            case 6: openVisualSearch(); break;
                            case 7: showLedger(); break;
                            case 8: showReportCard(); break;
                            case 9: toggleNoImages(); break;
                            case 10: showPageTruth(); break;
                            case 11: saveOffline(); break;
                            case 12: showOffline(); break;
                            case 13: pickSecurityLevel(); break;
                            case 14: toggleDesktop(); break;
                            case 15: readAloud(); break;
                            case 16: stopReading(); break;
                            case 17: toggleVoiceLang(); break;
                            case 18: Updater.check(MainActivity.this, false); break;
                            case 19: clearData(); break;
                            case 20: about(); break;
                        }
                    }
                })
                .setNegativeButton("Close", null)
                .show();
    }

    private void clearData() {
        new AlertDialog.Builder(this)
                .setTitle("Clear browsing data?")
                .setMessage("History, bookmarks, cookies and cache will be removed.")
                .setPositiveButton("Clear", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        prefs.edit().clear().apply();
                        CookieManager.getInstance().removeAllCookies(null);
                        for (Tab t : tabs) { t.web.clearHistory(); t.web.clearCache(true); }
                        toast("Cleared");
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void about() {
        new AlertDialog.Builder(this)
                .setTitle("Mercy GX 1.0")
                .setMessage("A small, fast browser for Android.\n\n"
                        + "Engine: the WebView (Chromium) already on your phone.\n"
                        + "Tabs, ad-block, live search suggestions, HTTPS-only.\n"
                        + "No account, no ads, no telemetry.\n"
                        + "Everything stays on this device.")
                .setPositiveButton("OK", null)
                .show();
    }

    /* =========================================================
       helpers
    ========================================================= */
    /** "off", "on" or "pro" — one switch for the whole protection stack. */
    private String secLevel() {
        String v = prefs.getString("secLevel", "on");
        return (v.equals("off") || v.equals("on") || v.equals("pro")) ? v : "on";
    }
    private boolean adblockOn() { return !secLevel().equals("off"); }
    private boolean httpsOnly() { return !secLevel().equals("off"); }
    private boolean jsOn() { return !secLevel().equals("pro") || prefs.getBoolean("jsForceOn", false); }

    private void pickSecurityLevel() {
        final String[] levels = {"off", "on", "pro"};
        String[] labels = {
                "Off — no blocking at all",
                "On — ad-block, HTTPS-only, cookies isolated (recommended)",
                "Pro — everything in On, plus JavaScript off"};
        int checked = secLevel().equals("off") ? 0 : secLevel().equals("pro") ? 2 : 1;
        new AlertDialog.Builder(this)
                .setTitle("Security level")
                .setSingleChoiceItems(labels, checked, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        prefs.edit().putString("secLevel", levels[which])
                                .putBoolean("jsForceOn", false).apply();
                        d.dismiss();
                        toast("Security level: " + levels[which].toUpperCase());
                        for (Tab t : tabs) t.web.reload();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void toggleDesktop() {
        if (active == null) return;
        active.desktop = !active.desktop;
        WebSettings st = active.web.getSettings();
        if (active.desktop) {
            st.setUserAgentString("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
                    + "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36");
            st.setUseWideViewPort(true);
            st.setLoadWithOverviewMode(true);
        } else {
            st.setUserAgentString("Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 "
                    + "(KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36");
        }
        active.web.reload();
        toast("Desktop site " + (active.desktop ? "on" : "off"));
    }

    private boolean isBlocked(Uri u) {
        if (u == null || u.getHost() == null) return false;
        String host = u.getHost().toLowerCase();
        for (String h : BLOCK) {
            if (host.equals(h) || host.endsWith("." + h)) return true;
        }
        return false;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private void toast(String m) { Toast.makeText(this, m, Toast.LENGTH_SHORT).show(); }

    private void hideKeyboard() {
        InputMethodManager im = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (im != null && getCurrentFocus() != null) {
            im.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
        }
    }

    /* =========================================================
       system back
    ========================================================= */
    @Override
    public void onBackPressed() {
        if (active != null && active.web.canGoBack()) { active.web.goBack(); return; }
        if (tabs.size() > 1) { closeTab(active); return; }
        if (active != null && !active.url.equals(HOME)) { active.web.loadUrl(HOME); return; }
        super.onBackPressed();
    }

    @Override protected void onPause() { super.onPause(); if (active != null) active.web.onPause(); }
    @Override protected void onResume() { super.onResume(); if (active != null) active.web.onResume(); }

    @Override
    protected void onDestroy() {
        try { if (tts != null) { tts.stop(); tts.shutdown(); } } catch (Exception ignored) { }
        for (Tab t : tabs) {
            container.removeView(t.web);
            t.web.destroy();
        }
        tabs.clear();
        super.onDestroy();
    }
}
