package com.skinventor.mercygx;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.TrafficStats;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Build;
import android.os.Bundle;
import android.os.Process;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.SslErrorHandler;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Mercy Lite — a small, fast WebView browser: tabs, ad-block,
 * live suggestions, HTTPS-only. No third-party libraries.
 * Platform WebView only; no third-party libraries.
 */
public class MainActivity extends Activity {

    private static final String HOME = "https://appassets.androidplatform.net/assets/newtab.html";
    private static final String PREFS = "mercy_gx";

    /* ---------------- ad / tracker blocklist ---------------- */
    private static final Set<String> BLOCK = new HashSet<>(Arrays.asList(
            "doubleclick.net", "googlesyndication.com", "googleadservices.com",
            "adservice.google.com", "google-analytics.com", "googletagmanager.com",
            "googletagservices.com", "scorecardresearch.com", "criteo.com",
            "criteo.net", "taboola.com", "outbrain.com", "adnxs.com",
            "quantserve.com", "moatads.com", "rubiconproject.com", "pubmatic.com",
            "openx.net", "casalemedia.com", "smartadserver.com", "yieldmo.com",
            "amazon-adsystem.com", "adsrvr.org", "bidswitch.net", "sharethrough.com",
            "hotjar.com", "segment.io", "segment.com", "amplitude.com", "mixpanel.com",
            "fullstory.com", "mouseflow.com", "clarity.ms", "branch.io", "appsflyer.com",
            "adjust.com", "kochava.com", "onesignal.com", "inmobi.com", "unityads.unity3d.com",
            "chartboost.com", "vungle.com", "applovin.com", "ironsrc.com", "supersonicads.com",
            "mopub.com", "flurry.com", "umeng.com", "bugsnag.com", "sentry-cdn.com",
            "facebook.net", "fbcdn-ads.com", "analytics.tiktok.com", "ads.tiktok.com",
            "adcolony.com", "vungle.com", "startapp.com", "tapjoy.com", "smaato.net",
            "fyber.com", "digitalturbine.com", "adform.net", "teads.tv", "loopme.me",
            "ogury.com", "sizmek.com", "adsafeprotected.com", "doubleverify.com",
            "adloox.com", "comscore.com", "quantcast.com", "nielsen.com", "chartbeat.com",
            "parsely.com", "newrelic.com", "bugsnag.com", "mparticle.com", "tealiumiq.com",
            "heapanalytics.com", "kissmetrics.com", "crazyegg.com", "clicktale.net",
            "luckyorange.com", "inspectlet.com", "smartlook.com", "logrocket.com",
            "braze.com", "iterable.com", "leanplum.com", "clevertap.com", "moengage.com",
            "webengage.com", "singular.net", "appmetrica.yandex.com", "mc.yandex.ru",
            "an.yandex.ru", "talkingdata.com", "pubnub.com", "gumgum.com",
            "indexexchange.com", "33across.com", "triplelift.com", "sovrn.com",
            "adroll.com", "revcontent.com", "mgid.com", "zergnet.com", "plista.com",
            "ligatus.com", "thetradedesk.com", "mediamath.com", "advertising.com",
            "yieldlab.net", "emxdgt.com", "district-m.net", "spotxchange.com",
            "tremorhub.com", "conversantmedia.com", "zedo.com", "exponential.com",
            "undertone.com", "serving-sys.com", "flashtalking.com", "innovid.com",
            "extremereach.com", "yieldmanager.com", "2mdn.net", "everesttech.net",
            "demdex.net", "omtrdc.net", "krxd.net", "bluekai.com", "exelator.com",
            "rlcdn.com", "agkn.com", "mathtag.com", "turn.com", "tapad.com",
            "adsymptotic.com", "crwdcntrl.net", "narrative.io", "liveramp.com",
            "ads.linkedin.com", "analytics.twitter.com", "static.ads-twitter.com",
            "sc-static.net", "snapchat.com", "tr.snapchat.com", "ads.pinterest.com",
            "ct.pinterest.com", "analytics.tiktok.com", "business-api.tiktok.com",
            "adsrvr.org"
    ));

    /* ---------------- state ---------------- */
    private final List<Tab> tabs = new ArrayList<>();
    private Tab active;
    private int tabSeq = 1;
    private SharedPreferences prefs;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private Runnable suggestJob;
    private long blockedCount = 0;
    private android.speech.tts.TextToSpeech tts;
    private boolean ttsReady = false;
    /* data ledger: per-page bytes, time and trackers, per host */
    private long rxAtPageStart = -1;
    private long pageStartMs = 0;
    private final java.util.Set<String> pageTrackers =
            java.util.Collections.newSetFromMap(new java.util.concurrent.ConcurrentHashMap<String, Boolean>());
    /* every host this page talked to: name -> {requests, blocked} */
    private final java.util.Map<String, int[]> pageHosts =
            new java.util.concurrent.ConcurrentHashMap<>();

    /* ---------------- views ---------------- */
    private FrameLayout container;

    private androidx.webkit.WebViewAssetLoader assetLoader;
    private EditText urlBar;
    private TextView engineChip, pctLabel, btnTabs;
    private BudgetRing ring;
    private ListView suggestList;
    private final java.util.List<String> suggestItems = new java.util.ArrayList<>();
    private android.widget.ArrayAdapter<String> suggestAdapter;
    private android.os.Handler suggestHandler;
    private String pendingQuery = "";
    private ProgressBar progress;
    private androidx.swiperefreshlayout.widget.SwipeRefreshLayout swipe;

    private static class Tab {
        String id;
        WebView web;
        String url = HOME;
        String title = "New tab";
        View chip;
        boolean incognito = false;
        boolean desktop = false;
        boolean frozen = false;
        long lastActive = System.currentTimeMillis();
    }

    /* =========================================================
       lifecycle
    ========================================================= */
    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        CrashGuard.install(this);
        getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        container = findViewById(R.id.container);

        assetLoader = new androidx.webkit.WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new androidx.webkit.WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        urlBar = findViewById(R.id.url);
        engineChip = findViewById(R.id.engineChip);
        pctLabel = findViewById(R.id.pct);
        btnTabs = findViewById(R.id.btnTabs);
        ring = findViewById(R.id.ring);
        suggestList = findViewById(R.id.suggest);
        suggestHandler = new android.os.Handler(getMainLooper());
        wireHeader();
        progress = findViewById(R.id.progress);
        swipe = findViewById(R.id.swipe);
        swipe.setColorSchemeColors(android.graphics.Color.parseColor("#a06bff"));
        swipe.setOnRefreshListener(new androidx.swiperefreshlayout.widget.SwipeRefreshLayout.OnRefreshListener() {
            @Override public void onRefresh() {
                if (active != null) active.web.reload();
                else swipe.setRefreshing(false);
            }
        });


        if (Build.VERSION.SDK_INT <= 28
                && checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, 100);
        }

        wireToolbar();
        paintEngine();

        Uri incoming = getIntent() == null ? null : getIntent().getData();
        String scheme = incoming == null || incoming.getScheme() == null ? "" : incoming.getScheme();
        if (scheme.equals("http") || scheme.equals("https")) {
            newTab(incoming.toString());   // opened from a link in another app
        } else {
            newTab(HOME);
        }

        tts = new android.speech.tts.TextToSpeech(this,
                new android.speech.tts.TextToSpeech.OnInitListener() {
                    @Override public void onInit(int status) {
                        ttsReady = status == android.speech.tts.TextToSpeech.SUCCESS;
                    }
                });

        if (getIntent() != null && "mercy.daily.summary".equals(getIntent().getAction())) {
            showDailySummary();
        }
        reportLastCrash();
        if (!prefs.getBoolean("proofSeen", false)) {
            prefs.edit().putBoolean("proofSeen", true).apply();
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override public void run() { showProof(); }
            }, 900);
        }
        startTabJanitor();
        scheduleDailySummary();
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission("android.permission.POST_NOTIFICATIONS")
                != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 104);
        }
        Updater.autoCheck(this);
    }

    private void wireToolbar() {

    }

    /* ---------------- voice search ---------------- */
    private String voiceLang() { return prefs.getString("voiceLang", "hi-IN"); }

    private void startVoiceSearch() {
        try {
            android.content.Intent probe = new android.content.Intent(
                    android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            if (probe.resolveActivity(getPackageManager()) == null) {
                toast("No speech service on this phone — type instead");
                urlBar.requestFocus();
                return;
            }
        } catch (Exception ignored) { }

        try {
            Intent i = new Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE, voiceLang());
            i.putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, voiceLang());
            // keep the audio on the device whenever an offline model exists
            i.putExtra(android.speech.RecognizerIntent.EXTRA_PREFER_OFFLINE, true);
            i.putExtra(android.speech.RecognizerIntent.EXTRA_PROMPT,
                    voiceLang().startsWith("hi") ? "\u0939\u093F\u0902\u0926\u0940 \u092E\u0947\u0902 \u092C\u094B\u0932\u093F\u090F"
                            : "Speak your search");
            startActivityForResult(i, 101);
        } catch (Exception e) {
            toast("No voice input app found");
        }
    }

    /* ---------------- read aloud ---------------- */
    private void readAloud() {
        if (active == null) return;
        if (!ttsReady) { toast("Speech engine not ready yet"); return; }
        active.web.evaluateJavascript("(function(){try{return document.body.innerText||''}catch(e){return ''}})()",
                new android.webkit.ValueCallback<String>() {
                    @Override public void onReceiveValue(String value) {
                        String text = "";
                        try {
                            text = value == null ? "" : value;
                            if (text.startsWith("\"")) {
                                text = new org.json.JSONArray("[" + text + "]").getString(0);
                            }
                        } catch (Exception e) { text = ""; }
                        text = text.replaceAll("\\s+", " ").trim();
                        if (text.length() < 40) { toast("Nothing to read on this page"); return; }

                        boolean hindi = text.matches(".*[\\u0900-\\u097F].*");
                        java.util.Locale loc = hindi ? new java.util.Locale("hi", "IN")
                                : new java.util.Locale("en", "IN");
                        int res = tts.setLanguage(loc);
                        if (res == android.speech.tts.TextToSpeech.LANG_MISSING_DATA
                                || res == android.speech.tts.TextToSpeech.LANG_NOT_SUPPORTED) {
                            tts.setLanguage(java.util.Locale.US);
                        }
                        tts.stop();
                        int chunk = 2800;
                        for (int i = 0; i < text.length(); i += chunk) {
                            String part = text.substring(i, Math.min(text.length(), i + chunk));
                            tts.speak(part, android.speech.tts.TextToSpeech.QUEUE_ADD, null, "mercy" + i);
                        }
                        toast(hindi ? "\u0939\u093F\u0902\u0926\u0940 \u092E\u0947\u0902 \u092A\u0922\u093C \u0930\u0939\u093E \u0939\u0948" : "Reading aloud");
                    }
                });
    }

    private void stopReading() {
        try { if (tts != null) tts.stop(); } catch (Exception ignored) { }
        toast("Stopped");
    }

    private void toggleVoiceLang() {
        String now = voiceLang().startsWith("hi") ? "en-IN" : "hi-IN";
        prefs.edit().putString("voiceLang", now).apply();
        toast("Voice: " + (now.startsWith("hi") ? "Hindi" : "English"));
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == 101 && res == RESULT_OK && data != null) {
            java.util.ArrayList<String> r = data.getStringArrayListExtra(
                    android.speech.RecognizerIntent.EXTRA_RESULTS);
            if (r != null && !r.isEmpty()) {
                String q = r.get(0);
                setChromeQuery(q);
                go(q);
            }
        }
    }

    /* =========================================================
       tabs
    ========================================================= */
    private void newTab(String url) { newTab(url, false); }

    private void newTab(String url, boolean incognito) {
        final Tab t = new Tab();
        t.id = "t" + (tabSeq++);
        t.incognito = incognito;
        t.title = incognito ? "Incognito" : "New tab";
        t.web = buildWebView(t);
        t.url = url;
        container.addView(t.web, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        tabs.add(t);
        select(t);
        t.web.loadUrl(url);
    }

    private WebView buildWebView(final Tab tab) {
        WebView w = new WebView(this);
        WebSettings s = w.getSettings();
        w.setOverScrollMode(View.OVER_SCROLL_NEVER);
        s.setJavaScriptEnabled(jsOn());
        w.addJavascriptInterface(new HomeBridge(), "MercyHome");
        s.setDomStorageEnabled(!tab.incognito);
        s.setDatabaseEnabled(!tab.incognito);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        // hardening
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setSaveFormData(false);
        s.setGeolocationEnabled(false);
        s.setSupportMultipleWindows(false);
        if (Build.VERSION.SDK_INT >= 26) s.setSafeBrowsingEnabled(true);
        if (prefs.getBoolean("noImages", false)) s.setBlockNetworkImage(true);
        if (tab.incognito) s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        String customUa = prefs.getString("customUA", "");
        if (!customUa.isEmpty()) s.setUserAgentString(customUa);
        if (tab.desktop) {
            s.setUserAgentString("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
                    + "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36");
            s.setUseWideViewPort(true);
            s.setLoadWithOverviewMode(true);
        }
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        // Plain mobile Chrome UA: no "wv" token, no app name. Without this, Google
        // shows "This browser or app may not be secure" and blocks sign-in.
        s.setUserAgentString("Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 "
                + "(KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36");
        if (Build.VERSION.SDK_INT >= 26) s.setSafeBrowsingEnabled(true);

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, false);

        w.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri u = req.getUrl();
                String scheme = u.getScheme() == null ? "" : u.getScheme();
                if (scheme.equals("http")) {
                    if (httpsOnly()) {
                        view.loadUrl(u.toString().replaceFirst("^http://", "https://"));
                        toast("Upgraded to HTTPS");
                        return true;
                    }
                    return false;
                }
                if (scheme.equals("https") || scheme.equals("file")) return false;
                if (scheme.equals("mailto") || scheme.equals("tel")) {
                    try { startActivity(new android.content.Intent(android.content.Intent.ACTION_VIEW, u)); }
                    catch (Exception ignored) { toast("No app can handle this link"); }
                    return true;
                }
                // intent://, market://, app links — a page must not launch other apps
                toast("Blocked an unsafe link (" + scheme + ")");
                return true;
            }

            /* the ad-blocker: cancel the request before it leaves the phone */
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
                try {
                    WebResourceResponse local = assetLoader.shouldInterceptRequest(req.getUrl());
                    if (local != null) return local;   // the home page is served locally
                } catch (Exception ignored) { }
                String reqHost = req.getUrl() == null ? null : req.getUrl().getHost();
                boolean blocked = adblockOn() && isBlocked(req.getUrl());
                if (reqHost != null) {
                    int[] v = pageHosts.get(reqHost);
                    if (v == null) { v = new int[]{0, 0}; pageHosts.put(reqHost, v); }
                    synchronized (v) { v[0]++; if (blocked) v[1]++; }
                }
                if (blocked) {
                    blockedCount++;
                    if (req.getUrl().getHost() != null) pageTrackers.add(req.getUrl().getHost());
                    if (blockedCount % 10 == 0) runOnUiThread(new Runnable() {
                        @Override public void run() { pushBudget(); }
                    });
                    return new WebResourceResponse("text/plain", "utf-8",
                            new ByteArrayInputStream(new byte[0]));
                }
                return null;
            }

            @Override public boolean onRenderProcessGone(WebView view, android.webkit.RenderProcessGoneDetail detail) {
                Tab dead = tabOf(view);
                if (dead != null) {
                    try { container.removeView(dead.web); dead.web.destroy(); } catch (Exception ignored) { }
                    tabs.remove(dead);
                    if (tabs.isEmpty()) newTab(HOME);
                    else if (active == dead) select(tabs.get(0));
                    renderStrip();
                }
                toast("A page crashed — the tab was closed");
                return true;   // handled: keep the app alive
            }

            @Override public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                handler.cancel();
                toast("Blocked an insecure connection");
            }

            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                pageStartMs = System.currentTimeMillis();
                rxAtPageStart = rxBytes();
                pageTrackers.clear();
                pageHosts.clear();
                applySiteRules(view, url);
            }

            @Override public void onPageFinished(WebView view, String url) {
                progress.setVisibility(View.GONE);
                swipe.setRefreshing(false);
                Tab t = tabOf(view);
                if (t == null) return;
                t.url = url;
                t.title = view.getTitle() == null ? url : view.getTitle();
                if (t == active) {
                    t.lastActive = System.currentTimeMillis();
                    setChromeUrl(url);
                    updateNav();
                }
                boolean home = url != null && (url.contains("newtab.html") || url.contains("appassets"));
                applyHeaderMode(url);
                if (home) pushHomeConfig(view);
                pushBudget();
                paintCostLine();
                renderStrip();
                if (!t.incognito) {
                    addHistory(url, t.title);
                    recordLedger(url, System.currentTimeMillis() - pageStartMs);
                }
            }
        });

        w.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int p) {
                progress.setVisibility(p >= 100 ? View.GONE : View.VISIBLE);
                progress.setProgress(p);
            }
            @Override public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        request.deny();
                        toast("Blocked a device permission request");
                    }
                });
            }

            @Override public void onReceivedTitle(WebView view, String title) {
                Tab t = tabOf(view);
                if (t != null && title != null) { t.title = title; renderStrip(); }
            }
        });

        w.setDownloadListener(new DownloadListener() {
            @Override public void onDownloadStart(String url, String ua, String cd, String mime, long size) {
                if (url != null && url.startsWith("http://")) {
                    toast("Download blocked — not encrypted");
                    return;
                }
                try {
                    String name = URLUtil.guessFileName(url, cd, mime);
                    DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
                    r.setMimeType(mime);
                    r.addRequestHeader("User-Agent", ua);
                    r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
                    DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
                    if (dm != null) dm.enqueue(r);
                    toast("Downloading " + name);
                } catch (Exception e) { toast("Download failed"); }
            }
        });
        return w;
    }

    private Tab tabOf(WebView w) {
        for (Tab t : tabs) if (t.web == w) return t;
        return null;
    }

    private void select(Tab t) {
        if (t.frozen) wake(t);
        t.lastActive = System.currentTimeMillis();
        active = t;
        pushBudget();
        for (Tab x : tabs) {
            if (x.web != null) x.web.setVisibility(x == t ? View.VISIBLE : View.GONE);
        }
        setChromeUrl(t.url);
        updateNav();
        renderStrip();
    }

    /* =========================================================
       ruthless suspension — a hidden tab stops costing memory
    ========================================================= */
    private static final long SLEEP_AFTER_MS = 5 * 60 * 1000L;


    /* =========================================================
       21:00 summary — the only notification this app ever sends
    ========================================================= */
    private static final String CHANNEL_ID = "mercy_daily";
    private static final int NOTIF_ID = 2100;

    private void scheduleDailySummary() {
        try {
            android.app.AlarmManager am = (android.app.AlarmManager) getSystemService(Context.ALARM_SERVICE);
            if (am == null) return;
            Intent i = new Intent(this, MainActivity.class);
            i.setAction("mercy.daily.summary");
            int flags = Build.VERSION.SDK_INT >= 23
                    ? android.app.PendingIntent.FLAG_UPDATE_CURRENT | android.app.PendingIntent.FLAG_IMMUTABLE
                    : android.app.PendingIntent.FLAG_UPDATE_CURRENT;
            android.app.PendingIntent pi = android.app.PendingIntent.getActivity(this, 21, i, flags);

            java.util.Calendar c = java.util.Calendar.getInstance();
            c.set(java.util.Calendar.HOUR_OF_DAY, 21);
            c.set(java.util.Calendar.MINUTE, 0);
            c.set(java.util.Calendar.SECOND, 0);
            if (c.getTimeInMillis() < System.currentTimeMillis()) c.add(java.util.Calendar.DAY_OF_YEAR, 1);
            am.setInexactRepeating(android.app.AlarmManager.RTC,
                    c.getTimeInMillis(), android.app.AlarmManager.INTERVAL_DAY, pi);
        } catch (Exception ignored) { }
    }

    private void showDailySummary() {
        try {
            long today = todayBytes();
            if (today <= 0) return;
            android.app.NotificationManager nm =
                    (android.app.NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;

            if (Build.VERSION.SDK_INT >= 26) {
                android.app.NotificationChannel ch = new android.app.NotificationChannel(
                        CHANNEL_ID, "Daily summary", android.app.NotificationManager.IMPORTANCE_LOW);
                ch.setDescription("One line a day about your data");
                nm.createNotificationChannel(ch);
            }

            android.app.Notification.Builder b = Build.VERSION.SDK_INT >= 26
                    ? new android.app.Notification.Builder(this, CHANNEL_ID)
                    : new android.app.Notification.Builder(this);
            b.setSmallIcon(android.R.drawable.stat_notify_more)
             .setContentTitle("Today: " + human(today) + " · " + money(today))
             .setContentText("Open Mercy to see which site took the most")
             .setAutoCancel(true);
            nm.notify(NOTIF_ID, b.build());
        } catch (Exception ignored) { }
    }

    private void startTabJanitor() {
        final Handler h = new Handler(Looper.getMainLooper());
        h.postDelayed(new Runnable() {
            @Override public void run() {
                long now = System.currentTimeMillis();
                for (Tab t : new java.util.ArrayList<>(tabs)) {
                    if (t == active || t.frozen) continue;
                    if (now - t.lastActive > SLEEP_AFTER_MS) freeze(t);
                }
                h.postDelayed(this, 60 * 1000L);
            }
        }, 60 * 1000L);
    }

    /** Releases the WebView entirely; the URL and title stay so the tab can wake. */
    private void freeze(Tab t) {
        if (t.web == null || t == active) return;
        try {
            t.url = t.web.getUrl() == null ? t.url : t.web.getUrl();
            container.removeView(t.web);
            t.web.clearHistory();
            t.web.destroy();
        } catch (Exception ignored) { }
        t.web = null;
        t.frozen = true;
        renderStrip();
    }

    private void wake(Tab t) {
        if (!t.frozen) return;
        t.frozen = false;
        t.web = buildWebView(t);
        container.addView(t.web, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        t.web.loadUrl(t.url == null ? HOME : t.url);
    }

    private void closeTab(Tab t) {
        boolean wasPrivate = t.incognito;
        if (t.web != null) {
            container.removeView(t.web);
            t.web.clearHistory();
            t.web.destroy();
        }
        if (wasPrivate) {
            CookieManager.getInstance().removeAllCookies(null);
            CookieManager.getInstance().flush();
        }
        tabs.remove(t);
        if (tabs.isEmpty()) { newTab(HOME); return; }
        if (t == active) select(tabs.get(tabs.size() - 1));
        else renderStrip();
    }

    /** The tab strip is gone; the header shows a number instead. */
    private void renderStrip() {
        try {
            if (btnTabs != null) btnTabs.setText(String.valueOf(tabs.size()));
        } catch (Exception ignored) { }
    }


    /* =========================================================
       navigation
    ========================================================= */
    private boolean looksLikeUrl(String s) {
        if (s.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*")) return true;
        if (s.matches("^localhost(:\\d+)?(/.*)?$")) return true;
        return s.matches("^[^\\s]+\\.[a-zA-Z]{2,}([/?#].*)?$");
    }

    private void go(String input) {
        String s = input == null ? "" : input.trim();
        if (s.isEmpty() || active == null) return;
        pendingQuery = s;
        if (looksLikeUrl(s)) {
            String url = s.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*") ? s
                    : (s.startsWith("localhost") ? "http://" + s : "https://" + s);
            active.web.loadUrl(url);
        } else {
            active.web.loadUrl(searchUrl(s));
        }
        hideKeyboard();
    }


    /* =========================================================
       search engine chooser (Mercy + the usual suspects)
    ========================================================= */
    private static final String[] ENGINE_IDS =
            {"mercy", "google", "ddg", "brave", "ecosia", "startpage", "bing", "yahoo"};

    private String engineLabel(String id) {
        switch (id) {
            case "mercy": return "Mercy (own index)";
            case "brave": return "Brave Search";
            case "bing": return "Bing";
            case "startpage": return "Startpage";
            case "ecosia": return "Ecosia";
            case "google": return "Google";
            case "yahoo": return "Yahoo";
            default: return "DuckDuckGo";
        }
    }

    private String engineLetter(String id) {
        switch (id) {
            case "mercy": return "M";
            case "brave": return "B";
            case "bing": return "b";
            case "startpage": return "S";
            case "ecosia": return "E";
            case "google": return "G";
            default: return "D";
        }
    }

    private String engineColor(String id) {
        switch (id) {
            case "mercy": return "#e08a3c";
            case "brave": return "#fb542b";
            case "bing": return "#00a4ef";
            case "startpage": return "#6b7f8f";
            case "ecosia": return "#2f9e5f";
            case "google": return "#4285f4";
            case "yahoo": return "#6001d2";
            default: return "#de5833";
        }
    }

    private String currentEngine() {
        String id = prefs.getString("engine", "ddg");
        for (String e : ENGINE_IDS) if (e.equals(id)) return id;
        return "ddg";
    }

    private void paintEngine() {
        pushChromeConfig();
    }

    private void showEnginePicker() {
        final String[] labels = new String[ENGINE_IDS.length];
        String cur = currentEngine();
        int checked = 0;
        for (int i = 0; i < ENGINE_IDS.length; i++) {
            labels[i] = engineLabel(ENGINE_IDS[i]);
            if (ENGINE_IDS[i].equals(cur)) checked = i;
        }
        new android.app.AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle("Search engine")
                .setSingleChoiceItems(labels, checked, new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int which) {
                        prefs.edit().putString("engine", ENGINE_IDS[which]).apply();
                        paintEngine();
                        d.dismiss();
                        if (ENGINE_IDS[which].equals("mercy") && prefs.getString("mercyUrl", "").isEmpty()) {
                            askMercyUrl();
                        }
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void askMercyUrl() {
        final android.widget.EditText input = new android.widget.EditText(this);
        input.setHint("https://your-search.onrender.com/search");
        input.setText(prefs.getString("mercyUrl", ""));
        input.setTextSize(13);
        new android.app.AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle("Mercy engine URL")
                .setMessage("Apne search server ka /search endpoint daalo. Khali chhodo to DuckDuckGo use hoga.")
                .setView(input)
                .setPositiveButton("Save", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int w) {
                        prefs.edit().putString("mercyUrl", input.getText().toString().trim()).apply();
                        toast("Saved");
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private String searchUrl(String q) {
        String enc = android.net.Uri.encode(q);
        String id = currentEngine();
        switch (id) {
            case "mercy": {
                String base = prefs.getString("mercyUrl", "").trim();
                if (base.isEmpty()) {
                    toast("Mercy engine URL set nahi hai — DuckDuckGo use ho raha hai");
                    return "https://duckduckgo.com/?q=" + enc;
                }
                return base + (base.contains("?") ? "&q=" : "?q=") + enc;
            }
            case "brave": return "https://search.brave.com/search?q=" + enc;
            case "bing": return "https://www.bing.com/search?q=" + enc;
            case "startpage": return "https://www.startpage.com/sp/search?query=" + enc;
            case "ecosia": return "https://www.ecosia.org/search?q=" + enc;
            case "google": return "https://www.google.com/search?q=" + enc;
            case "yahoo": return "https://search.yahoo.com/search?p=" + enc;
            default: return "https://duckduckgo.com/?q=" + enc;
        }
    }

    private void goForward() {
        if (active != null && active.web.canGoForward()) active.web.goForward();
        else toast("Nothing to go forward to");
    }

    private void updateNav() {
        // no arrow in the header any more; the system back button drives navigation
    }

    /* =========================================================
       the header is the HTML chrome — native talks to it over a bridge
    ========================================================= */
    /* =========================================================
       the header — native views, so a keystroke costs one TextView
    ========================================================= */
    private void wireHeader() {
        engineChip.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showEnginePicker(); }
        });
        ring.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showLedger(); }
        });
        findViewById(R.id.btnNew).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { newTab(HOME); }
        });
        btnTabs.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showTabs(); }
        });
        findViewById(R.id.btnMenu).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showMenu(); }
        });
        findViewById(R.id.btnMic).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { startVoiceSearch(); }
        });

        urlBar.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_GO
                        || (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                    String text = urlBar.getText().toString().trim();
                    if (!text.isEmpty()) { hideSuggestions(); go(text); }
                    return true;
                }
                return false;
            }
        });
        urlBar.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) fetchSuggestions(urlBar.getText().toString());
                else hideSuggestions();
            }
        });
        urlBar.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(android.text.Editable e) {
                fetchSuggestions(e.toString());
            }
        });

        suggestAdapter = new android.widget.ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, suggestItems) {
            @Override public View getView(int position, View convert, android.view.ViewGroup parent) {
                TextView tv = (TextView) super.getView(position, convert, parent);
                tv.setTextColor(0xFFE6E6EA);
                tv.setTextSize(13f);
                tv.setPadding(dp(16), dp(12), dp(16), dp(12));
                return tv;
            }
        };
        suggestList.setAdapter(suggestAdapter);
        suggestList.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {
            @Override public void onItemClick(android.widget.AdapterView<?> p, View v, int pos, long id) {
                String text = suggestItems.get(pos);
                urlBar.setText(text);
                urlBar.setSelection(text.length());
                hideSuggestions();
                go(text);
            }
        });
    }

    /** suggestions from the engine, debounced so typing stays light */
    private void fetchSuggestions(final String query) {
        if (suggestHandler == null) return;
        suggestHandler.removeCallbacksAndMessages(null);
        final String q = query == null ? "" : query.trim();
        if (q.isEmpty()) { hideSuggestions(); return; }
        suggestHandler.postDelayed(new Runnable() {
            @Override public void run() {
                new Thread(new Runnable() {
                    @Override public void run() {
                        final java.util.List<String> out = new java.util.ArrayList<>();
                        try {
                            java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(
                                    "https://duckduckgo.com/ac/?q=" + java.net.URLEncoder.encode(q, "UTF-8")
                                            + "&type=list").openConnection();
                            c.setConnectTimeout(3000);
                            c.setReadTimeout(3000);
                            java.io.BufferedReader r = new java.io.BufferedReader(
                                    new java.io.InputStreamReader(c.getInputStream()));
                            StringBuilder sb = new StringBuilder();
                            String line;
                            while ((line = r.readLine()) != null) sb.append(line);
                            r.close();
                            String body = sb.toString().trim();
                            org.json.JSONArray arr;
                            if (body.startsWith("\"")) {           // double-encoded
                                body = new org.json.JSONTokener(body).nextValue().toString();
                            }
                            arr = new org.json.JSONArray(body);
                            for (int i = 0; i < arr.length() && i < 8; i++) {
                                Object o = arr.opt(i);
                                String phrase = null;
                                if (o instanceof String) phrase = (String) o;
                                else if (o instanceof org.json.JSONObject)
                                    phrase = ((org.json.JSONObject) o).optString("phrase", null);
                                if (phrase != null && !phrase.trim().isEmpty()) out.add(phrase.trim());
                            }
                        } catch (Exception ignored) { }
                        runOnUiThread(new Runnable() {
                            @Override public void run() {
                                if (!urlBar.hasFocus() || out.isEmpty()) { hideSuggestions(); return; }
                                suggestItems.clear();
                                suggestItems.addAll(out);
                                suggestAdapter.notifyDataSetChanged();
                                suggestList.setVisibility(View.VISIBLE);
                            }
                        });
                    }
                }).start();
            }
        }, 180);
    }

    private void hideSuggestions() {
        if (suggestList != null) suggestList.setVisibility(View.GONE);
    }

    /* the two header modes: engine chip on the home page, budget ring on a site */
    private void applyHeaderMode(String url) {
        boolean home = url == null || url.contains("newtab.html") || url.contains("appassets");
        engineChip.setVisibility(home ? View.VISIBLE : View.GONE);
        ring.setVisibility(home ? View.GONE : View.VISIBLE);
        pctLabel.setVisibility(home ? View.GONE : View.VISIBLE);
        findViewById(R.id.btnNew).setVisibility(home ? View.GONE : View.VISIBLE);
        btnTabs.setVisibility(home ? View.GONE : View.VISIBLE);
    }



    private void pushChromeConfig() {
        // the header is native now; nothing to push into it
    }


    /** B3: the page's price drawn as a line welded under the header. */
    private void paintCostLine() {
        pushBudget();   // the ring carries the cost now
    }


    /** Consecutive days under the daily budget, counting back from yesterday. */
    private int budgetStreak() {
        try {
            org.json.JSONObject daily = new org.json.JSONObject(prefs.getString("daily", "{}"));
            long budget = budgetBytes();
            java.text.SimpleDateFormat key = new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US);
            int streak = 0;
            for (int i = 1; i <= 60; i++) {
                java.util.Date d = new java.util.Date(System.currentTimeMillis() - i * 86400000L);
                long used = daily.optLong(key.format(d));
                if (used == 0) break;          // no record: the chain ends here
                if (used > budget) break;      // over budget: chain ends
                streak++;
            }
            return streak;
        } catch (Exception e) { return 0; }
    }

    /** F: the ring in the header is today's budget, measured. */
    private void pushBudget() {
        try {
            long today = todayBytes();
            long budget = budgetBytes();
            int pct = (int) Math.min(100, today * 100 / budget);
            String state = active != null && active.incognito ? "incognito"
                    : (today > budget ? "over" : "normal");
            if (ring != null) ring.setValue(pct, today > budget);
            if (pctLabel != null) {
                if ("incognito".equals(state)) { pctLabel.setText("PRIVATE"); pctLabel.setTextColor(0xFFC9B0FF); }
                else if (today > budget) { pctLabel.setText("OVER"); pctLabel.setTextColor(0xFFFF5C5C); }
                else { pctLabel.setText(pct + "%"); pctLabel.setTextColor(pct >= 60 ? 0xFFFFB020 : 0xFF5C5C66); }
            }
        } catch (Exception ignored) { }
    }

    /** the tab switcher, opened by the number in the header */
    private void showTabs() {
        final java.util.List<Tab> list = new java.util.ArrayList<>(tabs);
        String[] titles = new String[list.size()];
        for (int i = 0; i < list.size(); i++) {
            Tab t = list.get(i);
            titles[i] = (t == active ? "\u25CF " : "   ") + (t.title == null ? "New tab" : t.title);
        }
        new AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle("Tabs \u00B7 " + tabs.size())
                .setItems(titles, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) { select(list.get(which)); }
                })
                .setPositiveButton("New tab", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { newTab(HOME); }
                })
                .setNegativeButton("Close", null)
                .show();
    }

    private void pushHomeConfig(WebView view) {
        try {
            org.json.JSONObject cfg = new org.json.JSONObject();

            long today = todayBytes();
            cfg.put("used", human(today));
            cfg.put("cost", money(today));
            cfg.put("budgetPct", (int) Math.min(100, today * 100 / budgetBytes()));
            cfg.put("detail", human(today) + " of 200 MB today");

            String ver;
            try { ver = getPackageManager().getPackageInfo(getPackageName(), 0).versionName; }
            catch (Exception e) { ver = ""; }
            cfg.put("version", ver);

            // seven days, oldest first
            org.json.JSONObject daily = new org.json.JSONObject(prefs.getString("daily", "{}"));
            org.json.JSONArray days = new org.json.JSONArray();
            java.text.SimpleDateFormat key = new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US);
            java.text.SimpleDateFormat lab = new java.text.SimpleDateFormat("EEE", java.util.Locale.US);
            for (int i = 6; i >= 0; i--) {
                java.util.Date d = new java.util.Date(System.currentTimeMillis() - i * 86400000L);
                org.json.JSONObject day = new org.json.JSONObject();
                day.put("label", lab.format(d).substring(0, 2).toUpperCase());
                day.put("bytes", daily.optLong(key.format(d)));
                days.put(day);
            }
            cfg.put("days", days);

            // heaviest sites today (from the ledger)
            org.json.JSONObject all = new org.json.JSONObject(prefs.getString("ledger", "{}"));
            java.util.List<String> hosts = new java.util.ArrayList<>();
            for (java.util.Iterator<String> it = all.keys(); it.hasNext(); ) hosts.add(it.next());
            final org.json.JSONObject ledger = all;
            java.util.Collections.sort(hosts, new java.util.Comparator<String>() {
                @Override public int compare(String a, String b) {
                    return Long.compare(ledger.optJSONObject(b).optLong("bytes"),
                            ledger.optJSONObject(a).optLong("bytes"));
                }
            });
            org.json.JSONArray sites = new org.json.JSONArray();
            long total = 0;
            for (String h : hosts) total += all.optJSONObject(h).optLong("bytes");
            for (int i = 0; i < hosts.size() && i < 4; i++) {
                long b = all.optJSONObject(hosts.get(i)).optLong("bytes");
                org.json.JSONObject o = new org.json.JSONObject();
                o.put("host", hosts.get(i));
                o.put("cost", money(b) + (total > 0 ? "  \u00B7  " + (b * 100 / total) + "%" : ""));
                sites.put(o);
            }
            cfg.put("sites", sites);
            if (!hosts.isEmpty()) cfg.put("top", hosts.get(0));

            cfg.put("streak", budgetStreak());
            cfg.put("incognito", active != null && active.incognito);
            cfg.put("offline", new org.json.JSONArray(prefs.getString("offline", "[]")).length() + " pages");
            cfg.put("blocked", String.valueOf(blockedCount));
            cfg.put("requests", "1 request");

            view.evaluateJavascript("Home.init(" + cfg.toString() + ");", null);
        } catch (Exception ignored) { }
    }

    private void setChromeUrl(String url) {
        if (urlBar == null) return;
        boolean internal = url == null || url.contains("appassets") || url.startsWith("file://");
        if (!urlBar.hasFocus()) urlBar.setText(internal ? "" : url);
    }

    private void setChromeQuery(String text) {
        if (urlBar == null) return;
        urlBar.setText(text == null ? "" : text);
        urlBar.setSelection(urlBar.getText().length());
    }

    private void loadFromChrome(String url) {
        if (active == null) return;
        hideKeyboard();
        active.web.loadUrl(url);
    }

    /* =========================================================
       history / bookmarks
    ========================================================= */
    private JSONArray readArray(String key) {
        try { return new JSONArray(prefs.getString(key, "[]")); }
        catch (Exception e) { return new JSONArray(); }
    }

    private void addHistory(String url, String title) {
        if (url == null || url.equals("about:blank") || url.startsWith("file://")
                || url.contains("appassets.androidplatform.net")) return;
        try {
            JSONArray arr = readArray("history");
            JSONArray out = new JSONArray();
            JSONObject o = new JSONObject();
            o.put("url", url);
            o.put("title", title == null ? url : title);
            out.put(o);
            for (int i = 0; i < arr.length() && i < 199; i++) {
                JSONObject old = arr.getJSONObject(i);
                if (!url.equals(old.optString("url"))) out.put(old);
            }
            prefs.edit().putString("history", out.toString()).apply();
        } catch (Exception ignored) { }
    }

    private void toggleBookmark() {
        if (active == null) return;
        try {
            JSONArray arr = readArray("bookmarks");
            for (int i = 0; i < arr.length(); i++) {
                if (active.url.equals(arr.getJSONObject(i).optString("url"))) {
                    toast("Already bookmarked");
                    return;
                }
            }
            JSONObject o = new JSONObject();
            o.put("url", active.url);
            o.put("title", active.title);
            arr.put(o);
            prefs.edit().putString("bookmarks", arr.toString()).apply();
            toast("Bookmarked");
        } catch (Exception e) { toast("Bookmark failed"); }
    }



    /* ---------------- image search ---------------- */
    /** Images tab of whichever engine is selected. */
    private String imageSearchUrl(String q) {
        String enc = Uri.encode(q == null ? "" : q);
        switch (currentEngine()) {
            case "google": return "https://www.google.com/search?tbm=isch&q=" + enc;
            case "brave":  return "https://search.brave.com/images?q=" + enc;
            case "bing":   return "https://www.bing.com/images/search?q=" + enc;
            case "yahoo":  return "https://images.search.yahoo.com/search/images?p=" + enc;
            case "ecosia": return "https://www.ecosia.org/images?q=" + enc;
            case "startpage": return "https://www.startpage.com/sp/search?query=" + enc + "&cat=images";
            case "mercy": {
                String base = prefs.getString("mercyUrl", "").trim();
                if (!base.isEmpty()) return base + (base.contains("?") ? "&q=" : "?q=") + enc;
                return "https://duckduckgo.com/?q=" + enc + "&iax=images&ia=images";
            }
            default: return "https://duckduckgo.com/?q=" + enc + "&iax=images&ia=images";
        }
    }

    /** Reverse image search: opens the engine's visual-search page, where the
     *  user can upload a photo or point the camera. No API key needed. */
    private String visualSearchUrl() {
        switch (currentEngine()) {
            case "google": return "https://lens.google.com/";
            case "bing":   return "https://www.bing.com/visualsearch";
            case "yahoo":  return "https://images.search.yahoo.com/";
            default:       return "https://lens.google.com/";
        }
    }

    private void openImageSearch() {
        if (active == null) return;
        String q = pendingQuery;
        String url = imageSearchUrl(q);
        setChromeUrl(url);
        active.web.loadUrl(url);
    }

    private void openVisualSearch() {
        if (active == null) return;
        String url = visualSearchUrl();
        setChromeUrl(url);
        active.web.loadUrl(url);
    }


    /* =========================================================
       data ledger — what a page actually cost you
    ========================================================= */
    private long rxBytes() {
        long v = TrafficStats.getUidRxBytes(Process.myUid());
        return v == TrafficStats.UNSUPPORTED ? -1 : v;
    }

    private double tariffPerMb() {
        try { return Double.parseDouble(prefs.getString("tariff", "0.01")); }
        catch (Exception e) { return 0.01; }
    }

    private String hostOf(String url) {
        try {
            String h = Uri.parse(url).getHost();
            if (h == null) return null;
            return h.startsWith("www.") ? h.substring(4) : h;
        } catch (Exception e) { return null; }
    }

    private void recordLedger(String url, long ms) {
        if (url == null || url.contains("appassets.androidplatform.net") || url.startsWith("file://")) return;
        String host = hostOf(url);
        if (host == null) return;
        long bytes = 0;
        if (rxAtPageStart > 0) {
            long now = rxBytes();
            if (now > rxAtPageStart) bytes = now - rxAtPageStart;
        }
        try {
            org.json.JSONObject all = new org.json.JSONObject(prefs.getString("ledger", "{}"));
            org.json.JSONObject row = all.optJSONObject(host);
            if (row == null) row = new org.json.JSONObject();
            row.put("bytes", row.optLong("bytes") + Math.max(0, bytes));
            row.put("ms", row.optLong("ms") + Math.max(0, ms));
            row.put("visits", row.optLong("visits") + 1);
            row.put("trackers", row.optLong("trackers") + pageTrackers.size());
            all.put(host, row);

            // keep a per-day total so the home screen can show a week
            String day = new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
                    .format(new java.util.Date());
            org.json.JSONObject daily = new org.json.JSONObject(prefs.getString("daily", "{}"));
            daily.put(day, daily.optLong(day) + Math.max(0, bytes));

            prefs.edit().putString("ledger", all.toString())
                    .putString("daily", daily.toString()).apply();
        } catch (Exception ignored) { }
    }

    private org.json.JSONObject ledgerRow(String host) {
        try {
            org.json.JSONObject all = new org.json.JSONObject(prefs.getString("ledger", "{}"));
            return all.optJSONObject(host);
        } catch (Exception e) { return null; }
    }

    private String human(long b) {
        if (b < 1024) return b + " B";
        if (b < 1024 * 1024) return String.format("%.0f KB", b / 1024.0);
        if (b < 1024L * 1024 * 1024) return String.format("%.1f MB", b / 1048576.0);
        return String.format("%.2f GB", b / 1073741824.0);
    }

    private String currency() { return prefs.getString("currency", "\u20B9"); }

    private String money(long bytes) {
        double mb = bytes / 1048576.0;
        double amount = mb * tariffPerMb();
        String cur = currency();
        if (amount < 1 && cur.equals("\u20B9")) return String.format("%.0f paise", amount * 100);
        return String.format("%s%.2f", cur, amount);
    }

    private String humanTime(long ms) {
        long s = ms / 1000;
        if (s < 60) return s + "s";
        if (s < 3600) return (s / 60) + "m";
        return (s / 3600) + "h " + ((s % 3600) / 60) + "m";
    }



    /* =========================================================
       "what this page loaded" — every host behind the page
    ========================================================= */

    /* =========================================================
       per-site rules — remembered per host, applied on every visit
    ========================================================= */
    private org.json.JSONObject siteRule(String host) {
        if (host == null) return null;
        try {
            return new org.json.JSONObject(prefs.getString("rules", "{}")).optJSONObject(host);
        } catch (Exception e) { return null; }
    }

    private void applySiteRules(WebView view, String url) {
        String host = hostOf(url);
        if (host == null) return;
        org.json.JSONObject r = siteRule(host);
        if (r == null) return;
        WebSettings st = view.getSettings();
        if (r.has("js")) st.setJavaScriptEnabled(r.optInt("js") == 1);
        if (r.has("img")) st.setBlockNetworkImage(r.optInt("img") == 0);
        if (r.has("desk")) {
            boolean desk = r.optInt("desk") == 1;
            st.setUserAgentString(desk
                    ? "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
                    : "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36");
        }
    }


    /* =========================================================
       offline pages — a full snapshot (MHTML) on the device
    ========================================================= */
    private java.io.File offlineDir() {
        java.io.File d = new java.io.File(getFilesDir(), "offline");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    private void saveOffline() {
        if (active == null) return;
        final String url = active.url;
        final String title = active.title == null ? url : active.title;
        try {
            java.io.File f = new java.io.File(offlineDir(),
                    "page-" + System.currentTimeMillis() + ".mhtml");
            final String path = f.getAbsolutePath();
            active.web.saveWebArchive(path, false, new android.webkit.ValueCallback<String>() {
                @Override public void onReceiveValue(String value) {
                    java.io.File saved = new java.io.File(path);
                    if (!saved.exists() || saved.length() == 0) {
                        toast("Could not save this page");
                        return;
                    }
                    try {
                        org.json.JSONArray arr = new org.json.JSONArray(prefs.getString("offline", "[]"));
                        org.json.JSONObject o = new org.json.JSONObject();
                        o.put("title", title);
                        o.put("url", url);
                        o.put("path", path);
                        o.put("ts", System.currentTimeMillis());
                        o.put("size", saved.length());
                        arr.put(o);
                        prefs.edit().putString("offline", arr.toString()).apply();
                        toast("Saved offline — " + human(saved.length()));
                    } catch (Exception e) { toast("Saved, but the index failed"); }
                }
            });
        } catch (Exception e) { toast("Save failed"); }
    }

    private void showOffline() {
        try {
            final org.json.JSONArray arr = new org.json.JSONArray(prefs.getString("offline", "[]"));
            if (arr.length() == 0) { toast("No offline pages yet"); return; }

            final String[] titles = new String[arr.length()];
            final String[] paths = new String[arr.length()];
            long total = 0;
            for (int i = 0; i < arr.length(); i++) {
                org.json.JSONObject o = arr.getJSONObject(i);
                long size = o.optLong("size");
                total += size;
                titles[i] = o.optString("title") + "  \u00B7  " + human(size);
                paths[i] = o.optString("path");
            }

            new AlertDialog.Builder(this, R.style.MercyDialog)
                    .setTitle("Offline pages  \u00B7  " + human(total))
                    .setItems(titles, new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface d, int which) {
                            newTab("file://" + paths[which]);
                        }
                    })
                    .setNeutralButton("Delete all", new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface d, int w) {
                            for (String path : paths) {
                                try { new java.io.File(path).delete(); } catch (Exception ignored) { }
                            }
                            prefs.edit().putString("offline", "[]").apply();
                            toast("Offline pages deleted");
                        }
                    })
                    .setNegativeButton("Close", null)
                    .show();
        } catch (Exception e) { toast("Offline list unavailable"); }
    }

    private void openSiteRules() {
        if (active == null) return;
        final String host = hostOf(active.url);
        if (host == null) { toast("No site to configure"); return; }
        org.json.JSONObject r = siteRule(host);

        final String[] labels = {"JavaScript", "Load images", "Desktop site", "Block trackers"};
        final boolean[] checked = {
                r == null || !r.has("js") ? jsOn() : r.optInt("js") == 1,
                r == null || !r.has("img") ? !prefs.getBoolean("noImages", false) : r.optInt("img") == 1,
                r != null && r.optInt("desk") == 1,
                r == null || !r.has("blk") ? adblockOn() : r.optInt("blk") == 1
        };

        new AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle(host)
                .setMultiChoiceItems(labels, checked, new DialogInterface.OnMultiChoiceClickListener() {
                    @Override public void onClick(DialogInterface d, int which, boolean isChecked) {
                        checked[which] = isChecked;
                    }
                })
                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        try {
                            org.json.JSONObject all = new org.json.JSONObject(prefs.getString("rules", "{}"));
                            org.json.JSONObject row = new org.json.JSONObject();
                            row.put("js", checked[0] ? 1 : 0);
                            row.put("img", checked[1] ? 1 : 0);
                            row.put("desk", checked[2] ? 1 : 0);
                            row.put("blk", checked[3] ? 1 : 0);
                            all.put(host, row);
                            prefs.edit().putString("rules", all.toString()).apply();
                            toast("Rules saved for " + host);
                            if (active != null) active.web.reload();
                        } catch (Exception e) { toast("Could not save"); }
                    }
                })
                .setNeutralButton("Forget", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        try {
                            org.json.JSONObject all = new org.json.JSONObject(prefs.getString("rules", "{}"));
                            all.remove(host);
                            prefs.edit().putString("rules", all.toString()).apply();
                            toast("Rules cleared for " + host);
                            if (active != null) active.web.reload();
                        } catch (Exception ignored) { }
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showPageTruth() {
        if (pageHosts.isEmpty()) { toast("Open a page first"); return; }

        final java.util.List<String> hosts = new java.util.ArrayList<>(pageHosts.keySet());
        java.util.Collections.sort(hosts, new java.util.Comparator<String>() {
            @Override public int compare(String a, String b) {
                int[] va = pageHosts.get(a), vb = pageHosts.get(b);
                return Integer.compare(vb == null ? 0 : vb[0], va == null ? 0 : va[0]);
            }
        });

        String pageHost = active == null ? null : hostOf(active.url);
        int totalReq = 0, totalBlocked = 0, thirdParty = 0;
        StringBuilder sb = new StringBuilder();
        int shown = 0;
        for (String h : hosts) {
            int[] v = pageHosts.get(h);
            if (v == null) continue;
            totalReq += v[0];
            totalBlocked += v[1];
            boolean party3 = pageHost != null && !h.endsWith(pageHost) && !pageHost.endsWith(h);
            if (party3) thirdParty++;
            if (shown++ < 18) {
                sb.append(v[1] > 0 ? "\u2716 " : "\u2714 ")
                  .append(h)
                  .append("   ").append(v[0]).append(" req")
                  .append(v[1] > 0 ? "  ·  " + v[1] + " blocked" : "")
                  .append("\n");
            }
        }

        String head = (pageHost == null ? "This page" : pageHost) + "\n"
                + totalReq + " requests  ·  " + hosts.size() + " servers"
                + "  ·  " + thirdParty + " third-party\n"
                + totalBlocked + " blocked\n"
                + "————————————————\n\n";

        new AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle("What this page loaded")
                .setMessage(head + sb.toString().trim())
                .setPositiveButton("Close", null)
                .show();
    }

    private void showReportCard() {
        try {
            org.json.JSONObject all = new org.json.JSONObject(prefs.getString("ledger", "{}"));
            if (all.length() == 0) { toast("Nothing recorded yet"); return; }
            long total = 0, totalMs = 0, totalTrackers = 0, totalVisits = 0;
            java.util.List<String> hosts = new java.util.ArrayList<>();
            for (java.util.Iterator<String> it = all.keys(); it.hasNext(); ) hosts.add(it.next());
            final java.util.Map<String, Long> bytes = new java.util.HashMap<>();
            for (String h : hosts) {
                org.json.JSONObject r = all.optJSONObject(h);
                long b = r.optLong("bytes");
                bytes.put(h, b);
                total += b;
                totalMs += r.optLong("ms");
                totalTrackers += r.optLong("trackers");
                totalVisits += r.optLong("visits");
            }
            java.util.Collections.sort(hosts, new java.util.Comparator<String>() {
                @Override public int compare(String a, String b) {
                    return Long.compare(bytes.get(b), bytes.get(a));
                }
            });

            StringBuilder sb = new StringBuilder();
            sb.append("You spent ").append(human(total)).append(" and ")
              .append(money(total)).append(" on ").append(totalVisits)
              .append(" page loads.\n")
              .append(humanTime(totalMs)).append(" of browsing, ")
              .append(totalTrackers).append(" trackers blocked.\n\n");

            int top = 0;
            for (String h : hosts) {
                if (top++ >= 5) break;
                long b = bytes.get(h);
                int pct = total > 0 ? (int) Math.round(b * 100.0 / total) : 0;
                sb.append(h).append("  ").append(pct).append("%  \u00B7  ")
                  .append(human(b)).append("\n");
            }
            if (total > 0 && !hosts.isEmpty()) {
                long first = bytes.get(hosts.get(0));
                int pct = (int) Math.round(first * 100.0 / total);
                sb.append("\n");
                if (pct >= 40) {
                    sb.append("One site is eating ").append(pct)
                      .append("% of your data. Blocking images there would save the most.");
                } else {
                    sb.append("Your data is spread out — no single site dominates.");
                }
            }

            new AlertDialog.Builder(this, R.style.MercyDialog)
                    .setTitle("Report card")
                    .setMessage(sb.toString())
                    .setPositiveButton("Close", null)
                    .setNeutralButton("Save data mode", new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface d, int w) { toggleNoImages(); }
                    })
                    .show();
        } catch (Exception e) { toast("Report unavailable"); }
    }

    private void toggleNoImages() {
        boolean now = !prefs.getBoolean("noImages", false);
        prefs.edit().putBoolean("noImages", now).apply();
        toast("Save data mode " + (now ? "ON — images blocked" : "OFF"));
        if (active != null) active.web.reload();
    }


    /* =========================================================
       privacy proof — the app proves what it sends instead of claiming it
    ========================================================= */
    private String sha256OfFile(String path) {
        try {
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("SHA-256");
            java.io.FileInputStream in = new java.io.FileInputStream(path);
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) md.update(buf, 0, n);
            in.close();
            StringBuilder sb = new StringBuilder();
            for (byte b : md.digest()) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) { return "unavailable"; }
    }

    private String signerSha256() {
        try {
            byte[] cert;
            if (Build.VERSION.SDK_INT >= 28) {
                android.content.pm.PackageInfo pi = getPackageManager().getPackageInfo(
                        getPackageName(), android.content.pm.PackageManager.GET_SIGNING_CERTIFICATES);
                cert = pi.signingInfo.getApkContentsSigners()[0].toByteArray();
            } else {
                android.content.pm.PackageInfo pi = getPackageManager().getPackageInfo(
                        getPackageName(), android.content.pm.PackageManager.GET_SIGNATURES);
                cert = pi.signatures[0].toByteArray();
            }
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("SHA-256");
            StringBuilder sb = new StringBuilder();
            for (byte b : md.digest(cert)) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) { return "unavailable"; }
    }


    /* =========================================================
       crash safety — say what happened, never hide it
    ========================================================= */
    private void reportLastCrash() {
        if (!CrashGuard.hasCrash(this)) return;
        final int crashes = CrashGuard.count(this);
        new AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle("Mercy closed unexpectedly")
                .setMessage("The last session ended with an error"
                        + (crashes > 1 ? " (" + crashes + " times in a row)" : "") + ".\n\n"
                        + "You can read the log, or start in safe mode: one blank tab, "
                        + "JavaScript and blocking at their defaults.")
                .setPositiveButton("View log", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { showDiagnostics(); }
                })
                .setNeutralButton("Safe mode", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        prefs.edit().putString("secLevel", "on")
                                .putBoolean("noImages", false)
                                .putBoolean("configured", true).apply();
                        CrashGuard.clear(MainActivity.this);
                        newTab(HOME);
                        toast("Safe mode: defaults restored");
                    }
                })
                .setNegativeButton("Dismiss", null)
                .show();
    }

    private void showDiagnostics() {
        String log = CrashGuard.read(this);
        String info = "Crashes recorded: " + CrashGuard.count(this) + "\n\n" + log;
        new AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle("Diagnostics")
                .setMessage(info)
                .setPositiveButton("Close", null)
                .setNeutralButton("Clear log", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        CrashGuard.clear(MainActivity.this);
                        toast("Log cleared");
                    }
                })
                .show();
    }


    /* =========================================================
       dev panel — the page, as the browser actually sees it
    ========================================================= */
    private void showDevPanel() {
        if (active == null || active.web == null) { toast("Open a page first"); return; }
        final String[] items = {"Run JavaScript…", "View source", "Storage (localStorage)",
                "Cookies for this site", "Custom user agent", "Block a host", "Clear custom rules"};
        new AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle("Dev panel \u00B7 " + hostOf(active.url))
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        switch (which) {
                            case 0: runJsPrompt(); break;
                            case 1: dumpPage("source"); break;
                            case 2: dumpPage("storage"); break;
                            case 3: showCookies(); break;
                            case 4: askCustomUa(); break;
                            case 5: askBlockHost(); break;
                            case 6: clearCustomRules(); break;
                        }
                    }
                })
                .setNegativeButton("Close", null)
                .show();
    }

    private void runJsPrompt() {
        final EditText in = new EditText(this);
        in.setHint("document.title");
        in.setTextSize(13);
        new AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle("Run JavaScript")
                .setView(in)
                .setPositiveButton("Run", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        final String code = in.getText().toString();
                        if (code.trim().isEmpty()) return;
                        active.web.evaluateJavascript("(function(){try{return String(eval(" +
                                org.json.JSONObject.quote(code) + "))}catch(e){return 'Error: '+e}})()",
                                new android.webkit.ValueCallback<String>() {
                            @Override public void onReceiveValue(String value) {
                                showText("Result", unquote(value));
                            }
                        });
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void dumpPage(final String kind) {
        String js = kind.equals("source")
                ? "document.documentElement.outerHTML"
                : "(function(){var o={};for(var i=0;i<localStorage.length;i++){var k=localStorage.key(i);o[k]=localStorage.getItem(k)}return JSON.stringify(o,null,1)})()";
        active.web.evaluateJavascript(js, new android.webkit.ValueCallback<String>() {
            @Override public void onReceiveValue(String value) {
                String text = unquote(value);
                if (text.length() > 60000) text = text.substring(0, 60000) + "\n\n… truncated";
                showText(kind.equals("source") ? "Page source" : "localStorage", text);
            }
        });
    }

    private void showCookies() {
        try {
            String c = CookieManager.getInstance().getCookie(active.url);
            showText("Cookies", c == null || c.isEmpty() ? "No cookies for this site." : c);
        } catch (Exception e) { toast("Cookies unavailable"); }
    }

    private void askCustomUa() {
        final EditText in = new EditText(this);
        in.setText(prefs.getString("customUA", ""));
        in.setHint("leave empty for the default");
        in.setTextSize(12);
        new AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle("Custom user agent")
                .setView(in)
                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        prefs.edit().putString("customUA", in.getText().toString().trim()).apply();
                        toast("User agent saved");
                        if (active != null && active.web != null) active.web.reload();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void askBlockHost() {
        final EditText in = new EditText(this);
        in.setHint("ads.example.com");
        in.setTextSize(13);
        new AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle("Block a host")
                .setMessage("Added to the built-in list, on this device only.")
                .setView(in)
                .setPositiveButton("Add", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        String h = in.getText().toString().trim().toLowerCase();
                        if (h.isEmpty()) return;
                        try {
                            org.json.JSONArray arr = new org.json.JSONArray(prefs.getString("customBlock", "[]"));
                            arr.put(h);
                            prefs.edit().putString("customBlock", arr.toString()).apply();
                            toast("Blocked " + h);
                            if (active != null && active.web != null) active.web.reload();
                        } catch (Exception ignored) { }
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void clearCustomRules() {
        prefs.edit().remove("customBlock").remove("customUA").apply();
        toast("Custom rules cleared");
        if (active != null && active.web != null) active.web.reload();
    }

    private void showText(String title, String body) {
        android.widget.ScrollView sv = new android.widget.ScrollView(this);
        TextView tv = new TextView(this);
        tv.setText(body == null || body.isEmpty() ? "(empty)" : body);
        tv.setTextSize(11f);
        tv.setTypeface(android.graphics.Typeface.MONOSPACE);
        tv.setTextColor(0xFFE6E6EA);
        tv.setPadding(dp(14), dp(12), dp(14), dp(12));
        sv.addView(tv);
        new AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle(title)
                .setView(sv)
                .setPositiveButton("Close", null)
                .setNeutralButton("Copy", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        android.content.ClipboardManager cm =
                                (android.content.ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                        if (cm != null) cm.setPrimaryClip(android.content.ClipData.newPlainText(title, body));
                        toast("Copied");
                    }
                })
                .show();
    }

    private String unquote(String v) {
        if (v == null) return "";
        try {
            if (v.startsWith("\"")) return new org.json.JSONArray("[" + v + "]").getString(0);
        } catch (Exception ignored) { }
        return v;
    }


    /** A screen that answers "is this build healthy?" without anyone's help. */
    private void runSelfTest() {
        StringBuilder out = new StringBuilder();
        out.append("version      ").append(versionName()).append("\n");
        out.append("package      ").append(getPackageName()).append("\n");
        out.append("engine       system WebView ").append(android.webkit.WebSettings.getDefaultUserAgent(this).split("Chrome/")[1].split(" ")[0]).append("\n\n");
        out.append("header       ").append(urlBar != null ? "native, ready" : "NOT built").append("\n");
        out.append("tabs         ").append(tabs.size()).append("\n");
        out.append("ad block     ").append(BLOCK.size()).append(" networks + ")
           .append(customBlockCount()).append(" custom\n");
        out.append("budget       ").append(prefs.getLong("budgetMb", 200L)).append(" MB\n");
        out.append("security     ").append(secLevel()).append("\n");
        out.append("https only   ").append(httpsOnly() ? "on" : "off").append("\n");
        out.append("javascript   ").append(jsOn() ? "on" : "off").append("\n\n");
        out.append("What to check on screen:\n");
        out.append("• the header shows the engine chip on a new tab\n");
        out.append("• typing shows suggestions, Enter opens a page\n");
        out.append("• the tab number opens the list\n");
        out.append("• the menu sheet opens from the three dots\n");
        showText("Self test", out.toString());
    }

    private int customBlockCount() {
        try { return new org.json.JSONArray(prefs.getString("customBlock", "[]")).length(); }
        catch (Exception e) { return 0; }
    }

    private String versionName() {
        try { return getPackageManager().getPackageInfo(getPackageName(), 0).versionName; }
        catch (Exception e) { return "?"; }
    }

    private void showProof() {
        toast("Reading the app...");
        new Thread(new Runnable() {
            @Override public void run() {
                final String apkHash = sha256OfFile(getPackageCodePath());
                final String signer = signerSha256();
                String ver;
                try {
                    ver = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
                } catch (Exception e) { ver = "?"; }

                final StringBuilder sb = new StringBuilder();
                sb.append("What Mercy sent by itself\n");
                try {
                    org.json.JSONArray arr = new org.json.JSONArray(prefs.getString("appRequests", "[]"));
                    if (arr.length() == 0) {
                        sb.append("  nothing \u2014 zero requests\n");
                    } else {
                        for (int i = 0; i < arr.length() && i < 6; i++) {
                            org.json.JSONObject o = arr.getJSONObject(i);
                            long mins = (System.currentTimeMillis() - o.optLong("ts")) / 60000;
                            sb.append("  ").append(o.optString("host"))
                              .append("  \u00B7  ").append(o.optString("purpose"))
                              .append("  \u00B7  ").append(mins < 1 ? "just now" : mins + " min ago")
                              .append("\n");
                        }
                    }
                } catch (Exception e) { sb.append("  log unavailable\n"); }

                sb.append("\nThat is the whole list: no analytics, no crash reporting,\n")
                  .append("no advertising SDK, no account. The pages you open are yours.\n")
                  .append("\nThis build\n")
                  .append("  version      ").append(ver).append("\n")
                  .append("  APK SHA-256  ").append(apkHash).append("\n")
                  .append("  signer       ").append(signer).append("\n")
                  .append("\nCompare the APK hash with the .sha256 file published\n")
                  .append("next to the release. Match means this is exactly the\n")
                  .append("file built from the source you can read.\n");

                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        new AlertDialog.Builder(MainActivity.this)
                                .setTitle("Privacy proof")
                                .setMessage(sb.toString())
                                .setPositiveButton("Close", null)
                                .setNeutralButton("Copy hash", new DialogInterface.OnClickListener() {
                                    @Override public void onClick(DialogInterface d, int w) {
                                        android.content.ClipboardManager cm =
                                                (android.content.ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                                        if (cm != null) {
                                            cm.setPrimaryClip(android.content.ClipData.newPlainText("apk sha256", apkHash));
                                            toast("Hash copied");
                                        }
                                    }
                                })
                                .show();
                    }
                });
            }
        }).start();
    }


    /** the home page can still talk to the app */
    public class HomeBridge {
        @android.webkit.JavascriptInterface public void open(final String what) {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    if ("ledger".equals(what)) showLedger();
                    else if ("report".equals(what)) showReportCard();
                    else if ("offline".equals(what)) showOffline();
                    else if ("proof".equals(what)) showProof();
                    else if ("free".equals(what)) freeMemory();
                    else if ("data".equals(what)) toggleNoImages();
                    else if ("read".equals(what)) readAloud();
                    else if ("rules".equals(what)) openSiteRules();
                }
            });
        }
        @android.webkit.JavascriptInterface public void estimate(final String url) {
            runOnUiThread(new Runnable() { @Override public void run() { estimateLink(url); } });
        }
    }

    private void showLedger() {
        try {
            org.json.JSONObject all = new org.json.JSONObject(prefs.getString("ledger", "{}"));
            if (all.length() == 0) { toast("No pages recorded yet"); return; }

            java.util.List<String> hosts = new java.util.ArrayList<>();
            for (java.util.Iterator<String> it = all.keys(); it.hasNext(); ) hosts.add(it.next());
            final long[] bytesArr = new long[hosts.size()];
            final String[] rows = new String[hosts.size()];
            long totalBytes = 0, totalMs = 0, totalTrackers = 0;

            java.util.List<Integer> order = new java.util.ArrayList<>();
            for (int i = 0; i < hosts.size(); i++) order.add(i);
            for (int i = 0; i < hosts.size(); i++) {
                bytesArr[i] = all.optJSONObject(hosts.get(i)).optLong("bytes");
            }
            java.util.Collections.sort(order, new java.util.Comparator<Integer>() {
                @Override public int compare(Integer a, Integer b) {
                    return Long.compare(bytesArr[b], bytesArr[a]);
                }
            });

            StringBuilder sb = new StringBuilder();
            int shown = 0;
            for (int k = 0; k < order.size(); k++) {
                int i = order.get(k);
                org.json.JSONObject row = all.optJSONObject(hosts.get(i));
                long b = row.optLong("bytes"), m = row.optLong("ms"),
                     v = row.optLong("visits"), tr = row.optLong("trackers");
                totalBytes += b; totalMs += m; totalTrackers += tr;
                if (shown < 12) {
                    sb.append(hosts.get(i)).append("\n   ")
                      .append(human(b)).append(" · ").append(money(b))
                      .append(" · ").append(humanTime(m))
                      .append(" · ").append(v).append(" visits")
                      .append(" · ").append(tr).append(" trackers\n\n");
                    shown++;
                }
            }

            String header = "Total " + human(totalBytes) + "  ·  " + money(totalBytes)
                    + "\n" + humanTime(totalMs) + " browsing  ·  " + totalTrackers
                    + " trackers blocked\n\n"
                    + "Tariff: \u20B9" + tariffPerMb() + " per MB\n"
                    + "————————————————\n\n";

            new AlertDialog.Builder(this, R.style.MercyDialog)
                    .setTitle("Data ledger")
                    .setMessage(header + sb.toString().trim())
                    .setPositiveButton("Close", null)
                    .setNeutralButton("Set tariff", new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface d, int w) { askTariff(); }
                    })
                    .show();
        } catch (Exception e) { toast("Ledger unavailable"); }
    }

    private void askTariff() {
        final EditText input = new EditText(this);
        input.setText(String.valueOf(tariffPerMb()));
        input.setHint("rupees per MB, e.g. 0.01");
        input.setTextSize(14);
        new AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle("Data tariff")
                .setMessage("Your plan's price per MB. \u20B910/GB = 0.01")
                .setView(input)
                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        prefs.edit().putString("tariff", input.getText().toString().trim()).apply();
                        toast("Tariff saved");
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showSiteInfo() {
        String url = active == null ? "" : active.url;
        boolean https = url.startsWith("https://");
        boolean plain = url.startsWith("http://");
        String level = secLevel().toUpperCase();

        String security = https ? "\uD83D\uDD12 HTTPS — this page is encrypted"
                : plain ? "\u26A0 Not encrypted — HTTPS-only is upgrading it"
                : "Internal page";

        String msg = security
                + "\n\nAddress\n" + url
                + "\n\nSecurity level: " + level
                + (active != null && active.incognito ? "\nThis tab: INCOGNITO — nothing is saved" : "")
                + (active != null && active.desktop ? "\nMode: desktop site" : "")
                + "\n\nThis page\n"
                + (rxAtPageStart > 0 && rxBytes() > rxAtPageStart
                        ? human(rxBytes() - rxAtPageStart) + " · " + money(rxBytes() - rxAtPageStart)
                        : "measuring…")
                + " · " + pageTrackers.size() + " trackers here"
                + "\n\nBlocked in this session\n" + blockedCount + " ad & tracker requests"
                + "\n\nProtection"
                + "\n• Ad & tracker blocking: " + (adblockOn() ? "ON" : "OFF")
                + "\n• HTTPS-only: " + (httpsOnly() ? "ON" : "OFF")
                + "\n• JavaScript: " + (jsOn() ? "ON" : "OFF")
                + "\n• Third-party cookies: " + (secLevel().equals("off") ? "allowed" : "blocked")
                + "\n• Mixed content: blocked"
                + "\n• Camera / microphone: blocked"
                + "\n• Filter list: " + BLOCK.size() + " networks";

        new AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle("Site information")
                .setMessage(msg)
                .setPositiveButton("Close", null)
                .setNeutralButton(jsOn() ? "Turn JS off" : "Turn JS on",
                        new DialogInterface.OnClickListener() {
                            @Override public void onClick(DialogInterface d, int w) {
                                prefs.edit().putBoolean("jsForceOn", !jsOn()).apply();
                                toast("JavaScript " + (jsOn() ? "on" : "off"));
                                if (active != null) active.web.reload();
                            }
                        })
                .show();
    }

    private void showList(final String key, String emptyMsg) {
        JSONArray arr = readArray(key);
        if (arr.length() == 0) { toast(emptyMsg); return; }
        final String[] urls = new String[arr.length()];
        final String[] titles = new String[arr.length()];
        long listBytes = 0;
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            urls[i] = o == null ? "" : o.optString("url");
            titles[i] = o == null ? "" : o.optString("title");
            String host = hostOf(urls[i]);
            org.json.JSONObject row = host == null ? null : ledgerRow(host);
            if (row != null) {
                long b = row.optLong("bytes");
                if (b > 0) {
                    titles[i] = titles[i] + "  \u00B7  " + human(b) + "  \u00B7  " + money(b);
                    listBytes += b;
                }
            }
        }
        new AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle((key.equals("bookmarks") ? "Bookmarks" : "History")
                        + (listBytes > 0 ? "  \u00B7  " + human(listBytes) + "  \u00B7  " + money(listBytes) : ""))
                .setItems(titles, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) { go(urls[which]); }
                })
                .setNegativeButton("Close", null)
                .show();
    }

    /* =========================================================
       menu
    ========================================================= */
    /* =========================================================
       M1 — grouped sheet, slides in from the right
    ========================================================= */
    private void showMenu() {
        try { buildMenu(); }
        catch (Throwable t) { toast("Menu error: " + t.getClass().getSimpleName()); }
    }

    private void buildMenu() {
        final android.app.AlertDialog d = new android.app.AlertDialog.Builder(
                this, R.style.MercyDialog).create();
        d.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.HORIZONTAL);

        View scrim = new View(this);
        scrim.setBackgroundColor(0xB3000000);
        scrim.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { d.dismiss(); }
        });
        root.addView(scrim, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));

        android.widget.ScrollView sv = new android.widget.ScrollView(this);
        LinearLayout sheet = new LinearLayout(this);
        sheet.setOrientation(LinearLayout.VERTICAL);
        sheet.setBackgroundColor(0xFF0B0B0D);
        sv.addView(sheet, new android.widget.FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // header
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.VERTICAL);
        head.setBackgroundColor(0xFF0B0B0D);
        head.setPadding(dp(14), dp(18), dp(14), dp(10));
        TextView kicker = new TextView(this);
        kicker.setText("MERCY GX");
        kicker.setTextSize(8.5f);
        kicker.setLetterSpacing(0.2f);
        kicker.setTextColor(0xFF5C5C66);
        String h = active == null ? "" : hostOf(active.url);

        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        titleRow.setGravity(android.view.Gravity.CENTER_VERTICAL);
        titleRow.setPadding(0, dp(6), 0, 0);

        View ring = new View(this);
        ring.setBackground(budgetRingDrawable());
        LinearLayout.LayoutParams ringLp = new LinearLayout.LayoutParams(dp(22), dp(22));
        ringLp.setMarginEnd(dp(10));
        titleRow.addView(ring, ringLp);

        TextView host = new TextView(this);
        host.setText(h == null ? "New tab" : h);
        host.setTextSize(12.5f);
        host.setTextColor(0xFFF4F4F6);
        titleRow.addView(host, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView pct = new TextView(this);
        long today = todayBytes();
        long budget = budgetBytes();
        int p = (int) Math.min(100, today * 100 / budget);
        pct.setText(today > budget ? "OVER" : p + "%");
        pct.setTextSize(10f);
        pct.setTextColor(today > budget ? 0xFFFF5C5C : (p >= 60 ? 0xFFFFB020 : 0xFFA06BFF));
        titleRow.addView(pct);

        head.addView(kicker);
        head.addView(titleRow);
        sheet.addView(head);

        addGroup(sheet, "THIS PAGE", d);
        addItem(sheet, "\u25E7", "What this page loaded", String.valueOf(pageHosts.size()), d,
                new Runnable() { public void run() { showPageTruth(); } });
        addItem(sheet, "\u2193", "Save page offline", "", d,
                new Runnable() { public void run() { saveOffline(); } });
        addItem(sheet, "\u25C8", "Site rules", "", d,
                new Runnable() { public void run() { openSiteRules(); } });
        addItem(sheet, "\u25A4", "Desktop site", active != null && active.desktop ? "ON" : "OFF", d,
                new Runnable() { public void run() { toggleDesktop(); } });
        addItem(sheet, "\u25C9", "Read this page aloud", voiceLang().startsWith("hi") ? "HINDI" : "ENGLISH", d,
                new Runnable() { public void run() { readAloud(); } });

        addGroup(sheet, "NETWORK", d);
        addItem(sheet, "\u26A1", "Free memory", "freezes hidden tabs", d,
                new Runnable() { public void run() { freeMemory(); } });
        addItem(sheet, "\u2637", "Restrict background data", "opens settings", d,
                new Runnable() { public void run() { openDataSettings(); } });

        addGroup(sheet, "DATA", d);
        addItem(sheet, "\u25F4", "Data budget", prefs.getLong("budgetMb", 200L) + " MB", d,
                new Runnable() { public void run() { askBudget(); } });
        addItem(sheet, "\u25A6", "Data ledger", "", d,
                new Runnable() { public void run() { showLedger(); } });
        addItem(sheet, "\u25CD", "Report card", "", d,
                new Runnable() { public void run() { showReportCard(); } });
        addItem(sheet, "\u25A3", "Save data mode", prefs.getBoolean("noImages", false) ? "ON" : "OFF", d,
                new Runnable() { public void run() { toggleNoImages(); } });
        addItem(sheet, "\u2318", "Offline pages", "", d,
                new Runnable() { public void run() { showOffline(); } });

        addGroup(sheet, "PRIVACY", d);
        addItem(sheet, "\u25C8", "Security level", secLevel().toUpperCase(), d,
                new Runnable() { public void run() { pickSecurityLevel(); } });
        addItem(sheet, "\u2713", "Privacy proof", "", d,
                new Runnable() { public void run() { showProof(); } });
        addItem(sheet, "\u26A0", "Diagnostics", "", d,
                new Runnable() { public void run() { showDiagnostics(); } });
        addItem(sheet, "\u2715", "Clear browsing data", "", d,
                new Runnable() { public void run() { clearData(); } });

        addGroup(sheet, "APP", d);
        addItem(sheet, "\u2713", "Self test", "health", d,
                new Runnable() { public void run() { runSelfTest(); } });
        addItem(sheet, "\u2318", "Dev panel", "console", d,
                new Runnable() { public void run() { showDevPanel(); } });
        addItem(sheet, "\u2620", "Panic wipe \u2014 erase everything", "hold", d,
                new Runnable() { public void run() { confirmPanic(); } });
        addItem(sheet, "\uFF0B", "New tab", "", d,
                new Runnable() { public void run() { newTab(HOME); } });
        addItem(sheet, "\u25D0", "New incognito tab", "", d,
                new Runnable() { public void run() { newTab(HOME, true); } });
        addItem(sheet, "\u2605", "Bookmark this page", "", d,
                new Runnable() { public void run() { toggleBookmark(); } });
        addItem(sheet, "\u25F7", "Bookmarks", "", d,
                new Runnable() { public void run() { showList("bookmarks", "No bookmarks yet"); } });
        addItem(sheet, "\u25F7", "History", "", d,
                new Runnable() { public void run() { showList("history", "History is empty"); } });
        addItem(sheet, "\u2302", "Settings", "", d,
                new Runnable() { public void run() { newTab(HOME); } });
        addItem(sheet, "\u25CE", "Mercy search URL", "", d,
                new Runnable() { public void run() { askMercyUrl(); } });
        addItem(sheet, "\u21BB", "Check for updates", "", d,
                new Runnable() { public void run() { Updater.check(MainActivity.this, false); } });
        addItem(sheet, "\u24D8", "About Mercy GX", "", d,
                new Runnable() { public void run() { about(); } });

        // footer totals
        TextView foot = new TextView(this);
        foot.setText("TODAY " + human(todayBytes()) + "  \u00B7  " + money(todayBytes())
                + "\nNothing here leaves your phone.");
        foot.setTextSize(9f);
        foot.setPadding(dp(14), dp(14), dp(14), dp(24));
        foot.setTextColor(0xFF5C5C66);
        sheet.addView(foot);

        root.addView(sv, new LinearLayout.LayoutParams(dp(272), ViewGroup.LayoutParams.MATCH_PARENT));
        d.setView(root);
        d.show();
        android.view.Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0x00000000));
            w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            w.setDimAmount(0f);
        }
    }

    /* real, not decorative: this actually releases RAM */
    /* =========================================================
       panic wipe — cache, cookies, storage, history, ledger, files
    ========================================================= */
    /** The menu row asks once; the wipe itself is instant and final. */
    private void confirmPanic() {
        new AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle("Panic wipe")
                .setMessage("This erases cache, cookies, storage, history, bookmarks, "
                        + "the data ledger and every offline page, then closes the app. "
                        + "It cannot be undone.")
                .setPositiveButton("Erase everything", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { panicWipe(); }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void panicWipe() {
        try {
            android.webkit.CookieManager cm = android.webkit.CookieManager.getInstance();
            cm.removeAllCookies(null);
            cm.flush();
            android.webkit.WebStorage.getInstance().deleteAllData();
            for (Tab t : tabs) {
                if (t.web == null) continue;
                t.web.clearCache(true);
                t.web.clearHistory();
                t.web.clearFormData();
                t.web.clearSslPreferences();
            }
            prefs.edit().clear().apply();
            deleteTree(new java.io.File(getFilesDir(), "offline"));
            CrashGuard.clear(this);
        } catch (Exception ignored) { }
        toast("Burned. Everything is gone.");
        finishAffinity();
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override public void run() { Process.killProcess(Process.myPid()); }
        }, 400);
    }

    private void deleteTree(java.io.File f) {
        if (f == null || !f.exists()) return;
        if (f.isDirectory()) {
            java.io.File[] kids = f.listFiles();
            if (kids != null) for (java.io.File k : kids) deleteTree(k);
        }
        f.delete();
    }

    /* what will this link cost before you open it */
    private void estimateLink(String raw) {
        final String url = raw.startsWith("http") ? raw : "https://" + raw;
        toast("Checking " + url);
        new Thread(new Runnable() {
            @Override public void run() {
                long size = -1;
                String type = "";
                HttpURLConnection c = null;
                try {
                    c = (HttpURLConnection) new URL(url).openConnection();
                    c.setRequestMethod("HEAD");
                    c.setConnectTimeout(8000);
                    c.setReadTimeout(8000);
                    c.setRequestProperty("User-Agent", "MercyGX-App");
                    c.connect();
                    size = c.getContentLengthLong();
                    type = String.valueOf(c.getContentType());
                } catch (Exception ignored) {
                } finally { if (c != null) c.disconnect(); }

                final long fSize = size;
                final String fType = type;
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        String body;
                        if (fSize <= 0) {
                            body = "The server did not say how big this page is.\n\n"
                                 + "Rough guide: news ~2 MB, video pages ~15 MB, shopping ~5 MB.";
                        } else {
                            body = "HTML only: " + human(fSize) + " · " + money(fSize) + "\n\n"
                                 + "A real visit also pulls images, scripts and fonts — usually "
                                 + "8 to 20 times this. Budget roughly "
                                 + human(fSize * 12) + " · " + money(fSize * 12) + ".";
                        }
                        new AlertDialog.Builder(MainActivity.this)
                                .setTitle("Cost estimate")
                                .setMessage(url + "\n" + (fType.isEmpty() ? "" : fType + "\n") + "\n" + body)
                                .setPositiveButton("Open anyway", new DialogInterface.OnClickListener() {
                                    @Override public void onClick(DialogInterface d, int w) { go(url); }
                                })
                                .setNegativeButton("Cancel", null)
                                .show();
                    }
                });
            }
        }).start();
    }

    private void freeMemory() {
        int freed = 0;
        for (Tab t : new java.util.ArrayList<>(tabs)) {
            if (t == active || t.frozen) continue;
            freeze(t);
            freed++;
        }
        for (Tab t : tabs) {
            if (t.web != null) { t.web.clearCache(false); break; }
        }
        toast(freed == 0 ? "Nothing to free — only this tab is open"
                : freed + (freed == 1 ? " tab frozen, memory released" : " tabs frozen, memory released"));
    }

    private void openDataSettings() {
        try {
            startActivity(new Intent(android.provider.Settings.ACTION_DATA_USAGE_SETTINGS));
        } catch (Exception e) {
            try { startActivity(new Intent(android.provider.Settings.ACTION_WIRELESS_SETTINGS)); }
            catch (Exception ignored) { toast("Settings not available on this device"); }
        }
    }

    /** the user's own monthly pack, in MB — never a guess */
    private long budgetBytes() {
        long mb = prefs.getLong("budgetMb", 200L);
        if (mb <= 0) mb = 200L;
        return mb * 1024L * 1024L;
    }

    private void askBudget() {
        final String[] labels = {"200 MB", "500 MB", "1 GB", "2 GB", "5 GB", "Custom…"};
        final long[] values = {200, 500, 1024, 2048, 5120, -1};
        long current = prefs.getLong("budgetMb", 200L);
        int checked = 0;
        for (int i = 0; i < values.length; i++) if (values[i] == current) checked = i;
        new AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle("Data budget")
                .setMessage("The ring and the ledger use this number.")
                .setSingleChoiceItems(labels, checked, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        if (values[which] > 0) {
                            prefs.edit().putLong("budgetMb", values[which]).apply();
                            d.dismiss();
                            pushBudget();
                            toast("Budget set to " + labels[which]);
                        } else {
                            d.dismiss();
                            askBudgetCustom();
                        }
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void askBudgetCustom() {
        final EditText in = new EditText(this);
        in.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        in.setHint("MB, for example 750");
        new AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle("Budget in MB")
                .setView(in)
                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        try {
                            long mb = Long.parseLong(in.getText().toString().trim());
                            if (mb > 0) {
                                prefs.edit().putLong("budgetMb", mb).apply();
                                pushBudget();
                                toast("Budget set to " + mb + " MB");
                            }
                        } catch (Exception ignored) { }
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private long todayBytes() {
        try {
            String day = new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
                    .format(new java.util.Date());
            return new org.json.JSONObject(prefs.getString("daily", "{}")).optLong(day);
        } catch (Exception e) { return 0; }
    }

    /** the same ring as the header, drawn natively for the sheet */
    private android.graphics.drawable.Drawable budgetRingDrawable() {
        long today = todayBytes();
        long budget = budgetBytes();
        final int p = (int) Math.min(100, today * 100 / budget);
        final int colour = today > budget ? 0xFFFF5C5C : (p >= 60 ? 0xFFFFB020 : 0xFFA06BFF);
        return new android.graphics.drawable.Drawable() {
            @Override public void draw(android.graphics.Canvas c) {
                android.graphics.Paint paint = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
                android.graphics.RectF box = new android.graphics.RectF(0, 0, getBounds().width(), getBounds().height());
                paint.setStyle(android.graphics.Paint.Style.STROKE);
                paint.setStrokeWidth(dp(3));
                paint.setColor(0xFF26262C);
                c.drawArc(box, 0, 360, false, paint);
                paint.setColor(colour);
                c.drawArc(box, -90, 360f * p / 100f, false, paint);
            }
            @Override public void setAlpha(int alpha) { }
            @Override public void setColorFilter(android.graphics.ColorFilter cf) { }
            @Override public int getOpacity() { return android.graphics.PixelFormat.OPAQUE; }
        };
    }

    private void addGroup(LinearLayout parent, String title, final android.app.Dialog d) {
        TextView t = new TextView(this);
        t.setText(title);
        t.setTextSize(8.5f);
        t.setLetterSpacing(0.18f);
        t.setTextColor(0xFF5C5C66);
        t.setPadding(dp(14), dp(13), dp(14), dp(5));
        parent.addView(t);
    }

    private void addItem(LinearLayout parent, String glyph, String label, String value,
                         final android.app.Dialog d, final Runnable action) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        row.setPadding(dp(14), dp(11), dp(14), dp(11));
        row.setBackgroundColor(0xFF0B0B0D);

        TextView g = new TextView(this);
        g.setText(glyph);
        g.setTextSize(11f);
        g.setTextColor(0xFF8B8B95);
        g.setWidth(dp(18));

        TextView l = new TextView(this);
        l.setText(label);
        l.setTextSize(12f);
        l.setTextColor(0xFFF4F4F6);
        l.setPadding(dp(6), 0, 0, 0);

        row.addView(g);
        row.addView(l, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        if (value != null && !value.isEmpty()) {
            TextView v = new TextView(this);
            v.setText(value);
            v.setTextSize(9f);
            v.setTextColor(0xFF5C5C66);
            row.addView(v);
        }

        row.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) {
                d.dismiss();
                view.postDelayed(action, 120);
            }
        });
        parent.addView(row);

        View line = new View(this);
        line.setBackgroundColor(0x14FFFFFF);
        parent.addView(line, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1));
    }

    /* ---------------- security level + data clearing ---------------- */
    private String secLevel() {
        String v = prefs.getString("secLevel", "on");
        return (v.equals("off") || v.equals("on") || v.equals("pro")) ? v : "on";
    }
    private boolean adblockOn() { return !secLevel().equals("off"); }
    private boolean httpsOnly() { return !secLevel().equals("off"); }
    private boolean jsOn() { return !secLevel().equals("pro") || prefs.getBoolean("jsForceOn", false); }

    private void clearData() {
        new AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle("Clear browsing data")
                .setMessage("History, cookies and cache will be removed. "
                        + "Your ledger, offline pages and bookmarks stay.")
                .setPositiveButton("Clear", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        prefs.edit().putString("history", "[]").apply();
                        try {
                            android.webkit.CookieManager cm = android.webkit.CookieManager.getInstance();
                            cm.removeAllCookies(null);
                            cm.flush();
                            android.webkit.WebStorage.getInstance().deleteAllData();
                            for (Tab t : tabs) {
                                if (t.web != null) {
                                    t.web.clearCache(true);
                                    t.web.clearHistory();
                                    t.web.clearFormData();
                                }
                            }
                        } catch (Exception ignored) { }
                        toast("Browsing data cleared");
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void about() {
        String ver;
        try { ver = getPackageManager().getPackageInfo(getPackageName(), 0).versionName; }
        catch (Exception e) { ver = "?"; }
        new AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle("Mercy GX")
                .setMessage("Version " + ver + "\n\n"
                        + "Mercy Core \u2014 hardened system WebView\n"
                        + "The engine is Android's own WebView. We do not claim otherwise; "
                        + "what we do is strip it down: HTTPS-only, mixed content blocked, "
                        + BLOCK.size() + " ad and tracker networks refused, third-party "
                        + "cookies isolated, no telemetry of any kind.\n\n"
                        + "What that buys you: no analytics, no account, no crash uploads, "
                        + "and a privacy screen that lists every request this app makes.\n\n"
                        + "Mercy and the Mercy mark are trademarks of Sk Inventor.")
                .setPositiveButton("Close", null)
                .setNeutralButton("Privacy proof", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { showProof(); }
                })
                .show();
    }

    private void pickSecurityLevel() {
        final String[] levels = {"off", "on", "pro"};
        String[] labels = {
                "Off — no blocking at all",
                "On — ad-block, HTTPS-only, cookies isolated (recommended)",
                "Pro — everything in On, plus JavaScript off"};
        int checked = secLevel().equals("off") ? 0 : secLevel().equals("pro") ? 2 : 1;
        new AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle("Security level")
                .setSingleChoiceItems(labels, checked, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        prefs.edit().putString("secLevel", levels[which])
                                .putBoolean("jsForceOn", false).apply();
                        d.dismiss();
                        toast("Security level: " + levels[which].toUpperCase());
                        for (Tab t : tabs) t.web.reload();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void toggleDesktop() {
        if (active == null) return;
        active.desktop = !active.desktop;
        WebSettings st = active.web.getSettings();
        if (active.desktop) {
            st.setUserAgentString("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
                    + "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36");
            st.setUseWideViewPort(true);
            st.setLoadWithOverviewMode(true);
        } else {
            st.setUserAgentString("Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 "
                    + "(KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36");
        }
        active.web.reload();
        toast("Desktop site " + (active.desktop ? "on" : "off"));
    }

    private boolean isBlocked(Uri u) {
        if (u == null || u.getHost() == null) return false;
        String host = u.getHost().toLowerCase();
        try {
            org.json.JSONArray custom = new org.json.JSONArray(prefs.getString("customBlock", "[]"));
            for (int i = 0; i < custom.length(); i++) {
                String h = custom.optString(i, "");
                if (!h.isEmpty() && (host.equals(h) || host.endsWith("." + h))) return true;
            }
        } catch (Exception ignored) { }
        for (String h : BLOCK) {
            if (host.equals(h) || host.endsWith("." + h)) return true;
        }
        return false;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private void toast(String m) { Toast.makeText(this, m, Toast.LENGTH_SHORT).show(); }

    private void hideKeyboard() {
        InputMethodManager im = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (im != null && getCurrentFocus() != null) {
            im.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
        }
    }

    /* =========================================================
       system back
    ========================================================= */
    @Override
    public void onBackPressed() {
        if (active != null && active.web.canGoBack()) { active.web.goBack(); return; }
        if (tabs.size() > 1) { closeTab(active); return; }
        if (active != null && !active.url.equals(HOME)) { active.web.loadUrl(HOME); return; }
        super.onBackPressed();
    }

    @Override protected void onPause() { super.onPause(); if (active != null) active.web.onPause(); }
    @Override protected void onResume() { super.onResume(); if (active != null) active.web.onResume(); }

    @Override
    protected void onDestroy() {
        try { if (tts != null) { tts.stop(); tts.shutdown(); } } catch (Exception ignored) { }
        for (Tab t : tabs) {
            if (t.web == null) continue;
            container.removeView(t.web);
            t.web.destroy();
        }
        tabs.clear();
        super.onDestroy();
    }
}
