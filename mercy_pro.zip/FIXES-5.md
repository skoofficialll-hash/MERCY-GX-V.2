# Tester round 3 — what was actually broken

## 1. "Search engine does not work, it only shows the 713 sites" — true, and worse
The search page opened on a SITES tab built from the bundled address list, and the WEB
tab was not a search either: it printed two invented rows, `"<query> login"` and
`"<query> news"`, with made-up data estimates ("≈ 240 KB"). No engine was ever called.
Now there is one list, the way a browser does it:
- **first row: "Search the web for «query»" — pressing it goes to the chosen engine**;
- below it, matches from the phone's site list, under "ON THIS PHONE";
- the invented rows are gone.
The SITES / WEB switch is gone with them, so there is no second place to look.

## 2. "Desktop site does not work like other browsers, and there is no tablet site"
There were two faults. The user-agent was only set when the engine was built, so the
toggle changed a flag and nothing else; and the mode was forgotten on every restart.
Now there is one setting — `uaMode` — with three values: **mobile, tablet, desktop**.
It is applied to the engine, remembered across restarts, and reloads the page in place.
The menu has two honest rows: **Desktop site** and **Tablet site**, each showing ON or
OFF, and tapping again returns to mobile. The row is no longer hidden on large screens.

## 3. "The layout stays mobile on every device"
The interface had no breakpoint at all. Added: at 720 px the column widens to 900 px,
headings and chips scale up, the language grid goes to four columns, rows get taller
touch targets; at 1000 px it widens to 1040 px. Verified at 320 px and 800 px: no
horizontal overflow on any of the four pages, no JavaScript errors.

## 4. "Duplicate, unnecessary buttons"
Previous round removed the repeated glyphs. This round removed the duplicate control
itself: the search screen had its own SITES/WEB switch while the app already had an
engine picker — two controls for one idea. One list, one control.

## 5. "No loading animation, no skeleton"
The skeleton exists in code (`showSkeleton()` on page start, `hideSkeleton()` on
finish). If it does not appear on your device, the cause is that a page which fails
immediately never reaches `onPageFinished` in time to hide it, or the skeleton is
painted under the engine view. This one needs a device run to confirm — tell me which
phone and whether you see a white flash, a black screen or nothing at all.

## Not verifiable here
No JDK / Android SDK in this environment, so no APK. Checks that did run: all 17 Java
files parse, the manifest and every XML resource are valid, no resource is missing, the
`UiHash` the app compares at launch matches the shipped `ui.html`, and all four HTML
pages load with zero errors at 320 px and 800 px.
