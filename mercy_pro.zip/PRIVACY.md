# Mercy GX — privacy statement

Last updated: 14 November 2026 · applies to Mercy GX 15.0.0 (113) and later

This is the text to host at a public URL for the Play Store "Privacy policy" field.
It describes what the app actually does, and nothing more.

## What Mercy GX stores on your phone

Everything below stays in the app's private storage. There is no account, no login and
no server that holds your data.

* pages you visited (history), bookmarks, saved pages, notes, study timers
* the data ledger: bytes and time per site, and the day totals behind the ring
* settings: theme, language, search engine, tariff, budget, tab limit

Notes are stored under a key derived from your PIN when you set one.

## What leaves the phone

Only these, and only when the feature is used:

1. **The pages you open.** The site you type is requested from that site. Your browser
   engine sends the same headers any browser sends.
2. **Search suggestions while you type.** Sent to your chosen search engine
   (DuckDuckGo by default) as you type in the address bar. This can be turned off by
   choosing an engine you trust, or by leaving the field empty.
3. **The update check.** One request to `skoofficialll-hash.github.io` (or
   `api.github.com` as a fallback) when you ask for updates, at most once a day.
   It carries no identifier.
4. **The site-list update**, when you tap "Update site list": one request for a JSON
   file of popular addresses.
5. **The offline voice model download**, when you ask for it: one request for the Vosk
   Hindi model.

There is **no** analytics, **no** crash reporting service, **no** advertising SDK and
**no** third-party tracker in this app. The app lists its own network requests inside
Settings → Privacy proof, so you can check this claim instead of trusting it.

## Permissions and why

| permission | why |
|---|---|
| INTERNET | it is a browser |
| ACCESS_NETWORK_STATE | to tell "no internet" apart from "site is down" |
| CAMERA | scanning a QR code, only when you tap scan |
| RECORD_AUDIO | offline voice search, only while you hold the mic |
| REQUEST_INSTALL_PACKAGES | installing an update you downloaded |

## Children

The app has no accounts and collects nothing, so there is nothing to collect from a
child. It is not directed at children under 13.

## Removing your data

Settings → "Clear everything" erases history, bookmarks, saved pages, notes, the ledger,
cookies, cache and every setting from the phone. Uninstalling the app does the same.

## Contact

Sk Inventor · skinventoroffical@gmail.com
