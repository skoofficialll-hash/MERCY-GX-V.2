# BUGS.md — the ledger

One row per finding. **P0** = crash / data loss · **P1** = a feature that does not work ·
**P2** = wrong behaviour, accessibility, honesty · **P3** = polish / lint.

Rule: a build does not go to a reviewer while any P0 or P1 is `open`.
The `fixed` rows stay in the file so the count never resets and nobody re-reports them.

Filters behind these rows: `javac -Xlint:all`, PMD 7.9, SpotBugs 4.9.8 (effort max),
ESLint 10, html-validate 10, tinycss2, jsdom load + 104-click runner, and
`tools/filters.py` (14 custom filters: prefs keys, asset references, duplicate ids,
duplicate JS names, CSS drift, a11y labels, silent catches, markers, long methods,
dead JS, hardcoded counts, threads, unreachable methods, licence reachability).

## Round 9 (14.5.0) — 27 fixed

| id | sev | area | finding | status |
|---|---|---|---|---|
| R9-01 | P0 | interface | `applyTheme(8)` on a 6-row table threw on every launch; the rest of the boot script never ran | fixed |
| R9-02 | P1 | interface | 25 `bridge('…')` actions had no `UiBridge` method — those buttons were silent no-ops | fixed |
| R9-03 | P0 | engine | `newTab()` opened a GeckoSession with a null runtime in WebView mode (default) → crash on first tab | fixed |
| R9-04 | P0 | engine | `closeTab`, `goForward`, `onDestroy`, `onPause` dereferenced a null session in WebView mode | fixed |
| R9-05 | P1 | data | `"daily"` bucket was read and never written — TODAY, budget ring, ₹ spent always 0 | fixed |
| R9-06 | P1 | data | `lastUrl`/`lastTitle` never written — "Continue" always empty | fixed |
| R9-07 | P1 | data | budget ring used a hardcoded 200 MB, ignored the saved budget | fixed |
| R9-08 | P2 | theme | `lightTheme()` called Midnight light and Sand dark | fixed |
| R9-09 | P1 | theme | `pickAccent()` called itself — accent dialog reopened for ever | fixed |
| R9-10 | P1 | library | library page stored in `menuOverlay`; closing Notes left it on screen | fixed |
| R9-11 | P1 | settings | "Theme" row wrote a `"light"` pref nothing read | fixed |
| R9-12 | P2 | menu | local `tabs` shadowed the browser tab list — "Tabs" showed 5 | fixed |
| R9-13 | P2 | tabs | session restore added tabs beside the blank one, growing the strip every restart | fixed |
| R9-14 | P1 | nav | back button ignored notes / library / reader overlays | fixed |
| R9-15 | P0 | exit | `onDestroy` NPE on null sessions; neither engine released | fixed |
| R9-16 | P1 | QR | SurfaceTextureListener attached after `show()` → black preview; camera never released on pause | fixed |
| R9-17 | P1 | offline | saved page opened behind the interface (invisible) | fixed |
| R9-18 | P2 | i18n | error-page bodies were Hinglish in every language | fixed |
| R9-19 | P1 | assets | 8 × `available()` + single `read()` — a 63 KB JSON could arrive truncated | fixed |
| R9-20 | P1 | notes | PIN sealing XORed chars then `getBytes()` → corrupted notes | fixed |
| R9-21 | P2 | logging | `note()` and `CrashGuard.note()` called themselves from their own catch | fixed |
| R9-22 | P1 | update | download to public Downloads needs WRITE_EXTERNAL_STORAGE below API 29; no REQUEST_INSTALL_PACKAGES | fixed |
| R9-23 | P1 | interface | `pushChromeConfig()` only reachable from a Bridge that is never registered → theme/language never reached the page | fixed |
| R9-24 | P2 | onboarding | native 5-screen intro and the HTML intro both ran | fixed |
| R9-25 | P2 | css | ~30 lines of JavaScript inside `<style>`; CSS after it was eaten | fixed |
| R9-26 | P2 | honesty | "713 sites work offline", "0 KB per page", "74 hosts", invented recents and week bars | fixed |
| R9-27 | P1 | i18n | `Lang.ui()` asked for `"hi:ui_5"` while `labels.json` ships flat `"ui_5"` — 69 labels never used | fixed |

## Round 10 (14.6.0) — this build

### fixed

| id | sev | area | finding | status |
|---|---|---|---|---|
| R10-01 | P1 | reachability | **22 private methods with no caller** — Find on page, Images, Search by picture, Site information, "site broken", Text size, Accent, Tab limit, Tor, instant answers, index hits, recent pane: features that existed but had no door | fixed (11 wired into the menu, 6 kept as internal helpers) |
| R10-02 | P1 | diagnostics | `notesText()` never called — the 50 caught exceptions the app records were invisible | fixed |
| R10-03 | P1 | settings | `forceDark` read and never written — the darken-pages toggle did not exist | fixed |
| R10-04 | P1 | settings | `indexPack` read and never written — the country pack could not be chosen | fixed |
| R10-05 | P1 | licence | `FILTER-LICENSES.txt` shipped but unreachable; CC BY-SA attribution was only a file path in a dialog | fixed (Licence text button) |
| R10-06 | P2 | a11y | 57 click listeners, 0 `contentDescription` — the header was silent to TalkBack | fixed (10 labelled, decorative icons skipped) |
| R10-07 | P2 | a11y | `aria-label` on brand/newtab artwork without `role="img"` — ignored by screen readers | fixed |
| R10-08 | P2 | honesty | "44 373 hosts, 96%" was a number nobody measured | fixed (live `blocker.size()`) |
| R10-09 | P1 | assets | `chrome.html` + `newtab.html` shipped (49 KB) and nothing loads them; `chrome.html` calls 8 functions that do not exist | fixed (moved to `design/`) |
| R10-10 | P2 | css | a block of JS still inside `<style>` earlier; now CSS parses with 0 error rules | fixed |
| R10-11 | P2 | html | 3 `<input>` and 2 `<button>` without `type` | fixed |
| R10-12 | P2 | js | `paintLibrary()` called from `go()` but defined nowhere | fixed |
| R10-13 | P2 | js | dead `isWideScreen()` | fixed |
| R10-14 | P2 | i18n | `toLowerCase()/toUpperCase()` without `Locale.ROOT` in 12 places — Turkish locale broke host/URL matching | fixed |
| R10-15 | P2 | theme | 12 ternaries with identical branches (`lightTheme() ? panel() : panel()`) | fixed |
| R10-16 | P2 | nulls | `Notes.Note` fields never initialised; `QrScanner.preview` unset in ctor; `OfflineVoice.copyTree` ignored a null `listFiles()` | fixed |
| R10-17 | P1 | threads | `Lang.TABLE` lazily built from an instance method into a static field (two threads could race) | fixed (`synchronized` + `volatile`) |
| R10-18 | P2 | leaks | `Updater.fetch()` leaked its reader on exception | fixed |
| R10-19 | P2 | nav | back onto the interface loaded it behind a hidden chrome layer (blank screen) | fixed |
| R10-20 | P2 | search | Images always opened with an empty query | fixed |
| R10-21 | P2 | threading | GeckoView delegates touched views from the engine thread; `pushBudget()` too | fixed |
| R10-22 | P2 | ui | 9 dialogs used the light system theme inside a dark app | fixed |
| R10-23 | P2 | engine | security level "pro" (JS off) and "save data mode" did nothing in WebView mode | fixed |
| R10-24 | P2 | privacy | excused sites ("turn blocking off here") were saved and never restored | fixed |
| R10-25 | P3 | lint | ESLint: 25 errors → **0**; html-validate: 90 → **0** on shipped pages | fixed |


## Round 11 (15.0.0) — release readiness

### fixed

| id | sev | area | finding | status |
|---|---|---|---|---|
| R11-01 | P1 | release | `versionName` was 14.6.0 with no release path documented; no keystore story, no AAB instructions | fixed (`RELEASE.md`, `keystore.properties.example`, `.gitignore`) |
| R11-02 | P1 | release | a release build depended on remembering four `export` variables; forget one and the build is silently unsigned | fixed (reads `keystore.properties`, falls back to env) |
| R11-03 | P2 | release | `packagingOptions` is deprecated in AGP 8.7 | fixed (`packaging`) |
| R11-04 | P2 | release | `geckoviewVersion=+` made every build different | fixed (`-Pgecko=…` pin, documented) |
| R11-05 | P1 | release | `proguard-rules.pro` was **empty** — turning on shrinking would strip every `@JavascriptInterface` method and every reflection target, i.e. the whole UI would stop working | fixed (keep rules for the bridge, GeckoView, Vosk, JNA) |
| R11-06 | P2 | i18n | native menu and settings labels were English in a 13-language app | fixed (53 labels × 3 languages via `Lang.m`) |
| R11-07 | P1 | store | no privacy policy text, no data-safety answers, no store checklist | fixed (`PRIVACY.md`, `STORE-CHECKLIST.md`) |
| R11-08 | P2 | build | `lint` block absent: a release build could ship with lint errors nobody saw | fixed (`checkReleaseBuilds true`) |
| R11-09 | P2 | build | bundle split languages while the app ships its own 13 | fixed (`language { enableSplit false }`) |

### still open

| id | sev | finding | why |
|---|---|---|---|
| O-01 | P0 | the APK has never been built or run | `RELEASE.md` step 4 is the list to walk on a phone |
| O-02 | P1 | GeckoView only compiled against stubs here | needs a real link |
| O-03 | P2 | ~99 toasts and dialog strings are still English-only (menu + settings are now translated) | needs a translation table for the remaining ones |
| O-04 | P2 | path-based EasyList rules not implemented | needs a filter engine |
| O-05 | P2 | `MercyReaderEngine` OCR is a seeded generator, not OCR | product decision |
| O-06 | P3 | 30 CSS selectors declared several times (`.h1` ×6, `.wrap` ×6) | CSS cleanup, regression risk without a device |
| O-07 | P3 | 9 raw `Thread()` calls without names | cosmetic |
| O-08 | P3 | native intro (~300 lines) is dead code, left in place | removing UI code untested on a device adds risk for no user gain |

### open — needs a decision, a device, or work bigger than a patch

| id | sev | area | finding | why it is still open |
|---|---|---|---|---|
| O-01 | P0 | release | **the APK has never been built or run.** No Gradle / build-tools in this sandbox | needs one device run: camera, mic, installer, http+https, offline save, 6 themes, 13 languages |
| O-02 | P1 | engine | GeckoView path is only compiled against stubs (maven.mozilla.org unreachable here) | needs a real build to link |
| O-03 | P2 | i18n | 98 user-facing strings in Java are English-only (dialogs, toasts) while the page is in 13 languages | needs a translation table + 98 edits |
| O-04 | P2 | filter | path-based EasyList rules (0.9%) are not implemented | needs a real filter engine |
| O-05 | P2 | reader | `MercyReaderEngine` OCR is a seeded generator, not OCR; not wired to a button | product decision |
| O-06 | P3 | css | 30 selectors declared several times with different bodies (`.h1` ×6, `.wrap` ×6, `:root` ×4) | CSS cleanup, high regression risk |
| O-07 | P3 | threads | 9 raw `Thread()` calls with no names | cosmetic for debugging |
| O-08 | P3 | dead code | native intro (~300 lines) is no longer started | cleanup, not a defect |
