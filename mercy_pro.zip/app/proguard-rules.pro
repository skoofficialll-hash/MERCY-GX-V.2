# Mercy GX — keep rules
#
# R8 is off in this build (minifyEnabled false), so these rules are not doing any work
# today. They are here so that turning shrinking on later cannot silently break the two
# places where Java and JavaScript meet by name.

# 1. The interface bridge: every @JavascriptInterface method is called by name from
#    ui.html. Renaming or removing one makes a button do nothing, with no error.
-keepclassmembers class com.skinventor.mercypro.UiBridge {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class com.skinventor.mercypro.UiBridge { *; }

# 2. The other two bridge classes, kept for the same reason if they are ever registered.
-keepclassmembers class com.skinventor.mercypro.MainActivity$Bridge {
    @android.webkit.JavascriptInterface <methods>;
}
-keepclassmembers class com.skinventor.mercypro.MainActivity$HomeBridge {
    @android.webkit.JavascriptInterface <methods>;
}

# 3. GeckoView is reached partly by reflection (evaluateJS, installBuiltIn,
#    GeckoResult.accept) because its signatures move between releases.
-keep class org.mozilla.geckoview.** { *; }
-dontwarn org.mozilla.geckoview.**
-keepclassmembers class * extends org.mozilla.geckoview.GeckoSession$ProgressDelegate { *; }
-keepclassmembers class * extends org.mozilla.geckoview.GeckoSession$ContentDelegate { *; }

# 4. Reflection on the engine API in MainActivity (method names are compared as strings).
-keepclassmembers class com.skinventor.mercypro.MainActivity {
    *** evaluateJS(...);
}

# 5. Vosk / JNA load native code by class name.
-keep class org.vosk.** { *; }
-keep class com.sun.jna.** { *; }
-dontwarn com.sun.jna.**

# 6. Keep the crash log readable: line numbers matter for a bug report.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
