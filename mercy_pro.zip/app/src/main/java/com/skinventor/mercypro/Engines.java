package com.skinventor.mercypro;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Search providers as data, not code.
 *
 * If a provider changes its URL, or shuts down, this file is not touched:
 * assets/engines.json is edited and the browser follows. If the asset is
 * missing or broken, the built-in defaults below keep the browser working —
 * that is the difference between a product and a dependency.
 */
public class Engines {

    public static class Provider {
        public final String id, name, search, images;
        Provider(String id, String name, String search, String images) {
            this.id = id; this.name = name; this.search = search; this.images = images;
        }
    }

    private final List<Provider> list = new ArrayList<>();

    /* the fallback: never empty, never fetched */
    private static final Provider[] SAFE = {
        new Provider("ddg", "DuckDuckGo", "https://duckduckgo.com/?q={q}",
                "https://duckduckgo.com/?q={q}&iax=images&ia=images"),
        new Provider("wikipedia", "Wikipedia", "https://en.wikipedia.org/w/index.php?search={q}",
                "https://commons.wikimedia.org/w/index.php?search={q}"),
        new Provider("bing", "Bing", "https://www.bing.com/search?q={q}",
                "https://www.bing.com/images/search?q={q}")
    };

    public Engines(Context c) {
        InputStream in = null;
        try {
            JSONObject o = new JSONObject(Io.readAsset(c, "engines.json"));
            JSONArray arr = o.optJSONArray("engines");
            if (arr != null) {
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject e = arr.optJSONObject(i);
                    if (e == null) continue;
                    String id = e.optString("id", "");
                    String search = e.optString("search", "");
                    if (id.isEmpty() || search.isEmpty()) continue;
                    list.add(new Provider(id, e.optString("name", id), search,
                            e.optString("images", search)));
                }
            }
        } catch (Exception e) {
            CrashGuard.note("engines", e);
        } finally {
            try { if (in != null) in.close(); } catch (Exception ignored) { }
        }
        if (list.isEmpty()) for (Provider p : SAFE) list.add(p);
    }

    public List<Provider> all() { return java.util.Collections.unmodifiableList(list); }

    public String[] names() {
        String[] n = new String[list.size()];
        for (int i = 0; i < list.size(); i++) n[i] = list.get(i).name;
        return n;
    }

    public String[] ids() {
        String[] n = new String[list.size()];
        for (int i = 0; i < list.size(); i++) n[i] = list.get(i).id;
        return n;
    }

    public Provider byId(String id) {
        for (Provider p : list) if (p.id.equals(id)) return p;
        return list.isEmpty() ? SAFE[0] : list.get(0);
    }

    /** {q} is replaced; if a provider drops the placeholder we append instead of breaking */
    public String url(String id, String query, boolean images) {
        Provider p = byId(id);
        String enc = android.net.Uri.encode(query == null ? "" : query);
        String tpl = images ? p.images : p.search;
        if (tpl.contains("{q}")) return tpl.replace("{q}", enc);
        return tpl + (tpl.contains("?") ? "&q=" : "?q=") + enc;
    }
}
