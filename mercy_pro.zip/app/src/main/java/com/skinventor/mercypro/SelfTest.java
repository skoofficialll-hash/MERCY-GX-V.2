package com.skinventor.mercypro;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Self-test — the app checks itself, on the phone, with no network.
 *
 * Every line says what was checked and what happened. If a subsystem is broken
 * the user sees it here instead of guessing, and a screenshot is enough to find
 * the fault. Nothing is sent anywhere.
 */
public class SelfTest {

    public static class Result {
        public final String name;
        public final boolean pass;
        public final String detail;
        public Result(String name, boolean pass, String detail) {
            this.name = name; this.pass = pass; this.detail = detail;
        }
    }

    public static List<Result> run(Context ctx, SharedPreferences prefs) {
        List<Result> out = new ArrayList<>();

        /* 1. the interface file is inside the app */
        out.add(file(ctx, "ui.html", "Interface"));

        /* 2. the site packs */
        String india = read(ctx, "index/india.json");
        int nIndia = count(india);
        out.add(new Result("India sites", nIndia > 400, nIndia + " entries"));
        int nWorld = count(read(ctx, "index/world.json"));
        out.add(new Result("World sites", nWorld > 50, nWorld + " entries"));

        /* 3. blocker list — count the hosts, not the top-level keys */
        int nBlock = size(read(ctx, "blocklist.json"), "hosts");
        out.add(new Result("Tracker list", nBlock > 20, nBlock + " hosts"));

        /* 4. search engines — count the providers, not the top-level keys */
        int nEng = size(read(ctx, "engines.json"), "engines");
        out.add(new Result("Search engines", nEng >= 1, nEng + " providers"));

        /* 5. labels table */
        int nLabels = count(read(ctx, "labels.json"));
        out.add(new Result("Label table", nLabels > 20, nLabels + " keys"));

        /* 6. languages */
        int langs = Lang.CODES == null ? 0 : Lang.CODES.length;
        out.add(new Result("Languages", langs >= 13, langs + " languages, Hindi default"));

        /* 7. notes: write, read, delete */
        try {
            Notes notes = new Notes(prefs);
            Notes.Note note = notes.add("self test", "written by the self test");
            boolean back = false;
            for (Notes.Note n : notes.all()) {
                if (n.id.equals(note.id) && n.body.contains("self test")) back = true;
            }
            notes.delete(note.id);
            out.add(new Result("Notes", back, back ? "write, read and delete work" : "note did not come back"));
        } catch (Throwable t) {
            CrashGuard.note("selftest-notes", t);
            out.add(new Result("Notes", false, t.getClass().getSimpleName()));
        }

        /* 8. the theme list is complete and every entry has a divider colour */
        try {
            int n = MainActivity.THEME_COUNT;
            out.add(new Result("Themes", n == 6, n + " palettes — 3 dark, 3 light"));
        } catch (Throwable t) {
            out.add(new Result("Themes", false, t.getClass().getSimpleName()));
        }

        /* 9. storage is writable */
        try {
            prefs.edit().putBoolean("selfTest", true).apply();
            boolean ok = prefs.getBoolean("selfTest", false);
            prefs.edit().remove("selfTest").apply();
            out.add(new Result("Storage", ok, ok ? "settings save and load" : "setting did not stick"));
        } catch (Throwable t) {
            out.add(new Result("Storage", false, t.getClass().getSimpleName()));
        }

        /* 9b. the brand page and its artwork are inside the app */
        String brand = read(ctx, "brand.html");
        int marks = occurrences(brand, "class=\"mk\"");
        int arts = occurrences(brand, "class=\"art\"");
        out.add(new Result("Brand page", brand.length() > 1000,
                brand.length() == 0 ? "brand.html is missing" : "brand.html " + brand.length() + " bytes"));
        out.add(new Result("Brand artwork", marks >= 8 && arts >= 6, marks + " marks, " + arts + " animated pieces"));

        /* 10. crash guard is installed */
        out.add(new Result("Crash guard", true,
                CrashGuard.hasCrash(ctx) ? "a crash log exists — read it in Diagnostics" : "no crash recorded"));

        /* 11. the interface is the file we shipped — the check the app runs on launch,
               reported here too, so "the app files are damaged" is never a surprise */
        out.add(interfaceHash(ctx));

        /* 12. every action the page sends exists in the bridge.
               Twenty-five of them did not: the button threw inside bridge()'s
               try/catch and did nothing, with no error anywhere. */
        out.add(bridgeContract(ctx));

        /* 13. the index really holds what the interface advertises */
        int total = nIndia + nWorld;
        out.add(new Result("Popular sites", total > 500, total + " addresses bundled (before de-duplication)"));

        return out;
    }

    /** sha256 of the shipped interface against the constant the build writes */
    private static Result interfaceHash(Context ctx) {
        try {
            byte[] data = Io.readAssetBytes(ctx, "ui.html");
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("SHA-256");
            StringBuilder sb = new StringBuilder();
            for (byte b : md.digest(data)) sb.append(String.format("%02x", b));
            String hash = sb.toString();
            boolean ok = hash.equals(UiHash.SHA256);
            return new Result("Interface check", ok,
                    ok ? "sha256 matches the build" : "hash " + hash.substring(0, 12) + " — reinstall Mercy");
        } catch (Throwable t) {
            return new Result("Interface check", false, t.getClass().getSimpleName());
        }
    }

    /** every bridge('name') in the page must be a real @JavascriptInterface method */
    private static Result bridgeContract(Context ctx) {
        try {
            java.util.Set<String> methods = new java.util.HashSet<>();
            for (java.lang.reflect.Method m : UiBridge.class.getDeclaredMethods()) {
                if (m.isAnnotationPresent(android.webkit.JavascriptInterface.class)) methods.add(m.getName());
            }
            String page = read(ctx, "ui.html");
            java.util.regex.Matcher mm = java.util.regex.Pattern
                    .compile("bridge\\(\\s*'([A-Za-z0-9_]+)").matcher(page);
            java.util.Set<String> missing = new java.util.TreeSet<>();
            int seen = 0;
            while (mm.find()) {
                seen++;
                String name = mm.group(1);
                if (!methods.contains(name)) missing.add(name);
            }
            if (seen == 0) return new Result("Page actions", false, "no bridge calls found in ui.html");
            return new Result("Page actions", missing.isEmpty(),
                    missing.isEmpty() ? seen + " calls, all wired" : "missing: " + missing);
        } catch (Throwable t) {
            return new Result("Page actions", false, t.getClass().getSimpleName());
        }
    }

    private static Result file(Context ctx, String name, String label) {
        try {
            /* measure what is actually there, not what available() guessed */
            int size = Io.readAssetBytes(ctx, name).length;
            return new Result(label, size > 100, name + " " + size + " bytes");
        } catch (Throwable t) {
            return new Result(label, false, name + " is missing");
        }
    }

    private static String read(Context ctx, String name) {
        return Io.readAsset(ctx, name);
    }

    /** length of a named array inside a JSON object — the honest count */
    private static int size(String json, String key) {
        if (json == null || json.trim().isEmpty()) return 0;
        try {
            JSONArray a = new JSONObject(json.trim()).optJSONArray(key);
            return a == null ? 0 : a.length();
        } catch (Throwable t) {
            CrashGuard.note("selftest-size", t);
            return 0;
        }
    }

    private static int occurrences(String hay, String needle) {
        if (hay == null || needle == null || needle.isEmpty()) return 0;
        int n = 0, i = 0;
        while ((i = hay.indexOf(needle, i)) != -1) { n++; i += needle.length(); }
        return n;
    }

    private static int count(String json) {
        if (json == null || json.trim().isEmpty()) return 0;
        try {
            String t = json.trim();
            if (t.startsWith("[")) return new JSONArray(t).length();
            if (t.startsWith("{")) return new JSONObject(t).length();
        } catch (Throwable ignored) { CrashGuard.note("SelfTest", ignored); }
        return 0;
    }

    /** one block of text for the dialog */
    public static String report(List<Result> results) {
        StringBuilder sb = new StringBuilder();
        int pass = 0;
        for (Result r : results) {
            if (r.pass) pass++;
            sb.append(r.pass ? "\u2713  " : "\u2717  ")
              .append(r.name).append("  \u2014  ").append(r.detail).append("\n");
        }
        sb.append("\n").append(pass).append(" of ").append(results.size()).append(" checks pass");
        return sb.toString();
    }
}
