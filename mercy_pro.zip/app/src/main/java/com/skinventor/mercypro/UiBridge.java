package com.skinventor.mercypro;

import android.webkit.JavascriptInterface;

/**
 * The only door between the HTML interface and Java.
 *
 * Every call is small and named after what a person asked for. Nothing here
 * sends data anywhere; it moves the browser between its own screens.
 */
public class UiBridge {

    public interface Host {
        void uiOpen(String url);
        void uiSearch();
        void uiAction(String action, String value);
        void uiTariff(String perMb);
        void uiCats(String csv);
        void uiLang(String code);
        void uiIntroDone();
        void uiTheme(String index);
    }

    private final Host host;

    public UiBridge(Host host) { this.host = host; }

    @JavascriptInterface public void open(String url) { host.uiOpen(url); }
    @JavascriptInterface public void search() { host.uiSearch(); }
    @JavascriptInterface public void tabs() { host.uiAction("tabs", ""); }
    @JavascriptInterface public void menu() { host.uiAction("menu", ""); }
    @JavascriptInterface public void reload() { host.uiAction("reload", ""); }
    @JavascriptInterface public void reader() { host.uiAction("reader", ""); }
    @JavascriptInterface public void share() { host.uiAction("share", ""); }
    @JavascriptInterface public void free() { host.uiAction("free", ""); }
    @JavascriptInterface public void scan() { host.uiAction("scan", ""); }
    @JavascriptInterface public void voice() { host.uiAction("voice", ""); }
    @JavascriptInterface public void settings() { host.uiAction("settings", ""); }
    @JavascriptInterface public void diag() { host.uiAction("diag", ""); }
    @JavascriptInterface public void selftest() { host.uiAction("selftest", ""); }
    @JavascriptInterface public void about() { host.uiAction("about", ""); }
    @JavascriptInterface public void ledger() { host.uiAction("ledger", ""); }
    @JavascriptInterface public void report() { host.uiAction("report", ""); }
    @JavascriptInterface public void update() { host.uiAction("update", ""); }
    @JavascriptInterface public void budget() { host.uiAction("budget", ""); }
    @JavascriptInterface public void tariff(String perMb) { host.uiTariff(perMb); }
    @JavascriptInterface public void cats(String csv) { host.uiCats(csv); }
    @JavascriptInterface public void lang(String code) { host.uiLang(code); }
    @JavascriptInterface public void introDone(String v) { host.uiIntroDone(); }
    @JavascriptInterface public void lib(String what) { host.uiAction("lib:" + what, ""); }
    @JavascriptInterface public void theme(String index) { host.uiTheme(index); }

    /* ---------------------------------------------------------------
       The page already asked for these: every one of them was missing
       here, so bridge('save'), bridge('offline'), bridge('studyStart')
       and twenty-one others threw inside bridge()'s try/catch and the
       button did nothing at all. One method per action the page sends.
    --------------------------------------------------------------- */
    @JavascriptInterface public void blocked() { host.uiAction("blocked", ""); }
    @JavascriptInterface public void blocker(String value) { host.uiAction("blocker", value); }
    @JavascriptInterface public void bookmark() { host.uiAction("bookmark", ""); }
    @JavascriptInterface public void brand() { host.uiAction("brand", ""); }
    @JavascriptInterface public void engine(String which) { host.uiAction("engine", which); }
    @JavascriptInterface public void hideCheck(String hostName) { host.uiAction("hideCheck", hostName); }
    @JavascriptInterface public void hidethem(String value) { host.uiAction("hidethem", value); }
    @JavascriptInterface public void home() { host.uiAction("home", ""); }
    @JavascriptInterface public void newtab() { host.uiAction("newtab", ""); }
    @JavascriptInterface public void language() { host.uiAction("language", ""); }
    @JavascriptInterface public void launchEngine(String value) { host.uiAction("launchEngine", value); }
    @JavascriptInterface public void save() { host.uiAction("save", ""); }
    @JavascriptInterface public void offline() { host.uiAction("offline", ""); }
    @JavascriptInterface public void notes() { host.uiAction("notes", ""); }
    @JavascriptInterface public void noteAdd(String value) { host.uiAction("noteAdd", value); }
    @JavascriptInterface public void noteOpen(String id) { host.uiAction("noteOpen", id); }
    @JavascriptInterface public void notePin() { host.uiAction("notePin", ""); }
    @JavascriptInterface public void studyStart() { host.uiAction("studyStart", ""); }
    @JavascriptInterface public void studyStop() { host.uiAction("studyStop", ""); }
    @JavascriptInterface public void studyDone() { host.uiAction("studyDone", ""); }
    @JavascriptInterface public void kaamStep(String value) { host.uiAction("kaamStep", value); }
    @JavascriptInterface public void kaamDone(String value) { host.uiAction("kaamDone", value); }
    @JavascriptInterface public void kaamReceipt(String value) { host.uiAction("kaamReceipt", value); }
    @JavascriptInterface public void kaamWipe(String value) { host.uiAction("kaamWipe", value); }
    @JavascriptInterface public void tab(String id) { host.uiAction("tab", id); }
    @JavascriptInterface public void closetab(String id) { host.uiAction("closetab", id); }
    /** the page may never wipe the phone: the action is refused in Java too */
    @JavascriptInterface public void wipe() { host.uiAction("wipe", ""); }
}
