package com.skinventor.mercypro;

/** sha256 of assets/ui.html, written at build time */
public final class UiHash {
    public static final String SHA256 = "35ea125f9c6b0b260cb4d90bf2845900f45d19862399c155da7cbdb88b12a0a6";
}
