package com.skinventor.mercypro;

import android.Manifest;
import android.app.Dialog;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.Image;
import android.media.ImageReader;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.Size;
import android.view.Gravity;
import android.view.Surface;
import android.view.TextureView;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.google.zxing.BinaryBitmap;
import com.google.zxing.DecodeHintType;
import com.google.zxing.MultiFormatReader;
import com.google.zxing.NotFoundException;
import com.google.zxing.PlanarYUVLuminanceSource;
import com.google.zxing.Result;
import com.google.zxing.common.HybridBinarizer;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/**
 * In-app QR scanner with no Google dependency: Camera2 for the preview,
 * ZXing for the decoding. Everything happens on the device.
 */
public class QrScanner {

    public interface Listener { void onScanned(String text); }

    private final Context ctx;
    private final Listener callback;

    private Dialog dialog;
    private TextureView preview;          /* created in show(), null before that */
    private ImageReader reader;
    private CameraDevice camera;
    private CameraCaptureSession session;
    private HandlerThread thread;
    private Handler handler;
    private MultiFormatReader zxing;
    private boolean done = false;

    public QrScanner(Context ctx, Listener callback) {
        this.ctx = ctx;
        this.callback = callback;
    }

    public void show() {
        if (ctx.checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            return;   // caller asks for the permission first
        }

        dialog = new Dialog(ctx);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        FrameLayout root = new FrameLayout(ctx);
        root.setBackgroundColor(Color.parseColor("#0b0d10"));

        preview = new TextureView(ctx);
        root.addView(preview, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        TextView hint = new TextView(ctx);
        hint.setText("Point the camera at a QR code");
        hint.setTextColor(Color.parseColor("#e9ebee"));
        hint.setTextSize(13);
        hint.setGravity(Gravity.CENTER);
        hint.setPadding(0, 40, 0, 0);
        root.addView(hint, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP));

        TextView close = new TextView(ctx);
        close.setText("Close");
        close.setTextColor(Color.parseColor("#4f8cff"));
        close.setTextSize(14);
        close.setGravity(Gravity.CENTER);
        close.setPadding(24, 24, 24, 40);
        close.setOnClickListener(v -> dismiss());
        root.addView(close, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM));

        /* the listener has to be in place before the dialog is shown: the surface
           can become available during show(), and a listener attached afterwards
           never gets onSurfaceTextureAvailable — that was the black camera screen */
        preview.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
            @Override public void onSurfaceTextureAvailable(SurfaceTexture st, int w, int h) { openCamera(); }
            @Override public void onSurfaceTextureSizeChanged(SurfaceTexture st, int w, int h) { }
            @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture st) { return true; }
            @Override public void onSurfaceTextureUpdated(SurfaceTexture st) { }
        });

        dialog.setContentView(root);
        dialog.setOnDismissListener(d -> stopCamera());
        dialog.show();

        /* if the surface is already there, nothing will fire: open the camera now */
        if (preview.isAvailable() && camera == null) preview.post(this::openCamera);
    }

    /** the screen went away under us (pause, wipe, new page): release the camera */
    public void close() {
        done = true;
        dismiss();
        stopCamera();
    }

    private void openCamera() {
        /* check the permission before anything is allocated, or a refusal leaks a
           HandlerThread, an ImageReader and a half-open camera */
        if (Build.VERSION.SDK_INT >= 23
                && ctx.checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        if (camera != null || reader != null) return;      /* already open */
        try {
            CameraManager cm = (CameraManager) ctx.getSystemService(Context.CAMERA_SERVICE);
            if (cm == null) { return; }
            String id = null;
            for (String candidate : cm.getCameraIdList()) {
                CameraCharacteristics ch = cm.getCameraCharacteristics(candidate);
                Integer facing = ch.get(CameraCharacteristics.LENS_FACING);
                if (facing != null && facing == CameraCharacteristics.LENS_FACING_BACK) {
                    id = candidate;
                    break;
                }
            }
            if (id == null && cm.getCameraIdList().length > 0) id = cm.getCameraIdList()[0];
            if (id == null) return;

            CameraCharacteristics ch = cm.getCameraCharacteristics(id);
            StreamConfigurationMap map = ch.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            Size pick = null;
            if (map != null) {
                for (Size s : map.getOutputSizes(ImageReader.class)) {
                    if (s.getWidth() <= 1280 && s.getHeight() <= 1280) { pick = s; break; }
                }
            }
            if (pick == null) pick = new Size(640, 480);

            thread = new HandlerThread("qr-camera");
            thread.start();
            handler = new Handler(thread.getLooper());

            reader = ImageReader.newInstance(pick.getWidth(), pick.getHeight(), android.graphics.ImageFormat.YUV_420_888, 2);
            reader.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
                @Override public void onImageAvailable(ImageReader r) {
                    Image img = null;
                    try { img = r.acquireLatestImage(); }
                    catch (Exception e) {
                        /* the reader can close under us when the dialog goes away */
                        CrashGuard.note("qrAcquire", e);
                        return;
                    }
                    if (img != null) decode(img);
                }
            }, handler);

            Map<DecodeHintType, Object> hints = new EnumMap<>(DecodeHintType.class);
            List<com.google.zxing.BarcodeFormat> formats = new ArrayList<>();
            formats.add(com.google.zxing.BarcodeFormat.QR_CODE);
            hints.put(DecodeHintType.POSSIBLE_FORMATS, formats);
            hints.put(DecodeHintType.TRY_HARDER, Boolean.TRUE);
            zxing = new MultiFormatReader();
            zxing.setHints(hints);

            cm.openCamera(id, new CameraDevice.StateCallback() {
                @Override public void onOpened(CameraDevice device) {
                    camera = device;
                    startPreview();
                }
                @Override public void onDisconnected(CameraDevice device) { device.close(); camera = null; }
                @Override public void onError(CameraDevice device, int error) { device.close(); camera = null; }
            }, handler);
        } catch (CameraAccessException | SecurityException e) {
            // no camera, no permission — the dialog just stays on the hint text
        }
    }

    private void startPreview() {
        try {
            SurfaceTexture st = preview.getSurfaceTexture();
            if (st == null || camera == null || reader == null) return;
            st.setDefaultBufferSize(reader.getWidth(), reader.getHeight());
            Surface surface = new Surface(st);
            final CaptureRequest.Builder builder =
                    camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            builder.addTarget(surface);
            builder.addTarget(reader.getSurface());
            builder.set(CaptureRequest.CONTROL_AF_MODE,
                    CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);

            List<Surface> surfaces = new ArrayList<>();
            surfaces.add(surface);
            surfaces.add(reader.getSurface());
            camera.createCaptureSession(surfaces, new CameraCaptureSession.StateCallback() {
                @Override public void onConfigured(CameraCaptureSession s) {
                    session = s;
                    try { s.setRepeatingRequest(builder.build(), null, handler); }
                    catch (Exception ex) { CrashGuard.note("QrScanner", ex); }
                }
                @Override public void onConfigureFailed(CameraCaptureSession s) { }
            }, handler);
        } catch (Exception ex) { CrashGuard.note("QrScanner", ex); }
    }

    private void decode(Image image) {
        if (done) { image.close(); return; }
        try {
            Image.Plane plane = image.getPlanes()[0];
            ByteBuffer buf = plane.getBuffer();
            int w = image.getWidth();
            int h = image.getHeight();
            int rowStride = plane.getRowStride();
            byte[] data = new byte[w * h];
            if (plane.getPixelStride() == 1 && rowStride == w && buf.remaining() >= w * h) {
                buf.get(data);
            } else {
                byte[] row = new byte[rowStride];
                for (int y = 0; y < h; y++) {
                    int pos = y * rowStride;
                    if (pos + rowStride > buf.limit()) break;
                    buf.position(pos);
                    buf.get(row, 0, Math.min(rowStride, buf.remaining()));
                    System.arraycopy(row, 0, data, y * w, Math.min(w, rowStride));
                }
            }
            image.close();

            PlanarYUVLuminanceSource source =
                    new PlanarYUVLuminanceSource(data, w, h, 0, 0, w, h, false);
            BinaryBitmap bitmap = new BinaryBitmap(new HybridBinarizer(source));
            Result result = zxing.decodeWithState(bitmap);
            if (result != null && result.getText() != null) {
                done = true;
                final String text = result.getText();
                if (dialog != null && dialog.isShowing()) {
                    dialog.getWindow().getDecorView().post(new Runnable() {
                        @Override public void run() {
                            dismiss();
                            if (callback != null) callback.onScanned(text);
                        }
                    });
                }
            }
        } catch (NotFoundException ignored) {
            // nothing in this frame, keep going
        } catch (Exception ignored) {
            try { image.close(); } catch (Exception ex) { CrashGuard.note("QrScanner", ex); }
        }
    }

    private void stopCamera() {
        try { if (session != null) session.close(); } catch (Exception ex) { CrashGuard.note("QrScanner", ex); }
        session = null;
        try { if (camera != null) camera.close(); } catch (Exception ex) { CrashGuard.note("QrScanner", ex); }
        camera = null;
        try { if (reader != null) reader.close(); } catch (Exception ex) { CrashGuard.note("QrScanner", ex); }
        reader = null;
        try { if (thread != null) thread.quitSafely(); } catch (Exception ex) { CrashGuard.note("QrScanner", ex); }
        thread = null;
    }

    private void dismiss() {
        try { if (dialog != null && dialog.isShowing()) dialog.dismiss(); } catch (Exception ex) { CrashGuard.note("QrScanner", ex); }
    }
}
