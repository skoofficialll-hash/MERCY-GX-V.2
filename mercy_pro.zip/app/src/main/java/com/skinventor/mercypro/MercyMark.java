package com.skinventor.mercypro;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

/**
 * The Mercy GX marks, drawn on the same 24x24 grid as MercyIcon.
 *
 * Eight marks, all square, 2px stroke, one lime accent. They are drawn here
 * instead of shipped as images so they stay sharp at every density and the
 * accent can follow the theme.
 */
public class MercyMark extends View {

    public static final int BLADE = 0, CUT = 1, TWINS = 2, SIGIL = 3,
            CROSS = 4, SHIELD = 5, CIRCUIT = 6, PRISM = 7;

    public static final String[] NAMES = {
            "Blade M", "Cut square", "Twin blades", "GX sigil",
            "Crosshair", "Shield notch", "Circuit M", "Prism"
    };

    private int kind = BLADE;
    private int ink = 0xFFEDEBE6;
    private int accent = 0xFFC6F24E;

    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();

    public MercyMark(Context c) {
        super(c);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(dp(2f));
        stroke.setStrokeCap(Paint.Cap.SQUARE);
        stroke.setStrokeJoin(Paint.Join.MITER);
        fill.setStyle(Paint.Style.FILL);
    }

    public MercyMark mark(int k) { kind = k; invalidate(); return this; }

    public MercyMark colors(int inkColor, int accentColor) {
        ink = inkColor; accent = accentColor; invalidate(); return this;
    }

    private float dp(float v) { return v * getResources().getDisplayMetrics().density; }

    @Override protected void onMeasure(int w, int h) {
        int size = (int) dp(24);
        setMeasuredDimension(size, size);
    }

    @Override protected void onDraw(Canvas canvas) {
        float s = getWidth() / 24f;
        canvas.save();
        canvas.scale(s, s);
        drawMark(canvas, kind);
        canvas.restore();
    }

    /** the mark itself, in 24x24 units — used by onDraw and by toBitmap() */
    private void drawMark(Canvas c, int k) {
        stroke.setColor(ink);
        fill.setColor(accent);
        path.reset();

        switch (k) {
            case CUT:
                path.moveTo(3, 21); path.lineTo(3, 3); path.lineTo(21, 3);
                c.drawPath(path, stroke);
                stroke.setColor(accent);
                path.reset(); path.moveTo(21, 21); path.lineTo(3, 3);
                c.drawPath(path, stroke);
                break;

            case TWINS:
                path.moveTo(4, 20); path.lineTo(12, 4); path.lineTo(20, 20);
                c.drawPath(path, stroke);
                stroke.setColor(accent);
                path.reset(); path.moveTo(8, 20); path.lineTo(12, 12); path.lineTo(16, 20);
                c.drawPath(path, stroke);
                break;

            case SIGIL:
                c.drawRect(3, 3, 21, 21, fill);
                stroke.setColor(0xFF0C0E11);
                path.moveTo(7, 7); path.lineTo(17, 17);
                path.moveTo(17, 7); path.lineTo(7, 17);
                c.drawPath(path, stroke);
                break;

            case CROSS:
                c.drawRect(3, 3, 21, 21, stroke);
                path.moveTo(12, 3); path.lineTo(12, 8);
                path.moveTo(12, 16); path.lineTo(12, 21);
                path.moveTo(3, 12); path.lineTo(8, 12);
                path.moveTo(16, 12); path.lineTo(21, 12);
                c.drawPath(path, stroke);
                c.drawCircle(12, 12, 2, fill);
                break;

            case SHIELD:
                path.moveTo(4, 4); path.lineTo(20, 4); path.lineTo(20, 14);
                path.lineTo(12, 20); path.lineTo(4, 14); path.close();
                c.drawPath(path, stroke);
                stroke.setColor(accent);
                path.reset(); path.moveTo(9, 9); path.lineTo(12, 12); path.lineTo(15, 9);
                c.drawPath(path, stroke);
                break;

            case CIRCUIT:
                path.moveTo(3, 19); path.lineTo(3, 5); path.lineTo(12, 13);
                path.lineTo(21, 5); path.lineTo(21, 19);
                c.drawPath(path, stroke);
                c.drawRect(2, 17, 6, 21, fill);
                c.drawRect(18, 17, 22, 21, fill);
                break;

            case PRISM:
                path.moveTo(12, 3); path.lineTo(21, 21); path.lineTo(3, 21); path.close();
                c.drawPath(path, stroke);
                stroke.setColor(accent);
                path.reset(); path.moveTo(12, 3); path.lineTo(12, 21);
                c.drawPath(path, stroke);
                break;

            default: /* BLADE */
                c.drawRect(3, 3, 21, 21, stroke);
                path.moveTo(7, 17); path.lineTo(7, 7); path.lineTo(12, 13);
                path.lineTo(17, 7); path.lineTo(17, 17);
                c.drawPath(path, stroke);
                c.drawRect(16, 16, 21, 21, fill);
                break;
        }
    }

    /** a flat bitmap of any mark — for notifications, shortcuts, share cards */
    public static Bitmap toBitmap(Context ctx, int kind, int px, int inkColor, int accentColor) {
        Bitmap bmp = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        float s = px / 24f;
        c.scale(s, s);
        MercyMark v = new MercyMark(ctx);
        v.colors(inkColor, accentColor);
        v.drawMark(c, kind);
        return bmp;
    }
}
