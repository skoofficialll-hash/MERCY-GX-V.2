package com.skinventor.mercypro;

import android.content.SharedPreferences;
import java.util.LinkedHashMap;
import java.util.Map;

/** Languages: India first (Hindi default), then the world's biggest. */
public class Lang {
    public static final String[] CODES = {"hi","en","hinglish","bn","mr","te","ta","gu","kn","ml","pa","or","ur",
            };
    public static final String[] NAMES = {"हिन्दी","English","Hinglish","বাংলা","मराठी","తెలుగు","தமிழ்","ગુજરાતી",
            "ಕನ್ನಡ","മലയാളം","ਪੰਜਾਬੀ","ଓଡ଼ିଆ","اردو",};

    public static boolean isRtl(String code) { return "ur".equals(code) || "ar".equals(code); }

    private static final Map<String, String[]> T = new LinkedHashMap<>();
    static {
        T.put("offline_title", new String[]{"आप ऑफ़लाइन हैं।","You are offline.","Net nahi hai."});
        T.put("offline_body", new String[]{"इंटरनेट नहीं है। जो पेज आपने सेव किए हैं वे खुलेंगे। बाकी के लिए नेट चाहिए।",
                "No internet. Pages you saved will open. Everything else needs a connection.",
                "Net nahi hai. Jo page save kiye hain wahi khulenge. Baaki ke liye net chahiye."});
        T.put("open_offline", new String[]{"ऑफ़लाइन साइटें खोलें","Open offline sites","Offline sites kholo"});
        T.put("try_again", new String[]{"फिर कोशिश करें","Try again","Phir try karo"});
        T.put("stop_loading", new String[]{"रोकें","Stop loading","Band karo"});
        T.put("go_home", new String[]{"होम पर जाएँ","Go home","Home chalo"});
        T.put("go_back", new String[]{"पीछे जाएँ","Go back","Peeche chalo"});
        T.put("reload", new String[]{"फिर लोड करें","Reload","Reload karo"});
        T.put("continue", new String[]{"जारी रखें","Continue","Continue"});
        T.put("offline_block", new String[]{"लोकप्रिय साइटें · इसी फ़ोन में","POPULAR SITES · ON THIS PHONE","POPULAR SITES · ISI PHONE MEIN"});
        T.put("blocked_title", new String[]{"यह ट्रैकर ब्लॉक हुआ।","Tracker blocked.","Tracker block hua."});
        T.put("blocked_body", new String[]{"यह साइट आपका डेटा भेज रही थी। हमने रोका।",
                "This page was sending your data somewhere. We stopped it.",
                "Ye page tumhara data bhej raha tha. Humne roka."});
        T.put("settings", new String[]{"सेटिंग्स","Settings","Settings"});
        T.put("theme", new String[]{"थीम","Theme","Theme"});
        T.put("language", new String[]{"भाषा","Language","Bhasha"});
        T.put("blocker", new String[]{"विज्ञापन और ट्रैकर ब्लॉक","Block ads and trackers","Ads aur tracker block"});
        T.put("library", new String[]{"लाइब्रेरी","Library","Library"});
        T.put("nothing_leaves", new String[]{"यहाँ से कुछ भी आपका फ़ोन नहीं छोड़ता।","Nothing here leaves your phone.","Yahan se kuch bhi phone nahi chhodta."});
        T.put("type_to_search", new String[]{"खोजने के लिए लिखें। हाल के पेज यहाँ दिखेंगे।","Type to search. Your recent pages will show here.","Search karne ke liye likho. Recent pages yahan dikhenge."});
        T.put("your_data_money", new String[]{"आपका डेटा, पैसों में।","Your data, in money.","Tumhara data, paison mein."});
        T.put("continue", new String[]{"जारी रखें","Continue","Continue"});
        T.put("appearance", new String[]{"रूप","Appearance","Appearance"});
        T.put("search_engine", new String[]{"सर्च इंजन","Search engine","Search engine"});
        T.put("data_budget", new String[]{"डेटा बजट","Data budget","Data budget"});
        T.put("report_card", new String[]{"रिपोर्ट कार्ड","Report card","Report card"});
        T.put("data_tariff", new String[]{"डेटा का दाम","Data tariff","Data ka daam"});
        T.put("offline_pages", new String[]{"ऑफ़लाइन पेज","Offline pages","Offline pages"});
        T.put("bookmarks", new String[]{"बुकमार्क","Bookmarks","Bookmarks"});
        T.put("new_tab", new String[]{"नया टैब","New tab","Naya tab"});
        T.put("incognito_tab", new String[]{"गुप्त टैब","New incognito tab","Naya incognito tab"});
        T.put("bookmark_page", new String[]{"इस पेज को बुकमार्क करें","Bookmark this page","Ye page bookmark karo"});
        T.put("reload_page", new String[]{"पेज फिर लोड करें","Reload page","Page reload karo"});
        T.put("share_page", new String[]{"पेज शेयर करें","Share page","Page share karo"});
        T.put("reader", new String[]{"रीडर मोड","Reader mode","Reader mode"});
        T.put("reader_fail", new String[]{"इस पेज पर पढ़ने लायक टेक्स्ट नहीं मिला।","No readable text found on this page.","Is page par padhne layak text nahi mila."});
        T.put("study", new String[]{"स्टडी मोड","Study mode","Study mode"});
        T.put("study_start", new String[]{"25 मिनट शुरू करें","Start 25 minutes","25 minute shuru"});
        T.put("study_stop", new String[]{"रोकें","Stop","Band karo"});
        T.put("wipe_title", new String[]{"सब कुछ मिटाएँ?","Erase everything?","Sab kuch mita dein?"});
        T.put("wipe_body", new String[]{"इससे इतिहास, टैब, बुकमार्क और सेटिंग्स मिट जाएँगी। यह वापस नहीं आएगा।",
                "This deletes history, tabs, bookmarks and settings. It cannot be undone.",
                "Isse history, tabs, bookmarks aur settings mit jayengi. Wapas nahi aayengi."});
        T.put("type_erase", new String[]{"ERASE लिखें","Type ERASE","ERASE likho"});
        T.put("diagnostics", new String[]{"जाँच","Diagnostics","Diagnostics"});
        T.put("engine", new String[]{"इंजन","Engine","Engine"});
    }

    private final SharedPreferences prefs;
    public Lang(SharedPreferences p) { prefs = p; }
    public String code() { String c = prefs.getString("lang", null); return c == null ? "hi" : c; }
    public void set(String c) { prefs.edit().putString("lang", c).apply(); }
    public boolean rtl() { return isRtl(code()); }
    /** menu labels: Hindi / English / Hinglish, chosen by the app language */
    private static final String[][] MENU = {
        /* key,           hi,                    en,                   hinglish */
        {"reader",        "रीडर",                 "Reader mode",        "Reader"},
        {"readerNew",     "रीडर (नया इंजन)",        "Reader (new engine)","Reader (naya engine)"},
        {"readAloud",     "सुनकर पढ़ो",             "Read aloud",         "Sun kar padho"},
        {"reload",        "पेज फिर खोलो",            "Reload page",        "Page phir kholo"},
        {"pageFacts",     "इस पेज में क्या है",       "What this page has", "Is page mein kya hai"},
        {"voice",         "ऑफ़लाइन आवाज़",           "Offline voice",      "Offline awaaz"},
        {"desktop",       "डेस्कटॉप साइट",           "Desktop site",       "Desktop site"},
        {"tablet",        "टैबलेट साइट",             "Tablet site",        "Tablet site"},
        {"mobile",        "मोबाइल साइट",             "Mobile site",        "Mobile site"},
        {"share",         "पेज भेजो",               "Share page",         "Page bhejo"},
        {"find",          "पेज में ढूँढो",           "Find on page",       "Page mein dhoondo"},
        {"images",        "तस्वीरें",                "Images",             "Tasveerein"},
        {"byPicture",     "तस्वीर से खोजो",          "Search by picture",  "Tasveer se search"},
        {"siteInfo",      "साइट की जानकारी",         "Site information",   "Site ki jankari"},
        {"siteBroken",    "साइट टूटी लगे तो",        "If this site is broken", "Site tooti lage to"},
        {"freeMemory",    "मेमोरी खाली करो",         "Free memory",        "Memory khali karo"},
        {"budget",        "डेटा बजट",               "Data budget",        "Data budget"},
        {"siteList",      "साइट सूची अपडेट",         "Update site list",   "Site list update"},
        {"ledger",        "डेटा लेजर",              "Data ledger",        "Data ledger"},
        {"report",        "रिपोर्ट कार्ड",           "Report card",        "Report card"},
        {"saveData",      "डेटा बचत मोड",           "Save data mode",     "Data bachat mode"},
        {"settings",      "सेटिंग्स",                "Settings",           "Settings"},
        {"newTab",        "नया टैब",                "New tab",            "Naya tab"},
        {"incognito",     "गुप्त टैब",              "New incognito tab",  "Gupt tab"},
        {"bookmarkPage",  "यह पेज बुकमार्क करो",     "Bookmark this page", "Yeh page bookmark karo"},
        {"bookmarks",     "बुकमार्क",               "Bookmarks",          "Bookmarks"},
        {"history",       "इतिहास",                 "History",            "History"},
        {"textSize",      "अक्षर का आकार",           "Text size",          "Text size"},
        {"accent",        "रंग",                    "Accent colour",      "Rang"},
        {"tabLimit",      "टैब की सीमा",             "Tab limit",          "Tab limit"},
        {"tor",           "टॉर (Orbot से)",          "Tor via Orbot",      "Tor (Orbot se)"},
        {"security",      "सुरक्षा स्तर",            "Security level",     "Security level"},
        {"proof",         "प्राइवेसी प्रमाण",         "Privacy proof",      "Privacy proof"},
        {"diagnostics",   "डायग्नोस्टिक्स",          "Diagnostics",        "Diagnostics"},
        {"console",       "कंसोल",                  "Console",            "Console"},
        {"devPanel",      "डेव पैनल",               "Dev panel",          "Dev panel"},
        {"selfTest",      "सेल्फ़ टेस्ट",             "Self test",          "Self test"},
        {"updates",       "अपडेट देखो",             "Check for updates",  "Update dekho"},
        {"about",         "मर्सी GX के बारे में",     "About Mercy GX",     "Mercy GX ke baare mein"},
        {"panic",         "सब मिटाओ",               "Panic wipe",         "Sab mitao"},
        {"fullScreen",    "पूरी स्क्रीन",            "Full screen",        "Full screen"},
        {"back",          "पीछे",                   "Back",               "Peeche"},
        {"forward",       "आगे",                    "Forward",            "Aage"},
        {"tabs",          "टैब",                    "Tabs",               "Tabs"},
        {"tariff",        "डेटा दाम",               "Data tariff",        "Data daam"},
        {"darken",        "पेज गहरे रंग में",         "Darken pages",       "Page gehare rang mein"},
        {"pack",          "साइट सूची पैक",           "Site list pack",     "Site list pack"},
        {"language",      "भाषा",                   "Language",           "Bhasha"},
        {"lightDark",     "हल्का / गहरा",            "Light / dark",       "Light / dark"},
        {"blocker",       "विज्ञापन ब्लॉकर",          "Ad blocker",         "Ad blocker"},
        {"clearAll",      "सब मिटाओ",               "Clear everything",   "Sab mitao"},
        {"engine",        "पेज इंजन",                "Page engine",        "Page engine"},
        {"tabsLimitRow",  "टैब की सीमा",             "Tab limit",          "Tab limit"},
    };

    /** a menu label in the app language, falling back to the English literal */
    public String m(String key, String english) {
        String c = code();
        for (String[] row : MENU) {
            if (!row[0].equals(key)) continue;
            if ("hi".equals(c)) return row[1];
            if ("hinglish".equals(c)) return row[3];
            return row[2];
        }
        return english;
    }

    public String t(String key) {
        String[] row = T.get(key);
        if (row == null) return key;
        String c = code();
        if ("hi".equals(c)) return row[0];
        if ("hinglish".equals(c)) return row[2];
        return row[1];
    }

    private static android.content.Context APP;

    /** called once from the activity so labels can be read from assets */
    public static void attach(android.content.Context c) { APP = c.getApplicationContext(); }

    /**
     * A label that always resolves: the language table, then English, then the
     * string the caller passed.
     *
     * labels.json ships flat keys ("ui_5": "Accent hex"), but this lookup only
     * ever asked for "hi:ui_5" and "en:ui_5", so the asset was read and never
     * used — every label in the app stayed English whatever language was picked.
     */
    public String ui(String key, String fallback) {
        try {
            if (TABLE == null) {
                /* two threads (UI + the blocker thread) can arrive here together;
                   building the table twice is harmless, publishing it half-built is not */
                synchronized (Lang.class) {
                    if (TABLE == null) TABLE = new org.json.JSONObject(Io.readAsset(APP, "labels.json"));
                }
            }
            String k = code() + ":" + key;
            if (TABLE.has(k)) return TABLE.getString(k);
            if (TABLE.has("en:" + key)) return TABLE.getString("en:" + key);
            if (TABLE.has(key)) return TABLE.getString(key);      /* the shipped flat table */
        } catch (Throwable t) { CrashGuard.note("lang.ui", t); }
        return fallback;
    }

    private static volatile org.json.JSONObject TABLE;
}
