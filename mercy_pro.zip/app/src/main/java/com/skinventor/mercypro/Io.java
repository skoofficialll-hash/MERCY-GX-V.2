package com.skinventor.mercypro;

import android.content.Context;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

/**
 * Reading a file that ships inside the APK, once, correctly.
 *
 * The old code did `new byte[in.available()]; in.read(buf);` in eight places.
 * available() is a hint, and read() is allowed to return fewer bytes than asked —
 * so a large compressed asset (the 63 KB site index, the 843 KB filter list) could
 * come back truncated. A truncated JSON file parses to nothing, which is why the
 * site list and the self test could claim zero entries on a real phone while
 * looking fine on a desk. This reads until the stream actually ends.
 */
public final class Io {

    private Io() { }

    public static byte[] readAll(InputStream in) throws java.io.IOException {
        if (in == null) return new byte[0];
        ByteArrayOutputStream out = new ByteArrayOutputStream(8192);
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        return out.toByteArray();
    }

    /** one asset, as text; never null */
    public static String readAsset(Context c, String name) {
        InputStream in = null;
        try {
            in = c.getAssets().open(name);
            return new String(readAll(in), "UTF-8");
        } catch (Throwable t) {
            CrashGuard.note("asset:" + name, t);
            return "";
        } finally {
            close(in);
        }
    }

    /** one asset, as bytes; never null */
    public static byte[] readAssetBytes(Context c, String name) {
        InputStream in = null;
        try {
            in = c.getAssets().open(name);
            return readAll(in);
        } catch (Throwable t) {
            CrashGuard.note("asset:" + name, t);
            return new byte[0];
        } finally {
            close(in);
        }
    }

    public static void close(java.io.Closeable c) {
        if (c == null) return;
        try { c.close(); } catch (Throwable ignored) { }
    }
}
