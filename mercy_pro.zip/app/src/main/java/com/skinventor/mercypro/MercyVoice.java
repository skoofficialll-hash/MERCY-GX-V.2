package com.skinventor.mercypro;

import android.content.Context;
import android.os.Build;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;

import java.util.Locale;
import java.util.Set;

/**
 * Read aloud with the phone's own speech engine.
 *
 * No library, no download, no network: this is the OS API. A voice is only used
 * after three checks, because isLanguageAvailable() on its own lies — it can say
 * AVAILABLE while the voice data is not installed and the engine silently falls
 * back to a different language.
 */
public class MercyVoice {

    private TextToSpeech tts;
    private boolean ready = false;
    private String why = "starting";

    public MercyVoice(Context c) {
        try {
            tts = new TextToSpeech(c, new TextToSpeech.OnInitListener() {
                @Override public void onInit(int status) {
                    if (status != TextToSpeech.SUCCESS) {
                        why = "this phone has no speech engine";
                        return;
                    }
                    ready = true;
                    why = pick(Locale.getDefault()) ? "ready" : "no offline voice for this language";
                }
            });
        } catch (Throwable t) {
            why = "speech could not start";
            CrashGuard.note("voice", t);
        }
    }

    /** the three checks, in order */
    private boolean pick(Locale want) {
        if (tts == null) return false;
        try {
            int avail = tts.isLanguageAvailable(want);
            if (avail == TextToSpeech.LANG_MISSING_DATA || avail == TextToSpeech.LANG_NOT_SUPPORTED) {
                Locale fallback = new Locale(want.getLanguage());
                if (tts.isLanguageAvailable(fallback) == TextToSpeech.LANG_NOT_SUPPORTED) return false;
                want = fallback;
            }
            if (Build.VERSION.SDK_INT >= 21) {
                Voice v = tts.getVoice();
                if (v != null) {
                    Set<String> f = v.getFeatures();
                    if (f != null && f.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED)) return false;
                    if (v.isNetworkConnectionRequired()) return false;   /* stay offline */
                }
            }
            return tts.setLanguage(want) >= TextToSpeech.LANG_AVAILABLE;
        } catch (Throwable t) {
            CrashGuard.note("voicePick", t);
            return false;
        }
    }

    public boolean isReady() { return ready && tts != null; }

    public String status() { return why; }

    /** true if the words actually went to the engine */
    public boolean speak(String text) {
        if (!isReady() || text == null) return false;
        String body = text.trim();
        if (body.isEmpty()) return false;
        if (body.length() > 6000) body = body.substring(0, 6000);   /* keep one utterance sane */
        try {
            tts.speak(body, TextToSpeech.QUEUE_FLUSH, null, "mercy-read");
            return true;
        } catch (Throwable t) {
            CrashGuard.note("voiceSpeak", t);
            return false;
        }
    }

    public void stop() {
        try { if (tts != null) tts.stop(); } catch (Throwable t) { CrashGuard.note("voiceStop", t); }
    }

    public void release() {
        try {
            if (tts != null) { tts.stop(); tts.shutdown(); }
        } catch (Throwable t) {
            CrashGuard.note("voiceRelease", t);
        }
        tts = null;
        ready = false;
    }
}
