/* Mercy Core — the only extension this browser ships.
   It reports what a page actually contains, and runs code only when the app asks.
   It never sends anything to a server. */
(function () {
  "use strict";

  function facts() {
    var imgs = document.images ? document.images.length : 0;
    var links = document.links ? document.links.length : 0;
    var scripts = document.scripts ? document.scripts.length : 0;
    var domBytes = 0;
    try { domBytes = new Blob([document.documentElement.outerHTML]).size; } catch (e) { }
    var imgsBytes = 0;
    try {
      for (var i = 0; i < document.images.length; i++) {
        var im = document.images[i];
        if (im.naturalWidth) imgsBytes += im.naturalWidth * im.naturalHeight * 4;
      }
    } catch (e) { }
    return {
      type: "facts",
      url: location.href,
      host: location.hostname,
      title: document.title || "",
      images: imgs,
      links: links,
      scripts: scripts,
      domBytes: domBytes,
      imageBytes: imgsBytes,
      forms: document.forms ? document.forms.length : 0,
      iframes: document.querySelectorAll("iframe").length
    };
  }

  function send(payload) {
    try {
      browser.runtime.sendNativeMessage("browser", payload);
    } catch (e) { }
  }

  /* the page is ready — tell the app what it is looking at */
  send(facts());

  /* the app can ask for one thing at a time; nothing else runs */
  try {
    browser.runtime.onMessage.addListener(function (msg, sender, respond) {
      if (!msg || typeof msg !== "object") return;
      if (msg.type === "facts") { respond(facts()); return true; }
      if (msg.type === "eval" && typeof msg.code === "string") {
        var out;
        try {
          /* eslint-disable no-eval */
          out = String(eval(msg.code));
        } catch (e) {
          out = "Error: " + e;
        }
        respond({ type: "evalResult", value: out });
        return true;
      }
      if (msg.type === "textOnly") {
        try {
          for (var i = 0; i < document.images.length; i++) document.images[i].style.display = "none";
          respond({ type: "ok" });
        } catch (e) { respond({ type: "error", message: String(e) }); }
        return true;
      }
    });
  } catch (e) { }
})();
