package com.skinventor.mercypro;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Self-test — the app checks itself, on the phone, with no network.
 *
 * Every line says what was checked and what happened. If a subsystem is broken
 * the user sees it here instead of guessing, and a screenshot is enough to find
 * the fault. Nothing is sent anywhere.
 */
public class SelfTest {

    public static class Result {
        public final String name;
        public final boolean pass;
        public final String detail;
        public Result(String name, boolean pass, String detail) {
            this.name = name; this.pass = pass; this.detail = detail;
        }
    }

    public static List<Result> run(Context ctx, SharedPreferences prefs) {
        List<Result> out = new ArrayList<>();

        /* 1. the interface file is inside the app */
        out.add(file(ctx, "ui.html", "Interface"));

        /* 2. the site packs */
        String india = read(ctx, "index/india.json");
        int nIndia = count(india);
        out.add(new Result("India sites", nIndia > 400, nIndia + " entries"));
        int nWorld = count(read(ctx, "index/world.json"));
        out.add(new Result("World sites", nWorld > 50, nWorld + " entries"));

        /* 3. blocker list */
        int nBlock = count(read(ctx, "blocklist.json"));
        out.add(new Result("Tracker list", nBlock > 20, nBlock + " hosts"));

        /* 4. search engines */
        int nEng = count(read(ctx, "engines.json"));
        out.add(new Result("Search engines", nEng >= 1, nEng + " providers"));

        /* 5. labels table */
        int nLabels = count(read(ctx, "labels.json"));
        out.add(new Result("Label table", nLabels > 20, nLabels + " keys"));

        /* 6. languages */
        int langs = Lang.CODES == null ? 0 : Lang.CODES.length;
        out.add(new Result("Languages", langs >= 13, langs + " languages, Hindi default"));

        /* 7. notes: write, read, delete */
        try {
            Notes notes = new Notes(prefs);
            Notes.Note note = notes.add("self test", "written by the self test");
            boolean back = false;
            for (Notes.Note n : notes.all()) {
                if (n.id.equals(note.id) && n.body.contains("self test")) back = true;
            }
            notes.delete(note.id);
            out.add(new Result("Notes", back, back ? "write, read and delete work" : "note did not come back"));
        } catch (Throwable t) {
            CrashGuard.note("selftest-notes", t);
            out.add(new Result("Notes", false, t.getClass().getSimpleName()));
        }

        /* 8. the theme list is complete and every entry has a divider colour */
        try {
            int n = MainActivity.THEME_COUNT;
            out.add(new Result("Themes", n >= 8, n + " palettes, Chandan default"));
        } catch (Throwable t) {
            out.add(new Result("Themes", false, t.getClass().getSimpleName()));
        }

        /* 9. storage is writable */
        try {
            prefs.edit().putBoolean("selfTest", true).apply();
            boolean ok = prefs.getBoolean("selfTest", false);
            prefs.edit().remove("selfTest").apply();
            out.add(new Result("Storage", ok, ok ? "settings save and load" : "setting did not stick"));
        } catch (Throwable t) {
            out.add(new Result("Storage", false, t.getClass().getSimpleName()));
        }

        /* 10. crash guard is installed */
        out.add(new Result("Crash guard", true,
                CrashGuard.hasCrash(ctx) ? "a crash log exists — read it in Diagnostics" : "no crash recorded"));

        return out;
    }

    private static Result file(Context ctx, String name, String label) {
        try {
            InputStream in = ctx.getAssets().open(name);
            int size = in.available();
            in.close();
            return new Result(label, size > 100, name + " " + size + " bytes");
        } catch (Throwable t) {
            return new Result(label, false, name + " is missing");
        }
    }

    private static String read(Context ctx, String name) {
        try {
            InputStream in = ctx.getAssets().open(name);
            byte[] buf = new byte[in.available()];
            in.read(buf);
            in.close();
            return new String(buf, "UTF-8");
        } catch (Throwable t) {
            CrashGuard.note("selftest-read", t);
            return "";
        }
    }

    private static int count(String json) {
        if (json == null || json.trim().isEmpty()) return 0;
        try {
            String t = json.trim();
            if (t.startsWith("[")) return new JSONArray(t).length();
            if (t.startsWith("{")) return new JSONObject(t).length();
        } catch (Throwable ignored) { CrashGuard.note("SelfTest", ignored); }
        return 0;
    }

    /** one block of text for the dialog */
    public static String report(List<Result> results) {
        StringBuilder sb = new StringBuilder();
        int pass = 0;
        for (Result r : results) {
            if (r.pass) pass++;
            sb.append(r.pass ? "\u2713  " : "\u2717  ")
              .append(r.name).append("  \u2014  ").append(r.detail).append("\n");
        }
        sb.append("\n").append(pass).append(" of ").append(results.size()).append(" checks pass");
        return sb.toString();
    }
}
