package com.skinventor.mercypro;

import android.content.Context;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;

import org.vosk.Model;
import org.vosk.Recognizer;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Speech recognition that runs entirely on the phone.
 *
 * Vosk does the decoding, the model lives in the app's private storage and
 * nothing is uploaded anywhere. No Google services are involved.
 */
public class OfflineVoice {

    public interface Callback {
        void onStatus(String text);
        void onPartial(String text);
        void onFinal(String text);
        void onError(String message);
    }

    private static final String MODEL_FOLDER = "vosk-hi";
    private static final String MODEL_URL =
            "https://alphacephei.com/vosk/models/vosk-model-small-hi-0.22.zip";
    private static final int SAMPLE_RATE = 16000;

    private final Context ctx;
    private Model model;
    private volatile boolean listening = false;
    private Thread worker;

    public OfflineVoice(Context ctx) { this.ctx = ctx.getApplicationContext(); }

    /* ---------------- model ---------------- */

    public File modelDir() { return new File(ctx.getFilesDir(), MODEL_FOLDER); }

    public boolean isReady() {
        File d = modelDir();
        return d.isDirectory() && d.list() != null && d.list().length > 0;
    }

    /** Downloads and unpacks the Hindi model once. Runs on a background thread. */
    public void download(final Callback cb) {
        new Thread(new Runnable() {
            @Override public void run() {
                File tmp = new File(ctx.getCacheDir(), "vosk-model.zip");
                try {
                    cb.onStatus("Downloading the Hindi voice model (42 MB)…");
                    HttpURLConnection c = (HttpURLConnection) new URL(MODEL_URL).openConnection();
                    c.setConnectTimeout(15000);
                    c.setReadTimeout(30000);
                    c.connect();
                    int total = c.getContentLength();
                    InputStream in = new BufferedInputStream(c.getInputStream());
                    OutputStream out = new FileOutputStream(tmp);
                    byte[] buf = new byte[8192];
                    long done = 0;
                    int n, lastPct = -1;
                    while ((n = in.read(buf)) > 0) {
                        out.write(buf, 0, n);
                        done += n;
                        if (total > 0) {
                            int pct = (int) (done * 100 / total);
                            if (pct != lastPct && pct % 10 == 0) { lastPct = pct; cb.onStatus("Downloading… " + pct + "%"); }
                        }
                    }
                    out.close();
                    in.close();
                    c.disconnect();

                    cb.onStatus("Unpacking…");
                    unzip(tmp, ctx.getFilesDir(), MODEL_FOLDER);
                    tmp.delete();

                    cb.onStatus("Model ready — voice works offline now");
                } catch (Exception e) {
                    try { tmp.delete(); } catch (Exception ex) { CrashGuard.note("OfflineVoice", ex); }
                    cb.onError("Download failed. Check the connection and try again.");
                }
            }
        }).start();
    }

    private void unzip(File zip, File targetRoot, String finalName) throws Exception {
        File stage = new File(targetRoot, finalName + "-tmp");
        deleteTree(stage);
        stage.mkdirs();

        ZipInputStream zin = new ZipInputStream(new FileInputStream(zip));
        ZipEntry e;
        String rootEntry = null;
        while ((e = zin.getNextEntry()) != null) {
            String name = e.getName();
            if (rootEntry == null && name.contains("/")) rootEntry = name.substring(0, name.indexOf('/'));
            File f = new File(stage, name);
            if (!f.getCanonicalPath().startsWith(stage.getCanonicalPath())) continue; // zip-slip guard
            if (e.isDirectory()) {
                f.mkdirs();
            } else {
                f.getParentFile().mkdirs();
                OutputStream os = new FileOutputStream(f);
                byte[] buf = new byte[8192];
                int n;
                while ((n = zin.read(buf)) > 0) os.write(buf, 0, n);
                os.close();
            }
            zin.closeEntry();
        }
        zin.close();

        // the archive holds one top folder; lift it to the final name
        File src = rootEntry == null ? stage : new File(stage, rootEntry);
        File dest = new File(targetRoot, finalName);
        deleteTree(dest);
        if (!src.renameTo(dest)) {
            copyTree(src, dest);
        }
        deleteTree(stage);
    }

    private void copyTree(File from, File to) throws Exception {
        if (from.isDirectory()) {
            to.mkdirs();
            for (File f : from.listFiles()) copyTree(f, new File(to, f.getName()));
        } else {
            InputStream in = new FileInputStream(from);
            OutputStream out = new FileOutputStream(to);
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            in.close();
            out.close();
        }
    }

    private void deleteTree(File f) {
        if (f == null || !f.exists()) return;
        if (f.isDirectory()) {
            File[] kids = f.listFiles();
            if (kids != null) for (File k : kids) deleteTree(k);
        }
        f.delete();
    }

    /* ---------------- recognition ---------------- */

    public void start(final Callback cb) {
        if (!isReady()) { cb.onError("Model not downloaded yet"); return; }
        if (listening) return;
        listening = true;

        worker = new Thread(new Runnable() {
            @Override public void run() {
                AudioRecord rec = null;
                Recognizer recognizer = null;
                try {
                    if (model == null) model = new Model(modelDir().getAbsolutePath());
                    recognizer = new Recognizer(model, SAMPLE_RATE);

                    int min = AudioRecord.getMinBufferSize(SAMPLE_RATE,
                            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
                    int size = Math.max(min, 8192);
                    rec = new AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION,
                            SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO,
                            AudioFormat.ENCODING_PCM_16BIT, size);
                    if (rec.getState() != AudioRecord.STATE_INITIALIZED) {
                        cb.onError("Microphone is busy");
                        return;
                    }
                    rec.startRecording();
                    cb.onStatus("Listening…");

                    byte[] buf = new byte[4096];
                    long lastPartial = 0;
                    while (listening) {
                        int n = rec.read(buf, 0, buf.length);
                        if (n <= 0) continue;
                        if (recognizer.acceptWaveForm(buf, n)) {
                            String text = extract(recognizer.getResult(), "text");
                            if (text != null && !text.trim().isEmpty()) {
                                listening = false;
                                cb.onFinal(text.trim());
                                break;
                            }
                        } else if (System.currentTimeMillis() - lastPartial > 400) {
                            lastPartial = System.currentTimeMillis();
                            String part = extract(recognizer.getPartialResult(), "partial");
                            if (part != null && !part.trim().isEmpty()) cb.onPartial(part.trim());
                        }
                    }
                } catch (Exception e) {
                    cb.onError("Offline voice failed: " + e.getClass().getSimpleName());
                } finally {
                    listening = false;
                    if (rec != null) {
                        try { rec.stop(); } catch (Exception ex) { CrashGuard.note("OfflineVoice", ex); }
                        try { rec.release(); } catch (Exception ex) { CrashGuard.note("OfflineVoice", ex); }
                    }
                    if (recognizer != null) {
                        try { recognizer.close(); } catch (Exception ex) { CrashGuard.note("OfflineVoice", ex); }
                    }
                }
            }
        }, "vosk-voice");
        worker.start();
    }

    public void stop() { listening = false; }

    private String extract(String json, String key) {
        try {
            org.json.JSONObject o = new org.json.JSONObject(json);
            return o.optString(key, "");
        } catch (Exception e) { return ""; }
    }
}
