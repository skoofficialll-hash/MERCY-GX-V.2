package com.skinventor.mercypro;

/**
 * Reader mode — the article, without the page.
 *
 * The engine hands us the page as text; we keep only what a person reads:
 * the title, the paragraphs, and nothing else. No scripts, no ads, no layout,
 * so it also uses far less data than the page it came from.
 */
public class Reader {

    public static class Article {
        public String title = "";
        public String byline = "";
        public final StringBuilder body = new StringBuilder();
        public int words() {
            String t = body.toString().trim();
            return t.isEmpty() ? 0 : t.split("\\s+").length;
        }
        public boolean ok() { return words() >= 40; }        /* a real article, not a stub */
    }

    /** the javascript that pulls the article out — no libraries, no network */
    public static final String EXTRACT_JS =
        "(function(){"
      + " var pick=function(s){var e=document.querySelector(s);return e?e.innerText:'';};"
      + " var title=document.title||'';"
      + " var by=pick('article [rel=author]')||pick('.byline')||pick('[class*=author]');"
      + " var nodes=document.querySelectorAll('article p, main p, .post p, .entry-content p, p');"
      + " var seen={},out=[];"
      + " for(var i=0;i<nodes.length;i++){"
      + "   var t=(nodes[i].innerText||'').replace(/\\s+/g,' ').trim();"
      + "   if(t.length<60) continue;"                       /* menus, captions, buttons */
      + "   if(seen[t]) continue;"
      + "   seen[t]=1; out.push(t);"
      + "   if(out.length>=120) break;"
      + " }"
      + " if(out.length===0){"
      + "   var b=document.body?document.body.innerText:'';"
      + "   b=b.replace(/\\s+/g,' ').trim();"
      + "   if(b.length>200) out=[b];"
      + " }"
      + " return JSON.stringify({title:title,byline:by,paras:out});"
      + "})();";

    /** turn the engine's json into an Article; never throws */
    public static Article parse(String json) {
        Article a = new Article();
        try {
            org.json.JSONObject o = new org.json.JSONObject(json);
            a.title = o.optString("title", "");
            a.byline = o.optString("byline", "");
            org.json.JSONArray ps = o.optJSONArray("paras");
            if (ps != null) for (int i = 0; i < ps.length(); i++) {
                String p = ps.optString(i, "").trim();
                if (p.isEmpty()) continue;
                if (a.body.length() > 0) a.body.append("\n\n");
                a.body.append(p);
            }
        } catch (Exception e) { CrashGuard.note("reader", e); }
        return a;
    }

    /** minutes at a calm 200 words per minute */
    public static int minutes(Article a) {
        int w = a.words();
        return w == 0 ? 0 : Math.max(1, w / 200);
    }
}
