package com.skinventor.mercypro;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;

import java.io.File;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Keeps the app honest when something goes wrong.
 *
 * A crash is written to a file on the phone — never sent anywhere. On the next
 * launch the app says what happened and offers safe mode, so one bad page can
 * never leave someone with an app that refuses to open.
 */
public class CrashGuard {

    private static final java.util.ArrayDeque<String> NOTES = new java.util.ArrayDeque<>();

    /** every caught exception lands here instead of disappearing */
    public static void note(String where, Throwable e) {
        try {
            if (NOTES.size() > 40) NOTES.removeLast();
            NOTES.addFirst(where + ": " + (e == null ? "?" : e.getClass().getSimpleName()));
        } catch (Throwable ignored) { }
    }

    public static String notes() {
        if (NOTES.isEmpty()) return "";
        StringBuilder sb = new StringBuilder();
        for (String n : NOTES) sb.append("\u2022 ").append(n).append("\n");
        return sb.toString();
    }

    private static final String DIR = "crash";
    private static final String FILE = "last-crash.txt";

    public static void install(final Context ctx) {
        final Thread.UncaughtExceptionHandler previous = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            @Override public void uncaughtException(Thread t, Throwable e) {
                try { write(ctx, e); } catch (Exception ex) { CrashGuard.note("CrashGuard", ex); }
                if (previous != null) previous.uncaughtException(t, e);
            }
        });
    }

    private static void write(Context ctx, Throwable e) {
        try {
            File dir = new File(ctx.getFilesDir(), DIR);
            if (!dir.exists()) dir.mkdirs();
            File f = new File(dir, FILE);

            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));

            String head = "Mercy GX " + version(ctx)
                    + "\nAndroid " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")"
                    + "\n" + Build.MANUFACTURER + " " + Build.MODEL
                    + "\n" + new SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.US).format(new Date())
                    + "\n\n";

            java.io.FileOutputStream out = new java.io.FileOutputStream(f, false);
            out.write((head + sw.toString()).getBytes("UTF-8"));
            out.close();

            SharedPreferences p = ctx.getSharedPreferences("mercy", Context.MODE_PRIVATE);
            int count = p.getInt("crashCount", 0) + 1;
            p.edit().putInt("crashCount", count).apply();
        } catch (Exception ex) { CrashGuard.note("CrashGuard", ex); }
    }

    private static String version(Context ctx) {
        try { return ctx.getPackageManager().getPackageInfo(ctx.getPackageName(), 0).versionName; }
        catch (Exception e) { return "?"; }
    }

    public static File file(Context ctx) { return new File(new File(ctx.getFilesDir(), DIR), FILE); }

    public static boolean hasCrash(Context ctx) { return file(ctx).exists(); }

    public static String read(Context ctx) {
        try {
            File f = file(ctx);
            if (!f.exists()) return "No crash recorded.";
            java.io.FileInputStream in = new java.io.FileInputStream(f);
            byte[] buf = new byte[(int) f.length()];
            int n = in.read(buf);
            in.close();
            return new String(buf, 0, Math.max(n, 0), "UTF-8");
        } catch (Exception e) { return "Log unavailable."; }
    }

    public static void clear(Context ctx) {
        try { file(ctx).delete(); } catch (Exception ex) { CrashGuard.note("CrashGuard", ex); }
        ctx.getSharedPreferences("mercy", Context.MODE_PRIVATE)
                .edit().putInt("crashCount", 0).apply();
    }

    public static int count(Context ctx) {
        return ctx.getSharedPreferences("mercy", Context.MODE_PRIVATE).getInt("crashCount", 0);
    }
}
