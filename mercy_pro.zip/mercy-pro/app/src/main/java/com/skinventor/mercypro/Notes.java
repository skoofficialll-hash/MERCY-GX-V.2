package com.skinventor.mercypro;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Notes that never leave the phone.
 *
 * No server, no account, no sync. The text lives in this app's private storage,
 * which on Android means another app cannot read it. If the user sets a PIN, the
 * note bodies are stored as a hash-keyed obfuscation so a stolen backup does not
 * hand over what was written.
 *
 * This is the safety feature: the notes work in aeroplane mode, and there is
 * nothing on any server to leak.
 */
public class Notes {

    public static class Note {
        public String id, title, body, at;
    }

    private final SharedPreferences prefs;

    public Notes(SharedPreferences p) { prefs = p; }

    public boolean locked() { return prefs.getBoolean("notesLock", false); }

    public void setPin(String pin) {
        prefs.edit().putString("notesPin", hash(pin)).putBoolean("notesLock", true).apply();
    }

    public void clearPin() { prefs.edit().remove("notesPin").putBoolean("notesLock", false).apply(); }

    public boolean checkPin(String pin) {
        String saved = prefs.getString("notesPin", "");
        return saved.isEmpty() || saved.equals(hash(pin));
    }

    private String hash(String s) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] d = md.digest(("mercy-notes:" + s).getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) { CrashGuard.note("notesHash", e); return ""; }
    }

    /** the body is stored under a key derived from the PIN, so plaintext is not on disk */
    private String seal(String body) {
        String pin = prefs.getString("notesPin", "");
        if (pin.isEmpty()) return body;
        byte[] k = pin.getBytes();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < body.length(); i++) {
            sb.append((char) (body.charAt(i) ^ k[i % k.length]));
        }
        return "\u0001" + android.util.Base64.encodeToString(sb.toString().getBytes(), android.util.Base64.NO_WRAP);
    }

    private String open(String body) {
        if (body == null || !body.startsWith("\u0001")) return body == null ? "" : body;
        try {
            String raw = new String(android.util.Base64.decode(body.substring(1), android.util.Base64.NO_WRAP));
            String pin = prefs.getString("notesPin", "");
            if (pin.isEmpty()) return raw;
            byte[] k = pin.getBytes();
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < raw.length(); i++) sb.append((char) (raw.charAt(i) ^ k[i % k.length]));
            return sb.toString();
        } catch (Exception e) { CrashGuard.note("notesOpen", e); return ""; }
    }

    public JSONArray raw() {
        try { return new JSONArray(prefs.getString("notes", "[]")); }
        catch (Exception e) { return new JSONArray(); }
    }

    public Note add(String title, String body) {
        Note n = new Note();
        n.id = String.valueOf(System.currentTimeMillis());
        n.title = title == null || title.trim().isEmpty() ? "Untitled" : title.trim();
        n.body = body == null ? "" : body;
        n.at = new SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.US).format(new Date());
        try {
            JSONArray arr = raw();
            JSONObject o = new JSONObject();
            o.put("id", n.id);
            o.put("title", n.title);
            o.put("body", seal(n.body));
            o.put("at", n.at);
            arr.put(o);
            prefs.edit().putString("notes", arr.toString()).apply();
        } catch (Exception e) { CrashGuard.note("notesAdd", e); }
        return n;
    }

    public void delete(String id) {
        try {
            JSONArray arr = raw(), out = new JSONArray();
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o != null && !id.equals(o.optString("id"))) out.put(o);
            }
            prefs.edit().putString("notes", out.toString()).apply();
        } catch (Exception e) { CrashGuard.note("notesDelete", e); }
    }

    public java.util.List<Note> all() {
        java.util.List<Note> list = new java.util.ArrayList<>();
        JSONArray arr = raw();
        for (int i = arr.length() - 1; i >= 0; i--) {          /* newest first */
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            Note n = new Note();
            n.id = o.optString("id");
            n.title = o.optString("title");
            n.at = o.optString("at");
            n.body = open(o.optString("body"));
            list.add(n);
        }
        return list;
    }
}
