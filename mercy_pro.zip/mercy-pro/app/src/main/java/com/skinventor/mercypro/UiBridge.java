package com.skinventor.mercypro;

import android.webkit.JavascriptInterface;

/**
 * The only door between the HTML interface and Java.
 *
 * Every call is small and named after what a person asked for. Nothing here
 * sends data anywhere; it moves the browser between its own screens.
 */
public class UiBridge {

    public interface Host {
        void uiOpen(String url);
        void uiSearch();
        void uiAction(String action, String value);
        void uiTariff(String perMb);
        void uiCats(String csv);
        void uiLang(String code);
        void uiIntroDone();
        void uiTheme(String index);
    }

    private final Host host;

    public UiBridge(Host host) { this.host = host; }

    @JavascriptInterface public void open(String url) { host.uiOpen(url); }
    @JavascriptInterface public void search() { host.uiSearch(); }
    @JavascriptInterface public void tabs() { host.uiAction("tabs", ""); }
    @JavascriptInterface public void menu() { host.uiAction("menu", ""); }
    @JavascriptInterface public void reload() { host.uiAction("reload", ""); }
    @JavascriptInterface public void reader() { host.uiAction("reader", ""); }
    @JavascriptInterface public void share() { host.uiAction("share", ""); }
    @JavascriptInterface public void free() { host.uiAction("free", ""); }
    @JavascriptInterface public void scan() { host.uiAction("scan", ""); }
    @JavascriptInterface public void voice() { host.uiAction("voice", ""); }
    @JavascriptInterface public void settings() { host.uiAction("settings", ""); }
    @JavascriptInterface public void diag() { host.uiAction("diag", ""); }
    @JavascriptInterface public void about() { host.uiAction("about", ""); }
    @JavascriptInterface public void ledger() { host.uiAction("ledger", ""); }
    @JavascriptInterface public void report() { host.uiAction("report", ""); }
    @JavascriptInterface public void update() { host.uiAction("update", ""); }
    @JavascriptInterface public void budget() { host.uiAction("budget", ""); }
    @JavascriptInterface public void tariff(String perMb) { host.uiTariff(perMb); }
    @JavascriptInterface public void cats(String csv) { host.uiCats(csv); }
    @JavascriptInterface public void lang(String code) { host.uiLang(code); }
    @JavascriptInterface public void introDone(String v) { host.uiIntroDone(); }
    @JavascriptInterface public void lib(String what) { host.uiAction("lib:" + what, ""); }
    @JavascriptInterface public void theme(String index) { host.uiTheme(index); }
}
