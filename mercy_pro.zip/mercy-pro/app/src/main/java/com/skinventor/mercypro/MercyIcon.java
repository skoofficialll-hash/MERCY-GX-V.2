package com.skinventor.mercypro;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

/**
 * Line icons drawn on a 24x24 grid, 1.5px stroke, square caps.
 *
 * Why not font glyphs: ⌘ ⚙ ◑ ▥ render differently on every phone and look cheap.
 * These are the same everywhere and match the sharp design.
 */
public class MercyIcon extends View {

    public static final String SEARCH = "search", TABS = "tabs", BOOKMARK = "bookmark",
            HISTORY = "history", SHIELD = "shield", DATA = "data", THEME = "theme",
            DEV = "dev", SETTINGS = "settings", SHARE = "share", DOWNLOAD = "download",
            GLOBE = "globe", CLOSE = "close", RELOAD = "reload", PLUS = "plus",
            LOCK = "lock", STAR = "star", WARN = "warn", TRASH = "trash";

    private String key = SEARCH;
    private int color = 0xFFE8E8EA;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();

    public MercyIcon(Context c) {
        super(c);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(1.5f));
        paint.setStrokeCap(Paint.Cap.SQUARE);
        paint.setStrokeJoin(Paint.Join.MITER);
    }

    public MercyIcon icon(String k) { key = k; invalidate(); return this; }
    public MercyIcon tint(int c) { color = c; invalidate(); return this; }

    private float dp(float v) {
        return v * getResources().getDisplayMetrics().density;
    }

    @Override protected void onMeasure(int w, int h) {
        int size = (int) dp(20);
        setMeasuredDimension(size, size);
    }

    @Override protected void onDraw(Canvas canvas) {
        paint.setColor(color);
        float s = getWidth() / 24f;          // scale the 24px grid to the view
        canvas.save();
        canvas.scale(s, s);
        path.reset();

        switch (key) {
            case TABS:
                rect(3, 6, 14, 18);
                canvas.drawPath(path, paint);
                path.reset();
                move(7, 6); line(7, 3); line(18, 3); line(18, 15); line(14, 15);
                break;
            case BOOKMARK:
                move(6, 3); line(18, 3); line(18, 21); line(12, 16.5f); line(6, 21); close();
                break;
            case HISTORY:
                move(3, 12);
                arc(12, 12, 9, 9, 0, 300, false);
                move(3, 3); line(3, 8); line(8, 8);
                move(12, 8); line(12, 12); line(15, 14);
                break;
            case SHIELD:
                move(12, 3); line(19, 6); line(19, 12);
                arc(12, 12, 7, 9, 0, 180, true);
                move(19, 12); line(12, 21); line(5, 12);
                break;
            case DATA:
                move(4, 17); line(4, 9);
                move(9, 17); line(9, 5);
                move(14, 17); line(14, 11);
                move(19, 17); line(19, 8);
                break;
            case THEME:
                arc(12, 12, 4, 4, 0, 360, false);
                move(12, 2); line(12, 5);
                move(12, 19); line(12, 22);
                move(2, 12); line(5, 12);
                move(19, 12); line(22, 12);
                move(5, 5); line(7, 7);
                move(17, 17); line(19, 19);
                move(19, 5); line(17, 7);
                move(7, 17); line(5, 19);
                break;
            case DEV:
                move(9, 8); line(5, 12); line(9, 16);
                move(15, 8); line(19, 12); line(15, 16);
                break;
            case SETTINGS:
                arc(12, 12, 3, 3, 0, 360, false);
                arc(12, 12, 8, 8, 20, 40, false);
                arc(12, 12, 8, 8, 110, 40, false);
                arc(12, 12, 8, 8, 200, 40, false);
                arc(12, 12, 8, 8, 290, 40, false);
                move(12, 1); line(12, 4);
                move(12, 20); line(12, 23);
                move(1, 12); line(4, 12);
                move(20, 12); line(23, 12);
                break;
            case SHARE:
                move(12, 15); line(12, 3);
                move(8, 7); line(12, 3); line(16, 7);
                move(4, 14); line(4, 20); line(20, 20); line(20, 14);
                break;
            case DOWNLOAD:
                move(12, 3); line(12, 15);
                move(8, 11); line(12, 15); line(16, 11);
                move(4, 19); line(20, 19);
                break;
            case GLOBE:
                arc(12, 12, 9, 9, 0, 360, false);
                move(3, 12); line(21, 12);
                move(12, 3);
                arc(12, 12, 9, 9, 90, 180, false);
                move(12, 3);
                arc(12, 12, 9, 9, 270, 180, false);
                break;
            case CLOSE:
                move(5, 5); line(19, 19);
                move(19, 5); line(5, 19);
                break;
            case RELOAD:
                arc(12, 12, 8, 8, 40, 280, false);
                move(12, 4); line(16, 5); line(14, 9);
                break;
            case PLUS:
                move(12, 5); line(12, 19);
                move(5, 12); line(19, 12);
                break;
            case LOCK:
                rect(5, 11, 14, 10);
                move(8, 11); line(8, 7);
                arc(12, 7, 4, 4, 180, 180, false);
                move(16, 11); line(16, 7);
                break;
            case STAR:
                move(12, 3); line(14.6f, 9); line(21, 9.6f); line(16.2f, 14);
                line(17.6f, 20.4f); line(12, 17); line(6.4f, 20.4f);
                line(7.8f, 14); line(3, 9.6f); line(9.4f, 9); close();
                break;
            case WARN:
                move(12, 3); line(21, 20); line(3, 20); close();
                move(12, 9); line(12, 14);
                move(12, 17); line(12, 17.2f);
                break;
            case TRASH:
                move(4, 6); line(20, 6);
                move(9, 6); line(9, 3); line(15, 3); line(15, 6);
                move(6, 6); line(7, 21); line(17, 21); line(18, 6);
                break;
            default: /* SEARCH */
                arc(10, 10, 5.5f, 5.5f, 0, 360, false);
                move(14, 14); line(19, 19);
                break;
        }
        canvas.drawPath(path, paint);
        canvas.restore();
    }

    private void move(float x, float y) { path.moveTo(x, y); }
    private void line(float x, float y) { path.lineTo(x, y); }
    private void close() { path.close(); }
    private void rect(float x, float y, float w, float h) { path.addRect(x, y, x + w, y + h, Path.Direction.CW); }
    private void arc(float cx, float cy, float rx, float ry, float start, float sweep, boolean forceMove) {
        if (forceMove) path.moveTo(cx + rx, cy);
        path.addArc(cx - rx, cy - ry, cx + rx, cy + ry, start, sweep);
    }
}
