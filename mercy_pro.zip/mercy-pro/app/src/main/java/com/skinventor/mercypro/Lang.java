package com.skinventor.mercypro;

import android.content.SharedPreferences;
import java.util.LinkedHashMap;
import java.util.Map;

/** Languages: India first (Hindi default), then the world's biggest. */
public class Lang {
    public static final String[] CODES = {"hi","en","hinglish","bn","mr","te","ta","gu","kn","ml","pa","or","ur",
            "zh","es","ar","fr","pt","ru","id"};
    public static final String[] NAMES = {"हिन्दी","English","Hinglish","বাংলা","मराठी","తెలుగు","தமிழ்","ગુજરાતી",
            "ಕನ್ನಡ","മലയാളം","ਪੰਜਾਬੀ","ଓଡ଼ିଆ","اردو","中文","Español","العربية","Français","Português","Русский","Bahasa Indonesia"};

    public static boolean isRtl(String code) { return "ur".equals(code) || "ar".equals(code); }

    private static final Map<String, String[]> T = new LinkedHashMap<>();
    static {
        T.put("offline_title", new String[]{"आप ऑफ़लाइन हैं।","You are offline.","Net nahi hai."});
        T.put("offline_body", new String[]{"इंटरनेट नहीं है। पर 713 साइटें आपके फ़ोन में हैं — वही खुल जाएँगी।",
                "No internet. But 713 sites are on your phone — those will open.",
                "Net nahi hai. Par 713 sites phone par hi hain — wahi khul jayengi."});
        T.put("open_offline", new String[]{"ऑफ़लाइन साइटें खोलें","Open offline sites","Offline sites kholo"});
        T.put("try_again", new String[]{"फिर कोशिश करें","Try again","Phir try karo"});
        T.put("stop_loading", new String[]{"रोकें","Stop loading","Band karo"});
        T.put("go_home", new String[]{"होम पर जाएँ","Go home","Home chalo"});
        T.put("go_back", new String[]{"पीछे जाएँ","Go back","Peeche chalo"});
        T.put("reload", new String[]{"फिर लोड करें","Reload","Reload karo"});
        T.put("continue", new String[]{"जारी रखें","Continue","Continue"});
        T.put("offline_block", new String[]{"713 साइटें · ऑफ़लाइन","713 SITES · OFFLINE","713 SITES · OFFLINE"});
        T.put("blocked_title", new String[]{"यह ट्रैकर ब्लॉक हुआ।","Tracker blocked.","Tracker block hua."});
        T.put("blocked_body", new String[]{"यह साइट आपका डेटा भेज रही थी। हमने रोका।",
                "This page was sending your data somewhere. We stopped it.",
                "Ye page tumhara data bhej raha tha. Humne roka."});
        T.put("settings", new String[]{"सेटिंग्स","Settings","Settings"});
        T.put("theme", new String[]{"थीम","Theme","Theme"});
        T.put("language", new String[]{"भाषा","Language","Bhasha"});
        T.put("blocker", new String[]{"विज्ञापन और ट्रैकर ब्लॉक","Block ads and trackers","Ads aur tracker block"});
        T.put("engine", new String[]{"इंजन","Engine","Engine"});
    }

    private final SharedPreferences prefs;
    public Lang(SharedPreferences p) { prefs = p; }
    public String code() { String c = prefs.getString("lang", null); return c == null ? "hi" : c; }
    public void set(String c) { prefs.edit().putString("lang", c).apply(); }
    public boolean rtl() { return isRtl(code()); }
    public String t(String key) {
        String[] row = T.get(key);
        if (row == null) return key;
        String c = code();
        if ("hi".equals(c)) return row[0];
        if ("hinglish".equals(c)) return row[2];
        return row[1];
    }
}
