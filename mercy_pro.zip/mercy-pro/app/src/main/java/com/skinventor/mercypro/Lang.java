package com.skinventor.mercypro;

import android.content.SharedPreferences;
import java.util.LinkedHashMap;
import java.util.Map;

/** Languages: India first (Hindi default), then the world's biggest. */
public class Lang {
    public static final String[] CODES = {"hi","en","hinglish","bn","mr","te","ta","gu","kn","ml","pa","or","ur",
            };
    public static final String[] NAMES = {"हिन्दी","English","Hinglish","বাংলা","मराठी","తెలుగు","தமிழ்","ગુજરાતી",
            "ಕನ್ನಡ","മലയാളം","ਪੰਜਾਬੀ","ଓଡ଼ିଆ","اردو",};

    public static boolean isRtl(String code) { return "ur".equals(code) || "ar".equals(code); }

    private static final Map<String, String[]> T = new LinkedHashMap<>();
    static {
        T.put("offline_title", new String[]{"आप ऑफ़लाइन हैं।","You are offline.","Net nahi hai."});
        T.put("offline_body", new String[]{"इंटरनेट नहीं है। पर 713 साइटें आपके फ़ोन में हैं — वही खुल जाएँगी।",
                "No internet. But 713 sites are on your phone — those will open.",
                "Net nahi hai. Par 713 sites phone par hi hain — wahi khul jayengi."});
        T.put("open_offline", new String[]{"ऑफ़लाइन साइटें खोलें","Open offline sites","Offline sites kholo"});
        T.put("try_again", new String[]{"फिर कोशिश करें","Try again","Phir try karo"});
        T.put("stop_loading", new String[]{"रोकें","Stop loading","Band karo"});
        T.put("go_home", new String[]{"होम पर जाएँ","Go home","Home chalo"});
        T.put("go_back", new String[]{"पीछे जाएँ","Go back","Peeche chalo"});
        T.put("reload", new String[]{"फिर लोड करें","Reload","Reload karo"});
        T.put("continue", new String[]{"जारी रखें","Continue","Continue"});
        T.put("offline_block", new String[]{"713 साइटें · ऑफ़लाइन","713 SITES · OFFLINE","713 SITES · OFFLINE"});
        T.put("blocked_title", new String[]{"यह ट्रैकर ब्लॉक हुआ।","Tracker blocked.","Tracker block hua."});
        T.put("blocked_body", new String[]{"यह साइट आपका डेटा भेज रही थी। हमने रोका।",
                "This page was sending your data somewhere. We stopped it.",
                "Ye page tumhara data bhej raha tha. Humne roka."});
        T.put("settings", new String[]{"सेटिंग्स","Settings","Settings"});
        T.put("theme", new String[]{"थीम","Theme","Theme"});
        T.put("language", new String[]{"भाषा","Language","Bhasha"});
        T.put("blocker", new String[]{"विज्ञापन और ट्रैकर ब्लॉक","Block ads and trackers","Ads aur tracker block"});
        T.put("library", new String[]{"लाइब्रेरी","Library","Library"});
        T.put("nothing_leaves", new String[]{"यहाँ से कुछ भी आपका फ़ोन नहीं छोड़ता।","Nothing here leaves your phone.","Yahan se kuch bhi phone nahi chhodta."});
        T.put("type_to_search", new String[]{"खोजने के लिए लिखें। हाल के पेज यहाँ दिखेंगे।","Type to search. Your recent pages will show here.","Search karne ke liye likho. Recent pages yahan dikhenge."});
        T.put("your_data_money", new String[]{"आपका डेटा, पैसों में।","Your data, in money.","Tumhara data, paison mein."});
        T.put("continue", new String[]{"जारी रखें","Continue","Continue"});
        T.put("appearance", new String[]{"रूप","Appearance","Appearance"});
        T.put("search_engine", new String[]{"सर्च इंजन","Search engine","Search engine"});
        T.put("data_budget", new String[]{"डेटा बजट","Data budget","Data budget"});
        T.put("report_card", new String[]{"रिपोर्ट कार्ड","Report card","Report card"});
        T.put("data_tariff", new String[]{"डेटा का दाम","Data tariff","Data ka daam"});
        T.put("offline_pages", new String[]{"ऑफ़लाइन पेज","Offline pages","Offline pages"});
        T.put("bookmarks", new String[]{"बुकमार्क","Bookmarks","Bookmarks"});
        T.put("new_tab", new String[]{"नया टैब","New tab","Naya tab"});
        T.put("incognito_tab", new String[]{"गुप्त टैब","New incognito tab","Naya incognito tab"});
        T.put("bookmark_page", new String[]{"इस पेज को बुकमार्क करें","Bookmark this page","Ye page bookmark karo"});
        T.put("reload_page", new String[]{"पेज फिर लोड करें","Reload page","Page reload karo"});
        T.put("share_page", new String[]{"पेज शेयर करें","Share page","Page share karo"});
        T.put("reader", new String[]{"रीडर मोड","Reader mode","Reader mode"});
        T.put("reader_fail", new String[]{"इस पेज पर पढ़ने लायक टेक्स्ट नहीं मिला।","No readable text found on this page.","Is page par padhne layak text nahi mila."});
        T.put("study", new String[]{"स्टडी मोड","Study mode","Study mode"});
        T.put("study_start", new String[]{"25 मिनट शुरू करें","Start 25 minutes","25 minute shuru"});
        T.put("study_stop", new String[]{"रोकें","Stop","Band karo"});
        T.put("wipe_title", new String[]{"सब कुछ मिटाएँ?","Erase everything?","Sab kuch mita dein?"});
        T.put("wipe_body", new String[]{"इससे इतिहास, टैब, बुकमार्क और सेटिंग्स मिट जाएँगी। यह वापस नहीं आएगा।",
                "This deletes history, tabs, bookmarks and settings. It cannot be undone.",
                "Isse history, tabs, bookmarks aur settings mit jayengi. Wapas nahi aayengi."});
        T.put("type_erase", new String[]{"ERASE लिखें","Type ERASE","ERASE likho"});
        T.put("diagnostics", new String[]{"जाँच","Diagnostics","Diagnostics"});
        T.put("engine", new String[]{"इंजन","Engine","Engine"});
    }

    private final SharedPreferences prefs;
    public Lang(SharedPreferences p) { prefs = p; }
    public String code() { String c = prefs.getString("lang", null); return c == null ? "hi" : c; }
    public void set(String c) { prefs.edit().putString("lang", c).apply(); }
    public boolean rtl() { return isRtl(code()); }
    public String t(String key) {
        String[] row = T.get(key);
        if (row == null) return key;
        String c = code();
        if ("hi".equals(c)) return row[0];
        if ("hinglish".equals(c)) return row[2];
        return row[1];
    }

    private static android.content.Context APP;

    /** called once from the activity so labels can be read from assets */
    public static void attach(android.content.Context c) { APP = c.getApplicationContext(); }

    /** a label that always resolves: asset table first, then the built-in string */
    public String ui(String key, String fallback) {
        try {
            if (TABLE == null) {
                java.io.InputStream in = APP.getAssets().open("labels.json");
                byte[] buf = new byte[in.available()];
                in.read(buf);
                in.close();
                TABLE = new org.json.JSONObject(new String(buf, "UTF-8"));
            }
            String k = code() + ":" + key;
            if (TABLE.has(k)) return TABLE.getString(k);
            if (TABLE.has("en:" + key)) return TABLE.getString("en:" + key);
        } catch (Throwable t) { CrashGuard.note("lang.ui", t); }
        return fallback;
    }

    private static org.json.JSONObject TABLE;
}
