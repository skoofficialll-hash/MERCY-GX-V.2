package com.skinventor.mercypro;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;
import android.view.animation.LinearInterpolator;

/** Three mascots on Canvas: METER, BATTU, CHIDIYA. Random per error screen. */
public class Mascot extends View {
    public static final int METER = 0, BATTU = 1, CHIDIYA = 2;
    private int kind = METER, ink = 0xFFF2F2F2, accent = 0xFFC9A8FF;
    private float phase = 0f;
    private ValueAnimator anim;
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF box = new RectF();

    public Mascot(Context c) {
        super(c);
        line.setStyle(Paint.Style.STROKE); line.setStrokeWidth(dp(2)); line.setStrokeCap(Paint.Cap.SQUARE);
        fill.setStyle(Paint.Style.FILL);
        anim = ValueAnimator.ofFloat(0f, 1f);
        anim.setDuration(2600); anim.setRepeatCount(ValueAnimator.INFINITE);
        anim.setInterpolator(new LinearInterpolator());
        anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator a) { phase = (float) a.getAnimatedValue(); invalidate(); }
        });
        anim.start();
    }
    public Mascot kind(int k) { kind = k; invalidate(); return this; }
    public Mascot colors(int i, int a) { ink = i; accent = a; invalidate(); return this; }
    public static int randomKind() { return (int) (Math.random() * 3); }
    private float dp(float v) { return v * getResources().getDisplayMetrics().density; }
    @Override protected void onDetachedFromWindow() { super.onDetachedFromWindow(); if (anim != null) { anim.cancel(); anim = null; } }
    @Override protected void onMeasure(int w, int h) { setMeasuredDimension((int) dp(84), (int) dp(84)); }
    @Override protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight(), cx = w / 2f, cy = h / 2f, r = Math.min(w, h) * 0.42f;
        float s = (float) Math.sin(phase * Math.PI * 2);
        line.setColor(ink); fill.setColor(accent);
        if (kind == METER) {
            c.drawCircle(cx, cy, r, line);
            for (int i = 0; i <= 6; i++) {
                double a = Math.toRadians(150 + i * 40);
                c.drawLine(cx + (float) Math.cos(a) * (r - dp(2)), cy + (float) Math.sin(a) * (r - dp(2)),
                           cx + (float) Math.cos(a) * (r - dp(7)), cy + (float) Math.sin(a) * (r - dp(7)), line);
            }
            double na = Math.toRadians(150 - (1 - s) * 60);
            line.setColor(accent);
            c.drawLine(cx, cy, cx + (float) Math.cos(na) * (r * 0.72f), cy + (float) Math.sin(na) * (r * 0.72f), line);
            line.setColor(ink);
            c.drawCircle(cx, cy, dp(3), fill);
            fill.setColor(ink);
            c.drawCircle(cx - r * 0.30f, cy + r * 0.34f, dp(2), fill);
            c.drawCircle(cx + r * 0.30f, cy + r * 0.34f, dp(2), fill);
        } else if (kind == BATTU) {
            float bw = r * 1.9f, bh = r * 1.05f;
            box.set(cx - bw / 2, cy - bh / 2, cx + bw / 2, cy + bh / 2);
            c.drawRect(box, line);
            c.drawRect(cx + bw / 2, cy - bh * 0.22f, cx + bw / 2 + dp(4), cy + bh * 0.22f, fill);
            float lvl = 0.12f + (s + 1f) / 2f * 0.5f, pad = dp(3);
            fill.setColor(accent);
            c.drawRect(box.left + pad, box.top + pad, box.left + pad + (bw - pad * 2) * lvl, box.bottom - pad, fill);
            fill.setColor(ink);
            c.drawCircle(cx - bw * 0.16f, cy, dp(2), fill);
            c.drawCircle(cx + bw * 0.06f, cy, dp(2), fill);
        } else {
            float bob = s * dp(2.5f);
            box.set(cx - r * 0.95f, cy - r * 0.55f + bob, cx + r * 0.25f, cy + r * 0.75f + bob);
            c.drawOval(box, line);
            c.drawCircle(cx + r * 0.52f, cy - r * 0.42f + bob, r * 0.42f, line);
            line.setColor(0xFFFFB020);
            c.drawLine(cx + r * 0.94f, cy - r * 0.42f + bob, cx + r * 0.94f + dp(6), cy - r * 0.42f + bob + dp(1.5f), line);
            line.setColor(ink);
            fill.setColor(ink);
            c.drawCircle(cx + r * 0.58f, cy - r * 0.5f + bob, dp(1.8f), fill);
            float flap = (s + 1f) / 2f * dp(7);
            line.setColor(accent);
            box.set(cx - r * 0.7f, cy - r * 0.35f + bob - flap, cx + r * 0.1f, cy + r * 0.35f + bob - flap);
            c.drawOval(box, line);
            line.setColor(ink);
        }
    }
}
