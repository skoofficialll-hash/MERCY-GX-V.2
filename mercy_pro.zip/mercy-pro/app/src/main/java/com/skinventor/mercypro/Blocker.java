package com.skinventor.mercypro;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.util.HashSet;
import java.util.Set;

/** Ad and tracker blocker. The list ships in the APK, so it works offline. */
public class Blocker {
    private final Set<String> hosts = new HashSet<>();
    private final Set<String> allowed = new HashSet<>();
    private int blockedCount = 0;
    private boolean enabled = true;

    public Blocker(Context c, boolean enabled) { this.enabled = enabled; load(c); }

    private void load(Context c) {
        InputStream in = null;
        try {
            in = c.getAssets().open("blocklist.json");
            byte[] buf = new byte[in.available()]; in.read(buf);
            JSONArray arr = new JSONObject(new String(buf, "UTF-8")).optJSONArray("hosts");
            if (arr != null) for (int i = 0; i < arr.length(); i++) {
                String h = arr.optString(i, "").toLowerCase().trim();
                if (!h.isEmpty()) hosts.add(h);
            }
        } catch (Exception ex) { CrashGuard.note("Blocker", ex); } finally { try { if (in != null) in.close(); } catch (Exception ex) { CrashGuard.note("Blocker", ex); } }

        /* the EasyList-derived domain set: one host per line, "!" starts a comment */
        java.io.BufferedReader r = null;
        try {
            r = new java.io.BufferedReader(new java.io.InputStreamReader(
                    c.getAssets().open("easylist.txt"), "UTF-8"), 1 << 16);
            String line;
            while ((line = r.readLine()) != null) {
                if (line.isEmpty() || line.charAt(0) == '!') continue;
                hosts.add(line.trim().toLowerCase());
            }
        } catch (Exception ex) { CrashGuard.note("BlockerEasyList", ex); }
        finally { try { if (r != null) r.close(); } catch (Exception ex) { CrashGuard.note("Blocker", ex); } }
    }

    public int size() { return hosts.size(); }
    public int blocked() { return blockedCount; }
    public void setEnabled(boolean on) { enabled = on; }
    public boolean isEnabled() { return enabled; }

    public void allow(String host, boolean on) {
        if (host == null || host.isEmpty()) return;
        if (on) allowed.add(host); else allowed.remove(host);
    }
    public boolean isAllowed(String host) { return host != null && allowed.contains(host); }
    public Set<String> allowedHosts() { return allowed; }

    public boolean shouldBlock(String url) {
        if (!enabled || url == null) return false;
        String host = hostOf(url);
        if (host.isEmpty()) return false;
        String probe = host;
        while (true) {
            if (allowed.contains(probe)) return false;
            int dot = probe.indexOf('.');
            if (dot < 0) break;
            probe = probe.substring(dot + 1);
        }
        if (hosts.contains(host)) { blockedCount++; return true; }
        int dot = host.indexOf('.');
        while (dot > 0) {
            host = host.substring(dot + 1);
            if (hosts.contains(host)) { blockedCount++; return true; }
            dot = host.indexOf('.');
        }
        return false;
    }

    /** true when this exact host is on the list — used to explain a block to the user */
    public boolean isKnownTracker(String url) {
        String host = hostOf(url);
        return hosts.contains(host);
    }

    private static String hostOf(String url) {
        try {
            String h = url;
            int i = h.indexOf("://"); if (i > 0) h = h.substring(i + 3);
            int slash = h.indexOf('/'); if (slash > 0) h = h.substring(0, slash);
            int at = h.indexOf('@'); if (at >= 0) h = h.substring(at + 1);
            int colon = h.indexOf(':'); if (colon > 0) h = h.substring(0, colon);
            return h.toLowerCase();
        } catch (Exception e) { return ""; }
    }
}
