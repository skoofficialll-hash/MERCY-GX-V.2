package com.skinventor.mercypro;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

/**
 * The budget ring. One value, drawn as an arc: today's data against the user's pack.
 * Colour is the meaning — purple under 60%, amber from 60, red when the pack is spent.
 */
public class BudgetRing extends View {

    private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint arc = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF box = new RectF();
    private int percent = 0;
    private boolean over = false;

    public BudgetRing(Context c) { super(c); init(); }
    public BudgetRing(Context c, AttributeSet a) { super(c, a); init(); }
    public BudgetRing(Context c, AttributeSet a, int s) { super(c, a, s); init(); }

    private void init() {
        track.setStyle(Paint.Style.STROKE);
        track.setStrokeWidth(dp(3));
        track.setColor(0xFF26262C);
        arc.setStyle(Paint.Style.STROKE);
        arc.setStrokeWidth(dp(3));
        arc.setStrokeCap(Paint.Cap.ROUND);
        arc.setColor(0xFFA06BFF);
    }

    private float dp(float v) { return v * getResources().getDisplayMetrics().density; }

    /** 0..100 plus whether the pack is already spent. */
    public void setValue(int pct, boolean overBudget) {
        this.percent = Math.max(0, Math.min(100, pct));
        this.over = overBudget;
        arc.setColor(overBudget ? 0xFFFF5C5C : (percent >= 60 ? 0xFFFFB020 : 0xFFA06BFF));
        invalidate();
    }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        float inset = arc.getStrokeWidth() / 2f;
        box.set(inset, inset, getWidth() - inset, getHeight() - inset);
        c.drawArc(box, 0, 360, false, track);
        if (percent > 0) c.drawArc(box, -90, 360f * percent / 100f, false, arc);
        else if (over) c.drawArc(box, 0, 360, false, arc);
    }
}
