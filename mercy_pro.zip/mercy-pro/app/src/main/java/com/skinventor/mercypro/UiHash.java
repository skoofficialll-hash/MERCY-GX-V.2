package com.skinventor.mercypro;

/** sha256 of assets/ui.html, written at build time */
public final class UiHash {
    public static final String SHA256 = "d34541af2d93bec8317484e7eebe93f6af929fb1f4cebff91b243e248148430e";
}
