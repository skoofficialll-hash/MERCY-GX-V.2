package com.skinventor.mercypro;

/** sha256 of assets/ui.html, written at build time */
public final class UiHash {
    public static final String SHA256 = "744d82da14527450f88312700917a04e7f38587d4b74ec11225b67f04caab29e";
}
