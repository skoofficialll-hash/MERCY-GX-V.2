package com.skinventor.mercypro;

import android.app.Activity;
import android.app.AlertDialog;
import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.TrafficStats;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Process;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;
import org.mozilla.geckoview.GeckoResult;
import org.mozilla.geckoview.GeckoRuntime;
import org.mozilla.geckoview.GeckoRuntimeSettings;
import org.mozilla.geckoview.GeckoSession;
import org.mozilla.geckoview.GeckoSessionSettings;
import org.mozilla.geckoview.GeckoView;

import java.util.ArrayList;
import java.util.List;

/**
 * Mercy Pro — GeckoView (Firefox engine) browser shell.
 *
 * Tabs = one GeckoSession each; a single GeckoView swaps between them.
 * Content blocking (ads, analytics, social, trackers) is done by the engine itself.
 */
public class MainActivity extends Activity {

    private static final String HOME = "file:///android_asset/newtab.html";
    private static final String PREFS = "mercy_pro";

    private GeckoRuntime runtime;
    private GeckoView geckoView;
    private final List<Tab> tabs = new ArrayList<>();
    private Tab active;
    private int tabSeq = 1;

    private EditText urlBar;
    private ProgressBar progress;
    private LinearLayout strip;
    private HorizontalScrollView stripScroll;
    private TextView tabCount;
    private TextView btnBack, btnMic, btnScan, btnClear, engineBtn;

    private SharedPreferences prefs;
    private boolean nextDesktop = false;
    private OfflineVoice offlineVoice;
    private boolean pendingVoice = false;
    private static final int REQ_MIC = 103;
    private long rxAtPageStart = -1;
    private long pageStartMs = 0;

    private static class Tab {
        String id;
        GeckoSession session;
        String url = HOME;
        String title = "New tab";
        // our own back/forward bookkeeping — GeckoView's canGoBack() is not stable
        // across engine versions, so the shell tracks it instead
        boolean incognito = false;
        boolean desktop = false;
        final List<String> hist = new ArrayList<>();
        int idx = -1;
        boolean canBack() { return idx > 0; }
        boolean canForward() { return idx >= 0 && idx < hist.size() - 1; }
    }

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        CrashGuard.install(this);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        geckoView = findViewById(R.id.gecko);
        urlBar = findViewById(R.id.url);
        progress = findViewById(R.id.progress);
        strip = findViewById(R.id.tabstrip);
        stripScroll = findViewById(R.id.tabscroll);
        tabCount = findViewById(R.id.tabCount);
        engineBtn = findViewById(R.id.engineBtn);
        btnBack = findViewById(R.id.btnBack);
        btnMic = findViewById(R.id.btnMic);
        btnScan = findViewById(R.id.btnScan);
        btnClear = findViewById(R.id.btnClear);
        engineBtn = findViewById(R.id.engineBtn);
        tabCount.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showSiteInfo(); }
        });

        // engine settings: private by default, ad + tracker blocking on
        // Keep this minimal: GeckoView's defaults already enable standard tracking
        // protection, and this API surface is stable across engine versions.
        GeckoRuntimeSettings settings = new GeckoRuntimeSettings.Builder()
                .javaScriptEnabled(true)
                .remoteDebuggingEnabled(false)
                .build();

        runtime = GeckoRuntime.create(this, settings);

        offlineVoice = new OfflineVoice(this);
        reportLastCrash();
        wireToolbar();
        paintEngine();
        paintEngine();

        String start = HOME;
        Uri incoming = getIntent() == null ? null : getIntent().getData();
        if (incoming != null && incoming.getScheme() != null
                && (incoming.getScheme().equals("http") || incoming.getScheme().equals("https"))) {
            start = incoming.toString();
        }
        newTab(start);
    }

    /* ---------------- toolbar ---------------- */
    private void wireToolbar() {
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { goBack(); }
        });
        btnBack.setOnLongClickListener(new View.OnLongClickListener() {
            @Override public boolean onLongClick(View v) { goForward(); return true; }
        });
        findViewById(R.id.btnHome).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { newTab(HOME); }
        });
        findViewById(R.id.btnNewTab).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { newTab(HOME); }
        });
        findViewById(R.id.btnMenu).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showMenu(); }
        });
        engineBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showEnginePicker(); }
        });
        btnMic.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { startVoiceSearch(); }
        });
        btnScan.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { scanQrCode(); }
        });
        btnClear.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                urlBar.setText("");
                urlBar.requestFocus();
            }
        });

        urlBar.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_DONE
                        || (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                    go(urlBar.getText().toString());
                    return true;
                }
                return false;
            }
        });
        urlBar.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(android.text.Editable s) {
                btnClear.setVisibility(s.length() > 0 ? View.VISIBLE : View.GONE);
            }
        });
    }

    /* ---------------- voice ---------------- */
    private void startVoiceSearch() {
        if (offlineVoice != null && offlineVoice.isReady()) { startOfflineVoice(); return; }
        try {
            Intent i = new Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            // keep the audio on the device whenever an offline model exists
            i.putExtra(android.speech.RecognizerIntent.EXTRA_PREFER_OFFLINE, true);
            i.putExtra(android.speech.RecognizerIntent.EXTRA_PROMPT, "Speak your search");
            startActivityForResult(i, 101);
        } catch (Exception e) {
            toast("No voice input app found");
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == 101 && res == RESULT_OK && data != null) {
            java.util.ArrayList<String> r = data.getStringArrayListExtra(
                    android.speech.RecognizerIntent.EXTRA_RESULTS);
            if (r != null && !r.isEmpty()) {
                urlBar.setText(r.get(0));
                go(r.get(0));
            }
        }
    }

    /* ---------------- QR ---------------- */
    private static final int REQ_CAMERA = 102;
    private boolean pendingScan = false;

    private void scanQrCode() {
        boolean granted = Build.VERSION.SDK_INT < 23
                || checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
        if (!granted) {
            pendingScan = true;
            requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA);
            return;
        }
        new QrScanner(this, new QrScanner.Listener() {
            @Override public void onScanned(String text) {
                String target = looksLikeUrl(text)
                        ? text
                        : "https://duckduckgo.com/?q=" + Uri.encode(text);
                urlBar.setText(target);
                go(target);
            }
        }).show();
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] res) {
        super.onRequestPermissionsResult(req, perms, res);
        if (req == REQ_MIC) {
            if (res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED) {
                if (pendingVoice) { pendingVoice = false; startOfflineVoice(); }
            } else {
                toast("Microphone permission denied");
            }
            return;
        }
        if (req == REQ_CAMERA) {
            if (res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED) {
                if (pendingScan) { pendingScan = false; scanQrCode(); }
            } else {
                toast("Camera permission denied — cannot scan");
            }
        }
    }

    /* ---------------- engine picker ---------------- */
    private static final String[] ENGINE_IDS =
            {"mercy", "google", "ddg", "brave", "ecosia", "startpage", "bing", "yahoo"};

    private String engineLabel(String id) {
        switch (id) {
            case "mercy": return "Mercy (own index)";
            case "google": return "Google";
            case "brave": return "Brave Search";
            case "ecosia": return "Ecosia";
            case "startpage": return "Startpage";
            case "bing": return "Bing";
            case "yahoo": return "Yahoo";
            default: return "DuckDuckGo";
        }
    }

    private String engineColor(String id) {
        switch (id) {
            case "mercy": return "#4f8cff";
            case "google": return "#4285f4";
            case "brave": return "#fb542b";
            case "ecosia": return "#2f9e5f";
            case "startpage": return "#6b7f8f";
            case "bing": return "#00a4ef";
            case "yahoo": return "#a05cff";
            default: return "#de5833";
        }
    }

    private String currentEngine() {
        String id = prefs.getString("engine", "mercy");
        for (String e : ENGINE_IDS) if (e.equals(id)) return id;
        return "mercy";
    }

    private void paintEngine() {
        String id = currentEngine();
        engineBtn.setText(engineLabel(id) + " \u25BE");
        try { engineBtn.setTextColor(android.graphics.Color.parseColor(engineColor(id))); }
        catch (Exception ignored) { }
    }

    private void showEnginePicker() {
        final String[] labels = new String[ENGINE_IDS.length];
        String cur = currentEngine();
        int checked = 0;
        for (int i = 0; i < ENGINE_IDS.length; i++) {
            labels[i] = engineLabel(ENGINE_IDS[i]);
            if (ENGINE_IDS[i].equals(cur)) checked = i;
        }
        new AlertDialog.Builder(this)
                .setTitle("Search engine")
                .setSingleChoiceItems(labels, checked, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        prefs.edit().putString("engine", ENGINE_IDS[which]).apply();
                        paintEngine();
                        d.dismiss();
                        if (ENGINE_IDS[which].equals("mercy")
                                && prefs.getString("mercyUrl", "").isEmpty()) {
                            askMercyUrl();
                        }
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void askMercyUrl() {
        final EditText input = new EditText(this);
        input.setHint("https://your-search.onrender.com/search");
        input.setText(prefs.getString("mercyUrl", ""));
        input.setTextSize(13);
        new AlertDialog.Builder(this)
                .setTitle("Mercy engine URL")
                .setMessage("Your own search server. Leave empty to fall back to DuckDuckGo.")
                .setView(input)
                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        prefs.edit().putString("mercyUrl", input.getText().toString().trim()).apply();
                        toast("Saved");
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private String searchUrl(String q) {
        String enc = Uri.encode(q);
        String id = currentEngine();
        switch (id) {
            case "mercy": {
                String base = prefs.getString("mercyUrl", "").trim();
                if (base.isEmpty()) return "https://duckduckgo.com/?q=" + enc;
                return base + (base.contains("?") ? "&q=" : "?q=") + enc;
            }
            case "google": return "https://www.google.com/search?q=" + enc;
            case "brave": return "https://search.brave.com/search?q=" + enc;
            case "ecosia": return "https://www.ecosia.org/search?q=" + enc;
            case "startpage": return "https://www.startpage.com/sp/search?query=" + enc;
            case "bing": return "https://www.bing.com/search?q=" + enc;
            case "yahoo": return "https://search.yahoo.com/search?p=" + enc;
            default: return "https://duckduckgo.com/?q=" + enc;
        }
    }


    /* ---------------- image search ---------------- */
    /** Images tab of whichever engine is selected. */
    private String imageSearchUrl(String q) {
        String enc = Uri.encode(q == null ? "" : q);
        switch (currentEngine()) {
            case "google": return "https://www.google.com/search?tbm=isch&q=" + enc;
            case "brave":  return "https://search.brave.com/images?q=" + enc;
            case "bing":   return "https://www.bing.com/images/search?q=" + enc;
            case "yahoo":  return "https://images.search.yahoo.com/search/images?p=" + enc;
            case "ecosia": return "https://www.ecosia.org/images?q=" + enc;
            case "startpage": return "https://www.startpage.com/sp/search?query=" + enc + "&cat=images";
            case "mercy": {
                String base = prefs.getString("mercyUrl", "").trim();
                if (!base.isEmpty()) return base + (base.contains("?") ? "&q=" : "?q=") + enc;
                return "https://duckduckgo.com/?q=" + enc + "&iax=images&ia=images";
            }
            default: return "https://duckduckgo.com/?q=" + enc + "&iax=images&ia=images";
        }
    }

    /** Reverse image search: opens the engine's visual-search page, where the
     *  user can upload a photo or point the camera. No API key needed. */
    private String visualSearchUrl() {
        switch (currentEngine()) {
            case "google": return "https://lens.google.com/";
            case "bing":   return "https://www.bing.com/visualsearch";
            case "yahoo":  return "https://images.search.yahoo.com/";
            default:       return "https://lens.google.com/";
        }
    }

    private void openImageSearch() {
        if (active == null) return;
        String q = urlBar.getText().toString().trim();
        String url = imageSearchUrl(q);
        urlBar.setText(url);
        active.session.loadUri(url);
    }

    private void openVisualSearch() {
        if (active == null) return;
        String url = visualSearchUrl();
        urlBar.setText(url);
        active.session.loadUri(url);
    }


    /* ---------------- data ledger ---------------- */
    private long rxBytes() {
        long v = TrafficStats.getUidRxBytes(Process.myUid());
        return v == TrafficStats.UNSUPPORTED ? -1 : v;
    }

    private double tariffPerMb() {
        try { return Double.parseDouble(prefs.getString("tariff", "0.01")); }
        catch (Exception e) { return 0.01; }
    }

    private String hostOf(String url) {
        try {
            String h = Uri.parse(url).getHost();
            if (h == null) return null;
            return h.startsWith("www.") ? h.substring(4) : h;
        } catch (Exception e) { return null; }
    }

    private void recordLedger(String url, long ms) {
        String host = hostOf(url);
        if (host == null) return;
        long bytes = 0;
        if (rxAtPageStart > 0) {
            long now = rxBytes();
            if (now > rxAtPageStart) bytes = now - rxAtPageStart;
        }
        try {
            org.json.JSONObject all = new org.json.JSONObject(prefs.getString("ledger", "{}"));
            org.json.JSONObject row = all.optJSONObject(host);
            if (row == null) row = new org.json.JSONObject();
            row.put("bytes", row.optLong("bytes") + Math.max(0, bytes));
            row.put("ms", row.optLong("ms") + Math.max(0, ms));
            row.put("visits", row.optLong("visits") + 1);
            all.put(host, row);
            prefs.edit().putString("ledger", all.toString()).apply();
        } catch (Exception ignored) { }
    }

    private org.json.JSONObject ledgerRow(String host) {
        try {
            org.json.JSONObject all = new org.json.JSONObject(prefs.getString("ledger", "{}"));
            return all.optJSONObject(host);
        } catch (Exception e) { return null; }
    }

    private String human(long b) {
        if (b < 1024) return b + " B";
        if (b < 1048576) return String.format("%.0f KB", b / 1024.0);
        if (b < 1073741824L) return String.format("%.1f MB", b / 1048576.0);
        return String.format("%.2f GB", b / 1073741824.0);
    }

    private String money(long bytes) {
        double rupees = (bytes / 1048576.0) * tariffPerMb();
        if (rupees < 1) return String.format("%.0f paise", rupees * 100);
        return String.format("\u20B9%.2f", rupees);
    }

    private String humanTime(long ms) {
        long s = ms / 1000;
        if (s < 60) return s + "s";
        if (s < 3600) return (s / 60) + "m";
        return (s / 3600) + "h " + ((s % 3600) / 60) + "m";
    }


    private void showReportCard() {
        try {
            org.json.JSONObject all = new org.json.JSONObject(prefs.getString("ledger", "{}"));
            if (all.length() == 0) { toast("Nothing recorded yet"); return; }
            long total = 0, totalMs = 0, totalVisits = 0;
            java.util.List<String> hosts = new java.util.ArrayList<>();
            for (java.util.Iterator<String> it = all.keys(); it.hasNext(); ) hosts.add(it.next());
            final java.util.Map<String, Long> bytes = new java.util.HashMap<>();
            for (String h : hosts) {
                org.json.JSONObject r = all.optJSONObject(h);
                long b = r.optLong("bytes");
                bytes.put(h, b);
                total += b;
                totalMs += r.optLong("ms");
                totalVisits += r.optLong("visits");
            }
            java.util.Collections.sort(hosts, new java.util.Comparator<String>() {
                @Override public int compare(String a, String b) {
                    return Long.compare(bytes.get(b), bytes.get(a));
                }
            });
            StringBuilder sb = new StringBuilder();
            sb.append("You spent ").append(human(total)).append(" and ").append(money(total))
              .append(" on ").append(totalVisits).append(" page loads.\n")
              .append(humanTime(totalMs)).append(" of browsing.\n\n");
            int top = 0;
            for (String h : hosts) {
                if (top++ >= 5) break;
                long b = bytes.get(h);
                int pct = total > 0 ? (int) Math.round(b * 100.0 / total) : 0;
                sb.append(h).append("  ").append(pct).append("%  \u00B7  ").append(human(b)).append("\n");
            }
            new AlertDialog.Builder(this)
                    .setTitle("Report card")
                    .setMessage(sb.toString())
                    .setPositiveButton("Close", null)
                    .setNeutralButton("Save data mode", new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface d, int w) { toggleNoImages(); }
                    })
                    .show();
        } catch (Exception e) { toast("Report unavailable"); }
    }

    private void toggleNoImages() {
        boolean now = !prefs.getBoolean("noImages", false);
        prefs.edit().putBoolean("noImages", now).apply();
        toast("Save data mode " + (now ? "ON — images blocked" : "OFF"));
        if (active != null) active.session.reload();
    }


    /* ---------------- crash safety ---------------- */
    private void reportLastCrash() {
        if (!CrashGuard.hasCrash(this)) return;
        new AlertDialog.Builder(this)
                .setTitle("Mercy closed unexpectedly")
                .setMessage("The last session ended with an error. You can read the log, "
                        + "or start with safe defaults.")
                .setPositiveButton("View log", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { showDiagnostics(); }
                })
                .setNeutralButton("Safe mode", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        prefs.edit().putString("secLevel", "on").putBoolean("noImages", false).apply();
                        CrashGuard.clear(MercyProActivity());
                        newTab(HOME);
                        toast("Safe mode: defaults restored");
                    }
                })
                .setNegativeButton("Dismiss", null)
                .show();
    }

    private MainActivity MercyProActivity() { return this; }

    private void showDiagnostics() {
        String log = CrashGuard.read(this);
        new AlertDialog.Builder(this)
                .setTitle("Diagnostics")
                .setMessage("Crashes recorded: " + CrashGuard.count(this) + "\n\n" + log)
                .setPositiveButton("Close", null)
                .setNeutralButton("Clear log", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        CrashGuard.clear(MainActivity.this);
                        toast("Log cleared");
                    }
                })
                .show();
    }

    private void showLedger() {
        try {
            org.json.JSONObject all = new org.json.JSONObject(prefs.getString("ledger", "{}"));
            if (all.length() == 0) { toast("No pages recorded yet"); return; }
            java.util.List<String> hosts = new java.util.ArrayList<>();
            for (java.util.Iterator<String> it = all.keys(); it.hasNext(); ) hosts.add(it.next());
            final long[] bytes = new long[hosts.size()];
            java.util.List<Integer> order = new java.util.ArrayList<>();
            for (int i = 0; i < hosts.size(); i++) {
                bytes[i] = all.optJSONObject(hosts.get(i)).optLong("bytes");
                order.add(i);
            }
            java.util.Collections.sort(order, new java.util.Comparator<Integer>() {
                @Override public int compare(Integer a, Integer b) { return Long.compare(bytes[b], bytes[a]); }
            });
            long tb = 0, tm = 0;
            StringBuilder sb = new StringBuilder();
            int shown = 0;
            for (int k = 0; k < order.size(); k++) {
                int i = order.get(k);
                org.json.JSONObject row = all.optJSONObject(hosts.get(i));
                long b = row.optLong("bytes"), m = row.optLong("ms"), v = row.optLong("visits");
                tb += b; tm += m;
                if (shown++ < 12) {
                    sb.append(hosts.get(i)).append("\n   ").append(human(b)).append(" · ")
                      .append(money(b)).append(" · ").append(humanTime(m))
                      .append(" · ").append(v).append(" visits\n\n");
                }
            }
            String header = "Total " + human(tb) + "  ·  " + money(tb) + "\n" + humanTime(tm)
                    + " browsing\n\nTariff: \u20B9" + tariffPerMb() + " per MB\n"
                    + "————————————————\n\n";
            new AlertDialog.Builder(this)
                    .setTitle("Data ledger")
                    .setMessage(header + sb.toString().trim())
                    .setPositiveButton("Close", null)
                    .setNeutralButton("Set tariff", new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface d, int w) { askTariff(); }
                    })
                    .show();
        } catch (Exception e) { toast("Ledger unavailable"); }
    }


    /* =========================================================
       offline voice — Vosk, on the phone, no Google involved
    ========================================================= */
    private void startOfflineVoice() {
        boolean granted = Build.VERSION.SDK_INT < 23
                || checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
        if (!granted) {
            pendingVoice = true;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
            return;
        }
        if (!offlineVoice.isReady()) { askVoiceModel(); return; }

        final AlertDialog[] box = new AlertDialog[1];
        box[0] = new AlertDialog.Builder(this)
                .setTitle("Offline voice")
                .setMessage("Listening…")
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { offlineVoice.stop(); }
                })
                .show();

        offlineVoice.start(new OfflineVoice.Callback() {
            @Override public void onStatus(String text) { if (box[0].isShowing()) box[0].setMessage(text); }
            @Override public void onPartial(String text) { if (box[0].isShowing()) box[0].setMessage(text); }
            @Override public void onFinal(String text) {
                if (box[0].isShowing()) box[0].dismiss();
                urlBar.setText(text);
                go(text);
            }
            @Override public void onError(String message) {
                if (box[0].isShowing()) box[0].dismiss();
                toast(message);
            }
        });
    }

    private void askVoiceModel() {
        new AlertDialog.Builder(this)
                .setTitle("Hindi voice model")
                .setMessage("Offline voice needs a one-time 42 MB download.\n\n"
                        + "After that the recognition runs on this phone: no Google, "
                        + "no server, no audio leaving the device.")
                .setPositiveButton("Download", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { downloadVoiceModel(); }
                })
                .setNegativeButton("Later", null)
                .show();
    }

    private void downloadVoiceModel() {
        final AlertDialog[] prog = new AlertDialog[1];
        prog[0] = new AlertDialog.Builder(this)
                .setTitle("Hindi voice model")
                .setMessage("Starting…")
                .setCancelable(false)
                .setNegativeButton("Hide", null)
                .show();
        offlineVoice.download(new OfflineVoice.Callback() {
            @Override public void onStatus(String text) { if (prog[0].isShowing()) prog[0].setMessage(text); }
            @Override public void onPartial(String text) { }
            @Override public void onFinal(String text) { }
            @Override public void onError(String message) {
                if (prog[0].isShowing()) prog[0].dismiss();
                toast(message);
            }
        });
    }

    private void askTariff() {
        final EditText input = new EditText(this);
        input.setText(String.valueOf(tariffPerMb()));
        input.setHint("rupees per MB, e.g. 0.01");
        input.setTextSize(14);
        new AlertDialog.Builder(this)
                .setTitle("Data tariff")
                .setMessage("Your plan's price per MB. \u20B910/GB = 0.01")
                .setView(input)
                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        prefs.edit().putString("tariff", input.getText().toString().trim()).apply();
                        toast("Tariff saved");
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showSiteInfo() {
        String url = active == null ? "" : active.url;
        boolean https = url.startsWith("https://");
        String msg = (https ? "\uD83D\uDD12 HTTPS — encrypted" : "\u26A0 Not encrypted")
                + "\n\nAddress\n" + url
                + "\n\nSecurity level: " + secLevel().toUpperCase()
                + (active != null && active.incognito ? "\nThis tab: INCOGNITO" : "")
                + (active != null && active.desktop ? "\nMode: desktop site" : "")
                + "\n\nEngine: " + engineLabel(currentEngine())
                + "\nJavaScript: " + (jsOn() ? "ON" : "OFF")
                + "\n\nThis page\n"
                + (rxAtPageStart > 0 && rxBytes() > rxAtPageStart
                        ? human(rxBytes() - rxAtPageStart) + " · " + money(rxBytes() - rxAtPageStart)
                        : "measuring…");
        new AlertDialog.Builder(this)
                .setTitle("Site information")
                .setMessage(msg)
                .setPositiveButton("Close", null)
                .show();
    }

    /* ---------------- tabs ---------------- */
    private void newTab(String url) { newTab(url, false); }

    private void newTab(String url, boolean incognito) {
        final Tab tab = new Tab();
        tab.id = "t" + (tabSeq++);
        tab.url = url;
        tab.incognito = incognito;
        tab.desktop = nextDesktop;
        nextDesktop = false;
        tab.title = incognito ? "Incognito" : "New tab";

        GeckoSessionSettings sessionSettings = new GeckoSessionSettings.Builder()
                .userAgentOverride(uaFor(nextDesktop))
                .usePrivateMode(incognito)          // real private browsing in GeckoView
                .allowJavascript(jsOn())
                .build();
        GeckoSession session = new GeckoSession(sessionSettings);
        session.setProgressDelegate(new GeckoSession.ProgressDelegate() {
            @Override public void onPageStart(GeckoSession s, String uri) {
                pageStartMs = System.currentTimeMillis();
                rxAtPageStart = rxBytes();
                if (uri != null) {
                    tab.url = uri;
                    boolean isCurrent = tab.idx >= 0 && tab.idx < tab.hist.size()
                            && tab.hist.get(tab.idx).equals(uri);
                    if (!isCurrent) {
                        while (tab.hist.size() > tab.idx + 1) {
                            tab.hist.remove(tab.hist.size() - 1);
                        }
                        tab.hist.add(uri);
                        tab.idx = tab.hist.size() - 1;
                    }
                    if (tab == active) updateNav();
                }
                progress.setVisibility(View.VISIBLE);
            }
            @Override public void onPageStop(GeckoSession s, boolean success) {
                progress.setVisibility(View.GONE);
                if (tab == active) { urlBar.setText(tab.url); updateNav(); }
                addHistory(tab.url, tab.title);
                recordLedger(tab.url, System.currentTimeMillis() - pageStartMs);
            }
            @Override public void onProgressChange(GeckoSession s, int p) {
                progress.setProgress(p);
                progress.setVisibility(p >= 100 ? View.GONE : View.VISIBLE);
            }
        });
        session.setContentDelegate(new GeckoSession.ContentDelegate() {
            @Override public void onTitleChange(GeckoSession s, String title) {
                if (title != null && title.length() > 0) { tab.title = title; renderStrip(); }
            }
        });

        session.open(runtime);
        tab.session = session;
        tabs.add(tab);
        select(tab);
        session.loadUri(url);
    }

    private void select(Tab tab) {
        active = tab;
        geckoView.setSession(tab.session);
        urlBar.setText(tab.url);
        updateNav();
        renderStrip();
    }

    private void closeTab(Tab tab) {
        tab.session.close();
        tabs.remove(tab);
        if (tabs.isEmpty()) { newTab(HOME); return; }
        if (tab == active) select(tabs.get(tabs.size() - 1));
        else renderStrip();
    }

    private void renderStrip() {
        strip.removeAllViews();
        for (final Tab t : tabs) {
            LinearLayout chip = new LinearLayout(this);
            chip.setOrientation(LinearLayout.HORIZONTAL);
            chip.setGravity(Gravity.CENTER_VERTICAL);
            chip.setPadding(dp(10), dp(6), dp(6), dp(6));
            chip.setBackgroundColor(t == active ? Color.parseColor("#232830") : Color.parseColor("#15181e"));

            TextView label = new TextView(this);
            String title = t.title == null ? "New tab" : t.title;
            if (title.length() > 16) title = title.substring(0, 16) + "…";
            label.setText(title);
            label.setTextSize(11);
            label.setTextColor(t == active ? Color.parseColor("#eceef1") : Color.parseColor("#98a1ac"));
            label.setSingleLine(true);
            chip.addView(label);

            TextView x = new TextView(this);
            x.setText("  ✕");
            x.setTextSize(11);
            x.setTextColor(Color.parseColor("#68717c"));
            x.setPadding(dp(6), 0, dp(2), 0);
            x.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { closeTab(t); }
            });
            chip.addView(x);

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, 0, dp(5), 0);
            chip.setLayoutParams(lp);
            chip.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { select(t); }
            });
            strip.addView(chip);
        }
        tabCount.setText(String.valueOf(tabs.size()));
        stripScroll.post(new Runnable() {
            @Override public void run() { stripScroll.fullScroll(View.FOCUS_RIGHT); }
        });
    }

    /* ---------------- navigation ---------------- */
    private boolean looksLikeUrl(String s) {
        if (s.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*")) return true;
        if (s.matches("^localhost(:\\d+)?(/.*)?$")) return true;
        return s.matches("^[^\\s]+\\.[a-zA-Z]{2,}([/?#].*)?$");
    }

    private void go(String input) {
        String s = input == null ? "" : input.trim();
        if (s.isEmpty() || active == null) return;
        if (looksLikeUrl(s)) {
            String url = s.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*") ? s
                    : (s.startsWith("localhost") ? "http://" + s : "https://" + s);
            active.session.loadUri(url);
        } else {
            active.session.loadUri(searchUrl(s));
        }
        hideKeyboard();
    }


    private void goBack() {
        if (active == null || !active.canBack()) return;
        active.idx--;
        active.session.goBack();
        updateNav();
    }

    private void goForward() {
        if (active == null || !active.canForward()) return;
        active.idx++;
        active.session.goForward();
        updateNav();
    }

    /* ---------------- security level ---------------- */
    private String secLevel() {
        String v = prefs.getString("secLevel", "on");
        return (v.equals("off") || v.equals("on") || v.equals("pro")) ? v : "on";
    }
    private boolean jsOn() { return !secLevel().equals("pro"); }

    private String uaFor(boolean desktop) {
        return desktop
                ? "Mozilla/5.0 (X11; Linux x86_64; rv:128.0) Gecko/20100101 Firefox/128.0"
                : "Mozilla/5.0 (Android 13; Mobile; rv:128.0) Gecko/128.0 Firefox/128.0";
    }

    private void pickSecurityLevel() {
        final String[] levels = {"off", "on", "pro"};
        String[] labels = {
                "Off — JavaScript allowed, no strict blocking",
                "On — standard tracking protection (recommended)",
                "Pro — everything in On, plus JavaScript off"};
        int checked = secLevel().equals("off") ? 0 : secLevel().equals("pro") ? 2 : 1;
        new AlertDialog.Builder(this)
                .setTitle("Security level")
                .setSingleChoiceItems(labels, checked, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        prefs.edit().putString("secLevel", levels[which]).apply();
                        d.dismiss();
                        toast("Security level: " + levels[which].toUpperCase());
                        reopenActive();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void toggleDesktop() {
        if (active == null) return;
        active.desktop = !active.desktop;
        toast("Desktop site " + (active.desktop ? "on" : "off"));
        reopenActive();
    }

    /** Engine settings can only be set when a session is created, so changing
     *  security level or desktop mode reopens the tab with the same URL. */
    private void reopenActive() {
        if (active == null) return;
        String url = active.url;
        boolean incognito = active.incognito;
        nextDesktop = active.desktop;
        Tab old = active;
        newTab(url, incognito);
        closeTab(old);
    }

    private void updateNav() {
        boolean back = active != null && active.canBack();
        btnBack.setAlpha(back ? 1f : 0.35f);
    }

    /* ---------------- history ---------------- */
    private void addHistory(String url, String title) {
        if (active != null && active.incognito) return;   // private tabs leave no trace
        if (url == null || url.startsWith("file://")) return;
        try {
            JSONArray arr = new JSONArray(prefs.getString("history", "[]"));
            JSONArray out = new JSONArray();
            JSONObject o = new JSONObject();
            o.put("url", url);
            o.put("title", title == null ? url : title);
            out.put(o);
            for (int i = 0; i < arr.length() && i < 199; i++) {
                JSONObject old = arr.getJSONObject(i);
                if (!url.equals(old.optString("url"))) out.put(old);
            }
            prefs.edit().putString("history", out.toString()).apply();
        } catch (Exception ignored) { }
    }

    private void showHistory() {
        try {
            JSONArray arr = new JSONArray(prefs.getString("history", "[]"));
            if (arr.length() == 0) { toast("History is empty"); return; }
            final String[] urls = new String[arr.length()];
            final String[] titles = new String[arr.length()];
            long listBytes = 0;
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                urls[i] = o.optString("url");
                titles[i] = o.optString("title");
                String host = hostOf(urls[i]);
                org.json.JSONObject row = host == null ? null : ledgerRow(host);
                if (row != null) {
                    long b = row.optLong("bytes");
                    if (b > 0) {
                        titles[i] = titles[i] + "  \u00B7  " + human(b) + "  \u00B7  " + money(b);
                        listBytes += b;
                    }
                }
            }
            new AlertDialog.Builder(this)
                    .setTitle("History" + (listBytes > 0
                            ? "  \u00B7  " + human(listBytes) + "  \u00B7  " + money(listBytes) : ""))
                    .setItems(titles, new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface d, int which) { go(urls[which]); }
                    })
                    .setNegativeButton("Close", null)
                    .show();
        } catch (Exception e) { toast("History unavailable"); }
    }

    /* ---------------- menu ---------------- */
    private void showMenu() {
        String[] items = {"New tab", "New incognito tab", "History", "Image search", "Search by image",
                "Data ledger", "Report card",
                "Offline voice: " + (offlineVoice != null && offlineVoice.isReady() ? "ready" : "download model"),
                "Save data: " + (prefs.getBoolean("noImages", false) ? "ON" : "OFF"),
                "Security level: " + secLevel().toUpperCase(),
                "Desktop site: " + (active != null && active.desktop ? "ON" : "OFF"),
                "Diagnostics", "Clear browsing data", "About Mercy Pro"};
        new AlertDialog.Builder(this)
                .setTitle("Mercy Pro")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        switch (which) {
                            case 0: newTab(HOME); break;
                            case 1: newTab(HOME, true); break;
                            case 2: showHistory(); break;
                            case 3: openImageSearch(); break;
                            case 4: openVisualSearch(); break;
                            case 5: showLedger(); break;
                            case 6: showReportCard(); break;
                            case 7: startOfflineVoice(); break;
                            case 8: toggleNoImages(); break;
                            case 9: pickSecurityLevel(); break;
                            case 10: toggleDesktop(); break;
                            case 11: showDiagnostics(); break;
                            case 12:
                                prefs.edit().clear().apply();
                                if (active != null) active.session.reload();
                                toast("Cleared");
                                break;
                            case 13: about(); break;
                        }
                    }
                })
                .setNegativeButton("Close", null)
                .show();
    }

    private void about() {
        new AlertDialog.Builder(this)
                .setTitle("Mercy Pro 2.0")
                .setMessage("A full-featured browser for Android, powered by GeckoView — "
                        + "the same engine Firefox for Android uses.\n\n"
                        + "Tabs, content blocking (ads, analytics, social, trackers), "
                        + "history, HTTPS-first loading.\n\n"
                        + "This build is large because the engine ships inside the app.")
                .setPositiveButton("OK", null)
                .show();
    }

    /* ---------------- helpers ---------------- */
    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }
    private void toast(String m) { Toast.makeText(this, m, Toast.LENGTH_SHORT).show(); }
    private void hideKeyboard() {
        InputMethodManager im = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (im != null) im.hideSoftInputFromWindow(urlBar.getWindowToken(), 0);
        urlBar.clearFocus();
    }

    @Override
    public void onBackPressed() {
        if (active != null && active.canBack()) { goBack(); return; }
        if (tabs.size() > 1) { closeTab(active); return; }
        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        for (Tab t : tabs) t.session.close();
        tabs.clear();
        super.onDestroy();
    }
}
