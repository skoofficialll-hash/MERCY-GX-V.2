package com.skinventor.mercypro;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;
import org.mozilla.geckoview.GeckoResult;
import org.mozilla.geckoview.GeckoRuntime;
import org.mozilla.geckoview.GeckoRuntimeSettings;
import org.mozilla.geckoview.GeckoSession;
import org.mozilla.geckoview.GeckoSessionSettings;
import org.mozilla.geckoview.GeckoView;

import java.util.ArrayList;
import java.util.List;

/**
 * Mercy Pro — GeckoView (Firefox engine) browser shell.
 *
 * Tabs = one GeckoSession each; a single GeckoView swaps between them.
 * Content blocking (ads, analytics, social, trackers) is done by the engine itself.
 */
public class MainActivity extends Activity {

    private static final String HOME = "file:///android_asset/newtab.html";
    private static final String PREFS = "mercy_pro";

    private GeckoRuntime runtime;
    private GeckoView geckoView;
    private final List<Tab> tabs = new ArrayList<>();
    private Tab active;
    private int tabSeq = 1;

    private EditText urlBar;
    private ProgressBar progress;
    private LinearLayout strip;
    private HorizontalScrollView stripScroll;
    private TextView tabCount;
    private TextView engineBtn;
    private TextView btnBack, btnMic, btnScan, btnClear, engineBtn;

    private SharedPreferences prefs;

    private static class Tab {
        String id;
        GeckoSession session;
        String url = HOME;
        String title = "New tab";
        // our own back/forward bookkeeping — GeckoView's canGoBack() is not stable
        // across engine versions, so the shell tracks it instead
        boolean incognito = false;
        boolean desktop = false;
        final List<String> hist = new ArrayList<>();
        int idx = -1;
        boolean canBack() { return idx > 0; }
        boolean canForward() { return idx >= 0 && idx < hist.size() - 1; }
    }

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        geckoView = findViewById(R.id.gecko);
        urlBar = findViewById(R.id.url);
        progress = findViewById(R.id.progress);
        strip = findViewById(R.id.tabstrip);
        stripScroll = findViewById(R.id.tabscroll);
        tabCount = findViewById(R.id.tabCount);
        engineBtn = findViewById(R.id.engineBtn);
        btnBack = findViewById(R.id.btnBack);
        btnMic = findViewById(R.id.btnMic);
        btnScan = findViewById(R.id.btnScan);
        btnClear = findViewById(R.id.btnClear);
        engineBtn = findViewById(R.id.engineBtn);
        tabCount.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showSiteInfo(); }
        });

        // engine settings: private by default, ad + tracker blocking on
        // Keep this minimal: GeckoView's defaults already enable standard tracking
        // protection, and this API surface is stable across engine versions.
        GeckoRuntimeSettings settings = new GeckoRuntimeSettings.Builder()
                .javaScriptEnabled(true)
                .remoteDebuggingEnabled(false)
                .build();

        runtime = GeckoRuntime.create(this, settings);

        wireToolbar();
        paintEngine();
        paintEngine();

        String start = HOME;
        Uri incoming = getIntent() == null ? null : getIntent().getData();
        if (incoming != null && incoming.getScheme() != null
                && (incoming.getScheme().equals("http") || incoming.getScheme().equals("https"))) {
            start = incoming.toString();
        }
        newTab(start);
    }

    /* ---------------- toolbar ---------------- */
    private void wireToolbar() {
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { goBack(); }
        });
        btnBack.setOnLongClickListener(new View.OnLongClickListener() {
            @Override public boolean onLongClick(View v) { goForward(); return true; }
        });
        findViewById(R.id.btnHome).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { newTab(HOME); }
        });
        findViewById(R.id.btnNewTab).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { newTab(HOME); }
        });
        findViewById(R.id.btnMenu).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showMenu(); }
        });
        engineBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showEnginePicker(); }
        });
        btnMic.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { startVoiceSearch(); }
        });
        btnScan.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { scanQrCode(); }
        });
        btnClear.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                urlBar.setText("");
                urlBar.requestFocus();
            }
        });

        urlBar.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_DONE
                        || (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                    go(urlBar.getText().toString());
                    return true;
                }
                return false;
            }
        });
        urlBar.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(android.text.Editable s) {
                btnClear.setVisibility(s.length() > 0 ? View.VISIBLE : View.GONE);
            }
        });
    }

    /* ---------------- voice ---------------- */
    private void startVoiceSearch() {
        try {
            Intent i = new Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(android.speech.RecognizerIntent.EXTRA_PROMPT, "Speak your search");
            startActivityForResult(i, 101);
        } catch (Exception e) {
            toast("No voice input app found");
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == 101 && res == RESULT_OK && data != null) {
            java.util.ArrayList<String> r = data.getStringArrayListExtra(
                    android.speech.RecognizerIntent.EXTRA_RESULTS);
            if (r != null && !r.isEmpty()) {
                urlBar.setText(r.get(0));
                go(r.get(0));
            }
        }
    }

    /* ---------------- QR ---------------- */
    private void scanQrCode() {
        try {
            com.google.android.gms.code.GmsBarcodeScannerOptions options =
                    new com.google.android.gms.code.GmsBarcodeScannerOptions.Builder().build();
            com.google.android.gms.code.GmsBarcodeScanner scanner =
                    com.google.android.gms.code.GmsBarcodeScanning.getClient(this, options);
            scanner.startScan()
                    .addOnSuccessListener(new com.google.android.gms.tasks.OnSuccessListener<
                            com.google.android.gms.code.Barcode>() {
                        @Override public void onSuccess(com.google.android.gms.code.Barcode barcode) {
                            String raw = barcode.getRawValue();
                            if (raw == null || raw.isEmpty()) { toast("Nothing in that code"); return; }
                            String target = looksLikeUrl(raw) ? raw
                                    : "https://duckduckgo.com/?q=" + Uri.encode(raw);
                            urlBar.setText(target);
                            go(target);
                        }
                    })
                    .addOnFailureListener(new com.google.android.gms.tasks.OnFailureListener() {
                        @Override public void onFailure(Exception e) { toast("Scan cancelled"); }
                    });
        } catch (Exception e) {
            toast("Scanner needs Google Play services");
        }
    }

    /* ---------------- engine picker ---------------- */
    private static final String[] ENGINE_IDS =
            {"mercy", "google", "ddg", "brave", "ecosia", "startpage", "bing", "yahoo"};

    private String engineLabel(String id) {
        switch (id) {
            case "mercy": return "Mercy (own index)";
            case "google": return "Google";
            case "brave": return "Brave Search";
            case "ecosia": return "Ecosia";
            case "startpage": return "Startpage";
            case "bing": return "Bing";
            case "yahoo": return "Yahoo";
            default: return "DuckDuckGo";
        }
    }

    private String engineColor(String id) {
        switch (id) {
            case "mercy": return "#4f8cff";
            case "google": return "#4285f4";
            case "brave": return "#fb542b";
            case "ecosia": return "#2f9e5f";
            case "startpage": return "#6b7f8f";
            case "bing": return "#00a4ef";
            case "yahoo": return "#a05cff";
            default: return "#de5833";
        }
    }

    private String currentEngine() {
        String id = prefs.getString("engine", "mercy");
        for (String e : ENGINE_IDS) if (e.equals(id)) return id;
        return "mercy";
    }

    private void paintEngine() {
        String id = currentEngine();
        engineBtn.setText(engineLabel(id) + " \u25BE");
        try { engineBtn.setTextColor(android.graphics.Color.parseColor(engineColor(id))); }
        catch (Exception ignored) { }
    }

    private void showEnginePicker() {
        final String[] labels = new String[ENGINE_IDS.length];
        String cur = currentEngine();
        int checked = 0;
        for (int i = 0; i < ENGINE_IDS.length; i++) {
            labels[i] = engineLabel(ENGINE_IDS[i]);
            if (ENGINE_IDS[i].equals(cur)) checked = i;
        }
        new AlertDialog.Builder(this)
                .setTitle("Search engine")
                .setSingleChoiceItems(labels, checked, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        prefs.edit().putString("engine", ENGINE_IDS[which]).apply();
                        paintEngine();
                        d.dismiss();
                        if (ENGINE_IDS[which].equals("mercy")
                                && prefs.getString("mercyUrl", "").isEmpty()) {
                            askMercyUrl();
                        }
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void askMercyUrl() {
        final EditText input = new EditText(this);
        input.setHint("https://your-search.onrender.com/search");
        input.setText(prefs.getString("mercyUrl", ""));
        input.setTextSize(13);
        new AlertDialog.Builder(this)
                .setTitle("Mercy engine URL")
                .setMessage("Your own search server. Leave empty to fall back to DuckDuckGo.")
                .setView(input)
                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        prefs.edit().putString("mercyUrl", input.getText().toString().trim()).apply();
                        toast("Saved");
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private String searchUrl(String q) {
        String enc = Uri.encode(q);
        String id = currentEngine();
        switch (id) {
            case "mercy": {
                String base = prefs.getString("mercyUrl", "").trim();
                if (base.isEmpty()) return "https://duckduckgo.com/?q=" + enc;
                return base + (base.contains("?") ? "&q=" : "?q=") + enc;
            }
            case "google": return "https://www.google.com/search?q=" + enc;
            case "brave": return "https://search.brave.com/search?q=" + enc;
            case "ecosia": return "https://www.ecosia.org/search?q=" + enc;
            case "startpage": return "https://www.startpage.com/sp/search?query=" + enc;
            case "bing": return "https://www.bing.com/search?q=" + enc;
            case "yahoo": return "https://search.yahoo.com/search?p=" + enc;
            default: return "https://duckduckgo.com/?q=" + enc;
        }
    }

    private void showSiteInfo() {
        String url = active == null ? "" : active.url;
        boolean https = url.startsWith("https://");
        String msg = (https ? "\uD83D\uDD12 HTTPS — encrypted" : "\u26A0 Not encrypted")
                + "\n\nAddress\n" + url
                + "\n\nSecurity level: " + secLevel().toUpperCase()
                + (active != null && active.incognito ? "\nThis tab: INCOGNITO" : "")
                + (active != null && active.desktop ? "\nMode: desktop site" : "")
                + "\n\nEngine: " + engineLabel(currentEngine())
                + "\nJavaScript: " + (jsOn() ? "ON" : "OFF");
        new AlertDialog.Builder(this)
                .setTitle("Site information")
                .setMessage(msg)
                .setPositiveButton("Close", null)
                .show();
    }

    /* ---------------- tabs ---------------- */
    private void newTab(String url) { newTab(url, false); }

    private void newTab(String url, boolean incognito) {
        final Tab tab = new Tab();
        tab.id = "t" + (tabSeq++);
        tab.url = url;
        tab.incognito = incognito;
        tab.title = incognito ? "Incognito" : "New tab";

        GeckoSessionSettings sessionSettings = new GeckoSessionSettings.Builder()
                .userAgentOverride(uaFor(false))
                .usePrivateMode(incognito)          // real private browsing in GeckoView
                .allowJavascript(jsOn())
                .build();
        GeckoSession session = new GeckoSession(sessionSettings);
        session.setProgressDelegate(new GeckoSession.ProgressDelegate() {
            @Override public void onPageStart(GeckoSession s, String uri) {
                if (uri != null) {
                    tab.url = uri;
                    boolean isCurrent = tab.idx >= 0 && tab.idx < tab.hist.size()
                            && tab.hist.get(tab.idx).equals(uri);
                    if (!isCurrent) {
                        while (tab.hist.size() > tab.idx + 1) {
                            tab.hist.remove(tab.hist.size() - 1);
                        }
                        tab.hist.add(uri);
                        tab.idx = tab.hist.size() - 1;
                    }
                    if (tab == active) updateNav();
                }
                progress.setVisibility(View.VISIBLE);
            }
            @Override public void onPageStop(GeckoSession s, boolean success) {
                progress.setVisibility(View.GONE);
                if (tab == active) { urlBar.setText(tab.url); updateNav(); }
                addHistory(tab.url, tab.title);
            }
            @Override public void onProgressChange(GeckoSession s, int p) {
                progress.setProgress(p);
                progress.setVisibility(p >= 100 ? View.GONE : View.VISIBLE);
            }
        });
        session.setContentDelegate(new GeckoSession.ContentDelegate() {
            @Override public void onTitleChange(GeckoSession s, String title) {
                if (title != null && title.length() > 0) { tab.title = title; renderStrip(); }
            }
        });

        session.open(runtime);
        tab.session = session;
        tabs.add(tab);
        select(tab);
        session.loadUri(url);
    }

    private void select(Tab tab) {
        active = tab;
        geckoView.setSession(tab.session);
        urlBar.setText(tab.url);
        updateNav();
        renderStrip();
    }

    private void closeTab(Tab tab) {
        tab.session.close();
        tabs.remove(tab);
        if (tabs.isEmpty()) { newTab(HOME); return; }
        if (tab == active) select(tabs.get(tabs.size() - 1));
        else renderStrip();
    }

    private void renderStrip() {
        strip.removeAllViews();
        for (final Tab t : tabs) {
            LinearLayout chip = new LinearLayout(this);
            chip.setOrientation(LinearLayout.HORIZONTAL);
            chip.setGravity(Gravity.CENTER_VERTICAL);
            chip.setPadding(dp(10), dp(6), dp(6), dp(6));
            chip.setBackgroundColor(t == active ? Color.parseColor("#232830") : Color.parseColor("#15181e"));

            TextView label = new TextView(this);
            String title = t.title == null ? "New tab" : t.title;
            if (title.length() > 16) title = title.substring(0, 16) + "…";
            label.setText(title);
            label.setTextSize(11);
            label.setTextColor(t == active ? Color.parseColor("#eceef1") : Color.parseColor("#98a1ac"));
            label.setSingleLine(true);
            chip.addView(label);

            TextView x = new TextView(this);
            x.setText("  ✕");
            x.setTextSize(11);
            x.setTextColor(Color.parseColor("#68717c"));
            x.setPadding(dp(6), 0, dp(2), 0);
            x.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { closeTab(t); }
            });
            chip.addView(x);

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, 0, dp(5), 0);
            chip.setLayoutParams(lp);
            chip.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { select(t); }
            });
            strip.addView(chip);
        }
        tabCount.setText(String.valueOf(tabs.size()));
        stripScroll.post(new Runnable() {
            @Override public void run() { stripScroll.fullScroll(View.FOCUS_RIGHT); }
        });
    }

    /* ---------------- navigation ---------------- */
    private boolean looksLikeUrl(String s) {
        if (s.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*")) return true;
        if (s.matches("^localhost(:\\d+)?(/.*)?$")) return true;
        return s.matches("^[^\\s]+\\.[a-zA-Z]{2,}([/?#].*)?$");
    }

    private void go(String input) {
        String s = input == null ? "" : input.trim();
        if (s.isEmpty() || active == null) return;
        if (looksLikeUrl(s)) {
            String url = s.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*") ? s
                    : (s.startsWith("localhost") ? "http://" + s : "https://" + s);
            active.session.loadUri(url);
        } else {
            active.session.loadUri(searchUrl(s));
        }
        hideKeyboard();
    }


    private void goBack() {
        if (active == null || !active.canBack()) return;
        active.idx--;
        active.session.goBack();
        updateNav();
    }

    private void goForward() {
        if (active == null || !active.canForward()) return;
        active.idx++;
        active.session.goForward();
        updateNav();
    }

    /* ---------------- security level ---------------- */
    private String secLevel() {
        String v = prefs.getString("secLevel", "on");
        return (v.equals("off") || v.equals("on") || v.equals("pro")) ? v : "on";
    }
    private boolean jsOn() { return !secLevel().equals("pro"); }

    private String uaFor(boolean desktop) {
        return desktop
                ? "Mozilla/5.0 (X11; Linux x86_64; rv:128.0) Gecko/20100101 Firefox/128.0"
                : "Mozilla/5.0 (Android 13; Mobile; rv:128.0) Gecko/128.0 Firefox/128.0";
    }

    private void pickSecurityLevel() {
        final String[] levels = {"off", "on", "pro"};
        String[] labels = {
                "Off — JavaScript allowed, no strict blocking",
                "On — standard tracking protection (recommended)",
                "Pro — everything in On, plus JavaScript off"};
        int checked = secLevel().equals("off") ? 0 : secLevel().equals("pro") ? 2 : 1;
        new AlertDialog.Builder(this)
                .setTitle("Security level")
                .setSingleChoiceItems(labels, checked, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        prefs.edit().putString("secLevel", levels[which]).apply();
                        d.dismiss();
                        toast("Security level: " + levels[which].toUpperCase());
                        if (active != null) {
                            active.session.setSettings(new GeckoSessionSettings.Builder()
                                    .userAgentOverride(uaFor(active.desktop))
                                    .usePrivateMode(active.incognito)
                                    .allowJavascript(jsOn())
                                    .build());
                            active.session.reload();
                        }
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void toggleDesktop() {
        if (active == null) return;
        active.desktop = !active.desktop;
        active.session.setSettings(new GeckoSessionSettings.Builder()
                .userAgentOverride(uaFor(active.desktop))
                .usePrivateMode(active.incognito)
                .allowJavascript(jsOn())
                .build());
        active.session.reload();
        toast("Desktop site " + (active.desktop ? "on" : "off"));
    }

    private void updateNav() {
        boolean back = active != null && active.canBack();
        btnBack.setAlpha(back ? 1f : 0.35f);
    }

    /* ---------------- history ---------------- */
    private void addHistory(String url, String title) {
        if (active != null && active.incognito) return;   // private tabs leave no trace
        if (url == null || url.startsWith("file://")) return;
        try {
            JSONArray arr = new JSONArray(prefs.getString("history", "[]"));
            JSONArray out = new JSONArray();
            JSONObject o = new JSONObject();
            o.put("url", url);
            o.put("title", title == null ? url : title);
            out.put(o);
            for (int i = 0; i < arr.length() && i < 199; i++) {
                JSONObject old = arr.getJSONObject(i);
                if (!url.equals(old.optString("url"))) out.put(old);
            }
            prefs.edit().putString("history", out.toString()).apply();
        } catch (Exception ignored) { }
    }

    private void showHistory() {
        try {
            JSONArray arr = new JSONArray(prefs.getString("history", "[]"));
            if (arr.length() == 0) { toast("History is empty"); return; }
            final String[] urls = new String[arr.length()];
            final String[] titles = new String[arr.length()];
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                urls[i] = o.optString("url");
                titles[i] = o.optString("title");
            }
            new AlertDialog.Builder(this)
                    .setTitle("History")
                    .setItems(titles, new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface d, int which) { go(urls[which]); }
                    })
                    .setNegativeButton("Close", null)
                    .show();
        } catch (Exception e) { toast("History unavailable"); }
    }

    /* ---------------- menu ---------------- */
    private void showMenu() {
        String[] items = {"New tab", "New incognito tab", "History",
                "Security level: " + secLevel().toUpperCase(),
                "Desktop site: " + (active != null && active.desktop ? "ON" : "OFF"),
                "Clear browsing data", "About Mercy Pro"};
        new AlertDialog.Builder(this)
                .setTitle("Mercy Pro")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        switch (which) {
                            case 0: newTab(HOME); break;
                            case 1: newTab(HOME, true); break;
                            case 2: showHistory(); break;
                            case 3: pickSecurityLevel(); break;
                            case 4: toggleDesktop(); break;
                            case 5:
                                prefs.edit().clear().apply();
                                if (active != null) active.session.reload();
                                toast("Cleared");
                                break;
                            case 6: about(); break;
                        }
                    }
                })
                .setNegativeButton("Close", null)
                .show();
    }

    private void about() {
        new AlertDialog.Builder(this)
                .setTitle("Mercy Pro 2.0")
                .setMessage("A full-featured browser for Android, powered by GeckoView — "
                        + "the same engine Firefox for Android uses.\n\n"
                        + "Tabs, content blocking (ads, analytics, social, trackers), "
                        + "history, HTTPS-first loading.\n\n"
                        + "This build is large because the engine ships inside the app.")
                .setPositiveButton("OK", null)
                .show();
    }

    /* ---------------- helpers ---------------- */
    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }
    private void toast(String m) { Toast.makeText(this, m, Toast.LENGTH_SHORT).show(); }
    private void hideKeyboard() {
        InputMethodManager im = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (im != null) im.hideSoftInputFromWindow(urlBar.getWindowToken(), 0);
        urlBar.clearFocus();
    }

    @Override
    public void onBackPressed() {
        if (active != null && active.canBack()) { goBack(); return; }
        if (tabs.size() > 1) { closeTab(active); return; }
        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        for (Tab t : tabs) t.session.close();
        tabs.clear();
        super.onDestroy();
    }
}
