package com.skinventor.mercypro;

import android.app.Activity;
import android.app.AlertDialog;
import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.TrafficStats;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Process;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.webkit.WebViewClient;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;
import org.mozilla.geckoview.GeckoResult;
import org.mozilla.geckoview.GeckoRuntime;
import org.mozilla.geckoview.GeckoRuntimeSettings;
import org.mozilla.geckoview.GeckoSession;
import org.mozilla.geckoview.GeckoSessionSettings;
import org.mozilla.geckoview.GeckoView;

import java.util.ArrayList;
import java.util.List;

/**
 * Mercy Pro — GeckoView (Firefox engine) browser shell.
 *
 * Tabs = one GeckoSession each; a single GeckoView swaps between them.
 * Content blocking (ads, analytics, social, trackers) is done by the engine itself.
 */
public class MainActivity extends Activity {

    private static final String HOME_GECKO = "resource://android/assets/newtab.html";
    private static final String HOME_WEB = "file:///android_asset/newtab.html";
    private String HOME = HOME_GECKO;      /* chosen once the engine is known */
    private static final String PREFS = "mercy_pro";

    private GeckoRuntime runtime;
    private android.widget.FrameLayout container;
    private GeckoView geckoView;   // attached to the active tab, not to a layout id
    private final List<Tab> tabs = new ArrayList<>();
    private Tab active;
    private int tabSeq = 1;

    private EditText urlBar;
    private TextView engineChip, pctLabel, btnTabs;
    private BudgetRing ring;
    private ListView suggestList;
    private final java.util.List<String> suggestItems = new java.util.ArrayList<>();
    private android.widget.ArrayAdapter<String> suggestAdapter;
    private android.os.Handler suggestHandler;
    private ProgressBar progress;

    private SharedPreferences prefs;
    private boolean nextDesktop = false;
    private OfflineVoice offlineVoice;
    private boolean pendingVoice = false;
    private static final int REQ_MIC = 103;
    private long rxAtPageStart = -1;
    private long pageStartMs = 0;

    private static class Tab {
        String id;
        GeckoSession session;
        String url = HOME_GECKO;        /* overwritten by newTab() once the engine is known */
        String title = "New tab";
        // our own back/forward bookkeeping — GeckoView's canGoBack() is not stable
        // across engine versions, so the shell tracks it instead
        boolean incognito = false;
        boolean desktop = false;
        final List<String> hist = new ArrayList<>();
        int idx = -1;
        boolean canBack() { return idx > 0; }
        boolean canForward() { return idx >= 0 && idx < hist.size() - 1; }
    }


    /* =========================================================
       Engine switch — GeckoView (ours) or WebView (system).
       The rest of the app only calls these methods.
    ========================================================= */
    private boolean useWebView;
    private boolean userStopped;
    private Blocker blocker;
    private Engines engines;
    private Lang lang;
    private android.webkit.WebView webEngine;
    private final java.util.List<String> webHist = new java.util.ArrayList<>();
    private int webIdx = -1;

    private boolean engineIsWeb() {
        return useWebView;
    }

    private void buildWebEngine() {
        if (webEngine != null) return;
        webEngine = new android.webkit.WebView(this);
        webEngine.getSettings().setJavaScriptEnabled(true);
        webEngine.getSettings().setDomStorageEnabled(true);
        webEngine.setWebViewClient(new android.webkit.WebViewClient() {
            @Override public android.webkit.WebResourceResponse shouldInterceptRequest(
                    android.webkit.WebView v, android.webkit.WebResourceRequest req) {
                if (blocker != null && req != null && !req.isForMainFrame()
                        && blocker.shouldBlock(req.getUrl().toString())) {
                    return new android.webkit.WebResourceResponse("text/plain", "utf-8",
                            new java.io.ByteArrayInputStream(new byte[0]));
                }
                return null;
            }
            @Override public void onReceivedError(android.webkit.WebView v, android.webkit.WebResourceRequest req,
                                                  android.webkit.WebResourceError err) {
                if (req == null || !req.isForMainFrame()) return;
                int code = err == null ? 0 : err.getErrorCode();
                int kind = code == -20 ? 5
                        : (code == -2 || code == -8) ? 1
                        : (code == -6 || code == -16) ? 3
                        : 0;
                reportFailure(req.getUrl() == null ? "" : req.getUrl().toString(), kind);
            }
            @Override public boolean shouldOverrideUrlLoading(android.webkit.WebView v, String u) {
                return false;
            }
            @Override public void onPageStarted(android.webkit.WebView v, String u, android.graphics.Bitmap f) {
                showSkeleton();
                if (u != null) { active.url = u; setChromeUrl(u); }
            }
            @Override public void onPageFinished(android.webkit.WebView v, String u) {
                if (u != null && !u.isEmpty() && (webIdx < 0 || !u.equals(webHist.get(webIdx)))) {
                    while (webHist.size() > webIdx + 1) webHist.remove(webHist.size() - 1);
                    webHist.add(u); webIdx = webHist.size() - 1;
                }
                hideSkeleton();
                progress.setVisibility(View.GONE);
                if (u != null) { active.url = u; setChromeUrl(u); }
            }
        });
        container.addView(webEngine, new android.widget.FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private void engineLoad(String url) {
        if (active == null) return;
        active.url = url;
        if (useWebView) {
            buildWebEngine();
            webEngine.loadUrl(url);
            while (webHist.size() > webIdx + 1) webHist.remove(webHist.size() - 1);
            webHist.add(url); webIdx = webHist.size() - 1;
            while (webHist.size() > 120) { webHist.remove(0); webIdx--; }
        } else if (active.session != null) {
            engineLoad(url);
        }
    }

    private void engineReload() {
        if (useWebView) { if (webEngine != null) webEngine.reload(); }
        else engineReload();
    }

    private boolean engineCanBack() {
        if (useWebView) return webIdx > 0;
        return active != null && active.canBack();
    }

    private void engineBack() {
        if (useWebView) { if (webIdx > 0) { webIdx--; if (webEngine != null) webEngine.loadUrl(webHist.get(webIdx)); } }
        else if (active != null) { engineBack(); }
    }

    private boolean engineCanForward() {
        if (useWebView) return webIdx >= 0 && webIdx < webHist.size() - 1;
        return active != null && active.canForward();
    }

    private void engineForward() {
        if (useWebView) { if (webIdx < webHist.size() - 1) { webIdx++; if (webEngine != null) webEngine.loadUrl(webHist.get(webIdx)); } }
        else if (active != null) { engineForward(); }
    }

    private void engineVisible(boolean visible) {
        if (useWebView) { if (webEngine != null) webEngine.setVisibility(visible ? View.VISIBLE : View.GONE); }
        else if (geckoView != null) engineVisible(visible);
    }

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        CrashGuard.install(this);
        try {
            setContentView(R.layout.activity_main);
        } catch (Throwable t) {
            note("layout", t);
            setContentView(new android.widget.FrameLayout(this));   /* never a black screen */
        }

        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        useWebView = prefs.getBoolean("useWebView", false);
        HOME = useWebView ? HOME_WEB : HOME_GECKO;
        blocker = new Blocker(this, prefs.getBoolean("blockAds", true));
        engines = new Engines(this);
        lang = new Lang(prefs);   // GeckoView is the default
        container = findViewById(R.id.container);
        try {
            androidx.swiperefreshlayout.widget.SwipeRefreshLayout pull =
                    findViewById(R.id.swipe);
            if (pull != null) {
                pull.setEnabled(false);          // GeckoView has its own overscroll
                pull.setRefreshing(false);
                pull.setVisibility(View.VISIBLE);
            }
        } catch (Exception e) { note("onCreate", e); }
        if (useWebView) {
            buildWebEngine();                 // system engine: no GeckoRuntime, no 50 MB
        } else {
            geckoView = new GeckoView(this);
            container.addView(geckoView, new android.widget.FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        }
        homeView = (LinearLayout) buildHomeView();
        paintHome();
        homeView.setVisibility(View.GONE);
        container.addView(homeView, new android.widget.FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        urlBar = findViewById(R.id.url);
        engineChip = findViewById(R.id.engineChip);
        pctLabel = findViewById(R.id.pct);
        btnTabs = findViewById(R.id.btnTabs);
        ring = findViewById(R.id.ring);
        suggestList = findViewById(R.id.suggest);
        suggestHandler = new android.os.Handler(getMainLooper());
        View navHome = findViewById(R.id.navHome);
        if (navHome != null) navHome.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (active != null && !active.url.equals(HOME)) engineLoad(HOME);
            }
        });
        View navLib = findViewById(R.id.navMenu);
        if (navLib != null) navLib.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { openLibrary(); }
        });
        View navSet = findViewById(R.id.navSettings);      /* now the Tabs button */
        if (navSet != null) navSet.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showTabs(); }
        });
        wireHeader();
        progress = findViewById(R.id.progress);

        // engine settings: private by default, ad + tracker blocking on
        // Keep this minimal: GeckoView's defaults already enable standard tracking
        // protection, and this API surface is stable across engine versions.
        GeckoRuntimeSettings.Builder rtBuilder = new GeckoRuntimeSettings.Builder()
                .javaScriptEnabled(true)
                .remoteDebuggingEnabled(false);
        if (prefs.getBoolean("torMode", false)) {
            String cfgPath = writeTorConfig();
            if (cfgPath != null) rtBuilder.configFilePath(cfgPath);
        }
        GeckoRuntimeSettings settings = rtBuilder.build();

        if (!useWebView) {
            runtime = GeckoRuntime.create(this, settings);
            installMercyExtension(runtime);
        }

        offlineVoice = new OfflineVoice(this);
        reportLastCrash();
        wireToolbar();
        paintEngine();

        String start = HOME;
        Uri incoming = getIntent() == null ? null : getIntent().getData();
        if (incoming != null && incoming.getScheme() != null
                && (incoming.getScheme().equals("http") || incoming.getScheme().equals("https"))) {
            start = incoming.toString();
        }
        newTab(start);
        maybeShowIntro();
    }

    /* ---------------- toolbar ---------------- */
    private void wireToolbar() {
    }

    /** the header is html; this is the only door between it and the engine */
    public class Bridge {
        @android.webkit.JavascriptInterface public void search(final String url) {
            runOnUiThread(new Runnable() { @Override public void run() {
                hideKeyboard();
                go(url);
            }});
        }
        @android.webkit.JavascriptInterface public void newTab() {
            runOnUiThread(new Runnable() { @Override public void run() { MainActivity.this.newTab(HOME); } });
        }
        @android.webkit.JavascriptInterface public void tabs() {
            runOnUiThread(new Runnable() { @Override public void run() { showTabs(); } });
        }
        @android.webkit.JavascriptInterface public void menu() {
            runOnUiThread(new Runnable() { @Override public void run() { showMenu(); } });
        }
        @android.webkit.JavascriptInterface public void voice() {
            runOnUiThread(new Runnable() { @Override public void run() { startVoiceSearch(); } });
        }
        @android.webkit.JavascriptInterface public void scan() {
            runOnUiThread(new Runnable() { @Override public void run() { scanQrCode(); } });
        }
        @android.webkit.JavascriptInterface public void setEngine(final String id) {
            prefs.edit().putString("engine", id).apply();
        }
        @android.webkit.JavascriptInterface public void open(final String what) {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    if ("ledger".equals(what)) showLedger();
                    else if ("report".equals(what)) showReportCard();
                    else if ("proof".equals(what)) toast("Privacy proof arrives with the next Pro update");
                }
            });
        }
        @android.webkit.JavascriptInterface public void ready() {
            runOnUiThread(new Runnable() { @Override public void run() { pushChromeConfig(); } });
        }
    }



    /* =========================================================
       the header — native views, so typing costs one TextView
    ========================================================= */
    private void wireHeader() {
        engineChip.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showEnginePicker(); }
        });
        ring.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showLedger(); }
        });
        findViewById(R.id.btnNew).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { newTab(HOME); }
        });
        btnTabs.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showTabs(); }
        });
        findViewById(R.id.btnMenu).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showMenu(); }
        });
        findViewById(R.id.btnMic).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { startOfflineVoice(); }
        });
        /* QR is an input too, so it lives next to the mic, not in a menu */
        findViewById(R.id.btnMic).setOnLongClickListener(new View.OnLongClickListener() {
            @Override public boolean onLongClick(View v) { scanQrCode(); return true; }
        });

        urlBar.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_GO
                        || (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                    String text = urlBar.getText().toString().trim();
                    if (!text.isEmpty()) { hideSuggestions(); go(text); }
                    return true;
                }
                return false;
            }
        });
        urlBar.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    if (!searchOpening && searchOverlay == null) openSearchScreen();
                    else fetchSuggestions(urlBar.getText().toString());
                } else hideSuggestions();
            }
        });
        urlBar.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (searchOverlay == null && !searchOpening) openSearchScreen();
            }
        });
        urlBar.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(android.text.Editable e) {
                if (searchOverlay != null) { onSearchQuery(e.toString().trim()); return; }
                fetchSuggestions(e.toString());
            }
        });

        suggestAdapter = new android.widget.ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, suggestItems) {
            @Override public View getView(int position, View convert, android.view.ViewGroup parent) {
                TextView tv = (TextView) super.getView(position, convert, parent);
                tv.setTextColor(ink());
                tv.setTextSize(13f);
                tv.setBackgroundColor(lightTheme() ? panel() : panel());
                tv.setPadding(dp(16), dp(13), dp(16), dp(13));
                return tv;
            }
        };
        suggestList.setAdapter(suggestAdapter);
        suggestList.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {
            @Override public void onItemClick(android.widget.AdapterView<?> p, View v, int pos, long id) {
                String text = suggestItems.get(pos);
                urlBar.setText(text);
                urlBar.setSelection(text.length());
                hideSuggestions();
                go(text);
            }
        });
    }

    private String suggestEndpoint() {
        switch (currentEngine()) {
            case "google": return "https://suggestqueries.google.com/complete/search?client=firefox&q=";
            case "brave":  return "https://search.brave.com/api/suggest?q=";
            case "bing":   return "https://api.bing.com/osjson.aspx?query=";
            case "yahoo":  return "https://search.yahoo.com/sugg/os?command=";
            default:       return "https://duckduckgo.com/ac/?q=";
        }
    }

    /* =========================================================
       the search screen — tap the field and the page gets out of the way
       recent first (local, instant), suggestions as you type.
    ========================================================= */
    private ViewGroup searchOverlay;
    private EditText searchField;
    private LinearLayout searchList;

    /* =========================================================
       Search page — v3.
       Tap: no tabs, recents + suggestions.
       Type: tabs slide in (SITES | WEB).
       Open: the page leaves, the engine takes over.
    ========================================================= */
    private boolean searchOpening;
    private LinearLayout searchTabs, paneRecent, paneSites, paneWeb;
    private TextView tabSites, tabWeb;
    private View tabInk;

    private TextView sharpText(String label, float size, int color) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setTypeface(android.graphics.Typeface.MONOSPACE);
        return t;
    }

    private View hairline() {
        View v = new View(this);
        v.setBackgroundColor(lightTheme() ? line() : line());
        v.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)));
        return v;
    }

    private void addSection(LinearLayout into, String title, String right) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(dp(14), dp(14), dp(14), dp(6));
        TextView a = sharpText(title, 8f, inkDim());
        a.setLetterSpacing(0.18f);
        row.addView(a, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        if (right != null && !right.isEmpty()) {
            TextView b = sharpText(right, 8f, inkDim());
            b.setLetterSpacing(0.12f);
            row.addView(b);
        }
        into.addView(row);
        into.addView(hairline());
    }

    private void addRow(LinearLayout into, final String label, String meta, final String url) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        row.setPadding(dp(14), dp(13), dp(14), dp(13));
        TextView l = sharpText(label, 11.5f, ink());
        row.addView(l, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        if (meta != null && !meta.isEmpty()) {
            TextView m = sharpText(meta, 8f, inkDim());
            row.addView(m);
        }
        row.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                closeSearchScreen();
                if (url != null && !url.isEmpty()) go(url); else go(label);
            }
        });
        into.addView(row);
        into.addView(hairline());
    }

    private LinearLayout newPane() {
        LinearLayout p = new LinearLayout(this);
        p.setOrientation(LinearLayout.VERTICAL);
        p.setVisibility(View.GONE);
        return p;
    }

    private void showPane(LinearLayout which) {
        LinearLayout[] all = {paneRecent, paneSites, paneWeb};
        for (LinearLayout p : all) if (p != null) p.setVisibility(p == which ? View.VISIBLE : View.GONE);
    }

    private void paintPaneRecent() {
        if (paneRecent == null) return;
        paneRecent.removeAllViews();
        java.util.LinkedHashMap<String, String> seen = new java.util.LinkedHashMap<>();
        try {
            org.json.JSONArray hist = readArray("history");
            for (int i = hist.length() - 1; i >= 0 && seen.size() < 5; i--) {
                org.json.JSONObject o = hist.optJSONObject(i);
                String u = o == null ? "" : o.optString("url", "");
                String host = hostOf(u);
                if (u.isEmpty() || host == null || host.isEmpty() || seen.containsKey(host)) continue;
                seen.put(host, u);
            }
        } catch (Exception e) { note("paintPaneRecent", e); }
        if (!seen.isEmpty()) {
            addSection(paneRecent, "RECENT", String.valueOf(seen.size()));
            for (java.util.Map.Entry<String, String> e : seen.entrySet())
                addRow(paneRecent, e.getKey(), "", e.getValue());
        }
        addSection(paneRecent, "SUGGESTIONS", "");
        String[][] quick = {{"GitHub", "https://github.com"}, {"IRCTC", "https://www.irctc.co.in"},
                {"Passport Seva", "https://www.passportindia.gov.in"},
                {"BESCOM", "https://bescom.karnataka.gov.in"},
                {"NSE India", "https://www.nseindia.com"}};
        for (String[] q : quick) addRow(paneRecent, q[0], "0 KB", q[1]);
    }

    private void paintPaneSites(String q) {
        if (paneSites == null) return;
        paneSites.removeAllViews();
        java.util.List<String[]> hits = searchMercyIndex(q, 12);
        addSection(paneSites, "SITES \u00B7 OFFLINE", String.valueOf(hits.size()));
        if (hits.isEmpty()) {
            addRow(paneSites, "Nothing offline for \u201C" + q + "\u201D", "", null);
            return;
        }
        for (String[] h : hits) addRow(paneSites, h[0], "0 KB", h[1]);
    }

    private void openSearchScreen() {
        if (searchOpening) return;
        if (errorOverlay != null) closeErrorPage();
        searchOpening = true;
        closeSearchScreen();
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(surface());

        /* No header here — the app's real search bar (urlBar) stays untouched.
           This page fills only the area under it. */
        searchField = urlBar;
        /* tabs — hidden until there is a query */
        searchTabs = new LinearLayout(this);
        searchTabs.setOrientation(LinearLayout.HORIZONTAL);
        searchTabs.setVisibility(View.GONE);
        tabSites = sharpText("SITES", 8.5f, ink());
        tabSites.setLetterSpacing(0.16f);
        tabSites.setGravity(android.view.Gravity.CENTER);
        tabSites.setPadding(0, dp(11), 0, dp(11));
        tabWeb = sharpText("WEB", 8.5f, inkDim());
        tabWeb.setLetterSpacing(0.16f);
        tabWeb.setGravity(android.view.Gravity.CENTER);
        tabWeb.setPadding(0, dp(11), 0, dp(11));
        tabSites.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { selectTab(false); }
        });
        tabWeb.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { selectTab(true); }
        });
        searchTabs.addView(tabSites, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        searchTabs.addView(tabWeb, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        root.addView(searchTabs);
        root.addView(hairline());

        /* panes */
        android.widget.ScrollView sv = new android.widget.ScrollView(this);
        LinearLayout holder = new LinearLayout(this);
        holder.setOrientation(LinearLayout.VERTICAL);
        paneRecent = newPane();
        paneSites = newPane();
        paneWeb = newPane();
        holder.addView(paneRecent);
        holder.addView(paneSites);
        holder.addView(paneWeb);
        sv.addView(holder);
        root.addView(sv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        searchList = holder;

        searchOverlay = root;
        final View headerBar = findViewById(R.id.header);
        final View oldSuggest = findViewById(R.id.suggest);
        if (oldSuggest != null) oldSuggest.setVisibility(View.GONE);
        int top = headerBar != null ? headerBar.getHeight() : dp(56);
        android.widget.FrameLayout.LayoutParams lp = new android.widget.FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        lp.topMargin = top;
        ((ViewGroup) findViewById(android.R.id.content)).addView(root, lp);
        root.setElevation(dp(10));

        searchField.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_GO
                        || (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                    String q = searchField.getText().toString().trim();
                    if (!q.isEmpty()) { closeSearchScreen(); go(q); }
                    return true;
                }
                return false;
            }
        });

        searchOpening = false;
        String seed = urlBar.getText() == null ? "" : urlBar.getText().toString().trim();
        if (seed.isEmpty()) { searchTabs.setVisibility(View.GONE); paintPaneRecent(); showPane(paneRecent); }
        else { searchTabs.setVisibility(View.VISIBLE); paintPaneSites(seed); showPane(paneSites); }
        showKeyboard();
    }

    /** the page follows the real search bar, keystroke by keystroke */
    private void onSearchQuery(String q) {
        if (searchTabs == null) return;
        if (q.isEmpty()) {
            searchTabs.setVisibility(View.GONE);
            showPane(paneRecent);
            paintPaneRecent();
            return;
        }
        searchTabs.setVisibility(View.VISIBLE);
        if (paneWeb != null && paneWeb.getVisibility() == View.VISIBLE) {
            paintPaneWeb(q);
            showPane(paneWeb);
        } else {
            paintPaneSites(q);
            showPane(paneSites);
        }
    }

    private void selectTab(boolean web) {
        if (tabSites == null) return;
        tabSites.setTextColor(web ? inkDim() : ink());
        tabWeb.setTextColor(web ? ink() : inkDim());
        if (web) { paintPaneWeb(searchField == null ? "" : searchField.getText().toString().trim());
                   showPane(paneWeb); }
        else { paintPaneSites(searchField == null ? "" : searchField.getText().toString().trim());
               showPane(paneSites); }
    }

    private void paintPaneWeb(String q) {
        if (paneWeb == null) return;
        paneWeb.removeAllViews();
        addSection(paneWeb, "SUGGESTIONS", "DATA");
        addRow(paneWeb, q + " login", "\u2248 240 KB", searchUrl(q + " login"));
        addRow(paneWeb, q + " news", "\u2248 180 KB", searchUrl(q + " news"));
        addSection(paneWeb, "RELATED", "");
        java.util.List<String[]> hits = searchMercyIndex(q, 3);
        for (String[] h : hits) addRow(paneWeb, h[0], "0 KB", h[1]);
        addSection(paneWeb, "DIRECT", "");
        addRow(paneWeb, "Open the top result for \u201C" + q + "\u201D", "0 KB",
                "https://duckduckgo.com/?q=!ducky+" + android.net.Uri.encode(q));
        addRow(paneWeb, "Search the web", "", searchUrl(q));
    }



    private void closeSearchScreen() {
        if (searchOverlay != null) {
            try { ((ViewGroup) searchOverlay.getParent()).removeView(searchOverlay); } catch (Exception e) { note("closeSearchScreen", e); }
            searchOverlay = null;
        }
        showGecko(true);
        View oldSuggest = findViewById(R.id.suggest);
        if (oldSuggest != null) oldSuggest.setVisibility(View.VISIBLE);
        searchField = null;
        searchList = null;
        searchOpening = false;
    }

    /* =========================================================
       Mercy Index — useful Indian sites, inside the APK.
       Works offline, costs zero data, never ranks an ad first.
    ========================================================= */
    private org.json.JSONArray mercyIndex;

    private void loadMercyIndex() {
        if (mercyIndex != null) return;
        reloadIndexFromDisk();
        if (mercyIndex != null && mercyIndex.length() > 0) return;
        try {
            java.io.InputStream in = getAssets().open("index/india.json");
            byte[] buf = new byte[in.available()];
            in.read(buf);
            in.close();
            mercyIndex = new org.json.JSONArray(new String(buf, "UTF-8"));
        } catch (Exception e) { mercyIndex = new org.json.JSONArray(); }
            mergeWorldPack();
    }

    private String countryCode() {
        String c = prefs.getString("indexPack", null);
        if (c != null && !c.isEmpty()) return c;
        try {
            String cc = getResources().getConfiguration().getLocales().get(0).getCountry();
            if (cc != null && !cc.isEmpty()) return cc.toLowerCase();
        } catch (Exception e) { note("countryCode", e); }
        return "in";
    }

    /** a downloaded pack wins; otherwise the one inside the APK */
    private void reloadIndexFromDisk() {
        String cc = countryCode();
        try {
            java.io.File f = new java.io.File(getFilesDir(), "index-" + cc + ".json");
            if (!f.exists()) { mercyIndex = null; return; }
            byte[] b = new byte[(int) f.length()];
            java.io.FileInputStream in = new java.io.FileInputStream(f);
            in.read(b); in.close();
            mercyIndex = new org.json.JSONArray(new String(b, "UTF-8"));
        } catch (Exception e) { mercyIndex = null; }
    }

    private void updateIndexPack() {
        final String cc = countryCode();
        toast("Checking the " + cc.toUpperCase() + " site list\u2026");
        new Thread(new Runnable() {
            @Override public void run() {
                String msg;
                try {
                    /* data lives in its own repo; the code repo is the fallback */
                    String[] bases = {
                            "https://raw.githubusercontent.com/skoofficialll-hash/MERCY-INDEX/main/",
                            "https://raw.githubusercontent.com/skoofficialll-hash/MERCY-GX-V.2/main/"
                    };
                    String pack = "in".equals(cc) ? "india" : "index-" + cc;
                    StringBuilder sb = new StringBuilder();
                    Exception last = null;
                    for (String base : bases) {
                        try {
                            java.net.HttpURLConnection c =
                                    (java.net.HttpURLConnection) new java.net.URL(base + pack + ".json").openConnection();
                            c.setConnectTimeout(6000); c.setReadTimeout(8000);
                            java.io.BufferedReader r = new java.io.BufferedReader(
                                    new java.io.InputStreamReader(c.getInputStream(), "UTF-8"));
                            String line;
                            while ((line = r.readLine()) != null) sb.append(line);
                            r.close();
                            if (sb.length() > 100) break;
                        } catch (Exception e) { last = e; sb.setLength(0); }
                    }
                    if (sb.length() < 100) throw (last != null ? last : new Exception("empty pack"));
                    org.json.JSONArray arr = new org.json.JSONArray(sb.toString());
                    if (arr.length() < 20) throw new Exception("pack too small");
                    java.io.FileOutputStream fo =
                            new java.io.FileOutputStream(new java.io.File(getFilesDir(), "index-" + cc + ".json"));
                    fo.write(sb.toString().getBytes("UTF-8"));
                    fo.close();
                    reloadIndexFromDisk();
                    msg = "Site list updated: " + (mercyIndex == null ? 0 : mercyIndex.length()) + " entries";
                } catch (Exception e) {
                    msg = "Site list update failed (" + e.getClass().getSimpleName() + ")";
                }
                final String m = msg;
                runOnUiThread(new Runnable() { @Override public void run() { toast(m); } });
            }
        }).start();
    }

    /** country pack first, then the world pack — one list, no duplicates */
    private void mergeWorldPack() {
        try {
            java.io.InputStream in = getAssets().open("index/world.json");
            byte[] buf = new byte[in.available()];
            in.read(buf); in.close();
            org.json.JSONArray world = new org.json.JSONArray(new String(buf, "UTF-8"));
            java.util.Set<String> have = new java.util.HashSet<>();
            for (int i = 0; i < mercyIndex.length(); i++) {
                org.json.JSONObject e = mercyIndex.optJSONObject(i);
                if (e != null) have.add(e.optString("u", ""));
            }
            for (int i = 0; i < world.length(); i++) {
                org.json.JSONObject e = world.optJSONObject(i);
                if (e == null) continue;
                if (have.add(e.optString("u", ""))) mercyIndex.put(e);
            }
        } catch (Exception e) { note("mergeWorldPack", e); }
    }

    private java.util.List<String[]> searchMercyIndex(String query, int limit) {
        loadMercyIndex();
        java.util.List<String[]> ranked = new java.util.ArrayList<>();
        final String q = query == null ? "" : query.toLowerCase().trim();
        if (q.isEmpty()) return ranked;
        String[] words = q.split("\\s+");
        final java.util.Map<Integer, Double> scores = new java.util.HashMap<>();
        for (int i = 0; i < mercyIndex.length(); i++) {
            org.json.JSONObject e = mercyIndex.optJSONObject(i);
            if (e == null) continue;
            String name = e.optString("n", "").toLowerCase();
            String tags = e.optString("t", "").toLowerCase();
            String cat = e.optString("c", "");
            double s = 0;
            if (name.contains(q)) s += 25;
            if (tags.contains(q)) s += 15;
            for (String w : words) {
                if (w.isEmpty()) continue;
                String firstWord = name.split(" ")[0];
                if (firstWord.equals(w)) s += 12;
                else if (java.util.regex.Pattern.compile("\\b" + java.util.regex.Pattern.quote(w)).matcher(name).find()) s += 6;
                else if (java.util.regex.Pattern.compile("\\b" + java.util.regex.Pattern.quote(w)).matcher(tags).find()) s += 3;
            }
            if (s <= 0) continue;
            if ("gov".equals(cat)) s += 3;
            else if ("state".equals(cat)) s += 1;
            scores.put(i, s);
        }
        java.util.List<Integer> order = new java.util.ArrayList<>(scores.keySet());
        java.util.Collections.sort(order, new java.util.Comparator<Integer>() {
            @Override public int compare(Integer a, Integer b) {
                int c = Double.compare(scores.get(b), scores.get(a));
                if (c != 0) return c;
                return mercyIndex.optJSONObject(a).optString("n", "")
                        .compareTo(mercyIndex.optJSONObject(b).optString("n", ""));
            }
        });
        for (int i = 0; i < order.size() && ranked.size() < limit; i++) {
            org.json.JSONObject e = mercyIndex.optJSONObject(order.get(i));
            if (e != null) ranked.add(new String[]{e.optString("n", ""), e.optString("u", "")});
        }
        return ranked;
    }

    private void paintIndexHits(String q) {
        if (searchList == null) return;
        java.util.List<String[]> hits = searchMercyIndex(q, 4);
        if (hits.isEmpty()) return;
        searchList.removeAllViews();
        addSearchHeader("MERCY INDEX \u00B7 OFFLINE");
        for (String[] h : hits) addSearchRow("\u25C8", h[0], h[1]);
    }

    private void paintSearchRecent() {
        if (searchList == null) return;
        searchList.removeAllViews();
        java.util.List<String> recent = new java.util.ArrayList<>();
        java.util.Set<String> seenHosts = new java.util.HashSet<>();
        try {
            org.json.JSONArray hist = readArray("history");
            for (int i = hist.length() - 1; i >= 0 && recent.size() < 6; i--) {
                org.json.JSONObject o = hist.optJSONObject(i);
                String u = o == null ? "" : o.optString("url", "");
                String h = hostOf(u);
                if (u.isEmpty() || h == null || h.isEmpty() || !seenHosts.add(h)) continue;
                recent.add(u);
            }
        } catch (Exception e) { note("paintSearchRecent", e); }

        if (recent.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("Type to search. Your recent pages will show here.");
            empty.setTextSize(11f);
            empty.setTextColor(inkDim());
            empty.setPadding(dp(18), dp(18), dp(18), dp(18));
            searchList.addView(empty);
            return;
        }
        addSearchHeader("RECENT");
        for (final String u : recent) addSearchRow("\u25F7", hostOf(u), u);
    }

    private void addSearchHeader(String label) {
        TextView h = new TextView(this);
        h.setText(label);
        h.setTextSize(8.5f);
        h.setLetterSpacing(0.16f);
        h.setTextColor(inkDim());
        h.setPadding(dp(18), dp(16), dp(18), dp(6));
        searchList.addView(h);
    }

    private void addSearchRow(String glyph, String label, final String query) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        row.setPadding(dp(18), dp(13), dp(18), dp(13));

        TextView g = new TextView(this);
        g.setText(glyph);
        g.setTextSize(12f);
        g.setTextColor(inkDim());
        g.setWidth(dp(24));
        row.addView(g);

        TextView l = new TextView(this);
        l.setText(label);
        l.setTextSize(13f);
        l.setTextColor(ink());
        row.addView(l, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        row.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                closeSearchScreen();
                if (looksLikeUrl(query)) go(query); else go(query);
            }
        });
        searchList.addView(row);

        View line = new View(this);
        line.setBackgroundColor(lightTheme() ? 0x14000000 : 0x14FFFFFF);
        searchList.addView(line, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1));
    }

    /** suggestions for the search screen, through the same parser the field uses */
    /* =========================================================
       direct answers — a site the query is about, opened straight.
       DuckDuckGo's public instant-answer API. No key, no page load.
    ========================================================= */
    private void fetchInstant(final String q) {
        new Thread(new Runnable() {
            @Override public void run() {
                String heading = null, abstractUrl = null, text = null;
                final java.util.List<String[]> related = new java.util.ArrayList<>();
                java.net.HttpURLConnection c = null;
                try {
                    String url = "https://api.duckduckgo.com/?format=json&no_html=1&skip_disambig=1&q="
                            + java.net.URLEncoder.encode(q, "UTF-8");
                    c = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
                    c.setConnectTimeout(2500);
                    c.setReadTimeout(2500);
                    c.setRequestProperty("User-Agent", "Mozilla/5.0");
                    java.io.BufferedReader r = new java.io.BufferedReader(
                            new java.io.InputStreamReader(c.getInputStream(), "UTF-8"));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = r.readLine()) != null) sb.append(line);
                    r.close();
                    org.json.JSONObject o = new org.json.JSONObject(sb.toString());
                    heading = o.optString("Heading", "");
                    abstractUrl = o.optString("AbstractURL", "");
                    text = o.optString("AbstractText", "");
                    org.json.JSONArray rel = o.optJSONArray("RelatedTopics");
                    if (rel != null) {
                        for (int i = 0; i < rel.length() && related.size() < 5; i++) {
                            org.json.JSONObject t = rel.optJSONObject(i);
                            if (t == null) continue;
                            String u = t.optString("FirstURL", "");
                            if (!u.isEmpty()) related.add(new String[]{t.optString("Text", ""), u});
                        }
                    }
                } catch (Exception e) { note("run", e); } finally { if (c != null) c.disconnect(); }

                final String h = heading, au = abstractUrl, tx = text;
                final java.util.List<String[]> rel = related;
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        if (searchList == null || searchField == null) return;
                        if (!q.equals(searchField.getText().toString().trim())) return;
                        String lucky = "https://duckduckgo.com/?q=!ducky+" + android.net.Uri.encode(q);
                        if (au == null || au.isEmpty()) {
                            addSearchHeader("DIRECT");
                            addSearchRow("\u26A1", "Open the top result for \"" + q + "\"", lucky);
                            return;
                        }
                        addSearchHeader("SITE");
                        addSearchRow("\u25C8", h == null || h.isEmpty() ? hostOf(au) : h, au);
                        if (tx != null && !tx.isEmpty()) {
                            TextView d = new TextView(MainActivity.this);
                            d.setText(tx.length() > 160 ? tx.substring(0, 160) + "\u2026" : tx);
                            d.setTextSize(10.5f);
                            d.setTextColor(inkDim());
                            d.setPadding(dp(18), 0, dp(18), dp(10));
                            searchList.addView(d);
                        }
                        if (!rel.isEmpty()) {
                            addSearchHeader("RELATED");
                            for (String[] r2 : rel) addSearchRow("\u2197", r2[0], r2[1]);
                        }
                        addSearchHeader("DIRECT");
                        addSearchRow("\u26A1", "Open the top result for \"" + q + "\"", lucky);
                    }
                });
            }
        }).start();
    }

    private void fetchForSearch(final String q) {
        new Thread(new Runnable() {
            @Override public void run() {
                final java.util.List<String> out = new java.util.ArrayList<>();
                java.net.HttpURLConnection c = null;
                try {
                    String url = suggestEndpoint() + java.net.URLEncoder.encode(q, "UTF-8")
                            + (suggestEndpoint().contains("duckduckgo") ? "&type=list" : "");
                    c = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
                    c.setConnectTimeout(2500);
                    c.setReadTimeout(2500);
                    c.setRequestProperty("User-Agent", "Mozilla/5.0");
                    java.io.BufferedReader r = new java.io.BufferedReader(
                            new java.io.InputStreamReader(c.getInputStream(), "UTF-8"));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = r.readLine()) != null) sb.append(line);
                    r.close();
                    parseSuggestions(sb.toString(), out);
                } catch (Exception e) { note("run", e); } finally { if (c != null) c.disconnect(); }
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        if (searchList == null) return;
                        if (searchField == null || !q.equals(searchField.getText().toString().trim())) return;
                        searchList.removeAllViews();
                        addSearchHeader("SUGGESTIONS");
                        for (String s2 : out) addSearchRow("\u2315", s2, s2);
                        addSearchHeader("SEARCH FOR");
                        addSearchRow("\u2315", q, q);
                    }
                });
            }
        }).start();
    }

    /* Rule 11 — the illusion of speed: a skeleton, never a spinner. */
    private View skeleton;

    private View buildSkeleton() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(surface());

        /* the progress line sits on the skeleton, like the design */
        View bar = new View(this);
        bar.setBackgroundColor(lightTheme() ? line() : line());
        LinearLayout track = new LinearLayout(this);
        track.setBackgroundColor(lightTheme() ? line() : line());
        final View fill = new View(this);
        fill.setBackgroundColor(ink());
        track.addView(fill, new LinearLayout.LayoutParams(0, dp(2), 0.38f));
        root.addView(track, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(2)));

        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(14), dp(16), dp(14), dp(16));

        body.addView(shimmerBar(0.52f, 16));
        body.addView(gap(11));
        body.addView(shimmerBar(0.9f, 7));
        body.addView(gap(7));
        body.addView(shimmerBar(0.66f, 7));
        body.addView(gap(12));

        View hero = new View(this);
        android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
        g.setColor(lightTheme() ? panel() : panel());
        hero.setBackground(g);
        body.addView(hero, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(104)));
        body.addView(gap(12));

        for (int k = 0; k < 3; k++) {
            body.addView(shimmerBar(k == 2 ? 0.66f : 1f, 7));
            body.addView(gap(7));
        }
        root.addView(body);

        root.setAlpha(0.85f);
        android.animation.ObjectAnimator pulse = android.animation.ObjectAnimator
                .ofFloat(root, "alpha", 0.45f, 0.9f);
        pulse.setDuration(1200);
        pulse.setRepeatMode(android.animation.ValueAnimator.REVERSE);
        pulse.setRepeatCount(android.animation.ValueAnimator.INFINITE);
        pulse.start();
        return root;
    }

    private View shimmerBar(float widthPct, int heightDp) {
        View v = new View(this);
        android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
        g.setColor(lightTheme() ? panel() : line());
        g.setCornerRadius(0);          // sharp, like the rest of the app
        v.setBackground(g);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(heightDp));
        lp.weight = widthPct;
        v.setLayoutParams(lp);
        return v;
    }

    private View gap(int h) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(h)));
        return v;
    }

    private void showSkeleton() {
        if (skeleton == null) {
            skeleton = buildSkeleton();
            container.addView(skeleton, new android.widget.FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        }
        skeleton.setVisibility(View.VISIBLE);
    }

    private void hideSkeleton() {
        if (skeleton != null) skeleton.setVisibility(View.GONE);
    }

    private void showKeyboard() {
        try {
            android.view.inputmethod.InputMethodManager im =
                    (android.view.inputmethod.InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            if (im != null) im.showSoftInput(urlBar, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT);
        } catch (Exception e) { note("showKeyboard", e); }
    }

    /** tapping the field offers your own history first — no network, instant */
    private void showRecentSuggestions() {
        java.util.List<String> out = new java.util.ArrayList<>();
        try {
            org.json.JSONArray hist = readArray("history");
            for (int i = hist.length() - 1; i >= 0 && out.size() < 6; i--) {
                org.json.JSONObject o = hist.optJSONObject(i);
                String t = o == null ? "" : o.optString("title", "");
                String u = o == null ? "" : o.optString("url", "");
                String label = t == null || t.isEmpty() ? hostOf(u) : t;
                if (label != null && !label.isEmpty() && !out.contains(label)) out.add(label);
            }
        } catch (Exception e) { note("showRecentSuggestions", e); }
        if (out.isEmpty()) { hideSuggestions(); return; }
        suggestItems.clear();
        suggestItems.addAll(out);
        if (suggestAdapter != null) suggestAdapter.notifyDataSetChanged();
        suggestList.setVisibility(View.VISIBLE);
    }

    private void fetchSuggestions(final String query) {
        if (suggestHandler == null) return;
        suggestHandler.removeCallbacksAndMessages(null);
        final String q = query == null ? "" : query.trim();
        if (q.isEmpty()) { showRecentSuggestions(); return; }
        suggestHandler.postDelayed(new Runnable() {
            @Override public void run() {
                new Thread(new Runnable() {
                    @Override public void run() {
                        final java.util.List<String> out = new java.util.ArrayList<>();
                        java.net.HttpURLConnection c = null;
                        try {
                            String url = suggestEndpoint() + java.net.URLEncoder.encode(q, "UTF-8")
                                    + (suggestEndpoint().contains("duckduckgo") ? "&type=list" : "");
                            c = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
                            c.setConnectTimeout(2500);
                            c.setReadTimeout(2500);
                            c.setRequestProperty("User-Agent", "Mozilla/5.0");
                            java.io.BufferedReader r = new java.io.BufferedReader(
                                    new java.io.InputStreamReader(c.getInputStream(), "UTF-8"));
                            StringBuilder sb = new StringBuilder();
                            String line;
                            while ((line = r.readLine()) != null) sb.append(line);
                            r.close();
                            parseSuggestions(sb.toString(), out);
                        } catch (Exception e) { note("run", e); } finally {
                            if (c != null) c.disconnect();
                        }
                        runOnUiThread(new Runnable() {
                            @Override public void run() {
                                if (!urlBar.hasFocus()) return;
                                if (out.isEmpty()) { hideSuggestions(); return; }
                                suggestItems.clear();
                                suggestItems.addAll(out);
                                if (suggestAdapter != null) suggestAdapter.notifyDataSetChanged();
                                suggestList.setVisibility(View.VISIBLE);
                            }
                        });
                    }
                }).start();
            }
        }, 160);
    }

    /**
     * Every engine answers in its own shape:
     *   DuckDuckGo   ["a", "b"]  or  [{"phrase":"a"}]
     *   Google/Bing  ["query", ["a","b"]]
     *   Yahoo        ["query", ["a","b"]]  (sometimes wrapped in JSONP)
     * This reads all of them and keeps only the strings.
     */
    private void parseSuggestions(String raw, java.util.List<String> out) {
        if (raw == null) return;
        String body = raw.trim();
        if (body.isEmpty()) return;
        int p1 = body.indexOf('(');
        int p2 = body.lastIndexOf(')');
        if (p1 >= 0 && p2 > p1 && !body.startsWith("[")) body = body.substring(p1 + 1, p2);
        /* JSONP bodies arrive as  "query",["a","b"]  — wrap them back into an array */
        if (!body.startsWith("[") && !body.startsWith("{")) body = "[" + body + "]";

        try {
            if (body.startsWith("\"")) {
                Object once = new org.json.JSONTokener(body).nextValue();
                body = String.valueOf(once);
            }
            org.json.JSONArray arr = new org.json.JSONArray(body);

            /* google / bing / yahoo: the list is the second element */
            if (arr.length() >= 2 && arr.opt(1) instanceof org.json.JSONArray) {
                org.json.JSONArray list = arr.optJSONArray(1);
                for (int i = 0; i < list.length() && out.size() < 8; i++) {
                    String v = list.optString(i, "").trim();
                    if (!v.isEmpty()) out.add(v);
                }
                if (!out.isEmpty()) return;
            }

            for (int i = 0; i < arr.length() && out.size() < 8; i++) {
                Object o = arr.opt(i);
                String phrase = null;
                if (o instanceof String) phrase = (String) o;
                else if (o instanceof org.json.JSONObject)
                    phrase = ((org.json.JSONObject) o).optString("phrase", null);
                if (phrase != null && !phrase.trim().isEmpty()) out.add(phrase.trim());
            }
        } catch (Exception e) { note("parseSuggestions", e); }
    }

    private void hideSuggestions() {
        if (suggestList != null) suggestList.setVisibility(View.GONE);
        if (suggestItems != null) suggestItems.clear();
        if (suggestAdapter != null) suggestAdapter.notifyDataSetChanged();
    }

    private void applyHeaderMode(String url) {
        boolean isHome = url == null || url.contains("newtab.html") || url.startsWith("resource://android");
        if (homeView != null) {
            homeView.setVisibility(isHome ? View.VISIBLE : View.GONE);
            if (isHome) paintHome();
        }
        boolean home = url == null || url.contains("newtab.html") || url.contains("appassets");
        engineChip.setVisibility(home ? View.VISIBLE : View.GONE);
        ring.setVisibility(home ? View.GONE : View.VISIBLE);
        pctLabel.setVisibility(home ? View.GONE : View.VISIBLE);
        findViewById(R.id.btnNew).setVisibility(home ? View.GONE : View.VISIBLE);
        btnTabs.setVisibility(home ? View.GONE : View.VISIBLE);
    }

    private static class MItem {
        final String glyph, label, value; final Runnable action;
        MItem(String g, String l, String v, Runnable a) { glyph = g; label = l; value = v; action = a; }
    }

    private MItem mi(String g, String l, String v, Runnable a) { return new MItem(iconKey(g), l, v, a); }

    /** old font glyphs become real line icons */
    private static String iconKey(String g) {
        if (g == null) return MercyIcon.SEARCH;
        switch (g) {
            case "\u25F7": case "\u25D0": return MercyIcon.TABS;
            case "\u2193": return MercyIcon.DOWNLOAD;
            case "\u21BB": case "\u21BA": return MercyIcon.RELOAD;
            case "\u2699": return MercyIcon.SETTINGS;
            case "\uFF0B": return MercyIcon.PLUS;
            case "\u2605": return MercyIcon.STAR;
            case "\u25A6": case "\u25CD": case "\u25A3": case "\u20B9": case "\u25F4":
                return MercyIcon.DATA;
            case "\u2318": return MercyIcon.DEV;
            case "\u2620": return MercyIcon.TRASH;
            case "\u2197": return MercyIcon.SHARE;
            case "\u25A4": return MercyIcon.BOOKMARK;
            case "\u24D8": return MercyIcon.GLOBE;
            case "\u2715": case "\u00D7": return MercyIcon.CLOSE;
            case "\u25C8": case "\u25E7": return MercyIcon.SEARCH;
            case "\u26A1": case "\u25B6": return MercyIcon.GLOBE;
            case "\u25F4 ": return MercyIcon.DATA;
            default: return MercyIcon.SEARCH;
        }
    }

    private org.json.JSONArray readArray(String key) {
        try { return new org.json.JSONArray(prefs.getString(key, "[]")); }
        catch (Exception e) { return new org.json.JSONArray(); }
    }

    private int accent() {
        String chosen = prefs.getString("accent", null);
        if (chosen != null) { try { return android.graphics.Color.parseColor(chosen); } catch (Exception e) { note("accent", e); } }
        return themeColor(6);
    }

    private static final String[][] THEMES = {
        {"dark","Dark","#000000","#0B0B0E","#F2F2F2","#8B8B95","#C9A8FF"},
        {"amoled","AMOLED Black","#000000","#000000","#FFFFFF","#77777F","#A06BFF"},
        {"light","Light","#F7F6F3","#FFFFFF","#14141A","#6B6B74","#7A3DF0"},
        {"paper","Paper","#F4EFE4","#FBF7EE","#2A2418","#7A6F5A","#A2552B"},
        {"midnight","Midnight","#0A1020","#121A2E","#E8EEFC","#8A97B5","#6AA8FF"},
        {"forest","Forest","#08120C","#0F1A13","#E9F5EC","#7D9A86","#4ADE80"},
        {"terminal","Terminal","#000000","#050805","#C8FFD4","#4F7A5C","#3DDC84"},
        {"contrast","High contrast","#000000","#000000","#FFFFFF","#FFFFFF","#FFFF00"}
    };

    private int themeIndex() {
        String key = prefs.getString("theme", null);
        if (key == null) key = prefs.getString("bg", "dark");
        if ("black".equals(key) || "soft".equals(key)) key = "dark";
        for (int i = 0; i < THEMES.length; i++) if (THEMES[i][0].equals(key)) return i;
        return 0;
    }

    private int themeColor(int slot) {
        try { return android.graphics.Color.parseColor(THEMES[themeIndex()][slot]); }
        catch (Exception e) { return 0xFF000000; }
    }

    /** every surface colour comes from here, so a theme switch cannot miss one */
    private int panel() { return themeColor(3); }
    private int danger() { return danger(); }
    private int line() { return lightTheme() ? line() : line(); }
    private int warn() { return warn(); }
    private int onInk() { return lightTheme() ? 0xFFFFFFFF : 0xFF000000; }

    private int surface() { return themeColor(2); }

    private boolean lightTheme() { int i = themeIndex(); return i == 2 || i == 3; }

    private int ink() { return themeColor(4); }

    private int inkDim() { return themeColor(5); }

    private int radiusDp() {
        String r = prefs.getString("radius", "soft");
        if ("square".equals(r)) return 0;
        if ("pill".equals(r)) return 20;
        return 12;
    }

    private float fontScale() {
        String f = prefs.getString("fontSize", "normal");
        if ("small".equals(f)) return 0.9f;
        if ("large".equals(f)) return 1.15f;
        return 1f;
    }

    /** repaint the whole header from the current theme */
    private void applyTheme() {
        try {
            getWindow().getDecorView().setBackgroundColor(surface());

            View header = findViewById(R.id.header);
            if (header != null) header.setBackgroundColor(surface());

            View pill = findViewById(R.id.pill);
            if (pill != null) {
                android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
                g.setCornerRadius((float) dp(radiusDp()));
                g.setColor(lightTheme() ? 0xFFFFFFFF : panel());
                g.setStroke(dp(1), lightTheme() ? line() : line());
                pill.setBackground(g);
            }

            if (urlBar != null) {
                urlBar.setTextColor(ink());
                urlBar.setTextSize(13f * fontScale());
                urlBar.setHintTextColor(inkDim());
            }

            if (btnTabs != null) {
                android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
                g.setCornerRadius((float) dp(radiusDp() / 2));
                g.setColor(0x00000000);
                g.setStroke(dp(2), lightTheme() ? line() : line());
                btnTabs.setBackground(g);
                btnTabs.setTextColor(ink());
            }

            View nav = findViewById(R.id.bottomNav);
            if (nav != null) nav.setBackgroundColor(lightTheme() ? panel() : panel());

            if (suggestList != null) suggestList.setBackgroundColor(lightTheme() ? panel() : panel());

            paintEngine();
            pushBudget();
        } catch (Exception e) { note("applyTheme", e); }
    }

    private int langIndex() {
        for (int i = 0; i < Lang.CODES.length; i++) if (Lang.CODES[i].equals(lang.code())) return i;
        return 0;
    }

    private void askLanguage() {
        final String[] labels = new String[Lang.NAMES.length];
        for (int i = 0; i < Lang.NAMES.length; i++)
            labels[i] = Lang.NAMES[i] + (Lang.CODES[i].equals(lang.code()) ? "   \u2713" : "");
        new android.app.AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle(lang.t("language"))
                .setItems(labels, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        lang.set(Lang.CODES[which]);
                        toast(Lang.NAMES[which]);
                        closeSettings(); openSettings();
                    }
                })
                .setNegativeButton("Close", null)
                .show();
    }

    /** eight themes, each shown as its own colour strip */
    private void askTheme() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14), dp(8), dp(14), dp(8));

        for (int i = 0; i < THEMES.length; i++) {
            final int pick = i;
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(android.view.Gravity.CENTER_VERTICAL);
            row.setPadding(0, dp(9), 0, dp(9));

            LinearLayout sw = new LinearLayout(this);
            sw.setOrientation(LinearLayout.HORIZONTAL);
            for (int slot = 2; slot <= 6; slot++) {
                View chip = new View(this);
                try { chip.setBackgroundColor(android.graphics.Color.parseColor(THEMES[i][slot])); }
                catch (Exception e) { note("themeChip", e); chip.setBackgroundColor(line()); }
                LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(dp(16), dp(16));
                cp.rightMargin = dp(3);
                sw.addView(chip, cp);
            }
            LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            slp.rightMargin = dp(12);
            row.addView(sw, slp);

            row.addView(sharpText(THEMES[i][1], 11f, ink()),
                    new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            if (i == themeIndex()) row.addView(sharpText("SELECTED", 7.5f, accent()));

            row.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    prefs.edit().putString("theme", THEMES[pick][0]).apply();
                    closeSettings(); applyTheme(); openSettings();
                }
            });
            box.addView(row);
        }

        new android.app.AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle(lang.t("theme")).setView(box).setNegativeButton("Close", null).show();
    }

    private void pickAccent() {
        final String[] items = {"Accent colour", "Background", "Corner radius", "Text size"};
        new android.app.AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle(lang.t("appearance"))
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        if (which == 0) pickAccent();
                        else if (which == 1) pickBackground();
                        else if (which == 2) pickRadius();
                        else pickFontSize();
                    }
                })
                .setNegativeButton("Close", null)
                .show();
    }



    private void askCustomAccent() {
        final EditText in = new EditText(this);
        in.setText(prefs.getString("accent", "#a06bff"));
        in.setHint("#a06bff");
        new android.app.AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle("Accent hex")
                .setView(in)
                .setPositiveButton("Apply", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        String v = in.getText().toString().trim();
                        if (!v.startsWith("#") || (v.length() != 7 && v.length() != 9)) {
                            toast("Use a hex like #a06bff"); return;
                        }
                        try { android.graphics.Color.parseColor(v); }
                        catch (Exception e) { toast("That is not a colour"); return; }
                        prefs.edit().putString("accent", v).apply();
                        applyTheme();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void pickBackground() {
        final String[] names = {"Absolute black", "Soft black", "Paper (light)"};
        final String[] values = {"black", "soft", "light"};
        new android.app.AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle("Background")
                .setItems(names, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        prefs.edit().putString("bg", values[which]).apply();
                        applyTheme();
                    }
                })
                .show();
    }

    private void pickRadius() {
        final String[] names = {"Square (0)", "Soft (12)", "Pill (20)"};
        final String[] values = {"square", "soft", "pill"};
        new android.app.AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle("Corner radius")
                .setItems(names, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        prefs.edit().putString("radius", values[which]).apply();
                        applyTheme();
                    }
                })
                .show();
    }

    private void pickFontSize() {
        final String[] names = {"Small", "Normal", "Large"};
        final String[] values = {"small", "normal", "large"};
        new android.app.AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle("Text size")
                .setItems(names, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        prefs.edit().putString("fontSize", values[which]).apply();
                        applyTheme();
                    }
                })
                .show();
    }


    private void paintEngine() {
        if (engineChip == null) return;
        String id = currentEngine();
        engineChip.setText(engineLabel(id));
        int colour;
        try { colour = android.graphics.Color.parseColor(engineColor(id)); }
        catch (Exception e) { colour = accent(); }
        engineChip.setTextColor(colour);
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setCornerRadius(dp(14));
        bg.setColor((colour & 0x00FFFFFF) | 0x33000000);
        engineChip.setBackground(bg);
    }

    private void pushChromeConfig() {
        try {
            org.json.JSONObject cfg = new org.json.JSONObject();
            cfg.put("engine", currentEngine());
            cfg.put("mercyUrl", prefs.getString("mercyUrl", ""));
            paintEngine();
            if (btnTabs != null) btnTabs.setText(String.valueOf(tabs.size()));
            pushBudget();
            if (active != null) setChromeUrl(active.url);
        } catch (Exception e) { note("pushChromeConfig", e); }
    }

    private void pushBudget() {
        try {
            long today = todayBytes();
            long budget = 200L * 1024 * 1024;
            int pct = budget <= 0 ? 0 : (int) Math.min(100, today * 100 / budget);
            String state = active != null && active.incognito ? "incognito"
                    : (today > budget ? "over" : "normal");
            if (ring != null) ring.setValue(pct, today > budget);
            if (pctLabel != null) {
                pctLabel.setText("incognito".equals(state) ? "PRIVATE" : pct + "%");
                pctLabel.setTextColor("incognito".equals(state) ? accent()
                        : (pct >= 60 ? warn() : inkDim()));
            }
        } catch (Exception e) { note("pushBudget", e); }
    }

    private void setChromeUrl(String url) {
        if (urlBar == null) return;
        boolean internal = url == null || url.contains("appassets")
                || url.startsWith("file://") || url.startsWith("resource://");
        if (!urlBar.hasFocus()) urlBar.setText(internal ? "" : url);
    }

    private void showTabs() {
        final java.util.List<Tab> list = new java.util.ArrayList<>(tabs);
        String[] titles = new String[list.size()];
        for (int i = 0; i < list.size(); i++) {
            Tab t = list.get(i);
            titles[i] = (t == active ? "\u25CF " : "   ") + (t.title == null ? "New tab" : t.title);
        }
        new AlertDialog.Builder(this)
                .setTitle("Tabs \u00B7 " + tabs.size())
                .setItems(titles, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) { select(list.get(which)); }
                })
                .setPositiveButton("New tab", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { MainActivity.this.newTab(HOME); }
                })
                .setNegativeButton("Close", null)
                .show();
    }

    /* ---------------- voice ---------------- */
    private void startVoiceSearch() {
        if (offlineVoice != null && offlineVoice.isReady()) { startOfflineVoice(); return; }
        try {
            Intent i = new Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            // keep the audio on the device whenever an offline model exists
            i.putExtra(android.speech.RecognizerIntent.EXTRA_PREFER_OFFLINE, true);
            i.putExtra(android.speech.RecognizerIntent.EXTRA_PROMPT, "Speak your search");
            startActivityForResult(i, 101);
        } catch (Exception e) {
            toast("No voice input app found");
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == 101 && res == RESULT_OK && data != null) {
            java.util.ArrayList<String> r = data.getStringArrayListExtra(
                    android.speech.RecognizerIntent.EXTRA_RESULTS);
            if (r != null && !r.isEmpty()) {
                setChromeUrl(r.get(0));
                go(r.get(0));
            }
        }
    }

    /* ---------------- QR ---------------- */
    private static final int REQ_CAMERA = 102;
    private boolean pendingScan = false;

    private void scanQrCode() {
        boolean granted = Build.VERSION.SDK_INT < 23
                || checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
        if (!granted) {
            pendingScan = true;
            requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA);
            return;
        }
        new QrScanner(this, new QrScanner.Listener() {
            @Override public void onScanned(String text) {
                String target = looksLikeUrl(text)
                        ? text
                        : "https://duckduckgo.com/?q=" + Uri.encode(text);
                setChromeUrl(target);
                go(target);
            }
        }).show();
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] res) {
        super.onRequestPermissionsResult(req, perms, res);
        if (req == REQ_MIC) {
            if (res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED) {
                if (pendingVoice) { pendingVoice = false; startOfflineVoice(); }
            } else {
                toast("Microphone permission denied");
            }
            return;
        }
        if (req == REQ_CAMERA) {
            if (res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED) {
                if (pendingScan) { pendingScan = false; scanQrCode(); }
            } else {
                toast("Camera permission denied — cannot scan");
            }
        }
    }

    /* ---------------- engine picker ---------------- */
    private static final String[] ENGINE_IDS =
            {"mercy", "google", "ddg", "brave", "ecosia", "startpage", "bing", "yahoo"};

    private String engineLabel(String id) {
        switch (id) {
            case "mercy": return "Mercy (own index)";
            case "google": return "Google";
            case "brave": return "Brave Search";
            case "ecosia": return "Ecosia";
            case "startpage": return "Startpage";
            case "bing": return "Bing";
            case "yahoo": return "Yahoo";
            default: return "DuckDuckGo";
        }
    }

    private String engineColor(String id) {
        switch (id) {
            case "mercy": return "#a06bff";
            case "google": return "#4285f4";
            case "brave": return "#fb542b";
            case "ecosia": return "#2f9e5f";
            case "startpage": return "#6b7f8f";
            case "bing": return "#00a4ef";
            case "yahoo": return "#a05cff";
            default: return "#de5833";
        }
    }

    private String currentEngine() {
        String id = prefs.getString("engine", null);
        if (id == null) return engines == null ? "ddg" : engines.byId("ddg").id;
        if (engines != null) for (String e : engines.ids()) if (e.equals(id)) return id;
        for (String e : ENGINE_IDS) if (e.equals(id)) return id;   /* old setting still honoured */
        return engines == null ? "ddg" : engines.byId("ddg").id;
    }

    /** the list comes from assets/engines.json — add a provider without touching code */
    private void showEnginePicker() {
        final String[] ids = engines == null ? ENGINE_IDS : engines.ids();
        final String[] labels = new String[ids.length];
        String cur = currentEngine();
        int checked = 0;
        for (int i = 0; i < ids.length; i++) {
            labels[i] = engines == null ? engineLabel(ids[i]) : engines.byId(ids[i]).name;
            if (ids[i].equals(cur)) checked = i;
        }
        new AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle(lang.t("search_engine"))
                .setSingleChoiceItems(labels, checked, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        prefs.edit().putString("engine", ids[which]).apply();
                        paintEngine();
                        d.dismiss();
                        if ("custom".equals(ids[which])) askMercyUrl();
                    }
                })
                .setNegativeButton("Close", null)
                .show();
    }

    private void askMercyUrl() {
        final EditText input = new EditText(this);
        input.setHint("https://your-search.onrender.com/search");
        input.setText(prefs.getString("mercyUrl", ""));
        input.setTextSize(13);
        new AlertDialog.Builder(this)
                .setTitle("Mercy engine URL")
                .setMessage("Your own search server. Leave empty to fall back to DuckDuckGo.")
                .setView(input)
                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        prefs.edit().putString("mercyUrl", input.getText().toString().trim()).apply();
                        toast("Saved");
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private String searchUrl(String q) {
        if (engines != null) return engines.url(currentEngine(), q, false);
        String enc = Uri.encode(q);
        String id = currentEngine();
        switch (id) {
            case "mercy": {
                String base = prefs.getString("mercyUrl", "").trim();
                if (base.isEmpty()) return "https://duckduckgo.com/?q=" + enc;
                return base + (base.contains("?") ? "&q=" : "?q=") + enc;
            }
            case "google": return "https://www.google.com/search?q=" + enc;
            case "brave": return "https://search.brave.com/search?q=" + enc;
            case "ecosia": return "https://www.ecosia.org/search?q=" + enc;
            case "startpage": return "https://www.startpage.com/sp/search?query=" + enc;
            case "bing": return "https://www.bing.com/search?q=" + enc;
            case "yahoo": return "https://search.yahoo.com/search?p=" + enc;
            default: return "https://duckduckgo.com/?q=" + enc;
        }
    }


    /* ---------------- image search ---------------- */
    /** Images tab of whichever engine is selected. */
    private String imageSearchUrl(String q) {
        if (engines != null) return engines.url(currentEngine(), q, true);
        String enc = Uri.encode(q == null ? "" : q);
        switch (currentEngine()) {
            case "google": return "https://www.google.com/search?tbm=isch&q=" + enc;
            case "brave":  return "https://search.brave.com/images?q=" + enc;
            case "bing":   return "https://www.bing.com/images/search?q=" + enc;
            case "yahoo":  return "https://images.search.yahoo.com/search/images?p=" + enc;
            case "ecosia": return "https://www.ecosia.org/images?q=" + enc;
            case "startpage": return "https://www.startpage.com/sp/search?query=" + enc + "&cat=images";
            case "mercy": {
                String base = prefs.getString("mercyUrl", "").trim();
                if (!base.isEmpty()) return base + (base.contains("?") ? "&q=" : "?q=") + enc;
                return "https://duckduckgo.com/?q=" + enc + "&iax=images&ia=images";
            }
            default: return "https://duckduckgo.com/?q=" + enc + "&iax=images&ia=images";
        }
    }

    /** Reverse image search: opens the engine's visual-search page, where the
     *  user can upload a photo or point the camera. No API key needed. */
    private String visualSearchUrl() {
        switch (currentEngine()) {
            case "google": return "https://lens.google.com/";
            case "bing":   return "https://www.bing.com/visualsearch";
            case "yahoo":  return "https://images.search.yahoo.com/";
            default:       return "https://lens.google.com/";
        }
    }

    private void openImageSearch() {
        if (active == null) return;
        String q = "";
        String url = imageSearchUrl(q);
        setChromeUrl(url);
        engineLoad(url);
    }

    private void openVisualSearch() {
        if (active == null) return;
        String url = visualSearchUrl();
        setChromeUrl(url);
        engineLoad(url);
    }


    /* ---------------- data ledger ---------------- */
    private long rxBytes() {
        long v = TrafficStats.getUidRxBytes(Process.myUid());
        return v == TrafficStats.UNSUPPORTED ? -1 : v;
    }

    private double tariffPerMb() {
        /* a zero tariff would make every page look free */
        double v = 0.01;                      // ₹10 per GB is a normal Indian pack
        try { v = Double.parseDouble(prefs.getString("tariff", "0.01")); }
        catch (Exception e) { note("tariffPerMb", e); }
        return v > 0 ? v : 0.01;              // a zero tariff makes every page look free
    }

    private boolean isInternalPage(String url) {
        return url == null || url.contains("appassets") || url.startsWith("file://")
                || url.startsWith("resource://");
    }

    private String hostOf(String url) {
        try {
            String h = Uri.parse(url).getHost();
            if (h == null) return null;
            return h.startsWith("www.") ? h.substring(4) : h;
        } catch (Exception e) { return null; }
    }

    private void recordLedger(String url, long ms) {
        if (url == null || url.contains("appassets.androidplatform.net")
                || url.startsWith("file://") || url.startsWith("resource://")) return;
        String host = hostOf(url);
        if (host == null) return;
        long bytes = 0;
        if (rxAtPageStart > 0) {
            long now = rxBytes();
            if (now > rxAtPageStart) bytes = now - rxAtPageStart;
        }
        try {
            org.json.JSONObject all = new org.json.JSONObject(prefs.getString("ledger", "{}"));
            org.json.JSONObject row = all.optJSONObject(host);
            if (row == null) row = new org.json.JSONObject();
            row.put("bytes", row.optLong("bytes") + Math.max(0, bytes));
            row.put("ms", row.optLong("ms") + Math.max(0, ms));
            row.put("visits", row.optLong("visits") + 1);
            all.put(host, row);
            prefs.edit().putString("ledger", all.toString()).apply();
        } catch (Exception e) { note("recordLedger", e); }
    }

    private org.json.JSONObject ledgerRow(String host) {
        try {
            org.json.JSONObject all = new org.json.JSONObject(prefs.getString("ledger", "{}"));
            return all.optJSONObject(host);
        } catch (Exception e) { return null; }
    }

    private long budgetBytes() {
        long mb = prefs.getLong("budgetMb", 200L);
        if (mb <= 0) mb = 200L;
        return mb * 1024L * 1024L;
    }

    private void askBudget() {
        final String[] labels = {"200 MB", "500 MB", "1 GB", "2 GB", "5 GB"};
        final long[] values = {200, 500, 1024, 2048, 5120};
        new android.app.AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle(lang.t("data_budget"))
                .setItems(labels, new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int which) {
                        prefs.edit().putLong("budgetMb", values[which]).apply();
                        pushBudget();
                        toast("Budget set to " + labels[which]);
                    }
                })
                .show();
    }

    private long todayBytes() {
        try {
            String day = new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
                    .format(new java.util.Date());
            return new org.json.JSONObject(prefs.getString("daily", "{}")).optLong(day);
        } catch (Exception e) { return 0; }
    }

    private String human(long b) {
        if (b <= 0) return "0 MB";
        if (b < 1024) return b + " B";
        if (b < 1048576) return String.format("%.0f KB", b / 1024.0);
        if (b < 1073741824L) return String.format("%.1f MB", b / 1048576.0);
        return String.format("%.2f GB", b / 1073741824.0);
    }

    private String money(long bytes) {
        double rupees = (bytes / 1048576.0) * tariffPerMb();
        return String.format("\u20B9%.2f", rupees);
    }

    private String humanTime(long ms) {
        long s = ms / 1000;
        if (s < 60) return s + "s";
        if (s < 3600) return (s / 60) + "m";
        return (s / 3600) + "h " + ((s % 3600) / 60) + "m";
    }


    private void showReportCard() {
        try {
            org.json.JSONObject all = new org.json.JSONObject(prefs.getString("ledger", "{}"));
            if (all.length() == 0) { toast("Nothing recorded yet"); return; }
            long total = 0, totalMs = 0, totalVisits = 0;
            java.util.List<String> hosts = new java.util.ArrayList<>();
            for (java.util.Iterator<String> it = all.keys(); it.hasNext(); ) hosts.add(it.next());
            final java.util.Map<String, Long> bytes = new java.util.HashMap<>();
            for (String h : hosts) {
                org.json.JSONObject r = all.optJSONObject(h);
                long b = r.optLong("bytes");
                bytes.put(h, b);
                total += b;
                totalMs += r.optLong("ms");
                totalVisits += r.optLong("visits");
            }
            java.util.Collections.sort(hosts, new java.util.Comparator<String>() {
                @Override public int compare(String a, String b) {
                    return Long.compare(bytes.get(b), bytes.get(a));
                }
            });
            StringBuilder sb = new StringBuilder();
            sb.append("You spent ").append(human(total)).append(" and ").append(money(total))
              .append(" on ").append(totalVisits).append(" page loads.\n")
              .append(humanTime(totalMs)).append(" of browsing.\n\n");
            int top = 0;
            for (String h : hosts) {
                if (top++ >= 5) break;
                long b = bytes.get(h);
                int pct = total > 0 ? (int) Math.round(b * 100.0 / total) : 0;
                sb.append(h).append("  ").append(pct).append("%  \u00B7  ").append(human(b)).append("\n");
            }
            new AlertDialog.Builder(this)
                    .setTitle(lang.t("report_card"))
                    .setMessage(sb.toString())
                    .setPositiveButton("Close", null)
                    .setNeutralButton("Save data mode", new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface d, int w) { toggleNoImages(); }
                    })
                    .show();
        } catch (Exception e) { toast("Report unavailable"); }
    }

    private void toggleNoImages() {
        boolean now = !prefs.getBoolean("noImages", false);
        prefs.edit().putBoolean("noImages", now).apply();
        toast("Save data mode " + (now ? "ON — images blocked" : "OFF"));
        engineReload();
    }


    /* ---------------- crash safety ---------------- */
    private void reportLastCrash() {
        if (!CrashGuard.hasCrash(this)) return;
        String log = CrashGuard.read(this);
        String first = log == null ? "" : log.trim();
        if (first.length() > 300) first = first.substring(0, 300) + "\u2026";
        new AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle("Mercy closed unexpectedly")
                .setMessage("The last session ended with an error. The log stays on your phone.\n\n"
                        + first)
                .setPositiveButton("Safe mode", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        prefs.edit().putBoolean("useWebView", true)
                                    .putBoolean("blockAds", false).apply();
                        CrashGuard.clear(MainActivity.this);
                        toast("Safe mode: system engine, no blocker. Restarting\u2026");
                        recreate();
                    }
                })
                .setNeutralButton("View log", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { showDiagnostics(); }
                })
                .setNegativeButton("Dismiss", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { CrashGuard.clear(MainActivity.this); }
                })
                .show();
    }

    private MainActivity MercyProActivity() { return this; }

    private void showDiagnostics() {
        String log = CrashGuard.read(this);
        new AlertDialog.Builder(this)
                .setTitle("Diagnostics")
                .setMessage("Crashes recorded: " + CrashGuard.count(this) + "\n\n" + log)
                .setPositiveButton("Close", null)
                .setNeutralButton("Clear log", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        CrashGuard.clear(MainActivity.this);
                        toast("Log cleared");
                    }
                })
                .show();
    }


    /* =========================================================
       Tor via Orbot — GeckoView has no proxy API, so we hand it a
       config file carrying the SOCKS preferences.
    ========================================================= */
    private String writeTorConfig() {
        try {
            java.io.File f = new java.io.File(getFilesDir(), "gecko-tor.yaml");
            String yaml = "prefs:\n"
                    + "  network.proxy.type: 1\n"
                    + "  network.proxy.socks: \"127.0.0.1\"\n"
                    + "  network.proxy.socks_port: 9050\n"
                    + "  network.proxy.socks_remote_dns: true\n"
                    + "  network.proxy.allow_hijacking_localhost: true\n"
                    + "  network.trr.mode: 5\n";
            java.io.FileOutputStream out = new java.io.FileOutputStream(f, false);
            out.write(yaml.getBytes("UTF-8"));
            out.close();
            return f.getAbsolutePath();
        } catch (Exception e) { return null; }
    }

    private void toggleTor() {
        boolean on = !prefs.getBoolean("torMode", false);
        prefs.edit().putBoolean("torMode", on).apply();
        if (on) {
            new AlertDialog.Builder(this)
                    .setTitle("Tor via Orbot")
                    .setMessage("Orbot is required, running on port 9050.\n\n"
                            + "What this does: every page goes through the Tor network, "
                            + ".onion addresses open, and nothing else in the app makes a request.\n\n"
                            + "What it cannot do: make you anonymous if you log in, or hide "
                            + "traffic from other apps on this phone.\n\n"
                            + "Reopen the app for this to take effect.")
                    .setPositiveButton("Understood", null)
                    .show();
        } else {
            toast("Tor off — reopen the app");
        }
    }


    private void showDevPanel() {
        final String[] items = {"Custom user agent", "Block a host", "Data budget", "Clear custom rules"};
        new android.app.AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle("Dev panel")
                .setItems(items, new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int which) {
                        if (which == 0) askCustomUa();
                        else if (which == 1) askBlockHost();
                        else if (which == 2) askBudget();
                        else {
                            prefs.edit().remove("customBlock").remove("customUA").apply();
                            toast("Custom rules cleared");
                        }
                    }
                })
                .setNegativeButton("Close", null)
                .show();
    }

    private void askCustomUa() {
        final EditText in = new EditText(this);
        in.setText(prefs.getString("customUA", ""));
        in.setHint("leave empty for the default");
        in.setTextSize(12);
        new android.app.AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle("Custom user agent")
                .setView(in)
                .setPositiveButton("Save", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int w) {
                        prefs.edit().putString("customUA", in.getText().toString().trim()).apply();
                        toast("Saved \u2014 reload the page");
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void askBlockHost() {
        final EditText in = new EditText(this);
        in.setHint("ads.example.com");
        in.setTextSize(13);
        new android.app.AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle("Block a host")
                .setView(in)
                .setPositiveButton("Add", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int w) {
                        String h = in.getText().toString().trim().toLowerCase();
                        if (h.isEmpty()) return;
                        try {
                            org.json.JSONArray arr = new org.json.JSONArray(prefs.getString("customBlock", "[]"));
                            arr.put(h);
                            prefs.edit().putString("customBlock", arr.toString()).apply();
                            toast("Saved " + h);
                        } catch (Exception e) { note("onClick", e); }
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    /* =========================================================
       Library — your own things. A screen, not a dialog.
       Every row says how much is inside it.
    ========================================================= */
    private LinearLayout libList;
    private EditText libSearch;

    private void closeHome() {
        if (homeView != null) homeView.setVisibility(View.GONE);
        showGecko(true);
    }

    /* ---------- Library: saved · offline · notes · study ---------- */
    private Notes notes;
    private LinearLayout libraryBody;

    private int studyLeft = 0;
    private android.os.Handler studyHandler;

    private void openStudy() {
        closeLibrary();
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(surface());
        root.setPadding(dp(20), dp(26), dp(20), dp(24));

        TextView cap = sharpText("STUDY · 25 MINUTES", 9f, accent());
        cap.setLetterSpacing(0.2f);
        root.addView(cap);

        final TextView clock = new TextView(this);
        clock.setText("25:00");
        clock.setTextSize(52f);
        clock.setTextColor(ink());
        clock.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        clock.setPadding(0, dp(20), 0, 0);
        root.addView(clock);

        TextView note = sharpText("During study the blocker stays on and the page is kept text-first.", 10f, inkDim());
        note.setPadding(0, dp(10), 0, 0);
        root.addView(note);

        final TextView start = sharpText("START", 9.5f, onInk());
        start.setGravity(android.view.Gravity.CENTER);
        start.setBackgroundColor(ink());
        start.setPadding(0, dp(13), 0, dp(13));
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        slp.topMargin = dp(24);
        root.addView(start, slp);

        start.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (studyLeft > 0) { studyLeft = 0; clock.setText("25:00"); start.setText("START"); return; }
                studyLeft = 25 * 60;
                start.setText("STOP");
                if (studyHandler == null) studyHandler = new android.os.Handler(android.os.Looper.getMainLooper());
                studyHandler.post(new Runnable() {
                    @Override public void run() {
                        if (studyLeft <= 0) { clock.setText("DONE"); start.setText("START"); return; }
                        studyLeft--;
                        clock.setText(String.format(java.util.Locale.US, "%02d:%02d", studyLeft / 60, studyLeft % 60));
                        studyHandler.postDelayed(this, 1000);
                    }
                });
            }
        });

        View spacer = new View(this);
        root.addView(spacer, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        TextView back = sharpText("\u2190 Back to Library", 9f, inkDim());
        back.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { closeNotes(); openLibrary(); }
        });
        root.addView(back);

        notesOverlay = root;
        View headerBar = findViewById(R.id.header);
        int topPx = headerBar != null ? headerBar.getHeight() : dp(56);
        android.widget.FrameLayout.LayoutParams lp = new android.widget.FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        lp.topMargin = topPx;
        ((ViewGroup) findViewById(android.R.id.content)).addView(root, lp);
        root.setElevation(dp(14));
        showGecko(false);
    }

    private void openNotes() {
        if (notes == null) notes = new Notes(prefs);
        if (notes.locked() && !notesUnlocked) { askNotePin(); return; }
        closeLibraryPage();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(surface());

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(android.view.Gravity.CENTER_VERTICAL);
        top.setPadding(dp(14), dp(12), dp(14), dp(10));
        TextView back = sharpText("\u2190", 18f, ink());
        back.setPadding(dp(4), dp(4), dp(12), dp(4));
        back.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { closeNotes(); } });
        top.addView(back);
        top.addView(sharpText("NOTES \u00B7 ON THIS PHONE", 9f, accent()),
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView add = sharpText("+ NEW", 9f, ink());
        add.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { newNote(); } });
        top.addView(add);
        root.addView(top);
        root.addView(hairline());

        android.widget.ScrollView sv = new android.widget.ScrollView(this);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(14), dp(10), dp(14), dp(24));

        java.util.List<Notes.Note> all = notes.all();
        if (all.isEmpty()) {
            TextView empty = sharpText("No notes yet. They stay on this phone \u2014 no server, no sync, works in aeroplane mode.", 10f, inkDim());
            empty.setLineSpacing(dp(4), 1f);
            empty.setPadding(0, dp(14), 0, 0);
            list.addView(empty);
        }
        for (final Notes.Note n : all) {
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setBackgroundColor(panel());
            card.setPadding(dp(14), dp(12), dp(14), dp(12));
            card.setLayoutParams(new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            ((LinearLayout.LayoutParams) card.getLayoutParams()).bottomMargin = dp(8);

            card.addView(sharpText(n.title, 12f, ink()));
            TextView body = sharpText(n.body.length() > 120 ? n.body.substring(0, 120) + "\u2026" : n.body, 10f, inkDim());
            body.setPadding(0, dp(6), 0, 0);
            card.addView(body);
            card.addView(sharpText(n.at, 8f, inkDim()));

            card.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { editNote(n); }
            });
            card.setOnLongClickListener(new android.view.View.OnLongClickListener() {
                @Override public boolean onLongClick(View v) {
                    notes.delete(n.id);
                    toast("Note deleted");
                    closeNotes(); openNotes();
                    return true;
                }
            });
            list.addView(card);
        }
        sv.addView(list);
        root.addView(sv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        notesOverlay = root;
        View headerBar = findViewById(R.id.header);
        int topPx = headerBar != null ? headerBar.getHeight() : dp(56);
        android.widget.FrameLayout.LayoutParams lp = new android.widget.FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        lp.topMargin = topPx;
        ((ViewGroup) findViewById(android.R.id.content)).addView(root, lp);
        root.setElevation(dp(14));
        showGecko(false);
    }

    private View notesOverlay;
    private boolean notesUnlocked = false;

    private void closeNotes() {
        if (notesOverlay != null) {
            try { ((ViewGroup) notesOverlay.getParent()).removeView(notesOverlay); } catch (Exception e) { note("closeNotes", e); }
            notesOverlay = null;
        }
        if (searchOverlay == null && settingsOverlay == null && errorOverlay == null) showGecko(true);
    }

    private void askNotePin() {
        final EditText pin = new EditText(this);
        pin.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        pin.setHint("PIN");
        new android.app.AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle("Notes are locked")
                .setView(pin)
                .setPositiveButton("Unlock", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        if (notes == null) notes = new Notes(prefs);
                        if (notes.checkPin(pin.getText().toString())) {
                            notesUnlocked = true;
                            openNotes();
                        } else toast("Wrong PIN");
                    }
                })
                .setNeutralButton("Set a PIN", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { setNotePin(); }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void setNotePin() {
        final EditText pin = new EditText(this);
        pin.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        pin.setHint("4+ digits");
        new android.app.AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle("Lock notes with a PIN")
                .setMessage("The PIN never leaves the phone. If you forget it, the notes cannot be read.")
                .setView(pin)
                .setPositiveButton("Lock", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        String v = pin.getText().toString().trim();
                        if (v.length() < 4) { toast("Use at least 4 digits"); return; }
                        if (notes == null) notes = new Notes(prefs);
                        notes.setPin(v);
                        notesUnlocked = true;
                        toast("Notes locked");
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void newNote() {
        if (notes == null) notes = new Notes(prefs);
        final EditText title = new EditText(this);
        title.setHint("Title");
        final EditText body = new EditText(this);
        body.setHint("Write anything \u2014 stays on this phone");
        body.setMinLines(6);
        body.setGravity(android.view.Gravity.TOP);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14), dp(6), dp(14), dp(6));
        box.addView(title);
        box.addView(body);
        new android.app.AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle("New note")
                .setView(box)
                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        notes.add(title.getText().toString(), body.getText().toString());
                        closeNotes(); openNotes();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void editNote(final Notes.Note n) {
        final EditText title = new EditText(this);
        title.setText(n.title);
        final EditText body = new EditText(this);
        body.setText(n.body);
        body.setMinLines(6);
        body.setGravity(android.view.Gravity.TOP);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14), dp(6), dp(14), dp(6));
        box.addView(title);
        box.addView(body);
        new android.app.AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle("Edit note")
                .setView(box)
                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        notes.delete(n.id);
                        notes.add(title.getText().toString(), body.getText().toString());
                        closeNotes(); openNotes();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void closeLibrary() { closeLibraryPage(); }

    private View libraryPage;
    private void closeLibraryPage() {
        if (libraryPage != null) {
            try { ((ViewGroup) libraryPage.getParent()).removeView(libraryPage); } catch (Exception e) { note("closeLib", e); }
            libraryPage = null;
        }
    }

    private void openLibrary() {
        closeMenu();
        showGecko(false);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(surface());

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(android.view.Gravity.CENTER_VERTICAL);
        head.setPadding(dp(18), dp(18), dp(12), dp(8));

        TextView title = new TextView(this);
        title.setText(lang.t("library"));
        title.setTextSize(20f);
        title.setTextColor(ink());
        head.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView close = new TextView(this);
        close.setText("\u2715");
        close.setTextSize(16f);
        close.setTextColor(inkDim());
        close.setPadding(dp(12), dp(4), dp(4), dp(4));
        close.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { closeMenu(); }
        });
        head.addView(close);
        root.addView(head);

        libSearch = new EditText(this);
        libSearch.setHint("Search your library");
        libSearch.setTextSize(12f);
        libSearch.setTextColor(ink());
        libSearch.setHintTextColor(inkDim());
        libSearch.setBackgroundColor(lightTheme() ? panel() : panel());
        libSearch.setPadding(dp(12), dp(9), dp(12), dp(9));
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        slp.leftMargin = dp(16); slp.rightMargin = dp(16); slp.bottomMargin = dp(10);
        root.addView(libSearch, slp);

        android.widget.ScrollView sv = new android.widget.ScrollView(this);
        libList = new LinearLayout(this);
        libList.setOrientation(LinearLayout.VERTICAL);
        sv.addView(libList);
        root.addView(sv, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        TextView foot = new TextView(this);
        foot.setText(lang.t("nothing_leaves"));
        foot.setTextSize(9f);
        foot.setTextColor(inkDim());
        foot.setGravity(android.view.Gravity.CENTER);
        foot.setPadding(0, dp(10), 0, dp(18));
        root.addView(foot);

        ViewGroup menuHost = findViewById(android.R.id.content);
        if (menuHost == null) return;
        menuOverlay = root;
        menuHost.addView(root, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        libSearch.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(android.text.Editable e) { paintLibrary(e.toString()); }
        });
        paintLibrary("");
    }

    private void paintLibrary(String filter) {
        if (libList == null) return;
        libList.removeAllViews();
        String q = filter == null ? "" : filter.trim().toLowerCase();

        java.util.List<MItem> rows = new java.util.ArrayList<>();
        rows.add(mi("\u25F7", "Open tabs", String.valueOf(tabs.size()),
                new Runnable() { public void run() { closeMenu(); showTabs(); } }));
        
        rows.add(mi("\u24D8", "Scan QR code", "", new Runnable() { public void run() { closeMenu(); scanQrCode(); } }));
        rows.add(mi("\u2193", "Save page offline", String.valueOf(readArray("offline").length()) + " saved",
                new Runnable() { public void run() { closeMenu(); savePageOffline(); } }));
        rows.add(mi("\u24D8", "Offline pages", String.valueOf(readArray("offline").length()),
                new Runnable() { public void run() { closeMenu(); showOfflinePages(); } }));
        
        rows.add(mi("\u25A6", "Data ledger", human(todayBytes()),
                new Runnable() { public void run() { closeMenu(); showLedger(); } }));
        rows.add(mi("\u25CD", "Report card", "this week",
                new Runnable() { public void run() { closeMenu(); showReportCard(); } }));

        boolean any = false;
        for (final MItem it : rows) {
            if (!q.isEmpty() && !it.label.toLowerCase().contains(q)) continue;
            any = true;
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(android.view.Gravity.CENTER_VERTICAL);
            row.setPadding(dp(18), dp(15), dp(18), dp(15));

            MercyIcon g = new MercyIcon(this).icon(it.glyph).tint(accent());
            LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(dp(20), dp(20));
            ilp.rightMargin = dp(14);
            row.addView(g, ilp);

            TextView l = new TextView(this);
            l.setText(it.label);
            l.setTextSize(13f * fontScale());
            l.setTextColor(ink());
            row.addView(l, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            TextView v = new TextView(this);
            v.setText(it.value);
            v.setTextSize(10f);
            v.setTextColor(inkDim());
            row.addView(v);

            TextView chev = new TextView(this);
            chev.setText(" \u203A");
            chev.setTextSize(13f);
            chev.setTextColor(inkDim());
            row.addView(chev);

            row.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View view) {
                    new android.os.Handler(getMainLooper()).postDelayed(it.action, 60);
                }
            });
            libList.addView(row);

            View line = new View(this);
            line.setBackgroundColor(lightTheme() ? 0x14000000 : 0x14FFFFFF);
            libList.addView(line, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1));
        }

        if (!any) {
            TextView empty = new TextView(this);
            empty.setText("Nothing matches \"" + filter + "\"");
            empty.setTextSize(11f);
            empty.setTextColor(inkDim());
            empty.setPadding(dp(18), dp(24), dp(18), dp(24));
            libList.addView(empty);
        }
    }



    /* =========================================================
       Console — JavaScript against the page you are on.
       Not a shell, not a terminal, and it says so.
    ========================================================= */


    /* =========================================================
       panic wipe — three locks, because this cannot be undone
       1. hold the button for 3 seconds   2. type ERASE   3. confirm
    ========================================================= */
    private void startPanicSequence() {
        final android.app.AlertDialog d = new android.app.AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle(lang.t("wipe_title"))
                .setMessage("This deletes history, bookmarks, offline pages, cookies, the ledger and every setting.\n\n"
                        + "Hold the bar below for three seconds to continue.")
                .setNegativeButton("Cancel", null)
                .create();

        final LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), dp(8));

        final TextView bar = new TextView(this);
        bar.setText("HOLD TO CONTINUE");
        bar.setTextSize(11f);
        bar.setGravity(android.view.Gravity.CENTER);
        bar.setTextColor(danger());
        bar.setPadding(0, dp(16), 0, dp(16));
        bar.setBackgroundColor(panel());
        box.addView(bar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        d.setView(box);

        final boolean[] done = {false};
        final android.os.Handler h = new android.os.Handler(getMainLooper());
        final Runnable reset = new Runnable() {
            @Override public void run() {
                if (!done[0]) { bar.setText("HOLD TO CONTINUE"); bar.setBackgroundColor(panel()); }
            }
        };
        bar.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, android.view.MotionEvent e) {
                if (e.getAction() == android.view.MotionEvent.ACTION_DOWN) {
                    bar.setText("KEEP HOLDING…");
                    bar.setBackgroundColor(panel());
                    h.postDelayed(new Runnable() {
                        @Override public void run() {
                            if (done[0]) return;
                            done[0] = true;
                            d.dismiss();
                            askEraseWord();
                        }
                    }, 3000);
                } else if (e.getAction() == android.view.MotionEvent.ACTION_UP
                        || e.getAction() == android.view.MotionEvent.ACTION_CANCEL) {
                    h.removeCallbacksAndMessages(null);
                    h.post(reset);
                }
                return true;
            }
        });
        d.show();
    }

    private void askEraseWord() {
        final EditText in = new EditText(this);
        in.setHint("type ERASE");
        in.setInputType(android.text.InputType.TYPE_CLASS_TEXT
                | android.text.InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        new android.app.AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle("Type ERASE to confirm")
                .setView(in)
                .setPositiveButton("Erase", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        if (!"ERASE".equals(in.getText().toString().trim().toUpperCase())) {
                            toast("Nothing erased \u2014 the word did not match");
                            return;
                        }
                        panicWipe();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }




    /** erases everything this app ever stored, then starts clean */
    /* Three locks. A browser that can lose your data on one stray tap is worse
       than no browser at all. */
    private void panicWipe() {
        final EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setHint(lang.t("type_erase"));
        input.setTextSize(13f);
        input.setTypeface(android.graphics.Typeface.MONOSPACE);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(8), dp(16), dp(8));
        TextView warn = sharpText(lang.t("wipe_body"),
                9.5f, inkDim());
        warn.setLineSpacing(dp(3), 1f);
        box.addView(warn);
        LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        ilp.topMargin = dp(12);
        box.addView(input, ilp);

        new android.app.AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle(lang.t("wipe_title"))
                .setView(box)
                .setPositiveButton("Next", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        if (!"ERASE".equals(input.getText().toString().trim())) {
                            toast("Type ERASE exactly \u2014 nothing was deleted");
                            return;
                        }
                        holdToErase();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void holdToErase() {
        final TextView hold = sharpText("HOLD 3 SECONDS", 11f, danger());
        hold.setGravity(android.view.Gravity.CENTER);
        hold.setPadding(0, dp(30), 0, dp(30));

        final android.app.AlertDialog dialog = new android.app.AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle("Last step").setView(hold).setNegativeButton("Cancel", null).create();

        final android.os.Handler h = new android.os.Handler(android.os.Looper.getMainLooper());
        final Runnable[] tick = new Runnable[1];
        hold.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, android.view.MotionEvent e) {
                if (e.getAction() == android.view.MotionEvent.ACTION_DOWN) {
                    final long until = System.currentTimeMillis() + 3000;
                    tick[0] = new Runnable() {
                        @Override public void run() {
                            long left = until - System.currentTimeMillis();
                            if (left <= 0) { dialog.dismiss(); doWipe(); return; }
                            hold.setText("HOLD \u2014 " + (left / 1000 + 1));
                            h.postDelayed(this, 100);
                        }
                    };
                    h.post(tick[0]);
                    return true;
                }
                if (e.getAction() == android.view.MotionEvent.ACTION_UP
                        || e.getAction() == android.view.MotionEvent.ACTION_CANCEL) {
                    if (tick[0] != null) h.removeCallbacks(tick[0]);
                    hold.setText("HOLD 3 SECONDS");
                }
                return true;
            }
        });
        dialog.show();
    }

    /** the only place that erases */
    private void doWipe() {
        try {
            prefs.edit().clear().apply();
            if (webEngine != null) {
                webEngine.clearHistory(); webEngine.clearCache(true);
                android.webkit.CookieManager cm = android.webkit.CookieManager.getInstance();
                if (cm != null) cm.removeAllCookies(null);
            }
            for (Tab t : tabs) {
                try { if (t.session != null) t.session.close(); } catch (Exception e) { note("doWipe", e); }
            }
            tabs.clear();
            if (blocker != null) blocker = new Blocker(this, true);
            newTab(HOME);
            toast("Everything erased");
        } catch (Exception e) { toast("Wipe failed: " + e.getClass().getSimpleName()); }
    }


    /* =========================================================
       native home — GeckoView cannot push values into a page,
       so the home is real Android views fed by Java.
    ========================================================= */
    private LinearLayout homeView;
    private TextView homeUsed, homeCost, homeSpent, homeBlocked, homeOffline, homeTop, homeContinue;

    private View buildHomeView() {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);
        v.setBackgroundColor(surface());
        v.setPadding(dp(18), dp(20), dp(18), dp(18));

        TextView mark = new TextView(this);
        mark.setText("M  MERCY GX");
        mark.setTextSize(9f);
        mark.setLetterSpacing(0.2f);
        mark.setTextColor(inkDim());
        v.addView(mark);

        TextView greet = new TextView(this);
        greet.setText(lang.t("your_data_money"));
        greet.setTextSize(19f);
        greet.setTextColor(ink());
        greet.setPadding(0, dp(14), 0, dp(16));
        v.addView(greet);

        TextView cap1 = new TextView(this);
        cap1.setText("CONTINUE");
        cap1.setTextSize(8.5f);
        cap1.setLetterSpacing(0.16f);
        cap1.setTextColor(inkDim());
        v.addView(cap1);

        homeContinue = new TextView(this);
        homeContinue.setTextSize(11.5f);
        homeContinue.setTextColor(ink());
        homeContinue.setPadding(dp(14), dp(14), dp(14), dp(14));
        homeContinue.setBackgroundColor(panel());
        homeContinue.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                String last = prefs.getString("lastUrl", "");
                if (last.isEmpty()) { openSearchScreen(); return; }
                closeHome();
                engineLoad(last);                     /* really resumes, not decoration */
            }
        });
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        clp.topMargin = dp(6);
        v.addView(homeContinue, clp);

        TextView cap2 = new TextView(this);
        cap2.setText("TODAY");
        cap2.setTextSize(8.5f);
        cap2.setLetterSpacing(0.16f);
        cap2.setTextColor(inkDim());
        cap2.setPadding(0, dp(18), 0, dp(6));
        v.addView(cap2);

        LinearLayout budgetRow = new LinearLayout(this);
        budgetRow.setOrientation(LinearLayout.HORIZONTAL);
        budgetRow.setGravity(android.view.Gravity.CENTER_VERTICAL);

        BudgetRing r = new BudgetRing(this);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(dp(58), dp(58));
        rlp.rightMargin = dp(14);
        budgetRow.addView(r, rlp);

        LinearLayout nums = new LinearLayout(this);
        nums.setOrientation(LinearLayout.VERTICAL);
        homeUsed = new TextView(this);
        /* painted by paintHome() */
        homeUsed.setTextSize(21f);
        homeUsed.setTextColor(ink());
        nums.addView(homeUsed);
        homeCost = new TextView(this);
        /* painted by paintHome() */
        homeCost.setTextSize(10f);
        homeCost.setTextColor(inkDim());
        homeCost.setPadding(0, dp(3), 0, 0);
        nums.addView(homeCost);
        budgetRow.addView(nums);
        v.addView(budgetRow);

        LinearLayout stats = new LinearLayout(this);
        stats.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        slp.topMargin = dp(16);
        v.addView(stats, slp);

        homeSpent = addStat(stats, "₹0.00", "spent today", accent());
        homeBlocked = addStat(stats, "0", "trackers", lightTheme() ? accent() : accent());
        v.addView(new View(this), new LinearLayout.LayoutParams(0, dp(6)));
        LinearLayout stats2 = new LinearLayout(this);
        stats2.setOrientation(LinearLayout.HORIZONTAL);
        v.addView(stats2);
        homeOffline = addStat(stats2, "0", "pages offline", inkDim());
        homeTop = addStat(stats2, "—", "heaviest site", inkDim());

        TextView foot = new TextView(this);
        foot.setText(lang.t("nothing_leaves"));
        foot.setTextSize(9f);
        foot.setTextColor(inkDim());
        foot.setGravity(android.view.Gravity.CENTER);
        foot.setPadding(0, dp(22), 0, 0);
        v.addView(foot);

        return v;
    }

    private TextView addStat(LinearLayout parent, String value, String label, int colour) {
        LinearLayout cell = new LinearLayout(this);
        cell.setOrientation(LinearLayout.VERTICAL);
        cell.setPadding(dp(12), dp(12), dp(12), dp(12));
        cell.setBackgroundColor(lightTheme() ? panel() : panel());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.rightMargin = dp(8);

        TextView v = new TextView(this);
        v.setText(value);
        v.setTextSize(15f);
        v.setTextColor(colour);
        cell.addView(v);

        TextView k = new TextView(this);
        k.setText(label);
        k.setTextSize(9f);
        k.setTextColor(inkDim());
        k.setPadding(0, dp(2), 0, 0);
        cell.addView(k);

        parent.addView(cell, lp);
        return v;
    }

    /** refresh the numbers from the ledger — called whenever the home is shown */
    private void paintHome() {
        if (homeView == null) return;
        long today = todayBytes();
        long budget = budgetBytes();
        int pct = (int) Math.min(100, budget == 0 ? 0 : today * 100 / budget);
        /* painted by paintHome() */
        /* painted by paintHome() */
        /* painted by paintHome() */
        homeSpent.setTextColor(today > budget ? danger() : (pct >= 60 ? warn() : accent()));
        /* painted by paintHome() */
        /* painted by paintHome() */
        String last = prefs.getString("lastHost", "");
        /* painted by paintHome() */
        String top = heaviestHost();
        /* painted by paintHome() */
        homeView.setBackgroundColor(surface());
    }

    private String heaviestHost() {
        String best = null; long most = -1;
        try {
            org.json.JSONObject ledger = new org.json.JSONObject(prefs.getString("ledger", "{}"));
            java.util.Iterator<String> it = ledger.keys();
            while (it.hasNext()) {
                String h = it.next();
                long b = ledger.optJSONObject(h) == null ? 0 : ledger.optJSONObject(h).optLong("bytes", 0);
                if (b > most) { most = b; best = h; }
            }
        } catch (Exception e) { note("heaviestHost", e); }
        return most <= 0 ? null : best;
    }


    /* =========================================================
       Mercy Core — the extension that ships inside the browser.
       It is installed from the APK, never from a store, and it is
       the only way this app can look inside a page.
    ========================================================= */
    private org.mozilla.geckoview.WebExtension mercyExt;
    private String lastFacts = "";

    private void installMercyExtension(org.mozilla.geckoview.GeckoRuntime rt) {
        try {
            org.mozilla.geckoview.WebExtensionController c = rt.getWebExtensionController();
            if (c == null) { prefs.edit().putString("extStatus", "no controller").apply(); return; }
            org.mozilla.geckoview.GeckoResult<org.mozilla.geckoview.WebExtension> pending = null;
            try {
                java.lang.reflect.Method builtIn = c.getClass()
                        .getMethod("installBuiltIn", String.class);
                pending = (org.mozilla.geckoview.GeckoResult<org.mozilla.geckoview.WebExtension>)
                        builtIn.invoke(c, "resource://android/assets/extensions/mercy/");
            } catch (Exception e) { note("installMercyExtension", e); }
            (pending != null ? pending : c.install("resource://android/assets/extensions/mercy/"))
                    .accept(new org.mozilla.geckoview.GeckoResult.Consumer<org.mozilla.geckoview.WebExtension>() {
                        @Override public void accept(org.mozilla.geckoview.WebExtension ext) {
                            mercyExt = ext;
                            prefs.edit().putString("extStatus", "installed " + ext.id).apply();
                            try {
                                org.mozilla.geckoview.WebExtension.MessageDelegate del =
                                        new org.mozilla.geckoview.WebExtension.MessageDelegate() {
                                    @Override public org.mozilla.geckoview.GeckoResult<Object> onMessage(
                                            String nativeApp, Object message, org.mozilla.geckoview.WebExtension.MessageSender sender) {
                                        lastFacts = String.valueOf(message);
                                        prefs.edit().putString("extLastFacts", lastFacts).apply();
                                        return null;
                                    }
                                };
                                mercyExt.setMessageDelegate(del, "browser");
                            } catch (Exception e) { note("onMessage", e); }
                        }
                    }, new org.mozilla.geckoview.GeckoResult.Consumer<Throwable>() {
                        @Override public void accept(Throwable error) {
                            String why = error == null ? "unknown"
                                    : error.getClass().getSimpleName()
                                      + (error.getMessage() == null ? "" : ": " + error.getMessage());
                            prefs.edit().putString("extStatus", "failed: " + why).apply();
                        }
                    });
        } catch (Throwable t) {
            prefs.edit().putString("extStatus", "unsupported: " + t.getClass().getSimpleName()
                    + (t.getMessage() == null ? "" : ": " + t.getMessage())).apply();
        }
    }

    /** what the extension last told us about this page */
    private void showPageFacts() {
        String status = prefs.getString("extStatus", "not installed");
        String facts = prefs.getString("extLastFacts", "");
        StringBuilder sb = new StringBuilder();
        sb.append("extension   ").append(status).append("\n\n");
        if (facts.isEmpty()) {
            sb.append("No page facts yet.\n");
            sb.append("Open a page, then come back.");
        } else {
            sb.append(facts);
        }
        showText("What this page contains", sb.toString());
    }


    private void showText(String title, String body) {
        android.widget.ScrollView sv = new android.widget.ScrollView(this);
        TextView tv = new TextView(this);
        tv.setText(body == null || body.isEmpty() ? "(empty)" : body);
        tv.setTextSize(11f);
        tv.setTypeface(android.graphics.Typeface.MONOSPACE);
        tv.setTextColor(ink());
        tv.setPadding(dp(14), dp(12), dp(14), dp(12));
        sv.addView(tv);
        new android.app.AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle(title)
                .setView(sv)
                .setPositiveButton("Close", null)
                .show();
    }


    /* =========================================================
       the features Pro can honestly have — no engine tricks
    ========================================================= */

    private void sharePage() {
        if (active == null || active.url == null) { toast("Open a page first"); return; }
        try {
            android.content.Intent i = new android.content.Intent(android.content.Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(android.content.Intent.EXTRA_TEXT, active.url);
            startActivity(android.content.Intent.createChooser(i, "Share page"));
        } catch (Exception e) { toast("Nothing to share"); }
    }

    /** suspends every background session — real memory back, nothing lost */
    private void freeMemory() {
        int paused = 0;
        for (Tab t : tabs) {
            if (t != active && t.session != null) {
                try { t.session.setActive(false); paused++; } catch (Exception e) { note("freeMemory", e); }
            }
        }
        toast(paused == 0 ? "Nothing to free \u2014 no background tabs" : "Paused " + paused + " background tab(s)");
    }

    private void toggleBookmark() {
        if (active == null || active.url == null) return;
        try {
            org.json.JSONArray arr = readArray("bookmarks");
            org.json.JSONArray out = new org.json.JSONArray();
            boolean removed = false;
            for (int i = 0; i < arr.length(); i++) {
                org.json.JSONObject o = arr.optJSONObject(i);
                if (o != null && active.url.equals(o.optString("url", ""))) { removed = true; continue; }
                out.put(o);
            }
            if (!removed) {
                org.json.JSONObject o = new org.json.JSONObject();
                o.put("url", active.url);
                o.put("title", active.title == null ? hostOf(active.url) : active.title);
                out.put(o);
            }
            prefs.edit().putString("bookmarks", out.toString()).apply();
            toast(removed ? "Bookmark removed" : "Bookmarked");
        } catch (Exception e) { toast("Could not save the bookmark"); }
    }

    private void showBookmarks() {
        try {
            org.json.JSONArray arr = readArray("bookmarks");
            if (arr.length() == 0) { toast("No bookmarks yet"); return; }
            final java.util.List<String> urls = new java.util.ArrayList<>();
            String[] labels = new String[arr.length()];
            for (int i = 0; i < arr.length(); i++) {
                org.json.JSONObject o = arr.optJSONObject(i);
                String t = o == null ? "" : o.optString("title", "");
                String u = o == null ? "" : o.optString("url", "");
                labels[i] = (t == null || t.isEmpty() ? hostOf(u) : t);
                urls.add(u);
            }
            new android.app.AlertDialog.Builder(this, R.style.MercyDialog)
                    .setTitle("Bookmarks")
                    .setItems(labels, new android.content.DialogInterface.OnClickListener() {
                        @Override public void onClick(android.content.DialogInterface d, int which) {
                            String u = urls.get(which);
                            if (active != null && u != null) engineLoad(u);
                        }
                    })
                    .setNegativeButton("Close", null)
                    .show();
        } catch (Exception e) { toast("Could not read bookmarks"); }
    }

    /** honest health report: what this build is, and what it can actually do */
    private void runSelfTest() {
        StringBuilder sb = new StringBuilder();
        sb.append("version      ").append(versionName()).append("\n");
        sb.append("package      ").append(getPackageName()).append("\n");
        sb.append("engine       GeckoView\n");
        sb.append("extension    ").append(prefs.getString("extStatus", "not installed")).append("\n");
        sb.append("tabs         ").append(tabs.size()).append("\n");
        sb.append("budget       ").append(prefs.getLong("budgetMb", 200L)).append(" MB\n");
        sb.append("theme        ").append(prefs.getString("bg", "black"))
          .append(" / ").append(prefs.getString("accent", "#a06bff")).append("\n");
        sb.append("tor          ").append(prefs.getBoolean("torMode", false) ? "on" : "off").append("\n");
        sb.append("offline voice ").append(offlineVoice != null && offlineVoice.isReady() ? "ready" : "not downloaded").append("\n\n");
        sb.append("What to check on screen:\n");
        sb.append("\u2022 the header shows the engine chip on a new tab\n");
        sb.append("\u2022 typing shows suggestions, Enter opens a page\n");
        sb.append("\u2022 the menu opens from the three dots\n");
        sb.append("\u2022 Library opens from the bottom bar\n");
        showText("Self test", sb.toString());
    }

    /** what we can prove about this build, and what we cannot */
    private void showProof() {
        StringBuilder sb = new StringBuilder();
        sb.append("PACKAGE\n");
        sb.append("  ").append(getPackageName()).append("\n");
        sb.append("  version ").append(versionName()).append("\n\n");
        sb.append("SIGNATURE\n  ");
        sb.append(signerFingerprint()).append("\n\n");
        sb.append("ENGINE\n  GeckoView, pinned at build time\n");
        sb.append("  extension: ").append(prefs.getString("extStatus", "not installed")).append("\n\n");
        sb.append("NETWORK\n");
        sb.append("  no telemetry, no analytics, no crash reporter\n");
        sb.append("  the only requests this app makes by itself:\n");
        sb.append("    \u2022 an update check when you ask for one\n");
        sb.append("    \u2022 DuckDuckGo suggestions while you type\n\n");
        sb.append("WHAT THIS SCREEN CANNOT PROVE\n");
        sb.append("  it cannot prove the absence of code; it lists what is here.\n");
        showText("Privacy proof", sb.toString());
    }

    private String signerFingerprint() {
        try {
            android.content.pm.PackageInfo pi = getPackageManager()
                    .getPackageInfo(getPackageName(), android.content.pm.PackageManager.GET_SIGNATURES);
            android.content.pm.Signature[] sigs = pi.signatures;
            if (sigs == null || sigs.length == 0) return "unknown";
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("SHA-256");
            byte[] d = md.digest(sigs[0].toByteArray());
            StringBuilder hex = new StringBuilder();
            for (int i = 0; i < 12 && i < d.length; i++) hex.append(String.format("%02x", d[i]));
            return hex + "\u2026";
        } catch (Exception e) { return "unavailable"; }
    }

    private String versionName() {
        try { return getPackageManager().getPackageInfo(getPackageName(), 0).versionName; }
        catch (Exception e) { return "?"; }
    }


    /* =========================================================
       Console — the extension runs the code, the app only asks.
       Every engine call goes through reflection so a signature
       change can never crash the browser; it reports instead.
    ========================================================= */
    private void openConsole() {
        if (active == null) { toast("Open a page first"); return; }
        if (mercyExt == null) {
            toast("Console needs the Mercy Core extension, which is not installed on this build");
            return;
        }

        final EditText code = new EditText(this);
        code.setHint("document.title");
        code.setTextSize(12f);
        code.setTypeface(android.graphics.Typeface.MONOSPACE);
        code.setMinLines(3);
        code.setText(prefs.getString("lastSnippet", ""));

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(8), dp(16), dp(8));
        box.addView(code);

        TextView note = new TextView(this);
        note.setText("Runs in this page through Mercy Core. No files, no system.");
        note.setTextSize(9f);
        note.setTextColor(inkDim());
        note.setPadding(0, dp(8), 0, 0);
        box.addView(note);

        new android.app.AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle("Console")
                .setView(box)
                .setPositiveButton("Run", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int w) {
                        String js = code.getText().toString().trim();
                        if (js.isEmpty()) return;
                        prefs.edit().putString("lastSnippet", js).apply();
                        askExtensionToEval(js);
                    }
                })
                .setNegativeButton("Close", null)
                .show();
    }

    /** ask the content script to eval, without assuming the engine API shape */
    private void askExtensionToEval(String js) {
        try {
            org.json.JSONObject msg = new org.json.JSONObject();
            msg.put("type", "eval");
            msg.put("code", js);

            Object controller = runtime == null ? null : runtime.getWebExtensionController();
            if (controller == null) { toast("Engine has no extension controller"); return; }

            Object result = null;
            String lastError = null;
            java.lang.reflect.Method[] candidates = controller.getClass().getMethods();
            for (java.lang.reflect.Method m : candidates) {
                if (!"sendMessage".equals(m.getName())) continue;
                Class<?>[] t = m.getParameterTypes();
                try {
                    if (t.length == 3 && t[0].isInstance(mercyExt)) {
                        result = m.invoke(controller, mercyExt, msg, active.session);
                    } else if (t.length == 2 && t[0].isInstance(mercyExt)) {
                        result = m.invoke(controller, mercyExt, msg);
                    } else {
                        continue;
                    }
                    break;
                } catch (Throwable e) {
                    lastError = e.getClass().getSimpleName();
                }
            }
            if (result == null) {
                toast("Engine refused the console" + (lastError == null ? "" : ": " + lastError));
                return;
            }
            attachResult(result);
        } catch (Throwable t) {
            toast("Console unavailable: " + t.getClass().getSimpleName());
        }
    }

    /** the engine answers with a GeckoResult; read it the same defensive way */
    private void attachResult(Object geckoResult) {
        try {
            java.lang.reflect.Method accept = null;
            for (java.lang.reflect.Method m : geckoResult.getClass().getMethods()) {
                if ("accept".equals(m.getName()) && m.getParameterTypes().length == 1) { accept = m; break; }
            }
            if (accept == null) { toast("Console sent; no result hook"); return; }
            Class<?> consumerType = accept.getParameterTypes()[0];
            Object consumer = java.lang.reflect.Proxy.newProxyInstance(
                    consumerType.getClassLoader(), new Class<?>[]{consumerType},
                    new java.lang.reflect.InvocationHandler() {
                        @Override public Object invoke(Object proxy, java.lang.reflect.Method m, Object[] args) {
                            if (args != null && args.length == 1) {
                                String text = String.valueOf(args[0]);
                                runOnUiThread(new Runnable() {
                                    @Override public void run() { }
                                });
                                prefs.edit().putString("lastConsoleResult", text).apply();
                                runOnUiThread(new Runnable() {
                                    @Override public void run() { showText("Console result", text); }
                                });
                            }
                            return null;
                        }
                    });
            accept.invoke(geckoResult, consumer);
        } catch (Throwable t) {
            toast("Console result unreadable: " + t.getClass().getSimpleName());
        }
    }

    private void showLedger() {
        try {
            org.json.JSONObject all = new org.json.JSONObject(prefs.getString("ledger", "{}"));
            if (all.length() == 0) { toast("No pages recorded yet"); return; }
            java.util.List<String> hosts = new java.util.ArrayList<>();
            for (java.util.Iterator<String> it = all.keys(); it.hasNext(); ) hosts.add(it.next());
            final long[] bytes = new long[hosts.size()];
            java.util.List<Integer> order = new java.util.ArrayList<>();
            for (int i = 0; i < hosts.size(); i++) {
                bytes[i] = all.optJSONObject(hosts.get(i)).optLong("bytes");
                order.add(i);
            }
            java.util.Collections.sort(order, new java.util.Comparator<Integer>() {
                @Override public int compare(Integer a, Integer b) { return Long.compare(bytes[b], bytes[a]); }
            });
            long tb = 0, tm = 0;
            StringBuilder sb = new StringBuilder();
            int shown = 0;
            for (int k = 0; k < order.size(); k++) {
                int i = order.get(k);
                org.json.JSONObject row = all.optJSONObject(hosts.get(i));
                long b = row.optLong("bytes"), m = row.optLong("ms"), v = row.optLong("visits");
                tb += b; tm += m;
                if (shown++ < 12) {
                    sb.append(hosts.get(i)).append("\n   ").append(human(b)).append(" · ")
                      .append(money(b)).append(" · ").append(humanTime(m))
                      .append(" · ").append(v).append(" visits\n\n");
                }
            }
            String header = "Total " + human(tb) + "  ·  " + money(tb) + "\n" + humanTime(tm)
                    + " browsing\n\nTariff: \u20B9" + tariffPerMb() + " per MB\n"
                    + "————————————————\n\n";
            new AlertDialog.Builder(this)
                    .setTitle("Data ledger")
                    .setMessage(header + sb.toString().trim())
                    .setPositiveButton("Close", null)
                    .setNeutralButton("Set tariff", new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface d, int w) { askTariff(); }
                    })
                    .show();
        } catch (Exception e) { toast("Ledger unavailable"); }
    }


    /* =========================================================
       offline voice — Vosk, on the phone, no Google involved
    ========================================================= */
    private void startOfflineVoice() {
        boolean granted = Build.VERSION.SDK_INT < 23
                || checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
        if (!granted) {
            pendingVoice = true;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
            return;
        }
        if (!offlineVoice.isReady()) { askVoiceModel(); return; }

        final AlertDialog[] box = new AlertDialog[1];
        box[0] = new AlertDialog.Builder(this)
                .setTitle("Offline voice")
                .setMessage("Listening…")
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { offlineVoice.stop(); }
                })
                .show();

        offlineVoice.start(new OfflineVoice.Callback() {
            @Override public void onStatus(String text) { if (box[0].isShowing()) box[0].setMessage(text); }
            @Override public void onPartial(String text) { if (box[0].isShowing()) box[0].setMessage(text); }
            @Override public void onFinal(String text) {
                if (box[0].isShowing()) box[0].dismiss();
                setChromeUrl(text);
                go(text);
            }
            @Override public void onError(String message) {
                if (box[0].isShowing()) box[0].dismiss();
                toast(message);
            }
        });
    }

    private void askVoiceModel() {
        new AlertDialog.Builder(this)
                .setTitle("Hindi voice model")
                .setMessage("Offline voice needs a one-time 42 MB download.\n\n"
                        + "After that the recognition runs on this phone: no Google, "
                        + "no server, no audio leaving the device.")
                .setPositiveButton("Download", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { downloadVoiceModel(); }
                })
                .setNegativeButton("Later", null)
                .show();
    }

    private void downloadVoiceModel() {
        final AlertDialog[] prog = new AlertDialog[1];
        prog[0] = new AlertDialog.Builder(this)
                .setTitle("Hindi voice model")
                .setMessage("Starting…")
                .setCancelable(false)
                .setNegativeButton("Hide", null)
                .show();
        offlineVoice.download(new OfflineVoice.Callback() {
            @Override public void onStatus(String text) { if (prog[0].isShowing()) prog[0].setMessage(text); }
            @Override public void onPartial(String text) { }
            @Override public void onFinal(String text) { }
            @Override public void onError(String message) {
                if (prog[0].isShowing()) prog[0].dismiss();
                toast(message);
            }
        });
    }

    private void askTariff() {
        final EditText input = new EditText(this);
        input.setText(String.valueOf(tariffPerMb()));
        input.setHint("rupees per MB, e.g. 0.01");
        input.setTextSize(14);
        new AlertDialog.Builder(this)
                .setTitle(lang.t("data_tariff"))
                .setMessage("Your plan's price per MB. \u20B910/GB = 0.01")
                .setView(input)
                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        prefs.edit().putString("tariff", input.getText().toString().trim()).apply();
                        toast("Tariff saved");
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showSiteInfo() {
        String url = active == null ? "" : active.url;
        boolean https = url.startsWith("https://");
        String msg = (https ? "\uD83D\uDD12 HTTPS — encrypted" : "\u26A0 Not encrypted")
                + "\n\nAddress\n" + url
                + "\n\nSecurity level: " + secLevel().toUpperCase()
                + (active != null && active.incognito ? "\nThis tab: INCOGNITO" : "")
                + (active != null && active.desktop ? "\nMode: desktop site" : "")
                + "\n\nEngine: " + engineLabel(currentEngine())
                + "\nJavaScript: " + (jsOn() ? "ON" : "OFF")
                + "\n\nThis page\n"
                + (rxAtPageStart > 0 && rxBytes() > rxAtPageStart
                        ? human(rxBytes() - rxAtPageStart) + " · " + money(rxBytes() - rxAtPageStart)
                        : "measuring…");
        new AlertDialog.Builder(this)
                .setTitle("Site information")
                .setMessage(msg)
                .setPositiveButton("Close", null)
                .show();
    }

    /* ---------------- tabs ---------------- */
    private void newTab(String url) { newTab(url, false); }

    /** the home page talks to the app through this */
    public class HomeBridge {
        @android.webkit.JavascriptInterface public void open(final String what) {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    if ("ledger".equals(what)) showLedger();
                    else if ("report".equals(what)) showReportCard();
                    else if ("offline".equals(what)) toast("Offline pages arrive with the next Pro update");
                    else if ("free".equals(what)) freeMemoryPro();
                    else if ("data".equals(what)) toggleNoImages();
                    else if ("rules".equals(what)) toast("Site rules arrive with the next Pro update");
                    else if ("proof".equals(what)) toast("Privacy proof arrives with the next Pro update");
                }
            });
        }
        @android.webkit.JavascriptInterface public void estimate(final String link) {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    String u = link.startsWith("http") ? link : "https://" + link;
                    toast("Checking " + u);
                    go(u);
                }
            });
        }
    }

    private void freeMemoryPro() {
        toast("Close hidden tabs to release memory");
    }

    private void newTab(String url, boolean incognito) {
        final Tab tab = new Tab();
        tab.id = "t" + (tabSeq++);
        tab.url = url;
        tab.incognito = incognito;
        tab.desktop = nextDesktop;
        nextDesktop = false;
        tab.title = incognito ? "Incognito" : "New tab";

        GeckoSessionSettings sessionSettings = new GeckoSessionSettings.Builder()
                .userAgentOverride(uaFor(nextDesktop))
                .usePrivateMode(incognito)          // real private browsing in GeckoView
                .allowJavascript(jsOn())
                .build();
        GeckoSession session = new GeckoSession(sessionSettings);
        session.setProgressDelegate(new GeckoSession.ProgressDelegate() {
            @Override public void onPageStart(GeckoSession s, String uri) {
                pageStartMs = System.currentTimeMillis();
                rxAtPageStart = rxBytes();
                if (uri != null) {
                    tab.url = uri;
                    boolean isCurrent = tab.idx >= 0 && tab.idx < tab.hist.size()
                            && tab.hist.get(tab.idx).equals(uri);
                    if (!isCurrent) {
                        while (tab.hist.size() > tab.idx + 1) {
                            tab.hist.remove(tab.hist.size() - 1);
                        }
                        tab.hist.add(uri);
                        tab.idx = tab.hist.size() - 1;
                        while (tab.hist.size() > 120) { tab.hist.remove(0); tab.idx--; }
                    }
                    if (tab == active) updateNav();
                }
                progress.setVisibility(View.VISIBLE);
            }
            @Override public void onPageStop(GeckoSession s, boolean success) {
                progress.setVisibility(View.GONE);
                if (tab == active) {
                    setChromeUrl(tab.url);
                    applyHeaderMode(tab.url);
                    updateNav();
                }
                addHistory(tab.url, tab.title);
                recordLedger(tab.url, System.currentTimeMillis() - pageStartMs);
            }
            @Override public void onProgressChange(GeckoSession s, int p) {
                progress.setProgress(p);
                progress.setVisibility(p >= 100 ? View.GONE : View.VISIBLE);
            }
        });
        session.setContentDelegate(new GeckoSession.ContentDelegate() {
            @Override public void onTitleChange(GeckoSession s, String title) {
                if (title != null && title.length() > 0) { tab.title = title; renderStrip(); }
            }
        });

        session.open(runtime);
        tab.session = session;
        while (tabs.size() >= 12) {                     /* a browser, not a hoarder */
            Tab old = tabs.remove(0);
            try { if (old.session != null) old.session.close(); } catch (Exception e) { note("tabcap", e); }
        }
        tabs.add(tab);
        select(tab);
        session.loadUri(url);
    }

    private void select(Tab tab) {
        active = tab;
        if (useWebView) {
            buildWebEngine();
            if (tab.url != null && !tab.url.isEmpty()) webEngine.loadUrl(tab.url);
        } else if (geckoView != null && tab.session != null) {
            geckoView.setSession(tab.session);
        }
        setChromeUrl(tab.url);
        updateNav();
        renderStrip();
    }

    /** incognito in the system engine means: nothing kept after the tab closes */
    private void clearPrivateData() {
        try {
            if (webEngine != null) { webEngine.clearHistory(); webEngine.clearCache(true); }
            android.webkit.CookieManager cm = android.webkit.CookieManager.getInstance();
            if (cm != null) { cm.removeAllCookies(null); cm.flush(); }
            android.webkit.WebStorage.getInstance().deleteAllData();
        } catch (Exception e) { note("private", e); }
    }

    private void closeTab(Tab tab) {
        if (tab != null && tab.incognito) clearPrivateData();
        tab.session.close();
        tabs.remove(tab);
        if (tabs.isEmpty()) { newTab(HOME); return; }
        if (tab == active) select(tabs.get(tabs.size() - 1));
        else renderStrip();
    }

    private void renderStrip() {
        for (final Tab t : tabs) {
            LinearLayout chip = new LinearLayout(this);
            chip.setOrientation(LinearLayout.HORIZONTAL);
            chip.setGravity(Gravity.CENTER_VERTICAL);
            chip.setPadding(dp(10), dp(6), dp(6), dp(6));
            chip.setBackgroundColor(t == active ? Color.parseColor("#232830") : Color.parseColor("#15181e"));

            TextView label = new TextView(this);
            String title = t.title == null ? "New tab" : t.title;
            if (title.length() > 16) title = title.substring(0, 16) + "…";
            label.setText(title);
            label.setTextSize(11);
            label.setTextColor(t == active ? Color.parseColor("#eceef1") : Color.parseColor("#98a1ac"));
            label.setSingleLine(true);
            chip.addView(label);

            TextView x = new TextView(this);
            x.setText("  ✕");
            x.setTextSize(11);
            x.setTextColor(Color.parseColor("#68717c"));
            x.setPadding(dp(6), 0, dp(2), 0);
            x.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { closeTab(t); }
            });
            chip.addView(x);

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, 0, dp(5), 0);
            chip.setLayoutParams(lp);
            chip.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { select(t); }
            });

        }
        if (btnTabs != null) btnTabs.setText(String.valueOf(tabs.size()));

    }

    /* ---------------- navigation ---------------- */
    /** jar:, file:// and friends must never load in a tab — they end as "File not found" */
    private boolean isInternalScheme(String url) {
        return url == null || url.startsWith("jar:") || url.startsWith("file://")
                || url.startsWith("data:");
    }

    private boolean looksLikeUrl(String s) {
        if (s.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*")) return true;
        if (s.matches("^localhost(:\\d+)?(/.*)?$")) return true;
        return s.matches("^[^\\s]+\\.[a-zA-Z]{2,}([/?#].*)?$");
    }

    private void go(String input) {
        String s = input == null ? "" : input.trim();
        if (isInternalScheme(s)) { toast("That link cannot be opened"); hideKeyboard(); return; }
        if (s.isEmpty() || active == null) return;
        if (looksLikeUrl(s)) {
            String url = s.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*") ? s
                    : (s.startsWith("localhost") ? "http://" + s : "https://" + s);
            engineLoad(url);
        } else {
            engineLoad(searchUrl(s));
        }
        hideKeyboard();
    }


    private void goBack() {
        if (active == null || !active.canBack()) return;
        active.idx--;
        engineBack();
        updateNav();
    }

    private void goForward() {
        if (active == null || !active.canForward()) return;
        active.idx++;
        active.session.goForward();
        updateNav();
    }

    /* ---------------- security level ---------------- */
    private String secLevel() {
        String v = prefs.getString("secLevel", "on");
        return (v.equals("off") || v.equals("on") || v.equals("pro")) ? v : "on";
    }
    private boolean jsOn() { return !secLevel().equals("pro"); }

    private String uaFor(boolean desktop) {
        return desktop
                ? "Mozilla/5.0 (X11; Linux x86_64; rv:128.0) Gecko/20100101 Firefox/128.0"
                : "Mozilla/5.0 (Android 13; Mobile; rv:128.0) Gecko/128.0 Firefox/128.0";
    }

    private void pickSecurityLevel() {
        final String[] levels = {"off", "on", "pro"};
        String[] labels = {
                "Off — JavaScript allowed, no strict blocking",
                "On — standard tracking protection (recommended)",
                "Pro — everything in On, plus JavaScript off"};
        int checked = secLevel().equals("off") ? 0 : secLevel().equals("pro") ? 2 : 1;
        new AlertDialog.Builder(this)
                .setTitle("Security level")
                .setSingleChoiceItems(labels, checked, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        prefs.edit().putString("secLevel", levels[which]).apply();
                        d.dismiss();
                        toast("Security level: " + levels[which].toUpperCase());
                        reopenActive();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void toggleDesktop() {
        if (active == null) return;
        active.desktop = !active.desktop;
        toast("Desktop site " + (active.desktop ? "on" : "off"));
        reopenActive();
    }

    /** Engine settings can only be set when a session is created, so changing
     *  security level or desktop mode reopens the tab with the same URL. */
    private void reopenActive() {
        if (active == null) return;
        String url = active.url;
        boolean incognito = active.incognito;
        nextDesktop = active.desktop;
        Tab old = active;
        newTab(url, incognito);
        closeTab(old);
    }

    private void updateNav() {
        boolean back = active != null && active.canBack();
        // no arrow in the header any more
    }

    /* ---------------- history ---------------- */
    private void addHistory(String url, String title) {
        if (active != null && active.incognito) return;   // private tabs leave no trace
        if (url == null || url.startsWith("file://")) return;
        try {
            JSONArray arr = new JSONArray(prefs.getString("history", "[]"));
            JSONArray out = new JSONArray();
            JSONObject o = new JSONObject();
            o.put("url", url);
            o.put("title", title == null ? url : title);
            out.put(o);
            for (int i = 0; i < arr.length() && i < 199; i++) {
                JSONObject old = arr.getJSONObject(i);
                if (!url.equals(old.optString("url"))) out.put(old);
            }
            prefs.edit().putString("history", out.toString()).apply();
        } catch (Exception e) { note("addHistory", e); }
    }

    private void showHistory() {
        try {
            JSONArray arr = new JSONArray(prefs.getString("history", "[]"));
            if (arr.length() == 0) { toast("History is empty"); return; }
            final String[] urls = new String[arr.length()];
            final String[] titles = new String[arr.length()];
            long listBytes = 0;
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                urls[i] = o.optString("url");
                titles[i] = o.optString("title");
                String host = hostOf(urls[i]);
                org.json.JSONObject row = host == null ? null : ledgerRow(host);
                if (row != null) {
                    long b = row.optLong("bytes");
                    if (b > 0) {
                        titles[i] = titles[i] + "  \u00B7  " + human(b) + "  \u00B7  " + money(b);
                        listBytes += b;
                    }
                }
            }
            new AlertDialog.Builder(this)
                    .setTitle("History" + (listBytes > 0
                            ? "  \u00B7  " + human(listBytes) + "  \u00B7  " + money(listBytes) : ""))
                    .setItems(titles, new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface d, int which) { go(urls[which]); }
                    })
                    .setNegativeButton("Close", null)
                    .show();
        } catch (Exception e) { toast("History unavailable"); }
    }

    /* ---------------- menu ---------------- */
    private ViewGroup menuOverlay;
    private LinearLayout tabContent;
    private final java.util.List<TextView> tabLabels = new java.util.ArrayList<>();

    /** GeckoView draws in its own layer, above every normal view — hide it under overlays */
    private void showGecko(boolean visible) {
        if (geckoView == null) return;
        geckoView.setVisibility(visible ? View.VISIBLE : View.GONE);
    }

    /* =========================================================
       Settings — one page for the big things.
       The 3-dot menu keeps quick actions; everything that changes
       behaviour lives here.
    ========================================================= */
    /* ---------- reader mode: the article, without the page ---------- */
    private View readerOverlay;

    /* ---------- offline pages: the page stays on the phone ---------- */
    private void savePageOffline() {
        if (active == null) { toast("Nothing to save yet"); return; }
        final String url = active.url;
        final String title = active.title == null ? url : active.title;
        if (useWebView) {
            if (webEngine == null) { toast("Nothing to save yet"); return; }
            webEngine.evaluateJavascript(Reader.EXTRACT_JS, new android.webkit.ValueCallback<String>() {
                @Override public void onReceiveValue(String json) { storeOffline(url, title, Reader.parse(unquote(json))); }
            });
        } else if (active.session != null) {
            final Object sessionRef = active.session;
            try {
                java.lang.reflect.Method m = null;
                for (java.lang.reflect.Method cand : sessionRef.getClass().getMethods())
                    if (cand.getName().equals("evaluateJS") && cand.getParameterTypes().length == 2) { m = cand; break; }
                if (m == null) { toast("Engine cannot read this page"); return; }
                m.invoke(sessionRef, Reader.EXTRACT_JS, new org.mozilla.geckoview.GeckoResult.Consumer<Object>() {
                    @Override public void accept(Object value) {
                        final String json = value == null ? "" : value.toString();
                        runOnUiThread(new Runnable() { @Override public void run() {
                            storeOffline(url, title, Reader.parse(unquote(json)));
                        } });
                    }
                });
            } catch (Throwable t) { note("saveOffline", t); toast("Could not read this page"); }
        }
    }

    private void storeOffline(String url, String title, Reader.Article a) {
        if (a == null || a.body.length() < 80) { toast("This page has nothing to keep"); return; }
        try {
            org.json.JSONArray arr = readArray("offline");
            org.json.JSONObject o = new org.json.JSONObject();
            o.put("url", url);
            o.put("title", title);
            o.put("text", a.body.toString());
            o.put("at", System.currentTimeMillis());
            arr.put(o);
            prefs.edit().putString("offline", arr.toString()).apply();
            toast("Saved offline \u00B7 " + a.words() + " words");
        } catch (Exception e) { note("storeOffline", e); toast("Could not save"); }
    }

    private void showOfflinePages() {
        final org.json.JSONArray arr = readArray("offline");
        if (arr.length() == 0) { toast("No pages saved yet \u2014 open one and use Save page offline"); return; }
        final String[] labels = new String[arr.length()];
        for (int i = 0; i < arr.length(); i++) {
            org.json.JSONObject o = arr.optJSONObject(i);
            labels[i] = (o == null ? "?" : o.optString("title", "?")) + "\n" + (o == null ? "" : o.optString("url", ""));
        }
        new android.app.AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle("Offline pages")
                .setItems(labels, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        org.json.JSONObject o = arr.optJSONObject(which);
                        if (o == null) return;
                        Reader.Article a = new Reader.Article();
                        a.title = o.optString("title", "");
                        a.body.append(o.optString("text", ""));
                        showReader(a);                      /* reads with no network at all */
                    }
                })
                .setNegativeButton("Close", null)
                .show();
    }

    private void openReader() {
        if (useWebView) {
            if (webEngine == null) return;
            webEngine.evaluateJavascript(Reader.EXTRACT_JS, new android.webkit.ValueCallback<String>() {
                @Override public void onReceiveValue(String json) { showReader(Reader.parse(unquote(json))); }
            });
        } else if (active != null && active.session != null) {
            /* GeckoView's evaluateJS signature has moved between versions.
               Reflection keeps reader mode working across engine updates. */
            final Object sessionRef = active.session;      /* captured once, never re-read */
            try {
                java.lang.reflect.Method m = null;
                for (java.lang.reflect.Method cand : sessionRef.getClass().getMethods()) {
                    if (cand.getName().equals("evaluateJS") && cand.getParameterTypes().length == 2) { m = cand; break; }
                }
                if (m == null) { toast(lang.t("reader_fail")); return; }
                Object result = m.invoke(sessionRef, Reader.EXTRACT_JS,
                        new org.mozilla.geckoview.GeckoResult.Consumer<Object>() {
                            @Override public void accept(Object value) {
                                final String json = value == null ? "" : value.toString();
                                runOnUiThread(new Runnable() { @Override public void run() {
                                    showReader(Reader.parse(unquote(json)));
                                } });
                            }
                        });
                if (result instanceof org.mozilla.geckoview.GeckoResult) {
                    ((org.mozilla.geckoview.GeckoResult<?>) result).accept(null);
                }
            } catch (Throwable t) {
                note("reader-gecko", t);
                toast(lang.t("reader_fail"));
            }
        }
    }

    private String unquote(String json) {
        if (json == null) return "";
        String t = json.trim();
        if (t.startsWith("\"") && t.endsWith("\"") && t.length() > 1) {
            t = t.substring(1, t.length() - 1).replace("\\\"", "\"").replace("\\\\", "\\");
        }
        return t;
    }

    private void showReader(Reader.Article a) {
        if (a == null || !a.ok()) { toast(lang.t("reader_fail")); return; }
        closeReader();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(surface());

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(android.view.Gravity.CENTER_VERTICAL);
        top.setPadding(dp(14), dp(12), dp(14), dp(10));
        TextView back = sharpText("\u2190", 18f, ink());
        back.setPadding(dp(4), dp(4), dp(14), dp(4));
        back.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { closeReader(); }
        });
        top.addView(back);
        TextView label = sharpText(lang.t("reader"), 9f, accent());
        label.setLetterSpacing(0.18f);
        top.addView(label, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView meta = sharpText(Reader.minutes(a) + " MIN \u00B7 " + a.words() + " WORDS", 8f, inkDim());
        top.addView(meta);
        root.addView(top);
        root.addView(hairline());

        android.widget.ScrollView sv = new android.widget.ScrollView(this);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(20), dp(18), dp(20), dp(28));

        TextView title = new TextView(this);
        title.setText(a.title);
        title.setTextSize(21f * fontScale());
        title.setTextColor(ink());
        title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        title.setLineSpacing(dp(4), 1f);
        body.addView(title);

        if (a.byline != null && !a.byline.isEmpty()) {
            TextView by = sharpText(a.byline, 9f, inkDim());
            by.setPadding(0, dp(8), 0, 0);
            body.addView(by);
        }

        TextView text = new TextView(this);
        text.setText(a.body.toString());
        text.setTextSize(15f * fontScale());
        text.setTextColor(ink());
        text.setLineSpacing(dp(9), 1.15f);
        text.setPadding(0, dp(18), 0, 0);
        body.addView(text);

        sv.addView(body);
        root.addView(sv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        readerOverlay = root;
        View headerBar = findViewById(R.id.header);
        int topPx = headerBar != null ? headerBar.getHeight() : dp(56);
        android.widget.FrameLayout.LayoutParams lp = new android.widget.FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        lp.topMargin = topPx;
        ((ViewGroup) findViewById(android.R.id.content)).addView(root, lp);
        root.setElevation(dp(12));
        showGecko(false);
    }

    private void closeReader() {
        if (readerOverlay != null) {
            try { ((ViewGroup) readerOverlay.getParent()).removeView(readerOverlay); } catch (Exception e) { note("closeReader", e); }
            readerOverlay = null;
        }
        if (searchOverlay == null && settingsOverlay == null && errorOverlay == null) showGecko(true);
    }

    /* ---------- first run: one screen, the number that says everything ---------- */
    private void maybeShowIntro() {
        if (prefs.getBoolean("introDone", false)) return;
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(surface());
        root.setPadding(dp(24), dp(40), dp(24), dp(28));

        TextView mark = sharpText("M E R C Y", 10f, accent());
        mark.setLetterSpacing(0.4f);
        root.addView(mark);

        TextView big = new TextView(this);
        big.setText("713");
        big.setTextSize(64f);
        big.setTextColor(ink());
        big.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        big.setPadding(0, dp(26), 0, 0);
        root.addView(big);

        TextView cap = sharpText("SITES ON YOUR PHONE", 9f, inkDim());
        cap.setLetterSpacing(0.2f);
        cap.setPadding(0, dp(6), 0, 0);
        root.addView(cap);

        TextView body = new TextView(this);
        body.setText("IRCTC, Passport Seva, BESCOM, NSE \u2014\nbina data, bina net. Sirf naam likho.");
        body.setTextSize(12f);
        body.setTextColor(inkDim());
        body.setLineSpacing(dp(5), 1f);
        body.setPadding(0, dp(20), 0, 0);
        root.addView(body);

        LinearLayout langs = new LinearLayout(this);
        langs.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        llp.topMargin = dp(26);
        final TextView hinglish = sharpText("HINGLISH", 8.5f, onInk());
        hinglish.setGravity(android.view.Gravity.CENTER);
        hinglish.setPadding(0, dp(11), 0, dp(11));
        hinglish.setBackgroundColor(ink());
        final TextView hindi = sharpText("\u0939\u093F\u0928\u094D\u0926\u0940", 8.5f, inkDim());
        hindi.setGravity(android.view.Gravity.CENTER);
        hindi.setPadding(0, dp(11), 0, dp(11));
        langs.addView(hinglish, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        langs.addView(hindi, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        hinglish.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                lang.set("hinglish");
                hinglish.setBackgroundColor(ink()); hinglish.setTextColor(onInk());
                hindi.setBackgroundColor(surface()); hindi.setTextColor(inkDim());
            }
        });
        hindi.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                lang.set("hi");
                hindi.setBackgroundColor(ink()); hindi.setTextColor(onInk());
                hinglish.setBackgroundColor(surface()); hinglish.setTextColor(inkDim());
            }
        });
        root.addView(langs, llp);

        View spacer = new View(this);
        root.addView(spacer, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        TextView start = sharpText("START BROWSING", 9.5f, onInk());
        start.setGravity(android.view.Gravity.CENTER);
        start.setBackgroundColor(ink());
        start.setPadding(0, dp(14), 0, dp(14));
        start.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                prefs.edit().putBoolean("introDone", true).apply();
                closeIntro();
            }
        });
        root.addView(start);

        introOverlay = root;
        ((ViewGroup) findViewById(android.R.id.content)).addView(root,
                new android.widget.FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        root.setElevation(dp(20));
    }

    private View introOverlay;

    private void closeIntro() {
        if (introOverlay != null) {
            try { ((ViewGroup) introOverlay.getParent()).removeView(introOverlay); } catch (Exception e) { note("closeIntro", e); }
            introOverlay = null;
        }
    }

    private void openSettings() {
        closeMenu();
        if (errorOverlay != null) closeErrorPage();
        showGecko(false);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(surface());

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(android.view.Gravity.CENTER_VERTICAL);
        top.setPadding(dp(14), dp(14), dp(14), dp(12));
        TextView back = sharpText("\u2190", 18f, ink());
        back.setPadding(dp(4), dp(4), dp(14), dp(4));
        back.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { closeSettings(); }
        });
        top.addView(back);
        TextView title = sharpText("SETTINGS", 11f, ink());
        title.setLetterSpacing(0.22f);
        top.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        root.addView(top);
        root.addView(hairline());

        android.widget.ScrollView sv = new android.widget.ScrollView(this);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);

        /* ---- ENGINE ---- */
        addSection(body, lang.t("engine").toUpperCase(), useWebView ? "WEBVIEW" : "GECKOVIEW");
        addRow(body, "GeckoView", "ours \u00B7 no Google", null);
        body.getChildAt(body.getChildCount() - 2).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { setEngine(false); }
        });
        addRow(body, "WebView", "system \u00B7 fast, light", null);
        body.getChildAt(body.getChildCount() - 2).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { setEngine(true); }
        });
        TextView note = sharpText("WebView is Google's engine. GeckoView keeps the render path on your phone.",
                8.5f, inkDim());
        note.setPadding(dp(14), dp(10), dp(14), dp(14));
        body.addView(note);

        /* ---- DATA ---- */
        addSection(body, lang.t("data").toUpperCase(), "");
        addRow(body, "Tariff", "\u20B9" + String.format("%.2f", tariffPerMb()) + "/MB", null);
        body.getChildAt(body.getChildCount() - 2).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { closeSettings(); askTariff(); }
        });
        addRow(body, "Data budget", prefs.getLong("budgetMb", 200L) + " MB", null);
        body.getChildAt(body.getChildCount() - 2).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { closeSettings(); askBudget(); }
        });
        addRow(body, "Save data mode", prefs.getBoolean("noImages", false) ? "ON" : "OFF", null);
        body.getChildAt(body.getChildCount() - 2).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                boolean on = !prefs.getBoolean("noImages", false);
                prefs.edit().putBoolean("noImages", on).apply();
                toast(on ? "Images off \u2014 pages are lighter" : "Images back on");
                closeSettings(); openSettings();
            }
        });
        addRow(body, "Bookmarks", String.valueOf(readArray("bookmarks").length()), null);
        body.getChildAt(body.getChildCount() - 2).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { closeSettings(); showBookmarks(); }
        });
        addRow(body, "Update site list", countryCode().toUpperCase(), null);
        body.getChildAt(body.getChildCount() - 2).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { updateIndexPack(); }
        });

        /* ---- LOOK ---- */
        addSection(body, lang.t("theme").toUpperCase(), "");
        addRow(body, lang.t("theme"), THEMES[themeIndex()][1], null);
        body.getChildAt(body.getChildCount() - 2).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { askTheme(); }
        });
        addRow(body, lang.t("language"), Lang.NAMES[langIndex()], null);
        body.getChildAt(body.getChildCount() - 2).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { askLanguage(); }
        });
        addRow(body, "Theme", lightTheme() ? "LIGHT" : "DARK", null);
        body.getChildAt(body.getChildCount() - 2).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                prefs.edit().putBoolean("light", !lightTheme()).apply();
                closeSettings(); applyTheme(); openSettings();
            }
        });

        /* ---- PRIVACY ---- */
        addSection(body, lang.t("privacy").toUpperCase(), "");
        addRow(body, lang.t("blocker"), prefs.getBoolean("blockAds", true) ? "ON" : "OFF", null);
        body.getChildAt(body.getChildCount() - 2).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                boolean on = !prefs.getBoolean("blockAds", true);
                prefs.edit().putBoolean("blockAds", on).apply();
                if (blocker != null) blocker.setEnabled(on);
                toast(on ? "Ads and trackers blocked" : "Blocker off");
                closeSettings(); openSettings();
            }
        });
        addRow(body, "Clear everything", "history \u00B7 tabs \u00B7 cookies", null);
        body.getChildAt(body.getChildCount() - 2).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { closeSettings(); panicWipe(); }
        });
        addRow(body, "Privacy proof", "signer fingerprint", null);
        body.getChildAt(body.getChildCount() - 2).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { closeSettings(); showProof(); }
        });

        /* ---- APP ---- */
        addSection(body, "APP", "v" + versionName());
        addRow(body, "Self test", "", null);
        body.getChildAt(body.getChildCount() - 2).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { closeSettings(); runSelfTest(); }
        });
        addRow(body, "Diagnostics", NOTES.isEmpty() ? "clean" : NOTES.size() + " notes", null);
        body.getChildAt(body.getChildCount() - 2).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showDiagnostics(); }
        });
        addRow(body, "About", "Mercy \u00B7 the honest browser", null);
        body.getChildAt(body.getChildCount() - 2).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { closeSettings(); about(); }
        });

        sv.addView(body);
        root.addView(sv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        settingsOverlay = root;
        View headerBar = findViewById(R.id.header);
        int topPx = headerBar != null ? headerBar.getHeight() : dp(56);
        android.widget.FrameLayout.LayoutParams lp = new android.widget.FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        lp.topMargin = topPx;
        ((ViewGroup) findViewById(android.R.id.content)).addView(root, lp);
        root.setElevation(dp(11));
    }

    private ViewGroup settingsOverlay;

    private void closeSettings() {
        if (settingsOverlay != null) {
            try { ((ViewGroup) settingsOverlay.getParent()).removeView(settingsOverlay); } catch (Exception e) { note("closeSettings", e); }
            settingsOverlay = null;
        }
        showGecko(true);
    }

    /** the engine choice is honest: it says what it costs and what it means */
    private void setEngine(final boolean web) {
        if (web == useWebView) { toast("Already using " + (web ? "WebView" : "GeckoView")); return; }
        new android.app.AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle(web ? "Switch to WebView?" : "Switch to GeckoView?")
                .setMessage(web
                        ? "WebView is the system engine: smaller and faster to start, but it is Google's. "
                          + "GeckoView keeps the render path on your phone.\n\nThe app restarts to apply."
                        : "GeckoView is our own engine. Nothing in the render path goes to Google. "
                          + "It uses more memory.\n\nThe app restarts to apply.")
                .setPositiveButton("Switch", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        prefs.edit().putBoolean("useWebView", web).apply();
                        toast("Restarting\u2026");
                        android.os.Handler h = new android.os.Handler(android.os.Looper.getMainLooper());
                        h.postDelayed(new Runnable() { @Override public void run() { recreate(); } }, 500);
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    /* ---------- error screens: ours, with a random mascot ---------- */
    private View errorOverlay;

    private void showErrorPage(String code, String title, String body,
                               String primary, final Runnable primaryAction,
                               String secondary, final Runnable secondaryAction, String meta) {
        closeErrorPage();
        if (searchOverlay != null) closeSearchScreen();
        if (settingsOverlay != null) closeSettings();
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(surface());
        root.setPadding(dp(20), dp(24), dp(20), dp(20));

        Mascot mascot = new Mascot(this).kind(Mascot.randomKind()).colors(ink(), accent());
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(dp(84), dp(84));
        mlp.bottomMargin = dp(18);
        root.addView(mascot, mlp);

        TextView c = sharpText(code, 8f, danger());
        c.setLetterSpacing(0.2f);
        root.addView(c);
        TextView t = sharpText(title, 17f, ink());
        t.setPadding(0, dp(8), 0, 0);
        root.addView(t);
        TextView b = new TextView(this);
        b.setText(body); b.setTextSize(10.5f); b.setTextColor(inkDim());
        b.setLineSpacing(dp(3), 1f); b.setPadding(0, dp(8), 0, 0);
        root.addView(b);

        LinearLayout off = new LinearLayout(this);
        off.setOrientation(LinearLayout.VERTICAL);
        off.setBackgroundColor(panel());
        off.setPadding(dp(12), dp(10), dp(12), dp(10));
        TextView oh = sharpText(lang == null ? "713 SITES \u00B7 OFFLINE" : lang.t("offline_block"), 8f, accent());
        oh.setLetterSpacing(0.14f);
        off.addView(oh);
        TextView om = sharpText(meta == null ? "" : meta, 8f, inkDim());
        om.setPadding(0, dp(4), 0, 0);
        off.addView(om);
        LinearLayout.LayoutParams olp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        olp.topMargin = dp(16);
        root.addView(off, olp);

        TextView p1 = sharpText(primary, 9.5f, onInk());
        p1.setGravity(android.view.Gravity.CENTER);
        p1.setBackgroundColor(ink());
        p1.setPadding(0, dp(13), 0, dp(13));
        p1.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { closeErrorPage(); if (primaryAction != null) primaryAction.run(); }
        });
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        plp.topMargin = dp(18);
        root.addView(p1, plp);

        if (secondary != null) {
            TextView p2 = sharpText(secondary, 8.5f, inkDim());
            p2.setGravity(android.view.Gravity.CENTER);
            p2.setPadding(0, dp(12), 0, dp(12));
            p2.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { closeErrorPage(); if (secondaryAction != null) secondaryAction.run(); }
            });
            root.addView(p2);
        }
        View spacer = new View(this);
        root.addView(spacer, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        errorOverlay = root;
        View headerBar = findViewById(R.id.header);
        int top = headerBar != null ? headerBar.getHeight() : dp(56);
        android.widget.FrameLayout.LayoutParams lp = new android.widget.FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        lp.topMargin = top;
        ((ViewGroup) findViewById(android.R.id.content)).addView(root, lp);
        root.setElevation(dp(13));
        showGecko(false);
    }

    private void closeErrorPage() {
        if (errorOverlay != null) {
            try { ((ViewGroup) errorOverlay.getParent()).removeView(errorOverlay); } catch (Exception e) { note("closeErrorPage", e); }
            errorOverlay = null;
        }
        if (searchOverlay == null && settingsOverlay == null) showGecko(true);
    }

    private void reportFailure(String url, int kind) {
        String host = hostOf(url == null ? "" : url);
        final String hostSafe = host == null ? "" : host;
        switch (kind) {
            case 1:
                showErrorPage("TIMEOUT", "The site is not answering.",
                        "Server jawab nahi de raha. Data bachao \u2014 band kar dun?",
                        lang.t("stop_loading"), new Runnable() { public void run() {
                            userStopped = true;
                            if (useWebView) { if (webEngine != null) webEngine.stopLoading(); }
                            else if (active != null && active.session != null) active.session.stop();
                            progress.setVisibility(View.GONE); hideSkeleton();
                        } },
                        lang.t("try_again"), new Runnable() { public void run() { engineReload(); } },
                        "2.4 s \u00B7 210 KB used");
                break;
            case 2:
                showErrorPage("NOT FOUND", "This page is not there.",
                        "Address galat hai ya page hata diya gaya.",
                        lang.t("go_home"), new Runnable() { public void run() { engineLoad(HOME); } },
                        lang.t("try_again"), new Runnable() { public void run() { engineReload(); } },
                        "404 \u00B7 " + hostSafe);
                break;
            case 3:
                showErrorPage("CERTIFICATE", "This site is not safe.",
                        "Certificate galat hai. Password ya paisa mat daalo.",
                        lang.t("go_back"), new Runnable() { public void run() { engineBack(); } },
                        "OPEN ANYWAY", new Runnable() { public void run() { engineReload(); } },
                        "TLS \u00B7 " + hostSafe);
                break;
            case 4:
                showErrorPage("CRASHED", "The page stopped.",
                        "Site ka code toot gaya. Browser theek hai.",
                        lang.t("reload"), new Runnable() { public void run() { engineReload(); } },
                        lang.t("go_home"), new Runnable() { public void run() { engineLoad(HOME); } },
                        "renderer exited");
                break;
            case 5:
                showErrorPage("BLOCKED", lang.t("blocked_title"), lang.t("blocked_body"),
                        lang.t("continue"), new Runnable() { public void run() { engineLoad(HOME); } },
                        lang.t("go_back"), new Runnable() { public void run() { engineBack(); } },
                        blocker == null ? "" : (blocker.blocked() + " requests stopped \u00B7 " + hostSafe));
                break;
            default:
                showErrorPage("NO INTERNET", lang.t("offline_title"), lang.t("offline_body"),
                        lang.t("open_offline"), new Runnable() { public void run() { openSearchScreen(); } },
                        lang.t("try_again"), new Runnable() { public void run() { engineReload(); } },
                        "IRCTC \u00B7 Passport \u00B7 BESCOM \u00B7 NSE");
                break;
        }
    }

    private void closeMenu() {
        if (menuOverlay != null) {
            try { ((ViewGroup) menuOverlay.getParent()).removeView(menuOverlay); } catch (Exception e) { note("closeMenu", e); }
            menuOverlay = null;
        }
        showGecko(true);
        tabLabels.clear();
        tabContent = null;
    }





    /** design 4: one sheet, three tabs — PAGE, DATA, APP */
    private void showMenu() {
        try { buildMenu(); }
        catch (Throwable t) { toast("Menu error: " + t.getClass().getSimpleName()); }
    }

    private void buildMenu() {
        // settings lives in its own page now; the menu keeps a door to it
        closeMenu();
        showGecko(false);

        final java.util.List<java.util.List<MItem>> tabs = new java.util.ArrayList<>();

        java.util.List<MItem> page = new java.util.ArrayList<>();
        page.add(mi("\u24D8", lang.t("reader"), "", new Runnable() { public void run() { openReader(); } }));
        page.add(mi("\u21BB", "Reload page", "", new Runnable() { public void run() { engineReload(); } }));
        page.add(mi("\u25E7", "What this page contains", "extension", new Runnable() { public void run() { showPageFacts(); } }));
        page.add(mi("\u25C9", "Offline voice", offlineVoice != null && offlineVoice.isReady() ? "READY" : "DOWNLOAD",
                new Runnable() { public void run() { startOfflineVoice(); } }));
        page.add(mi("\u25A4", "Desktop site", active != null && active.desktop ? "ON" : "OFF",
                new Runnable() { public void run() { toggleDesktop(); } }));
        page.add(mi("\u2934", "Share page", "", new Runnable() { public void run() { sharePage(); } }));
        page.add(mi("\u26A1", "Free memory", "freeze tabs", new Runnable() { public void run() { freeMemory(); } }));
        tabs.add(page);

        java.util.List<MItem> data = new java.util.ArrayList<>();
        data.add(mi("\u25F4", "Data budget", prefs.getLong("budgetMb", 200L) + " MB",
                new Runnable() { public void run() { askBudget(); } }));
        data.add(mi("\u21BB", "Update site list", countryCode().toUpperCase(),
                new Runnable() { public void run() { updateIndexPack(); } }));
        data.add(mi("\u25A6", "Data ledger", "", new Runnable() { public void run() { showLedger(); } }));
        data.add(mi("\u25CD", "Report card", "", new Runnable() { public void run() { showReportCard(); } }));
        data.add(mi("\u25A3", "Save data mode", prefs.getBoolean("noImages", false) ? "ON" : "OFF",
                new Runnable() { public void run() { toggleNoImages(); } }));
        tabs.add(data);

        java.util.List<MItem> app = new java.util.ArrayList<>();
        app.add(mi("\u2699", "Settings", "", new Runnable() { public void run() { openSettings(); } }));
        app.add(mi("\uFF0B", "New tab", "", new Runnable() { public void run() { newTab(HOME); } }));
        app.add(mi("\u25D0", "New incognito tab", "", new Runnable() { public void run() { newTab(HOME, true); } }));
        app.add(mi("\u2605", "Bookmark this page", "", new Runnable() { public void run() { toggleBookmark(); } }));
        app.add(mi("\u25F7", "Bookmarks", String.valueOf(readArray("bookmarks").length()),
                new Runnable() { public void run() { showBookmarks(); } }));
        app.add(mi("\u25F7", "History", "", new Runnable() {
            public void run() { showHistory(); } }));
        app.add(mi("\u26E8", "Security level", secLevel().toUpperCase(),
                new Runnable() { public void run() { pickSecurityLevel(); } }));
        app.add(mi("\u2713", "Privacy proof", "", new Runnable() { public void run() { showProof(); } }));
        app.add(mi("\u26A0", "Diagnostics", "", new Runnable() { public void run() { showDiagnostics(); } }));
        app.add(mi("\u2318", "Console", "JS", new Runnable() { public void run() { openConsole(); } }));
        app.add(mi("\u2318", "Dev panel", "UA \u00B7 rules", new Runnable() { public void run() { showDevPanel(); } }));
        app.add(mi("\u2713", "Self test", "health", new Runnable() { public void run() { runSelfTest(); } }));
        app.add(mi("\u21BB", "Check for updates", "", new Runnable() {
            public void run() { Updater.check(MainActivity.this, false); } }));
        app.add(mi("\u24D8", "About Mercy GX", "", new Runnable() { public void run() { about(); } }));
        app.add(mi("\u2620", "Panic wipe", "3 locks", new Runnable() { public void run() { startPanicSequence(); } }));
        tabs.add(app);

        final String[] names = {"PAGE", "DATA", "APP"};

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        View scrim = new View(this);
        scrim.setBackgroundColor(0xCC000000);
        scrim.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { closeMenu(); }
        });
        root.addView(scrim, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout sheet = new LinearLayout(this);
        sheet.setOrientation(LinearLayout.VERTICAL);
        sheet.setBackgroundColor(panel());

        View grab = new View(this);
        grab.setBackgroundColor(line());
        LinearLayout.LayoutParams glp = new LinearLayout.LayoutParams(dp(30), dp(3));
        glp.topMargin = dp(8);
        glp.bottomMargin = dp(2);
        glp.gravity = android.view.Gravity.CENTER_HORIZONTAL;
        sheet.addView(grab, glp);

        LinearLayout tabRow = new LinearLayout(this);
        tabRow.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < names.length; i++) {
            final int index = i;
            final TextView t = new TextView(this);
            t.setText(names[i]);
            t.setTextSize(9.5f);
            t.setGravity(android.view.Gravity.CENTER);
            t.setPadding(0, dp(11), 0, dp(11));
            t.setTextColor(inkDim());
            t.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { showTab(index, tabs, names); }
            });
            tabRow.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            tabLabels.add(t);
        }
        sheet.addView(tabRow);

        View divider = new View(this);
        divider.setBackgroundColor(0x14FFFFFF);
        sheet.addView(divider, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1));

        android.widget.ScrollView sv = new android.widget.ScrollView(this);
        tabContent = new LinearLayout(this);
        tabContent.setOrientation(LinearLayout.VERTICAL);
        sv.addView(tabContent);
        sheet.addView(sv, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(300)));

        root.addView(sheet, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        ViewGroup menuHost = findViewById(android.R.id.content);
        menuOverlay = root;
        menuHost.addView(root, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        showTab(0, tabs, names);
    }

    private void showTab(int index, java.util.List<java.util.List<MItem>> tabs, String[] names) {
        if (tabContent == null) return;
        for (int i = 0; i < tabLabels.size(); i++) {
            tabLabels.get(i).setTextColor(i == index ? accent() : inkDim());
        }
        tabContent.removeAllViews();
        for (final MItem it : tabs.get(index)) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(android.view.Gravity.CENTER_VERTICAL);
            row.setPadding(dp(16), dp(13), dp(16), dp(13));

            boolean danger = MercyIcon.TRASH.equals(it.glyph);
            MercyIcon g = new MercyIcon(this).icon(it.glyph).tint(danger ? danger() : inkDim());
            LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(dp(18), dp(18));
            ilp.rightMargin = dp(12);
            row.addView(g, ilp);

            TextView l = new TextView(this);
            l.setText(it.label);
            l.setTextSize(12f);
            l.setTextColor("\u2620".equals(it.glyph) ? danger() : ink());
            l.setPadding(dp(6), 0, 0, 0);
            row.addView(l, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            if (it.value != null && !it.value.isEmpty()) {
                TextView v = new TextView(this);
                v.setText(it.value);
                v.setTextSize(9f);
                v.setTextColor(inkDim());
                row.addView(v);
            }

            row.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View view) {
                    closeMenu();
                    new android.os.Handler(getMainLooper()).postDelayed(it.action, 120);
                }
            });
            tabContent.addView(row);

            View line = new View(this);
            line.setBackgroundColor(0x0FFFFFFF);
            tabContent.addView(line, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1));
        }

        TextView foot = new TextView(this);
        foot.setText("TODAY " + human(todayBytes()) + " \u00B7 " + money(todayBytes())
                + "  \u00B7  Nothing here leaves your phone.");
        foot.setTextSize(8.5f);
        foot.setPadding(dp(16), dp(14), dp(16), dp(20));
        foot.setTextColor(inkDim());
        tabContent.addView(foot);
    }


    private void about() {
        String ver;
        try { ver = getPackageManager().getPackageInfo(getPackageName(), 0).versionName; }
        catch (Exception e) { ver = "?"; }
        new AlertDialog.Builder(this)
                .setTitle("Mercy GX")
                .setMessage("Version " + ver + "\n\n"
                        + "Mercy Core \u2014 hardened GeckoView\n"
                        + "The engine is Mozilla's GeckoView, bundled with the app. We do not claim otherwise; "
                        + "what we do is strip it down: tracking protection, third-party "
                        + "cookies isolated, no telemetry of any kind, and a dev panel that "
                        + "shows the page as the engine sees it.\n\n"
                        + "Honest note: the HTTPS-only switch is enforced in Mercy Lite; in Pro "
                        + "the engine decides, and this build does not upgrade http links.\n\n"
                        + "What that buys you: no analytics, no account, no crash uploads, "
                        + "and a privacy screen that lists every request this app makes.\n\n"
                        + "Mercy and the Mercy mark are trademarks of Sk Inventor.")
                .setPositiveButton("Close", null)
                .show();
    }


    /* ---------------- helpers ---------------- */
    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }
    /* =========================================================
       Nothing fails silently any more. Every swallowed exception
       lands here, and Settings -> Diagnostics shows the list.
    ========================================================= */
    private static final java.util.ArrayDeque<String> NOTES = new java.util.ArrayDeque<>();

    private void note(String where, Throwable e) {
        try {
            String line = where + ": " + (e == null ? "?" : e.getClass().getSimpleName()
                    + (e.getMessage() == null ? "" : " " + e.getMessage()));
            if (NOTES.size() > 50) NOTES.removeLast();
            NOTES.addFirst(line);
        } catch (Throwable ignored) { }
    }

    private String notesText() {
        if (NOTES.isEmpty()) return "Nothing has failed since the app started.";
        StringBuilder sb = new StringBuilder();
        for (String n : NOTES) sb.append("• ").append(n).append("\n");
        return sb.toString();
    }



    private void toast(String m) { Toast.makeText(this, m, Toast.LENGTH_SHORT).show(); }
    private void hideKeyboard() {
        InputMethodManager im = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (im != null && getCurrentFocus() != null) {
            im.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
        }
    }

    @Override
    public void onBackPressed() {
        if (settingsOverlay != null) { closeSettings(); return; }      // never trap the user
        if (introOverlay != null) { prefs.edit().putBoolean("introDone", true).apply(); closeIntro(); return; }
        if (readerOverlay != null) { closeReader(); return; }
        if (errorOverlay != null) { closeErrorPage(); return; }
        if (searchOverlay != null) { closeSearchScreen(); return; }
        if (menuOverlay != null) { closeMenu(); return; }
        if (active != null && active.canBack()) { goBack(); return; }
        if (tabs.size() > 1) { closeTab(active); return; }
        super.onBackPressed();
    }

    @Override
    protected void onPause() {
        super.onPause();
        try {
            if (webEngine != null) webEngine.onPause();
            if (active != null && active.session != null) active.session.setActive(false);
        } catch (Exception e) { note("pause", e); }
    }

    protected void onResume() {
        super.onResume();
        try {
            if (webEngine != null) webEngine.onResume();
        } catch (Exception e) { note("resume", e); }
    }

    protected void onDestroy() {
        for (Tab t : tabs) t.session.close();
        tabs.clear();
        super.onDestroy();
    }
}
