package com.skinventor.mercypro;

import android.app.Activity;
import android.app.AlertDialog;
import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.TrafficStats;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Process;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.webkit.WebViewClient;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;
import org.mozilla.geckoview.GeckoResult;
import org.mozilla.geckoview.GeckoRuntime;
import org.mozilla.geckoview.GeckoRuntimeSettings;
import org.mozilla.geckoview.GeckoSession;
import org.mozilla.geckoview.GeckoSessionSettings;
import org.mozilla.geckoview.GeckoView;

import java.util.ArrayList;
import java.util.List;

/**
 * Mercy Pro — GeckoView (Firefox engine) browser shell.
 *
 * Tabs = one GeckoSession each; a single GeckoView swaps between them.
 * Content blocking (ads, analytics, social, trackers) is done by the engine itself.
 */
public class MainActivity extends Activity {

    private static final String HOME = "resource://android/assets/newtab.html";
    private static final String PREFS = "mercy_pro";

    private GeckoRuntime runtime;
    private android.widget.FrameLayout container;
    private GeckoView geckoView;   // attached to the active tab, not to a layout id
    private final List<Tab> tabs = new ArrayList<>();
    private Tab active;
    private int tabSeq = 1;

    private EditText urlBar;
    private TextView engineChip, pctLabel, btnTabs;
    private BudgetRing ring;
    private ListView suggestList;
    private final java.util.List<String> suggestItems = new java.util.ArrayList<>();
    private android.widget.ArrayAdapter<String> suggestAdapter;
    private android.os.Handler suggestHandler;
    private ProgressBar progress;

    private SharedPreferences prefs;
    private boolean nextDesktop = false;
    private OfflineVoice offlineVoice;
    private boolean pendingVoice = false;
    private static final int REQ_MIC = 103;
    private long rxAtPageStart = -1;
    private long pageStartMs = 0;

    private static class Tab {
        String id;
        GeckoSession session;
        String url = HOME;
        String title = "New tab";
        // our own back/forward bookkeeping — GeckoView's canGoBack() is not stable
        // across engine versions, so the shell tracks it instead
        boolean incognito = false;
        boolean desktop = false;
        final List<String> hist = new ArrayList<>();
        int idx = -1;
        boolean canBack() { return idx > 0; }
        boolean canForward() { return idx >= 0 && idx < hist.size() - 1; }
    }

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        CrashGuard.install(this);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        container = findViewById(R.id.container);
        geckoView = new GeckoView(this);
        container.addView(geckoView, new android.widget.FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        homeView = (LinearLayout) buildHomeView();
        homeView.setVisibility(View.GONE);
        container.addView(homeView, new android.widget.FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        urlBar = findViewById(R.id.url);
        engineChip = findViewById(R.id.engineChip);
        pctLabel = findViewById(R.id.pct);
        btnTabs = findViewById(R.id.btnTabs);
        ring = findViewById(R.id.ring);
        suggestList = findViewById(R.id.suggest);
        suggestHandler = new android.os.Handler(getMainLooper());
        View navHome = findViewById(R.id.navHome);
        if (navHome != null) navHome.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (active != null && !active.url.equals(HOME)) active.session.loadUri(HOME);
            }
        });
        View navLib = findViewById(R.id.navMenu);
        if (navLib != null) navLib.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { openLibrary(); }
        });
        wireHeader();
        progress = findViewById(R.id.progress);

        // engine settings: private by default, ad + tracker blocking on
        // Keep this minimal: GeckoView's defaults already enable standard tracking
        // protection, and this API surface is stable across engine versions.
        GeckoRuntimeSettings.Builder rtBuilder = new GeckoRuntimeSettings.Builder()
                .javaScriptEnabled(true)
                .remoteDebuggingEnabled(false);
        if (prefs.getBoolean("torMode", false)) {
            String cfgPath = writeTorConfig();
            if (cfgPath != null) rtBuilder.configFilePath(cfgPath);
        }
        GeckoRuntimeSettings settings = rtBuilder.build();

        runtime = GeckoRuntime.create(this, settings);
        installMercyExtension(runtime);

        offlineVoice = new OfflineVoice(this);
        reportLastCrash();
        wireToolbar();
        paintEngine();
        paintEngine();

        String start = HOME;
        Uri incoming = getIntent() == null ? null : getIntent().getData();
        if (incoming != null && incoming.getScheme() != null
                && (incoming.getScheme().equals("http") || incoming.getScheme().equals("https"))) {
            start = incoming.toString();
        }
        newTab(start);
    }

    /* ---------------- toolbar ---------------- */
    private void wireToolbar() {
    }

    /** the header is html; this is the only door between it and the engine */
    public class Bridge {
        @android.webkit.JavascriptInterface public void search(final String url) {
            runOnUiThread(new Runnable() { @Override public void run() {
                hideKeyboard();
                go(url);
            }});
        }
        @android.webkit.JavascriptInterface public void newTab() {
            runOnUiThread(new Runnable() { @Override public void run() { MainActivity.this.newTab(HOME); } });
        }
        @android.webkit.JavascriptInterface public void tabs() {
            runOnUiThread(new Runnable() { @Override public void run() { showTabs(); } });
        }
        @android.webkit.JavascriptInterface public void menu() {
            runOnUiThread(new Runnable() { @Override public void run() { showMenu(); } });
        }
        @android.webkit.JavascriptInterface public void voice() {
            runOnUiThread(new Runnable() { @Override public void run() { startVoiceSearch(); } });
        }
        @android.webkit.JavascriptInterface public void scan() {
            runOnUiThread(new Runnable() { @Override public void run() { scanQrCode(); } });
        }
        @android.webkit.JavascriptInterface public void setEngine(final String id) {
            prefs.edit().putString("engine", id).apply();
        }
        @android.webkit.JavascriptInterface public void open(final String what) {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    if ("ledger".equals(what)) showLedger();
                    else if ("report".equals(what)) showReportCard();
                    else if ("proof".equals(what)) toast("Privacy proof arrives with the next Pro update");
                }
            });
        }
        @android.webkit.JavascriptInterface public void ready() {
            runOnUiThread(new Runnable() { @Override public void run() { pushChromeConfig(); } });
        }
    }



    /* =========================================================
       the header — native views, so typing costs one TextView
    ========================================================= */
    private void wireHeader() {
        engineChip.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showEnginePicker(); }
        });
        ring.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showLedger(); }
        });
        findViewById(R.id.btnNew).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { newTab(HOME); }
        });
        btnTabs.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showTabs(); }
        });
        findViewById(R.id.btnMenu).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showMenu(); }
        });
        findViewById(R.id.btnMic).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { startOfflineVoice(); }
        });

        urlBar.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_GO
                        || (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                    String text = urlBar.getText().toString().trim();
                    if (!text.isEmpty()) { hideSuggestions(); go(text); }
                    return true;
                }
                return false;
            }
        });
        urlBar.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) fetchSuggestions(urlBar.getText().toString());
                else hideSuggestions();
            }
        });
        urlBar.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(android.text.Editable e) { fetchSuggestions(e.toString()); }
        });

        suggestAdapter = new android.widget.ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, suggestItems) {
            @Override public View getView(int position, View convert, android.view.ViewGroup parent) {
                TextView tv = (TextView) super.getView(position, convert, parent);
                tv.setTextColor(0xFFE6E6EA);
                tv.setTextSize(13f);
                tv.setPadding(dp(16), dp(12), dp(16), dp(12));
                return tv;
            }
        };
        suggestList.setAdapter(suggestAdapter);
        suggestList.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {
            @Override public void onItemClick(android.widget.AdapterView<?> p, View v, int pos, long id) {
                String text = suggestItems.get(pos);
                urlBar.setText(text);
                urlBar.setSelection(text.length());
                hideSuggestions();
                go(text);
            }
        });
    }

    private void fetchSuggestions(final String query) {
        if (suggestHandler == null) return;
        suggestHandler.removeCallbacksAndMessages(null);
        final String q = query == null ? "" : query.trim();
        if (q.isEmpty()) { hideSuggestions(); return; }
        suggestHandler.postDelayed(new Runnable() {
            @Override public void run() {
                new Thread(new Runnable() {
                    @Override public void run() {
                        final java.util.List<String> out = new java.util.ArrayList<>();
                        try {
                            java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(
                                    "https://duckduckgo.com/ac/?q=" + java.net.URLEncoder.encode(q, "UTF-8")
                                            + "&type=list").openConnection();
                            c.setConnectTimeout(3000);
                            c.setReadTimeout(3000);
                            java.io.BufferedReader r = new java.io.BufferedReader(
                                    new java.io.InputStreamReader(c.getInputStream()));
                            StringBuilder sb = new StringBuilder();
                            String line;
                            while ((line = r.readLine()) != null) sb.append(line);
                            r.close();
                            String body = sb.toString().trim();
                            if (body.startsWith("\"")) body = new org.json.JSONTokener(body).nextValue().toString();
                            org.json.JSONArray arr = new org.json.JSONArray(body);
                            for (int i = 0; i < arr.length() && i < 8; i++) {
                                Object o = arr.opt(i);
                                String phrase = null;
                                if (o instanceof String) phrase = (String) o;
                                else if (o instanceof org.json.JSONObject)
                                    phrase = ((org.json.JSONObject) o).optString("phrase", null);
                                if (phrase != null && !phrase.trim().isEmpty()) out.add(phrase.trim());
                            }
                        } catch (Exception ignored) { }
                        runOnUiThread(new Runnable() {
                            @Override public void run() {
                                if (!urlBar.hasFocus() || out.isEmpty()) { hideSuggestions(); return; }
                                suggestItems.clear();
                                suggestItems.addAll(out);
                                suggestAdapter.notifyDataSetChanged();
                                suggestList.setVisibility(View.VISIBLE);
                            }
                        });
                    }
                }).start();
            }
        }, 180);
    }

    private void hideSuggestions() {
        if (suggestList != null) suggestList.setVisibility(View.GONE);
    }

    private void applyHeaderMode(String url) {
        boolean isHome = url == null || url.contains("newtab.html") || url.startsWith("resource://android");
        if (homeView != null) {
            homeView.setVisibility(isHome ? View.VISIBLE : View.GONE);
            if (isHome) paintHome();
        }
        boolean home = url == null || url.contains("newtab.html") || url.contains("appassets");
        engineChip.setVisibility(home ? View.VISIBLE : View.GONE);
        ring.setVisibility(home ? View.GONE : View.VISIBLE);
        pctLabel.setVisibility(home ? View.GONE : View.VISIBLE);
        findViewById(R.id.btnNew).setVisibility(home ? View.GONE : View.VISIBLE);
        btnTabs.setVisibility(home ? View.GONE : View.VISIBLE);
    }

    private static class MItem {
        final String glyph, label, value; final Runnable action;
        MItem(String g, String l, String v, Runnable a) { glyph = g; label = l; value = v; action = a; }
    }

    private MItem mi(String g, String l, String v, Runnable a) { return new MItem(g, l, v, a); }

    private org.json.JSONArray readArray(String key) {
        try { return new org.json.JSONArray(prefs.getString(key, "[]")); }
        catch (Exception e) { return new org.json.JSONArray(); }
    }

    private int accent() {
        try { return android.graphics.Color.parseColor(prefs.getString("accent", "#a06bff")); }
        catch (Exception e) { return 0xFFA06BFF; }
    }

    private int surface() {
        String bg = prefs.getString("bg", "black");
        if ("soft".equals(bg)) return 0xFF0E0E12;
        if ("light".equals(bg)) return 0xFFF6F5F2;
        return 0xFF000000;
    }

    private boolean lightTheme() { return "light".equals(prefs.getString("bg", "black")); }

    private int ink() { return lightTheme() ? 0xFF141416 : 0xFFF4F4F6; }

    private int inkDim() { return lightTheme() ? 0xFF6A6A72 : 0xFF8B8B95; }

    private int radiusDp() {
        String r = prefs.getString("radius", "soft");
        if ("square".equals(r)) return 0;
        if ("pill".equals(r)) return 20;
        return 12;
    }

    private float fontScale() {
        String f = prefs.getString("fontSize", "normal");
        if ("small".equals(f)) return 0.9f;
        if ("large".equals(f)) return 1.15f;
        return 1f;
    }

    /** repaint the whole header from the current theme */
    private void applyTheme() {
        try {
            getWindow().getDecorView().setBackgroundColor(surface());

            View header = findViewById(R.id.header);
            if (header != null) header.setBackgroundColor(surface());

            View pill = findViewById(R.id.pill);
            if (pill != null) {
                android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
                g.setCornerRadius((float) dp(radiusDp()));
                g.setColor(lightTheme() ? 0xFFFFFFFF : 0xFF141418);
                g.setStroke(dp(1), lightTheme() ? 0xFFE2E0DA : 0xFF33333A);
                pill.setBackground(g);
            }

            if (urlBar != null) {
                urlBar.setTextColor(ink());
                urlBar.setTextSize(13f * fontScale());
                urlBar.setHintTextColor(inkDim());
            }

            if (btnTabs != null) {
                android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
                g.setCornerRadius((float) dp(radiusDp() / 2));
                g.setColor(0x00000000);
                g.setStroke(dp(2), lightTheme() ? 0xFFE2E0DA : 0xFF33333A);
                btnTabs.setBackground(g);
                btnTabs.setTextColor(ink());
            }

            View nav = findViewById(R.id.bottomNav);
            if (nav != null) nav.setBackgroundColor(lightTheme() ? 0xFFF1F0EC : 0xFF0B0B0D);

            if (suggestList != null) suggestList.setBackgroundColor(lightTheme() ? 0xFFFBFBF9 : 0xFF0D0D11);

            paintEngine();
            pushBudget();
        } catch (Exception ignored) { }
    }

    private void askTheme() {
        final String[] items = {"Accent colour", "Background", "Corner radius", "Text size"};
        new android.app.AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle("Appearance")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        if (which == 0) pickAccent();
                        else if (which == 1) pickBackground();
                        else if (which == 2) pickRadius();
                        else pickFontSize();
                    }
                })
                .setNegativeButton("Close", null)
                .show();
    }

    private void pickAccent() {
        final String[] names = {"Mercy purple", "Amber", "Forest", "Blue", "Rose", "Custom hex\u2026"};
        final String[] values = {"#a06bff", "#ffb020", "#3ddc84", "#4c9aff", "#ff6b8a", ""};
        new android.app.AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle("Accent colour")
                .setItems(names, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        if (values[which].isEmpty()) { askCustomAccent(); return; }
                        prefs.edit().putString("accent", values[which]).apply();
                        applyTheme();
                    }
                })
                .show();
    }

    private void askCustomAccent() {
        final EditText in = new EditText(this);
        in.setText(prefs.getString("accent", "#a06bff"));
        in.setHint("#a06bff");
        new android.app.AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle("Accent hex")
                .setView(in)
                .setPositiveButton("Apply", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        String v = in.getText().toString().trim();
                        if (!v.startsWith("#") || (v.length() != 7 && v.length() != 9)) {
                            toast("Use a hex like #a06bff"); return;
                        }
                        try { android.graphics.Color.parseColor(v); }
                        catch (Exception e) { toast("That is not a colour"); return; }
                        prefs.edit().putString("accent", v).apply();
                        applyTheme();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void pickBackground() {
        final String[] names = {"Absolute black", "Soft black", "Paper (light)"};
        final String[] values = {"black", "soft", "light"};
        new android.app.AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle("Background")
                .setItems(names, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        prefs.edit().putString("bg", values[which]).apply();
                        applyTheme();
                    }
                })
                .show();
    }

    private void pickRadius() {
        final String[] names = {"Square (0)", "Soft (12)", "Pill (20)"};
        final String[] values = {"square", "soft", "pill"};
        new android.app.AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle("Corner radius")
                .setItems(names, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        prefs.edit().putString("radius", values[which]).apply();
                        applyTheme();
                    }
                })
                .show();
    }

    private void pickFontSize() {
        final String[] names = {"Small", "Normal", "Large"};
        final String[] values = {"small", "normal", "large"};
        new android.app.AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle("Text size")
                .setItems(names, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        prefs.edit().putString("fontSize", values[which]).apply();
                        applyTheme();
                    }
                })
                .show();
    }


    private void paintEngine() {
        if (engineChip == null) return;
        String id = currentEngine();
        engineChip.setText(engineLabel(id));
        int colour;
        try { colour = android.graphics.Color.parseColor(engineColor(id)); }
        catch (Exception e) { colour = 0xFFA06BFF; }
        engineChip.setTextColor(colour);
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setCornerRadius(dp(14));
        bg.setColor((colour & 0x00FFFFFF) | 0x33000000);
        engineChip.setBackground(bg);
    }

    private void pushChromeConfig() {
        try {
            org.json.JSONObject cfg = new org.json.JSONObject();
            cfg.put("engine", currentEngine());
            cfg.put("mercyUrl", prefs.getString("mercyUrl", ""));
            paintEngine();
            if (btnTabs != null) btnTabs.setText(String.valueOf(tabs.size()));
            pushBudget();
            if (active != null) setChromeUrl(active.url);
        } catch (Exception ignored) { }
    }

    private void pushBudget() {
        try {
            long today = todayBytes();
            long budget = 200L * 1024 * 1024;
            int pct = (int) Math.min(100, today * 100 / budget);
            String state = active != null && active.incognito ? "incognito"
                    : (today > budget ? "over" : "normal");
            if (ring != null) ring.setValue(pct, today > budget);
            if (pctLabel != null) {
                pctLabel.setText("incognito".equals(state) ? "PRIVATE" : pct + "%");
                pctLabel.setTextColor("incognito".equals(state) ? 0xFFC9B0FF
                        : (pct >= 60 ? 0xFFFFB020 : 0xFF5C5C66));
            }
        } catch (Exception ignored) { }
    }

    private void setChromeUrl(String url) {
        if (urlBar == null) return;
        boolean internal = url == null || url.contains("appassets") || url.startsWith("file://");
        if (!urlBar.hasFocus()) urlBar.setText(internal ? "" : url);
    }

    private void showTabs() {
        final java.util.List<Tab> list = new java.util.ArrayList<>(tabs);
        String[] titles = new String[list.size()];
        for (int i = 0; i < list.size(); i++) {
            Tab t = list.get(i);
            titles[i] = (t == active ? "\u25CF " : "   ") + (t.title == null ? "New tab" : t.title);
        }
        new AlertDialog.Builder(this)
                .setTitle("Tabs \u00B7 " + tabs.size())
                .setItems(titles, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) { select(list.get(which)); }
                })
                .setPositiveButton("New tab", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { MainActivity.this.newTab(HOME); }
                })
                .setNegativeButton("Close", null)
                .show();
    }

    /* ---------------- voice ---------------- */
    private void startVoiceSearch() {
        if (offlineVoice != null && offlineVoice.isReady()) { startOfflineVoice(); return; }
        try {
            Intent i = new Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            // keep the audio on the device whenever an offline model exists
            i.putExtra(android.speech.RecognizerIntent.EXTRA_PREFER_OFFLINE, true);
            i.putExtra(android.speech.RecognizerIntent.EXTRA_PROMPT, "Speak your search");
            startActivityForResult(i, 101);
        } catch (Exception e) {
            toast("No voice input app found");
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == 101 && res == RESULT_OK && data != null) {
            java.util.ArrayList<String> r = data.getStringArrayListExtra(
                    android.speech.RecognizerIntent.EXTRA_RESULTS);
            if (r != null && !r.isEmpty()) {
                setChromeUrl(r.get(0));
                go(r.get(0));
            }
        }
    }

    /* ---------------- QR ---------------- */
    private static final int REQ_CAMERA = 102;
    private boolean pendingScan = false;

    private void scanQrCode() {
        boolean granted = Build.VERSION.SDK_INT < 23
                || checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
        if (!granted) {
            pendingScan = true;
            requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA);
            return;
        }
        new QrScanner(this, new QrScanner.Listener() {
            @Override public void onScanned(String text) {
                String target = looksLikeUrl(text)
                        ? text
                        : "https://duckduckgo.com/?q=" + Uri.encode(text);
                setChromeUrl(target);
                go(target);
            }
        }).show();
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] res) {
        super.onRequestPermissionsResult(req, perms, res);
        if (req == REQ_MIC) {
            if (res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED) {
                if (pendingVoice) { pendingVoice = false; startOfflineVoice(); }
            } else {
                toast("Microphone permission denied");
            }
            return;
        }
        if (req == REQ_CAMERA) {
            if (res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED) {
                if (pendingScan) { pendingScan = false; scanQrCode(); }
            } else {
                toast("Camera permission denied — cannot scan");
            }
        }
    }

    /* ---------------- engine picker ---------------- */
    private static final String[] ENGINE_IDS =
            {"mercy", "google", "ddg", "brave", "ecosia", "startpage", "bing", "yahoo"};

    private String engineLabel(String id) {
        switch (id) {
            case "mercy": return "Mercy (own index)";
            case "google": return "Google";
            case "brave": return "Brave Search";
            case "ecosia": return "Ecosia";
            case "startpage": return "Startpage";
            case "bing": return "Bing";
            case "yahoo": return "Yahoo";
            default: return "DuckDuckGo";
        }
    }

    private String engineColor(String id) {
        switch (id) {
            case "mercy": return "#a06bff";
            case "google": return "#4285f4";
            case "brave": return "#fb542b";
            case "ecosia": return "#2f9e5f";
            case "startpage": return "#6b7f8f";
            case "bing": return "#00a4ef";
            case "yahoo": return "#a05cff";
            default: return "#de5833";
        }
    }

    private String currentEngine() {
        String id = prefs.getString("engine", "mercy");
        for (String e : ENGINE_IDS) if (e.equals(id)) return id;
        return "mercy";
    }

    private void showEnginePicker() {
        final String[] labels = new String[ENGINE_IDS.length];
        String cur = currentEngine();
        int checked = 0;
        for (int i = 0; i < ENGINE_IDS.length; i++) {
            labels[i] = engineLabel(ENGINE_IDS[i]);
            if (ENGINE_IDS[i].equals(cur)) checked = i;
        }
        new AlertDialog.Builder(this)
                .setTitle("Search engine")
                .setSingleChoiceItems(labels, checked, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        prefs.edit().putString("engine", ENGINE_IDS[which]).apply();
                        paintEngine();
                        d.dismiss();
                        if (ENGINE_IDS[which].equals("mercy")
                                && prefs.getString("mercyUrl", "").isEmpty()) {
                            askMercyUrl();
                        }
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void askMercyUrl() {
        final EditText input = new EditText(this);
        input.setHint("https://your-search.onrender.com/search");
        input.setText(prefs.getString("mercyUrl", ""));
        input.setTextSize(13);
        new AlertDialog.Builder(this)
                .setTitle("Mercy engine URL")
                .setMessage("Your own search server. Leave empty to fall back to DuckDuckGo.")
                .setView(input)
                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        prefs.edit().putString("mercyUrl", input.getText().toString().trim()).apply();
                        toast("Saved");
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private String searchUrl(String q) {
        String enc = Uri.encode(q);
        String id = currentEngine();
        switch (id) {
            case "mercy": {
                String base = prefs.getString("mercyUrl", "").trim();
                if (base.isEmpty()) return "https://duckduckgo.com/?q=" + enc;
                return base + (base.contains("?") ? "&q=" : "?q=") + enc;
            }
            case "google": return "https://www.google.com/search?q=" + enc;
            case "brave": return "https://search.brave.com/search?q=" + enc;
            case "ecosia": return "https://www.ecosia.org/search?q=" + enc;
            case "startpage": return "https://www.startpage.com/sp/search?query=" + enc;
            case "bing": return "https://www.bing.com/search?q=" + enc;
            case "yahoo": return "https://search.yahoo.com/search?p=" + enc;
            default: return "https://duckduckgo.com/?q=" + enc;
        }
    }


    /* ---------------- image search ---------------- */
    /** Images tab of whichever engine is selected. */
    private String imageSearchUrl(String q) {
        String enc = Uri.encode(q == null ? "" : q);
        switch (currentEngine()) {
            case "google": return "https://www.google.com/search?tbm=isch&q=" + enc;
            case "brave":  return "https://search.brave.com/images?q=" + enc;
            case "bing":   return "https://www.bing.com/images/search?q=" + enc;
            case "yahoo":  return "https://images.search.yahoo.com/search/images?p=" + enc;
            case "ecosia": return "https://www.ecosia.org/images?q=" + enc;
            case "startpage": return "https://www.startpage.com/sp/search?query=" + enc + "&cat=images";
            case "mercy": {
                String base = prefs.getString("mercyUrl", "").trim();
                if (!base.isEmpty()) return base + (base.contains("?") ? "&q=" : "?q=") + enc;
                return "https://duckduckgo.com/?q=" + enc + "&iax=images&ia=images";
            }
            default: return "https://duckduckgo.com/?q=" + enc + "&iax=images&ia=images";
        }
    }

    /** Reverse image search: opens the engine's visual-search page, where the
     *  user can upload a photo or point the camera. No API key needed. */
    private String visualSearchUrl() {
        switch (currentEngine()) {
            case "google": return "https://lens.google.com/";
            case "bing":   return "https://www.bing.com/visualsearch";
            case "yahoo":  return "https://images.search.yahoo.com/";
            default:       return "https://lens.google.com/";
        }
    }

    private void openImageSearch() {
        if (active == null) return;
        String q = "";
        String url = imageSearchUrl(q);
        setChromeUrl(url);
        active.session.loadUri(url);
    }

    private void openVisualSearch() {
        if (active == null) return;
        String url = visualSearchUrl();
        setChromeUrl(url);
        active.session.loadUri(url);
    }


    /* ---------------- data ledger ---------------- */
    private long rxBytes() {
        long v = TrafficStats.getUidRxBytes(Process.myUid());
        return v == TrafficStats.UNSUPPORTED ? -1 : v;
    }

    private double tariffPerMb() {
        try { return Double.parseDouble(prefs.getString("tariff", "0.01")); }
        catch (Exception e) { return 0.01; }
    }

    private String hostOf(String url) {
        try {
            String h = Uri.parse(url).getHost();
            if (h == null) return null;
            return h.startsWith("www.") ? h.substring(4) : h;
        } catch (Exception e) { return null; }
    }

    private void recordLedger(String url, long ms) {
        if (url == null || url.contains("appassets.androidplatform.net")
                || url.startsWith("file://") || url.startsWith("resource://")) return;
        String host = hostOf(url);
        if (host == null) return;
        long bytes = 0;
        if (rxAtPageStart > 0) {
            long now = rxBytes();
            if (now > rxAtPageStart) bytes = now - rxAtPageStart;
        }
        try {
            org.json.JSONObject all = new org.json.JSONObject(prefs.getString("ledger", "{}"));
            org.json.JSONObject row = all.optJSONObject(host);
            if (row == null) row = new org.json.JSONObject();
            row.put("bytes", row.optLong("bytes") + Math.max(0, bytes));
            row.put("ms", row.optLong("ms") + Math.max(0, ms));
            row.put("visits", row.optLong("visits") + 1);
            all.put(host, row);
            prefs.edit().putString("ledger", all.toString()).apply();
        } catch (Exception ignored) { }
    }

    private org.json.JSONObject ledgerRow(String host) {
        try {
            org.json.JSONObject all = new org.json.JSONObject(prefs.getString("ledger", "{}"));
            return all.optJSONObject(host);
        } catch (Exception e) { return null; }
    }

    private long budgetBytes() {
        long mb = prefs.getLong("budgetMb", 200L);
        if (mb <= 0) mb = 200L;
        return mb * 1024L * 1024L;
    }

    private void askBudget() {
        final String[] labels = {"200 MB", "500 MB", "1 GB", "2 GB", "5 GB"};
        final long[] values = {200, 500, 1024, 2048, 5120};
        new android.app.AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle("Data budget")
                .setItems(labels, new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int which) {
                        prefs.edit().putLong("budgetMb", values[which]).apply();
                        pushBudget();
                        toast("Budget set to " + labels[which]);
                    }
                })
                .show();
    }

    private long todayBytes() {
        try {
            String day = new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
                    .format(new java.util.Date());
            return new org.json.JSONObject(prefs.getString("daily", "{}")).optLong(day);
        } catch (Exception e) { return 0; }
    }

    private String human(long b) {
        if (b < 1024) return b + " B";
        if (b < 1048576) return String.format("%.0f KB", b / 1024.0);
        if (b < 1073741824L) return String.format("%.1f MB", b / 1048576.0);
        return String.format("%.2f GB", b / 1073741824.0);
    }

    private String money(long bytes) {
        double rupees = (bytes / 1048576.0) * tariffPerMb();
        if (rupees < 1) return String.format("%.0f paise", rupees * 100);
        return String.format("\u20B9%.2f", rupees);
    }

    private String humanTime(long ms) {
        long s = ms / 1000;
        if (s < 60) return s + "s";
        if (s < 3600) return (s / 60) + "m";
        return (s / 3600) + "h " + ((s % 3600) / 60) + "m";
    }


    private void showReportCard() {
        try {
            org.json.JSONObject all = new org.json.JSONObject(prefs.getString("ledger", "{}"));
            if (all.length() == 0) { toast("Nothing recorded yet"); return; }
            long total = 0, totalMs = 0, totalVisits = 0;
            java.util.List<String> hosts = new java.util.ArrayList<>();
            for (java.util.Iterator<String> it = all.keys(); it.hasNext(); ) hosts.add(it.next());
            final java.util.Map<String, Long> bytes = new java.util.HashMap<>();
            for (String h : hosts) {
                org.json.JSONObject r = all.optJSONObject(h);
                long b = r.optLong("bytes");
                bytes.put(h, b);
                total += b;
                totalMs += r.optLong("ms");
                totalVisits += r.optLong("visits");
            }
            java.util.Collections.sort(hosts, new java.util.Comparator<String>() {
                @Override public int compare(String a, String b) {
                    return Long.compare(bytes.get(b), bytes.get(a));
                }
            });
            StringBuilder sb = new StringBuilder();
            sb.append("You spent ").append(human(total)).append(" and ").append(money(total))
              .append(" on ").append(totalVisits).append(" page loads.\n")
              .append(humanTime(totalMs)).append(" of browsing.\n\n");
            int top = 0;
            for (String h : hosts) {
                if (top++ >= 5) break;
                long b = bytes.get(h);
                int pct = total > 0 ? (int) Math.round(b * 100.0 / total) : 0;
                sb.append(h).append("  ").append(pct).append("%  \u00B7  ").append(human(b)).append("\n");
            }
            new AlertDialog.Builder(this)
                    .setTitle("Report card")
                    .setMessage(sb.toString())
                    .setPositiveButton("Close", null)
                    .setNeutralButton("Save data mode", new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface d, int w) { toggleNoImages(); }
                    })
                    .show();
        } catch (Exception e) { toast("Report unavailable"); }
    }

    private void toggleNoImages() {
        boolean now = !prefs.getBoolean("noImages", false);
        prefs.edit().putBoolean("noImages", now).apply();
        toast("Save data mode " + (now ? "ON — images blocked" : "OFF"));
        if (active != null) active.session.reload();
    }


    /* ---------------- crash safety ---------------- */
    private void reportLastCrash() {
        if (!CrashGuard.hasCrash(this)) return;
        new AlertDialog.Builder(this)
                .setTitle("Mercy closed unexpectedly")
                .setMessage("The last session ended with an error. You can read the log, "
                        + "or start with safe defaults.")
                .setPositiveButton("View log", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { showDiagnostics(); }
                })
                .setNeutralButton("Safe mode", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        prefs.edit().putString("secLevel", "on").putBoolean("noImages", false).apply();
                        CrashGuard.clear(MercyProActivity());
                        newTab(HOME);
                        toast("Safe mode: defaults restored");
                    }
                })
                .setNegativeButton("Dismiss", null)
                .show();
    }

    private MainActivity MercyProActivity() { return this; }

    private void showDiagnostics() {
        String log = CrashGuard.read(this);
        new AlertDialog.Builder(this)
                .setTitle("Diagnostics")
                .setMessage("Crashes recorded: " + CrashGuard.count(this) + "\n\n" + log)
                .setPositiveButton("Close", null)
                .setNeutralButton("Clear log", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        CrashGuard.clear(MainActivity.this);
                        toast("Log cleared");
                    }
                })
                .show();
    }


    /* =========================================================
       Tor via Orbot — GeckoView has no proxy API, so we hand it a
       config file carrying the SOCKS preferences.
    ========================================================= */
    private String writeTorConfig() {
        try {
            java.io.File f = new java.io.File(getFilesDir(), "gecko-tor.yaml");
            String yaml = "prefs:\n"
                    + "  network.proxy.type: 1\n"
                    + "  network.proxy.socks: \"127.0.0.1\"\n"
                    + "  network.proxy.socks_port: 9050\n"
                    + "  network.proxy.socks_remote_dns: true\n"
                    + "  network.proxy.allow_hijacking_localhost: true\n"
                    + "  network.trr.mode: 5\n";
            java.io.FileOutputStream out = new java.io.FileOutputStream(f, false);
            out.write(yaml.getBytes("UTF-8"));
            out.close();
            return f.getAbsolutePath();
        } catch (Exception e) { return null; }
    }

    private void toggleTor() {
        boolean on = !prefs.getBoolean("torMode", false);
        prefs.edit().putBoolean("torMode", on).apply();
        if (on) {
            new AlertDialog.Builder(this)
                    .setTitle("Tor via Orbot")
                    .setMessage("Orbot is required, running on port 9050.\n\n"
                            + "What this does: every page goes through the Tor network, "
                            + ".onion addresses open, and nothing else in the app makes a request.\n\n"
                            + "What it cannot do: make you anonymous if you log in, or hide "
                            + "traffic from other apps on this phone.\n\n"
                            + "Reopen the app for this to take effect.")
                    .setPositiveButton("Understood", null)
                    .show();
        } else {
            toast("Tor off — reopen the app");
        }
    }


    private void showDevPanel() {
        final String[] items = {"Custom user agent", "Block a host", "Data budget", "Clear custom rules"};
        new android.app.AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle("Dev panel")
                .setItems(items, new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int which) {
                        if (which == 0) askCustomUa();
                        else if (which == 1) askBlockHost();
                        else if (which == 2) askBudget();
                        else {
                            prefs.edit().remove("customBlock").remove("customUA").apply();
                            toast("Custom rules cleared");
                        }
                    }
                })
                .setNegativeButton("Close", null)
                .show();
    }

    private void askCustomUa() {
        final EditText in = new EditText(this);
        in.setText(prefs.getString("customUA", ""));
        in.setHint("leave empty for the default");
        in.setTextSize(12);
        new android.app.AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle("Custom user agent")
                .setView(in)
                .setPositiveButton("Save", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int w) {
                        prefs.edit().putString("customUA", in.getText().toString().trim()).apply();
                        toast("Saved \u2014 reload the page");
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void askBlockHost() {
        final EditText in = new EditText(this);
        in.setHint("ads.example.com");
        in.setTextSize(13);
        new android.app.AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle("Block a host")
                .setView(in)
                .setPositiveButton("Add", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int w) {
                        String h = in.getText().toString().trim().toLowerCase();
                        if (h.isEmpty()) return;
                        try {
                            org.json.JSONArray arr = new org.json.JSONArray(prefs.getString("customBlock", "[]"));
                            arr.put(h);
                            prefs.edit().putString("customBlock", arr.toString()).apply();
                            toast("Saved " + h);
                        } catch (Exception ignored) { }
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    /* =========================================================
       Library — your own things. A screen, not a dialog.
       Every row says how much is inside it.
    ========================================================= */
    private LinearLayout libList;
    private EditText libSearch;

    private void openLibrary() {
        closeMenu();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(surface());

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(android.view.Gravity.CENTER_VERTICAL);
        head.setPadding(dp(18), dp(18), dp(12), dp(8));

        TextView title = new TextView(this);
        title.setText("Library");
        title.setTextSize(20f);
        title.setTextColor(ink());
        head.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView close = new TextView(this);
        close.setText("\u2715");
        close.setTextSize(16f);
        close.setTextColor(inkDim());
        close.setPadding(dp(12), dp(4), dp(4), dp(4));
        close.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { closeMenu(); }
        });
        head.addView(close);
        root.addView(head);

        libSearch = new EditText(this);
        libSearch.setHint("Search your library");
        libSearch.setTextSize(12f);
        libSearch.setTextColor(ink());
        libSearch.setHintTextColor(inkDim());
        libSearch.setBackgroundColor(lightTheme() ? 0xFFEDECE8 : 0xFF141418);
        libSearch.setPadding(dp(12), dp(9), dp(12), dp(9));
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        slp.leftMargin = dp(16); slp.rightMargin = dp(16); slp.bottomMargin = dp(10);
        root.addView(libSearch, slp);

        android.widget.ScrollView sv = new android.widget.ScrollView(this);
        libList = new LinearLayout(this);
        libList.setOrientation(LinearLayout.VERTICAL);
        sv.addView(libList);
        root.addView(sv, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        TextView foot = new TextView(this);
        foot.setText("Nothing here leaves your phone.");
        foot.setTextSize(9f);
        foot.setTextColor(inkDim());
        foot.setGravity(android.view.Gravity.CENTER);
        foot.setPadding(0, dp(10), 0, dp(18));
        root.addView(foot);

        ViewGroup menuHost = findViewById(android.R.id.content);
        menuOverlay = root;
        menuHost.addView(root, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        libSearch.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(android.text.Editable e) { paintLibrary(e.toString()); }
        });
        paintLibrary("");
    }

    private void paintLibrary(String filter) {
        if (libList == null) return;
        libList.removeAllViews();
        String q = filter == null ? "" : filter.trim().toLowerCase();

        java.util.List<MItem> rows = new java.util.ArrayList<>();
        rows.add(mi("\u25F7", "Open tabs", String.valueOf(tabs.size()),
                new Runnable() { public void run() { closeMenu(); showTabs(); } }));
        
        rows.add(mi("\u2193", "Offline pages", String.valueOf(readArray("offline").length()),
                new Runnable() { public void run() { closeMenu(); toast("Offline pages are a Lite feature"); } }));
        
        rows.add(mi("\u25A6", "Data ledger", human(todayBytes()),
                new Runnable() { public void run() { closeMenu(); showLedger(); } }));
        rows.add(mi("\u25CD", "Report card", "this week",
                new Runnable() { public void run() { closeMenu(); showReportCard(); } }));

        boolean any = false;
        for (final MItem it : rows) {
            if (!q.isEmpty() && !it.label.toLowerCase().contains(q)) continue;
            any = true;
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(android.view.Gravity.CENTER_VERTICAL);
            row.setPadding(dp(18), dp(15), dp(18), dp(15));

            TextView g = new TextView(this);
            g.setText(it.glyph);
            g.setTextSize(13f);
            g.setTextColor(accent());
            g.setWidth(dp(26));
            row.addView(g);

            TextView l = new TextView(this);
            l.setText(it.label);
            l.setTextSize(13f * fontScale());
            l.setTextColor(ink());
            row.addView(l, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            TextView v = new TextView(this);
            v.setText(it.value);
            v.setTextSize(10f);
            v.setTextColor(inkDim());
            row.addView(v);

            TextView chev = new TextView(this);
            chev.setText(" \u203A");
            chev.setTextSize(13f);
            chev.setTextColor(inkDim());
            row.addView(chev);

            row.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View view) {
                    new android.os.Handler(getMainLooper()).postDelayed(it.action, 60);
                }
            });
            libList.addView(row);

            View line = new View(this);
            line.setBackgroundColor(lightTheme() ? 0x14000000 : 0x14FFFFFF);
            libList.addView(line, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1));
        }

        if (!any) {
            TextView empty = new TextView(this);
            empty.setText("Nothing matches \"" + filter + "\"");
            empty.setTextSize(11f);
            empty.setTextColor(inkDim());
            empty.setPadding(dp(18), dp(24), dp(18), dp(24));
            libList.addView(empty);
        }
    }



    /* =========================================================
       Console — JavaScript against the page you are on.
       Not a shell, not a terminal, and it says so.
    ========================================================= */


    /* =========================================================
       panic wipe — three locks, because this cannot be undone
       1. hold the button for 3 seconds   2. type ERASE   3. confirm
    ========================================================= */
    private void startPanicSequence() {
        final android.app.AlertDialog d = new android.app.AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle("Erase everything?")
                .setMessage("This deletes history, bookmarks, offline pages, cookies, the ledger and every setting.\n\n"
                        + "Hold the bar below for three seconds to continue.")
                .setNegativeButton("Cancel", null)
                .create();

        final LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), dp(8));

        final TextView bar = new TextView(this);
        bar.setText("HOLD TO CONTINUE");
        bar.setTextSize(11f);
        bar.setGravity(android.view.Gravity.CENTER);
        bar.setTextColor(0xFFFF5C5C);
        bar.setPadding(0, dp(16), 0, dp(16));
        bar.setBackgroundColor(0xFF1A1113);
        box.addView(bar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        d.setView(box);

        final boolean[] done = {false};
        final android.os.Handler h = new android.os.Handler(getMainLooper());
        final Runnable reset = new Runnable() {
            @Override public void run() {
                if (!done[0]) { bar.setText("HOLD TO CONTINUE"); bar.setBackgroundColor(0xFF1A1113); }
            }
        };
        bar.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, android.view.MotionEvent e) {
                if (e.getAction() == android.view.MotionEvent.ACTION_DOWN) {
                    bar.setText("KEEP HOLDING…");
                    bar.setBackgroundColor(0xFF3A1418);
                    h.postDelayed(new Runnable() {
                        @Override public void run() {
                            if (done[0]) return;
                            done[0] = true;
                            d.dismiss();
                            askEraseWord();
                        }
                    }, 3000);
                } else if (e.getAction() == android.view.MotionEvent.ACTION_UP
                        || e.getAction() == android.view.MotionEvent.ACTION_CANCEL) {
                    h.removeCallbacksAndMessages(null);
                    h.post(reset);
                }
                return true;
            }
        });
        d.show();
    }

    private void askEraseWord() {
        final EditText in = new EditText(this);
        in.setHint("type ERASE");
        in.setInputType(android.text.InputType.TYPE_CLASS_TEXT
                | android.text.InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        new android.app.AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle("Type ERASE to confirm")
                .setView(in)
                .setPositiveButton("Erase", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        if (!"ERASE".equals(in.getText().toString().trim().toUpperCase())) {
                            toast("Nothing erased \u2014 the word did not match");
                            return;
                        }
                        panicWipe();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }




    /** erases everything this app ever stored, then starts clean */
    private void panicWipe() {
        try {
            prefs.edit().clear().apply();
            for (Tab t : tabs) {
                try { t.session.close(); } catch (Exception ignored) { }
            }
            tabs.clear();
            newTab(HOME);
            toast("Everything erased");
        } catch (Exception e) { toast("Wipe failed: " + e.getClass().getSimpleName()); }
    }


    /* =========================================================
       native home — GeckoView cannot push values into a page,
       so the home is real Android views fed by Java.
    ========================================================= */
    private LinearLayout homeView;
    private TextView homeUsed, homeCost, homeSpent, homeBlocked, homeOffline, homeTop, homeContinue;

    private View buildHomeView() {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);
        v.setBackgroundColor(surface());
        v.setPadding(dp(18), dp(20), dp(18), dp(18));

        TextView mark = new TextView(this);
        mark.setText("M  MERCY GX");
        mark.setTextSize(9f);
        mark.setLetterSpacing(0.2f);
        mark.setTextColor(inkDim());
        v.addView(mark);

        TextView greet = new TextView(this);
        greet.setText("Your data, in money.");
        greet.setTextSize(19f);
        greet.setTextColor(ink());
        greet.setPadding(0, dp(14), 0, dp(16));
        v.addView(greet);

        TextView cap1 = new TextView(this);
        cap1.setText("CONTINUE");
        cap1.setTextSize(8.5f);
        cap1.setLetterSpacing(0.16f);
        cap1.setTextColor(inkDim());
        v.addView(cap1);

        homeContinue = new TextView(this);
        homeContinue.setText("Nothing yet — open a page and it comes back here.");
        homeContinue.setTextSize(11f);
        homeContinue.setTextColor(inkDim());
        homeContinue.setPadding(dp(12), dp(12), dp(12), dp(12));
        homeContinue.setBackgroundColor(lightTheme() ? 0xFFEDECE8 : 0xFF111114);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        clp.topMargin = dp(6);
        v.addView(homeContinue, clp);

        TextView cap2 = new TextView(this);
        cap2.setText("TODAY");
        cap2.setTextSize(8.5f);
        cap2.setLetterSpacing(0.16f);
        cap2.setTextColor(inkDim());
        cap2.setPadding(0, dp(18), 0, dp(6));
        v.addView(cap2);

        LinearLayout budgetRow = new LinearLayout(this);
        budgetRow.setOrientation(LinearLayout.HORIZONTAL);
        budgetRow.setGravity(android.view.Gravity.CENTER_VERTICAL);

        BudgetRing r = new BudgetRing(this);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(dp(58), dp(58));
        rlp.rightMargin = dp(14);
        budgetRow.addView(r, rlp);

        LinearLayout nums = new LinearLayout(this);
        nums.setOrientation(LinearLayout.VERTICAL);
        homeUsed = new TextView(this);
        homeUsed.setText("0 MB");
        homeUsed.setTextSize(21f);
        homeUsed.setTextColor(ink());
        nums.addView(homeUsed);
        homeCost = new TextView(this);
        homeCost.setText("₹0.00 spent · 200 MB budget");
        homeCost.setTextSize(10f);
        homeCost.setTextColor(inkDim());
        homeCost.setPadding(0, dp(3), 0, 0);
        nums.addView(homeCost);
        budgetRow.addView(nums);
        v.addView(budgetRow);

        LinearLayout stats = new LinearLayout(this);
        stats.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        slp.topMargin = dp(16);
        v.addView(stats, slp);

        homeSpent = addStat(stats, "₹0.00", "spent today", accent());
        homeBlocked = addStat(stats, "0", "trackers", lightTheme() ? 0xFF1E8E4E : 0xFF3DDC84);
        v.addView(new View(this), new LinearLayout.LayoutParams(0, dp(6)));
        LinearLayout stats2 = new LinearLayout(this);
        stats2.setOrientation(LinearLayout.HORIZONTAL);
        v.addView(stats2);
        homeOffline = addStat(stats2, "0", "pages offline", inkDim());
        homeTop = addStat(stats2, "—", "heaviest site", inkDim());

        TextView foot = new TextView(this);
        foot.setText("Nothing here leaves your phone.");
        foot.setTextSize(9f);
        foot.setTextColor(inkDim());
        foot.setGravity(android.view.Gravity.CENTER);
        foot.setPadding(0, dp(22), 0, 0);
        v.addView(foot);

        return v;
    }

    private TextView addStat(LinearLayout parent, String value, String label, int colour) {
        LinearLayout cell = new LinearLayout(this);
        cell.setOrientation(LinearLayout.VERTICAL);
        cell.setPadding(dp(12), dp(12), dp(12), dp(12));
        cell.setBackgroundColor(lightTheme() ? 0xFFEDECE8 : 0xFF111114);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.rightMargin = dp(8);

        TextView v = new TextView(this);
        v.setText(value);
        v.setTextSize(15f);
        v.setTextColor(colour);
        cell.addView(v);

        TextView k = new TextView(this);
        k.setText(label);
        k.setTextSize(9f);
        k.setTextColor(inkDim());
        k.setPadding(0, dp(2), 0, 0);
        cell.addView(k);

        parent.addView(cell, lp);
        return v;
    }

    /** refresh the numbers from the ledger — called whenever the home is shown */
    private void paintHome() {
        if (homeView == null) return;
        long today = todayBytes();
        long budget = budgetBytes();
        int pct = (int) Math.min(100, budget == 0 ? 0 : today * 100 / budget);
        homeUsed.setText(human(today));
        homeCost.setText(money(today) + " spent \u00B7 " + prefs.getLong("budgetMb", 200L) + " MB budget");
        homeSpent.setText(money(today));
        homeSpent.setTextColor(today > budget ? 0xFFFF5C5C : (pct >= 60 ? 0xFFFFB020 : accent()));
        homeBlocked.setText(String.valueOf(prefs.getLong("engineBlocked", 0L)));
        homeOffline.setText(String.valueOf(readArray("offline").length()));
        String last = prefs.getString("lastHost", "");
        homeContinue.setText(last.isEmpty()
                ? "Nothing yet \u2014 open a page and it comes back here."
                : last);
        String top = heaviestHost();
        homeTop.setText(top == null ? "\u2014" : top);
        homeView.setBackgroundColor(surface());
    }

    private String heaviestHost() {
        String best = null; long most = -1;
        try {
            org.json.JSONObject ledger = new org.json.JSONObject(prefs.getString("ledger", "{}"));
            java.util.Iterator<String> it = ledger.keys();
            while (it.hasNext()) {
                String h = it.next();
                long b = ledger.optJSONObject(h) == null ? 0 : ledger.optJSONObject(h).optLong("bytes", 0);
                if (b > most) { most = b; best = h; }
            }
        } catch (Exception ignored) { }
        return most <= 0 ? null : best;
    }


    /* =========================================================
       Mercy Core — the extension that ships inside the browser.
       It is installed from the APK, never from a store, and it is
       the only way this app can look inside a page.
    ========================================================= */
    private org.mozilla.geckoview.WebExtension mercyExt;
    private String lastFacts = "";

    private void installMercyExtension(org.mozilla.geckoview.GeckoRuntime runtime) {
        try {
            org.mozilla.geckoview.WebExtensionController c = runtime.getWebExtensionController();
            if (c == null) { prefs.edit().putString("extStatus", "no controller").apply(); return; }
            c.install("resource://android/assets/extensions/mercy/")
                    .accept(new org.mozilla.geckoview.GeckoResult.OnValueListener() {
                        @Override public org.mozilla.geckoview.GeckoResult onValue(Object value) {
                            mercyExt = (org.mozilla.geckoview.WebExtension) value;
                            prefs.edit().putString("extStatus", "installed " + mercyExt.id).apply();
                            try {
                                org.mozilla.geckoview.WebExtension.MessageDelegate del =
                                        new org.mozilla.geckoview.WebExtension.MessageDelegate() {
                                    @Override public org.mozilla.geckoview.GeckoResult onMessage(
                                            Object nativeApp, Object message, Object sender) {
                                        lastFacts = String.valueOf(message);
                                        prefs.edit().putString("extLastFacts", lastFacts).apply();
                                        return null;
                                    }
                                };
                                mercyExt.setMessageDelegate(del, "browser");
                            } catch (Throwable ignored) { }
                            return null;
                        }
                    }, new org.mozilla.geckoview.GeckoResult.OnExceptionListener() {
                        @Override public org.mozilla.geckoview.GeckoResult onException(Throwable e) {
                            prefs.edit().putString("extStatus", "failed: " + e.getClass().getSimpleName()).apply();
                            return null;
                        }
                    });
        } catch (Throwable t) {
            prefs.edit().putString("extStatus", "unsupported: " + t.getClass().getSimpleName()).apply();
        }
    }

    /** what the extension last told us about this page */
    private void showPageFacts() {
        String status = prefs.getString("extStatus", "not installed");
        String facts = prefs.getString("extLastFacts", "");
        StringBuilder sb = new StringBuilder();
        sb.append("extension   ").append(status).append("\n\n");
        if (facts.isEmpty()) {
            sb.append("No page facts yet.\n");
            sb.append("Open a page, then come back.");
        } else {
            sb.append(facts);
        }
        showText("What this page contains", sb.toString());
    }


    private void showText(String title, String body) {
        android.widget.ScrollView sv = new android.widget.ScrollView(this);
        TextView tv = new TextView(this);
        tv.setText(body == null || body.isEmpty() ? "(empty)" : body);
        tv.setTextSize(11f);
        tv.setTypeface(android.graphics.Typeface.MONOSPACE);
        tv.setTextColor(ink());
        tv.setPadding(dp(14), dp(12), dp(14), dp(12));
        sv.addView(tv);
        new android.app.AlertDialog.Builder(this, R.style.MercyDialog)
                .setTitle(title)
                .setView(sv)
                .setPositiveButton("Close", null)
                .show();
    }

    private void showLedger() {
        try {
            org.json.JSONObject all = new org.json.JSONObject(prefs.getString("ledger", "{}"));
            if (all.length() == 0) { toast("No pages recorded yet"); return; }
            java.util.List<String> hosts = new java.util.ArrayList<>();
            for (java.util.Iterator<String> it = all.keys(); it.hasNext(); ) hosts.add(it.next());
            final long[] bytes = new long[hosts.size()];
            java.util.List<Integer> order = new java.util.ArrayList<>();
            for (int i = 0; i < hosts.size(); i++) {
                bytes[i] = all.optJSONObject(hosts.get(i)).optLong("bytes");
                order.add(i);
            }
            java.util.Collections.sort(order, new java.util.Comparator<Integer>() {
                @Override public int compare(Integer a, Integer b) { return Long.compare(bytes[b], bytes[a]); }
            });
            long tb = 0, tm = 0;
            StringBuilder sb = new StringBuilder();
            int shown = 0;
            for (int k = 0; k < order.size(); k++) {
                int i = order.get(k);
                org.json.JSONObject row = all.optJSONObject(hosts.get(i));
                long b = row.optLong("bytes"), m = row.optLong("ms"), v = row.optLong("visits");
                tb += b; tm += m;
                if (shown++ < 12) {
                    sb.append(hosts.get(i)).append("\n   ").append(human(b)).append(" · ")
                      .append(money(b)).append(" · ").append(humanTime(m))
                      .append(" · ").append(v).append(" visits\n\n");
                }
            }
            String header = "Total " + human(tb) + "  ·  " + money(tb) + "\n" + humanTime(tm)
                    + " browsing\n\nTariff: \u20B9" + tariffPerMb() + " per MB\n"
                    + "————————————————\n\n";
            new AlertDialog.Builder(this)
                    .setTitle("Data ledger")
                    .setMessage(header + sb.toString().trim())
                    .setPositiveButton("Close", null)
                    .setNeutralButton("Set tariff", new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface d, int w) { askTariff(); }
                    })
                    .show();
        } catch (Exception e) { toast("Ledger unavailable"); }
    }


    /* =========================================================
       offline voice — Vosk, on the phone, no Google involved
    ========================================================= */
    private void startOfflineVoice() {
        boolean granted = Build.VERSION.SDK_INT < 23
                || checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
        if (!granted) {
            pendingVoice = true;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
            return;
        }
        if (!offlineVoice.isReady()) { askVoiceModel(); return; }

        final AlertDialog[] box = new AlertDialog[1];
        box[0] = new AlertDialog.Builder(this)
                .setTitle("Offline voice")
                .setMessage("Listening…")
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { offlineVoice.stop(); }
                })
                .show();

        offlineVoice.start(new OfflineVoice.Callback() {
            @Override public void onStatus(String text) { if (box[0].isShowing()) box[0].setMessage(text); }
            @Override public void onPartial(String text) { if (box[0].isShowing()) box[0].setMessage(text); }
            @Override public void onFinal(String text) {
                if (box[0].isShowing()) box[0].dismiss();
                setChromeUrl(text);
                go(text);
            }
            @Override public void onError(String message) {
                if (box[0].isShowing()) box[0].dismiss();
                toast(message);
            }
        });
    }

    private void askVoiceModel() {
        new AlertDialog.Builder(this)
                .setTitle("Hindi voice model")
                .setMessage("Offline voice needs a one-time 42 MB download.\n\n"
                        + "After that the recognition runs on this phone: no Google, "
                        + "no server, no audio leaving the device.")
                .setPositiveButton("Download", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { downloadVoiceModel(); }
                })
                .setNegativeButton("Later", null)
                .show();
    }

    private void downloadVoiceModel() {
        final AlertDialog[] prog = new AlertDialog[1];
        prog[0] = new AlertDialog.Builder(this)
                .setTitle("Hindi voice model")
                .setMessage("Starting…")
                .setCancelable(false)
                .setNegativeButton("Hide", null)
                .show();
        offlineVoice.download(new OfflineVoice.Callback() {
            @Override public void onStatus(String text) { if (prog[0].isShowing()) prog[0].setMessage(text); }
            @Override public void onPartial(String text) { }
            @Override public void onFinal(String text) { }
            @Override public void onError(String message) {
                if (prog[0].isShowing()) prog[0].dismiss();
                toast(message);
            }
        });
    }

    private void askTariff() {
        final EditText input = new EditText(this);
        input.setText(String.valueOf(tariffPerMb()));
        input.setHint("rupees per MB, e.g. 0.01");
        input.setTextSize(14);
        new AlertDialog.Builder(this)
                .setTitle("Data tariff")
                .setMessage("Your plan's price per MB. \u20B910/GB = 0.01")
                .setView(input)
                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        prefs.edit().putString("tariff", input.getText().toString().trim()).apply();
                        toast("Tariff saved");
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showSiteInfo() {
        String url = active == null ? "" : active.url;
        boolean https = url.startsWith("https://");
        String msg = (https ? "\uD83D\uDD12 HTTPS — encrypted" : "\u26A0 Not encrypted")
                + "\n\nAddress\n" + url
                + "\n\nSecurity level: " + secLevel().toUpperCase()
                + (active != null && active.incognito ? "\nThis tab: INCOGNITO" : "")
                + (active != null && active.desktop ? "\nMode: desktop site" : "")
                + "\n\nEngine: " + engineLabel(currentEngine())
                + "\nJavaScript: " + (jsOn() ? "ON" : "OFF")
                + "\n\nThis page\n"
                + (rxAtPageStart > 0 && rxBytes() > rxAtPageStart
                        ? human(rxBytes() - rxAtPageStart) + " · " + money(rxBytes() - rxAtPageStart)
                        : "measuring…");
        new AlertDialog.Builder(this)
                .setTitle("Site information")
                .setMessage(msg)
                .setPositiveButton("Close", null)
                .show();
    }

    /* ---------------- tabs ---------------- */
    private void newTab(String url) { newTab(url, false); }

    /** the home page talks to the app through this */
    public class HomeBridge {
        @android.webkit.JavascriptInterface public void open(final String what) {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    if ("ledger".equals(what)) showLedger();
                    else if ("report".equals(what)) showReportCard();
                    else if ("offline".equals(what)) toast("Offline pages arrive with the next Pro update");
                    else if ("free".equals(what)) freeMemoryPro();
                    else if ("data".equals(what)) toggleNoImages();
                    else if ("rules".equals(what)) toast("Site rules arrive with the next Pro update");
                    else if ("proof".equals(what)) toast("Privacy proof arrives with the next Pro update");
                }
            });
        }
        @android.webkit.JavascriptInterface public void estimate(final String link) {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    String u = link.startsWith("http") ? link : "https://" + link;
                    toast("Checking " + u);
                    go(u);
                }
            });
        }
    }

    private void freeMemoryPro() {
        toast("Close hidden tabs to release memory");
    }

    private void newTab(String url, boolean incognito) {
        final Tab tab = new Tab();
        tab.id = "t" + (tabSeq++);
        tab.url = url;
        tab.incognito = incognito;
        tab.desktop = nextDesktop;
        nextDesktop = false;
        tab.title = incognito ? "Incognito" : "New tab";

        GeckoSessionSettings sessionSettings = new GeckoSessionSettings.Builder()
                .userAgentOverride(uaFor(nextDesktop))
                .usePrivateMode(incognito)          // real private browsing in GeckoView
                .allowJavascript(jsOn())
                .build();
        GeckoSession session = new GeckoSession(sessionSettings);
        session.setProgressDelegate(new GeckoSession.ProgressDelegate() {
            @Override public void onPageStart(GeckoSession s, String uri) {
                pageStartMs = System.currentTimeMillis();
                rxAtPageStart = rxBytes();
                if (uri != null) {
                    tab.url = uri;
                    boolean isCurrent = tab.idx >= 0 && tab.idx < tab.hist.size()
                            && tab.hist.get(tab.idx).equals(uri);
                    if (!isCurrent) {
                        while (tab.hist.size() > tab.idx + 1) {
                            tab.hist.remove(tab.hist.size() - 1);
                        }
                        tab.hist.add(uri);
                        tab.idx = tab.hist.size() - 1;
                    }
                    if (tab == active) updateNav();
                }
                progress.setVisibility(View.VISIBLE);
            }
            @Override public void onPageStop(GeckoSession s, boolean success) {
                progress.setVisibility(View.GONE);
                if (tab == active) {
                    setChromeUrl(tab.url);
                    applyHeaderMode(tab.url);
                    updateNav();
                }
                addHistory(tab.url, tab.title);
                recordLedger(tab.url, System.currentTimeMillis() - pageStartMs);
            }
            @Override public void onProgressChange(GeckoSession s, int p) {
                progress.setProgress(p);
                progress.setVisibility(p >= 100 ? View.GONE : View.VISIBLE);
            }
        });
        session.setContentDelegate(new GeckoSession.ContentDelegate() {
            @Override public void onTitleChange(GeckoSession s, String title) {
                if (title != null && title.length() > 0) { tab.title = title; renderStrip(); }
            }
        });

        session.open(runtime);
        tab.session = session;
        tabs.add(tab);
        select(tab);
        session.loadUri(url);
    }

    private void select(Tab tab) {
        active = tab;
        geckoView.setSession(tab.session);
        setChromeUrl(tab.url);
        updateNav();
        renderStrip();
    }

    private void closeTab(Tab tab) {
        tab.session.close();
        tabs.remove(tab);
        if (tabs.isEmpty()) { newTab(HOME); return; }
        if (tab == active) select(tabs.get(tabs.size() - 1));
        else renderStrip();
    }

    private void renderStrip() {
        for (final Tab t : tabs) {
            LinearLayout chip = new LinearLayout(this);
            chip.setOrientation(LinearLayout.HORIZONTAL);
            chip.setGravity(Gravity.CENTER_VERTICAL);
            chip.setPadding(dp(10), dp(6), dp(6), dp(6));
            chip.setBackgroundColor(t == active ? Color.parseColor("#232830") : Color.parseColor("#15181e"));

            TextView label = new TextView(this);
            String title = t.title == null ? "New tab" : t.title;
            if (title.length() > 16) title = title.substring(0, 16) + "…";
            label.setText(title);
            label.setTextSize(11);
            label.setTextColor(t == active ? Color.parseColor("#eceef1") : Color.parseColor("#98a1ac"));
            label.setSingleLine(true);
            chip.addView(label);

            TextView x = new TextView(this);
            x.setText("  ✕");
            x.setTextSize(11);
            x.setTextColor(Color.parseColor("#68717c"));
            x.setPadding(dp(6), 0, dp(2), 0);
            x.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { closeTab(t); }
            });
            chip.addView(x);

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, 0, dp(5), 0);
            chip.setLayoutParams(lp);
            chip.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { select(t); }
            });

        }
        if (btnTabs != null) btnTabs.setText(String.valueOf(tabs.size()));

    }

    /* ---------------- navigation ---------------- */
    private boolean looksLikeUrl(String s) {
        if (s.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*")) return true;
        if (s.matches("^localhost(:\\d+)?(/.*)?$")) return true;
        return s.matches("^[^\\s]+\\.[a-zA-Z]{2,}([/?#].*)?$");
    }

    private void go(String input) {
        String s = input == null ? "" : input.trim();
        if (s.isEmpty() || active == null) return;
        if (looksLikeUrl(s)) {
            String url = s.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*") ? s
                    : (s.startsWith("localhost") ? "http://" + s : "https://" + s);
            active.session.loadUri(url);
        } else {
            active.session.loadUri(searchUrl(s));
        }
        hideKeyboard();
    }


    private void goBack() {
        if (active == null || !active.canBack()) return;
        active.idx--;
        active.session.goBack();
        updateNav();
    }

    private void goForward() {
        if (active == null || !active.canForward()) return;
        active.idx++;
        active.session.goForward();
        updateNav();
    }

    /* ---------------- security level ---------------- */
    private String secLevel() {
        String v = prefs.getString("secLevel", "on");
        return (v.equals("off") || v.equals("on") || v.equals("pro")) ? v : "on";
    }
    private boolean jsOn() { return !secLevel().equals("pro"); }

    private String uaFor(boolean desktop) {
        return desktop
                ? "Mozilla/5.0 (X11; Linux x86_64; rv:128.0) Gecko/20100101 Firefox/128.0"
                : "Mozilla/5.0 (Android 13; Mobile; rv:128.0) Gecko/128.0 Firefox/128.0";
    }

    private void pickSecurityLevel() {
        final String[] levels = {"off", "on", "pro"};
        String[] labels = {
                "Off — JavaScript allowed, no strict blocking",
                "On — standard tracking protection (recommended)",
                "Pro — everything in On, plus JavaScript off"};
        int checked = secLevel().equals("off") ? 0 : secLevel().equals("pro") ? 2 : 1;
        new AlertDialog.Builder(this)
                .setTitle("Security level")
                .setSingleChoiceItems(labels, checked, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        prefs.edit().putString("secLevel", levels[which]).apply();
                        d.dismiss();
                        toast("Security level: " + levels[which].toUpperCase());
                        reopenActive();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void toggleDesktop() {
        if (active == null) return;
        active.desktop = !active.desktop;
        toast("Desktop site " + (active.desktop ? "on" : "off"));
        reopenActive();
    }

    /** Engine settings can only be set when a session is created, so changing
     *  security level or desktop mode reopens the tab with the same URL. */
    private void reopenActive() {
        if (active == null) return;
        String url = active.url;
        boolean incognito = active.incognito;
        nextDesktop = active.desktop;
        Tab old = active;
        newTab(url, incognito);
        closeTab(old);
    }

    private void updateNav() {
        boolean back = active != null && active.canBack();
        // no arrow in the header any more
    }

    /* ---------------- history ---------------- */
    private void addHistory(String url, String title) {
        if (active != null && active.incognito) return;   // private tabs leave no trace
        if (url == null || url.startsWith("file://")) return;
        try {
            JSONArray arr = new JSONArray(prefs.getString("history", "[]"));
            JSONArray out = new JSONArray();
            JSONObject o = new JSONObject();
            o.put("url", url);
            o.put("title", title == null ? url : title);
            out.put(o);
            for (int i = 0; i < arr.length() && i < 199; i++) {
                JSONObject old = arr.getJSONObject(i);
                if (!url.equals(old.optString("url"))) out.put(old);
            }
            prefs.edit().putString("history", out.toString()).apply();
        } catch (Exception ignored) { }
    }

    private void showHistory() {
        try {
            JSONArray arr = new JSONArray(prefs.getString("history", "[]"));
            if (arr.length() == 0) { toast("History is empty"); return; }
            final String[] urls = new String[arr.length()];
            final String[] titles = new String[arr.length()];
            long listBytes = 0;
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                urls[i] = o.optString("url");
                titles[i] = o.optString("title");
                String host = hostOf(urls[i]);
                org.json.JSONObject row = host == null ? null : ledgerRow(host);
                if (row != null) {
                    long b = row.optLong("bytes");
                    if (b > 0) {
                        titles[i] = titles[i] + "  \u00B7  " + human(b) + "  \u00B7  " + money(b);
                        listBytes += b;
                    }
                }
            }
            new AlertDialog.Builder(this)
                    .setTitle("History" + (listBytes > 0
                            ? "  \u00B7  " + human(listBytes) + "  \u00B7  " + money(listBytes) : ""))
                    .setItems(titles, new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface d, int which) { go(urls[which]); }
                    })
                    .setNegativeButton("Close", null)
                    .show();
        } catch (Exception e) { toast("History unavailable"); }
    }

    /* ---------------- menu ---------------- */
    private ViewGroup menuOverlay;
    private LinearLayout tabContent;
    private final java.util.List<TextView> tabLabels = new java.util.ArrayList<>();

    private void closeMenu() {
        if (menuOverlay != null) {
            try { ((ViewGroup) menuOverlay.getParent()).removeView(menuOverlay); } catch (Exception ignored) { }
            menuOverlay = null;
        }
        tabLabels.clear();
        tabContent = null;
    }





    /** design 4: one sheet, three tabs — PAGE, DATA, APP */
    private void showMenu() {
        try { buildMenu(); }
        catch (Throwable t) { toast("Menu error: " + t.getClass().getSimpleName()); }
    }

    private void buildMenu() {
        closeMenu();

        final java.util.List<java.util.List<MItem>> tabs = new java.util.ArrayList<>();

        java.util.List<MItem> page = new java.util.ArrayList<>();
        page.add(mi("\u25E7", "Diagnostics", "",
                new Runnable() { public void run() { showDiagnostics(); } }));
        page.add(mi("\u25C8", "Site rules", "", new Runnable() { public void run() { toast("Site rules are a Lite feature"); } }));
        page.add(mi("\u25C9", "Offline voice", offlineVoice != null && offlineVoice.isReady() ? "READY" : "DOWNLOAD",
                new Runnable() { public void run() { startOfflineVoice(); } }));
        page.add(mi("\u2193", "Save page offline", "", new Runnable() { public void run() { toast("Offline pages are a Lite feature"); } }));
        page.add(mi("\u25A4", "Desktop site", active != null && active.desktop ? "ON" : "OFF",
                new Runnable() { public void run() { toggleDesktop(); } }));
        page.add(mi("\u2934", "Share page", "", new Runnable() { public void run() { toast("Sharing arrives in the next Pro build"); } }));
        page.add(mi("\u26A1", "Free memory", "freeze tabs", new Runnable() { public void run() { toast("Free memory is a Lite feature"); } }));
        tabs.add(page);

        java.util.List<MItem> data = new java.util.ArrayList<>();
        data.add(mi("\u25F4", "Data budget", prefs.getLong("budgetMb", 200L) + " MB",
                new Runnable() { public void run() { askBudget(); } }));
        data.add(mi("\u25A6", "Data ledger", "", new Runnable() { public void run() { showLedger(); } }));
        data.add(mi("\u25CD", "Report card", "", new Runnable() { public void run() { showReportCard(); } }));
        data.add(mi("\u25A3", "Save data mode", prefs.getBoolean("noImages", false) ? "ON" : "OFF",
                new Runnable() { public void run() { toggleNoImages(); } }));
        data.add(mi("\u2318", "Offline pages", "", new Runnable() { public void run() { toast("Offline pages are a Lite feature"); } }));
        tabs.add(data);

        java.util.List<MItem> app = new java.util.ArrayList<>();
        app.add(mi("\uFF0B", "New tab", "", new Runnable() { public void run() { newTab(HOME); } }));
        app.add(mi("\u25D0", "New incognito tab", "", new Runnable() { public void run() { newTab(HOME, true); } }));
        app.add(mi("\u2605", "Bookmark this page", "", new Runnable() { public void run() { toast("Bookmarks are a Lite feature"); } }));
        app.add(mi("\u25F7", "Bookmarks", "", new Runnable() {
            public void run() { toast("Bookmarks are a Lite feature"); } }));
        app.add(mi("\u25F7", "History", "", new Runnable() {
            public void run() { showHistory(); } }));
        app.add(mi("\u26E8", "Security level", secLevel().toUpperCase(),
                new Runnable() { public void run() { pickSecurityLevel(); } }));
        app.add(mi("\u2713", "Privacy proof", "", new Runnable() { public void run() { toast("Privacy proof arrives in a later Pro build"); } }));
        app.add(mi("\u26A0", "Diagnostics", "", new Runnable() { public void run() { showDiagnostics(); } }));
        app.add(mi("\u2318", "Dev panel", "console", new Runnable() { public void run() { showDevPanel(); } }));
        app.add(mi("\u2713", "Self test", "health", new Runnable() { public void run() { showDiagnostics(); } }));
        app.add(mi("\u21BB", "Check for updates", "", new Runnable() {
            public void run() { Updater.check(MainActivity.this, false); } }));
        app.add(mi("\u24D8", "About Mercy GX", "", new Runnable() { public void run() { about(); } }));
        app.add(mi("\u2620", "Panic wipe", "3 locks", new Runnable() { public void run() { startPanicSequence(); } }));
        tabs.add(app);

        final String[] names = {"PAGE", "DATA", "APP"};

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        View scrim = new View(this);
        scrim.setBackgroundColor(0xCC000000);
        scrim.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { closeMenu(); }
        });
        root.addView(scrim, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout sheet = new LinearLayout(this);
        sheet.setOrientation(LinearLayout.VERTICAL);
        sheet.setBackgroundColor(0xFF0B0B0D);

        View grab = new View(this);
        grab.setBackgroundColor(0xFF2A2A31);
        LinearLayout.LayoutParams glp = new LinearLayout.LayoutParams(dp(30), dp(3));
        glp.topMargin = dp(8);
        glp.bottomMargin = dp(2);
        glp.gravity = android.view.Gravity.CENTER_HORIZONTAL;
        sheet.addView(grab, glp);

        LinearLayout tabRow = new LinearLayout(this);
        tabRow.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < names.length; i++) {
            final int index = i;
            final TextView t = new TextView(this);
            t.setText(names[i]);
            t.setTextSize(9.5f);
            t.setGravity(android.view.Gravity.CENTER);
            t.setPadding(0, dp(11), 0, dp(11));
            t.setTextColor(0xFF5C5C66);
            t.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { showTab(index, tabs, names); }
            });
            tabRow.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            tabLabels.add(t);
        }
        sheet.addView(tabRow);

        View divider = new View(this);
        divider.setBackgroundColor(0x14FFFFFF);
        sheet.addView(divider, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1));

        android.widget.ScrollView sv = new android.widget.ScrollView(this);
        tabContent = new LinearLayout(this);
        tabContent.setOrientation(LinearLayout.VERTICAL);
        sv.addView(tabContent);
        sheet.addView(sv, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(300)));

        root.addView(sheet, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        ViewGroup menuHost = findViewById(android.R.id.content);
        menuOverlay = root;
        menuHost.addView(root, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        showTab(0, tabs, names);
    }

    private void showTab(int index, java.util.List<java.util.List<MItem>> tabs, String[] names) {
        if (tabContent == null) return;
        for (int i = 0; i < tabLabels.size(); i++) {
            tabLabels.get(i).setTextColor(i == index ? 0xFFA06BFF : 0xFF5C5C66);
        }
        tabContent.removeAllViews();
        for (final MItem it : tabs.get(index)) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(android.view.Gravity.CENTER_VERTICAL);
            row.setPadding(dp(16), dp(13), dp(16), dp(13));

            TextView g = new TextView(this);
            g.setText(it.glyph);
            g.setTextSize(11f);
            g.setTextColor("\u2620".equals(it.glyph) ? 0xFFFF5C5C : 0xFF8B8B95);
            g.setWidth(dp(20));
            row.addView(g);

            TextView l = new TextView(this);
            l.setText(it.label);
            l.setTextSize(12f);
            l.setTextColor("\u2620".equals(it.glyph) ? 0xFFFF5C5C : 0xFFF4F4F6);
            l.setPadding(dp(6), 0, 0, 0);
            row.addView(l, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            if (it.value != null && !it.value.isEmpty()) {
                TextView v = new TextView(this);
                v.setText(it.value);
                v.setTextSize(9f);
                v.setTextColor(0xFF5C5C66);
                row.addView(v);
            }

            row.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View view) {
                    closeMenu();
                    new android.os.Handler(getMainLooper()).postDelayed(it.action, 120);
                }
            });
            tabContent.addView(row);

            View line = new View(this);
            line.setBackgroundColor(0x0FFFFFFF);
            tabContent.addView(line, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1));
        }

        TextView foot = new TextView(this);
        foot.setText("TODAY " + human(todayBytes()) + " \u00B7 " + money(todayBytes())
                + "  \u00B7  Nothing here leaves your phone.");
        foot.setTextSize(8.5f);
        foot.setPadding(dp(16), dp(14), dp(16), dp(20));
        foot.setTextColor(0xFF5C5C66);
        tabContent.addView(foot);
    }


    private void about() {
        String ver;
        try { ver = getPackageManager().getPackageInfo(getPackageName(), 0).versionName; }
        catch (Exception e) { ver = "?"; }
        new AlertDialog.Builder(this)
                .setTitle("Mercy GX")
                .setMessage("Version " + ver + "\n\n"
                        + "Mercy Core \u2014 hardened GeckoView\n"
                        + "The engine is Mozilla's GeckoView, bundled with the app. We do not claim otherwise; "
                        + "what we do is strip it down: tracking protection, third-party "
                        + "cookies isolated, no telemetry of any kind, and a dev panel that "
                        + "shows the page as the engine sees it.\n\n"
                        + "Honest note: the HTTPS-only switch is enforced in Mercy Lite; in Pro "
                        + "the engine decides, and this build does not upgrade http links.\n\n"
                        + "What that buys you: no analytics, no account, no crash uploads, "
                        + "and a privacy screen that lists every request this app makes.\n\n"
                        + "Mercy and the Mercy mark are trademarks of Sk Inventor.")
                .setPositiveButton("Close", null)
                .show();
    }


    /* ---------------- helpers ---------------- */
    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }
    private void toast(String m) { Toast.makeText(this, m, Toast.LENGTH_SHORT).show(); }
    private void hideKeyboard() {
        InputMethodManager im = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (im != null && getCurrentFocus() != null) {
            im.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
        }
    }

    @Override
    public void onBackPressed() {
        if (menuOverlay != null) { closeMenu(); return; }
        if (active != null && active.canBack()) { goBack(); return; }
        if (tabs.size() > 1) { closeTab(active); return; }
        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        for (Tab t : tabs) t.session.close();
        tabs.clear();
        super.onDestroy();
    }
}
