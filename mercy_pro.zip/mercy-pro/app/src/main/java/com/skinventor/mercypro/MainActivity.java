package com.skinventor.mercypro;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;
import org.mozilla.geckoview.GeckoResult;
import org.mozilla.geckoview.GeckoRuntime;
import org.mozilla.geckoview.GeckoRuntimeSettings;
import org.mozilla.geckoview.GeckoSession;
import org.mozilla.geckoview.GeckoSessionSettings;
import org.mozilla.geckoview.GeckoView;

import java.util.ArrayList;
import java.util.List;

/**
 * Mercy Pro — GeckoView (Firefox engine) browser shell.
 *
 * Tabs = one GeckoSession each; a single GeckoView swaps between them.
 * Content blocking (ads, analytics, social, trackers) is done by the engine itself.
 */
public class MainActivity extends Activity {

    private static final String HOME = "file:///android_asset/newtab.html";
    private static final String PREFS = "mercy_pro";

    private GeckoRuntime runtime;
    private GeckoView geckoView;
    private final List<Tab> tabs = new ArrayList<>();
    private Tab active;
    private int tabSeq = 1;

    private EditText urlBar;
    private ProgressBar progress;
    private LinearLayout strip;
    private HorizontalScrollView stripScroll;
    private TextView tabCount;
    private TextView engineBtn;
    private android.widget.Button btnBack, btnFwd;

    private SharedPreferences prefs;

    private static class Tab {
        String id;
        GeckoSession session;
        String url = HOME;
        String title = "New tab";
    }

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        geckoView = findViewById(R.id.gecko);
        urlBar = findViewById(R.id.url);
        progress = findViewById(R.id.progress);
        strip = findViewById(R.id.tabstrip);
        stripScroll = findViewById(R.id.tabscroll);
        tabCount = findViewById(R.id.tabCount);
        engineBtn = findViewById(R.id.engineBtn);
        btnBack = findViewById(R.id.btnBack);
        btnFwd = findViewById(R.id.btnForward);

        // engine settings: private by default, ad + tracker blocking on
        // Keep this minimal: GeckoView's defaults already enable standard tracking
        // protection, and this API surface is stable across engine versions.
        GeckoRuntimeSettings settings = new GeckoRuntimeSettings.Builder()
                .javaScriptEnabled(true)
                .remoteDebuggingEnabled(false)
                .build();

        runtime = GeckoRuntime.create(this, settings);

        wireToolbar();
        paintEngine();

        String start = HOME;
        Uri incoming = getIntent() == null ? null : getIntent().getData();
        if (incoming != null && incoming.getScheme() != null
                && (incoming.getScheme().equals("http") || incoming.getScheme().equals("https"))) {
            start = incoming.toString();
        }
        newTab(start);
    }

    /* ---------------- toolbar ---------------- */
    private void wireToolbar() {
        findViewById(R.id.btnGo).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { go(urlBar.getText().toString()); }
        });
        findViewById(R.id.btnHome).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { newTab(HOME); }
        });
        findViewById(R.id.btnNewTab).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { newTab(HOME); }
        });
        findViewById(R.id.btnMenu).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showMenu(); }
        });
        engineBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showEnginePicker(); }
        });
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (active != null) active.session.goBack();
            }
        });
        btnFwd.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (active != null) active.session.goForward();
            }
        });
        urlBar.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_DONE
                        || (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                    go(urlBar.getText().toString());
                    return true;
                }
                return false;
            }
        });
    }

    /* ---------------- tabs ---------------- */
    private void newTab(String url) {
        final Tab tab = new Tab();
        tab.id = "t" + (tabSeq++);
        tab.url = url;

        GeckoSessionSettings sessionSettings = new GeckoSessionSettings.Builder()
                .userAgentOverride("Mozilla/5.0 (Android 13; Mobile; rv:128.0) Gecko/128.0 Firefox/128.0")
                .build();
        GeckoSession session = new GeckoSession(sessionSettings);
        session.setProgressDelegate(new GeckoSession.ProgressDelegate() {
            @Override public void onPageStart(GeckoSession s, String uri) {
                if (uri != null) tab.url = uri;
                progress.setVisibility(View.VISIBLE);
            }
            @Override public void onPageStop(GeckoSession s, boolean success) {
                progress.setVisibility(View.GONE);
                if (tab == active) { urlBar.setText(tab.url); updateNav(); }
                addHistory(tab.url, tab.title);
            }
            @Override public void onProgressChange(GeckoSession s, int p) {
                progress.setProgress(p);
                progress.setVisibility(p >= 100 ? View.GONE : View.VISIBLE);
            }
        });
        session.setContentDelegate(new GeckoSession.ContentDelegate() {
            @Override public void onTitleChange(GeckoSession s, String title) {
                if (title != null && title.length() > 0) { tab.title = title; renderStrip(); }
            }
        });

        session.open(runtime);
        tab.session = session;
        tabs.add(tab);
        select(tab);
        session.loadUri(url);
    }

    private void select(Tab tab) {
        active = tab;
        geckoView.setSession(tab.session);
        urlBar.setText(tab.url);
        updateNav();
        renderStrip();
    }

    private void closeTab(Tab tab) {
        tab.session.close();
        tabs.remove(tab);
        if (tabs.isEmpty()) { newTab(HOME); return; }
        if (tab == active) select(tabs.get(tabs.size() - 1));
        else renderStrip();
    }

    private void renderStrip() {
        strip.removeAllViews();
        for (final Tab t : tabs) {
            LinearLayout chip = new LinearLayout(this);
            chip.setOrientation(LinearLayout.HORIZONTAL);
            chip.setGravity(Gravity.CENTER_VERTICAL);
            chip.setPadding(dp(10), dp(6), dp(6), dp(6));
            chip.setBackgroundColor(t == active ? Color.parseColor("#232830") : Color.parseColor("#15181e"));

            TextView label = new TextView(this);
            String title = t.title == null ? "New tab" : t.title;
            if (title.length() > 16) title = title.substring(0, 16) + "…";
            label.setText(title);
            label.setTextSize(11);
            label.setTextColor(t == active ? Color.parseColor("#eceef1") : Color.parseColor("#98a1ac"));
            label.setSingleLine(true);
            chip.addView(label);

            TextView x = new TextView(this);
            x.setText("  ✕");
            x.setTextSize(11);
            x.setTextColor(Color.parseColor("#68717c"));
            x.setPadding(dp(6), 0, dp(2), 0);
            x.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { closeTab(t); }
            });
            chip.addView(x);

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, 0, dp(5), 0);
            chip.setLayoutParams(lp);
            chip.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { select(t); }
            });
            strip.addView(chip);
        }
        tabCount.setText(String.valueOf(tabs.size()));
        stripScroll.post(new Runnable() {
            @Override public void run() { stripScroll.fullScroll(View.FOCUS_RIGHT); }
        });
    }

    /* ---------------- navigation ---------------- */
    private boolean looksLikeUrl(String s) {
        if (s.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*")) return true;
        if (s.matches("^localhost(:\\d+)?(/.*)?$")) return true;
        return s.matches("^[^\\s]+\\.[a-zA-Z]{2,}([/?#].*)?$");
    }

    private void go(String input) {
        String s = input == null ? "" : input.trim();
        if (s.isEmpty() || active == null) return;
        if (looksLikeUrl(s)) {
            String url = s.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*") ? s
                    : (s.startsWith("localhost") ? "http://" + s : "https://" + s);
            active.session.loadUri(url);
        } else {
            active.session.loadUri(searchUrl(s));
        }
        hideKeyboard();
    }


    /* =========================================================
       search engine chooser (Mercy + the usual suspects)
    ========================================================= */
    private static final String[] ENGINE_IDS = {"mercy", "ddg", "brave", "bing", "startpage", "ecosia", "google"};

    private String engineLabel(String id) {
        switch (id) {
            case "mercy": return "Mercy — own index";
            case "brave": return "Brave Search";
            case "bing": return "Bing";
            case "startpage": return "Startpage";
            case "ecosia": return "Ecosia";
            case "google": return "Google";
            default: return "DuckDuckGo";
        }
    }

    private String engineLetter(String id) {
        switch (id) {
            case "mercy": return "M";
            case "brave": return "B";
            case "bing": return "b";
            case "startpage": return "S";
            case "ecosia": return "E";
            case "google": return "G";
            default: return "D";
        }
    }

    private String engineColor(String id) {
        switch (id) {
            case "mercy": return "#e08a3c";
            case "brave": return "#fb542b";
            case "bing": return "#00a4ef";
            case "startpage": return "#6b7f8f";
            case "ecosia": return "#2f9e5f";
            case "google": return "#4285f4";
            default: return "#de5833";
        }
    }

    private String currentEngine() {
        String id = prefs.getString("engine", "ddg");
        for (String e : ENGINE_IDS) if (e.equals(id)) return id;
        return "ddg";
    }

    private void paintEngine() {
        String id = currentEngine();
        engineBtn.setText(engineLetter(id) + " \u25BE");
        try { engineBtn.setTextColor(android.graphics.Color.parseColor(engineColor(id))); }
        catch (Exception ignored) { }
    }

    private void showEnginePicker() {
        final String[] labels = new String[ENGINE_IDS.length];
        String cur = currentEngine();
        int checked = 0;
        for (int i = 0; i < ENGINE_IDS.length; i++) {
            labels[i] = engineLabel(ENGINE_IDS[i]);
            if (ENGINE_IDS[i].equals(cur)) checked = i;
        }
        new android.app.AlertDialog.Builder(this)
                .setTitle("Search engine")
                .setSingleChoiceItems(labels, checked, new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int which) {
                        prefs.edit().putString("engine", ENGINE_IDS[which]).apply();
                        paintEngine();
                        d.dismiss();
                        if (ENGINE_IDS[which].equals("mercy") && prefs.getString("mercyUrl", "").isEmpty()) {
                            askMercyUrl();
                        }
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void askMercyUrl() {
        final android.widget.EditText input = new android.widget.EditText(this);
        input.setHint("https://your-search.onrender.com/search");
        input.setText(prefs.getString("mercyUrl", ""));
        input.setTextSize(13);
        new android.app.AlertDialog.Builder(this)
                .setTitle("Mercy engine URL")
                .setMessage("Apne search server ka /search endpoint daalo. Khali chhodo to DuckDuckGo use hoga.")
                .setView(input)
                .setPositiveButton("Save", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int w) {
                        prefs.edit().putString("mercyUrl", input.getText().toString().trim()).apply();
                        toast("Saved");
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private String searchUrl(String q) {
        String enc = android.net.Uri.encode(q);
        String id = currentEngine();
        switch (id) {
            case "mercy": {
                String base = prefs.getString("mercyUrl", "").trim();
                if (base.isEmpty()) {
                    toast("Mercy engine URL set nahi hai — DuckDuckGo use ho raha hai");
                    return "https://duckduckgo.com/?q=" + enc;
                }
                return base + (base.contains("?") ? "&q=" : "?q=") + enc;
            }
            case "brave": return "https://search.brave.com/search?q=" + enc;
            case "bing": return "https://www.bing.com/search?q=" + enc;
            case "startpage": return "https://www.startpage.com/sp/search?query=" + enc;
            case "ecosia": return "https://www.ecosia.org/search?q=" + enc;
            case "google": return "https://www.google.com/search?q=" + enc;
            default: return "https://duckduckgo.com/?q=" + enc;
        }
    }

    private void updateNav() {
        boolean back = active != null && Boolean.TRUE.equals(active.session.canGoBack());
        boolean fwd = active != null && Boolean.TRUE.equals(active.session.canGoForward());
        btnBack.setEnabled(back); btnBack.setAlpha(back ? 1f : 0.3f);
        btnFwd.setEnabled(fwd); btnFwd.setAlpha(fwd ? 1f : 0.3f);
    }

    /* ---------------- history ---------------- */
    private void addHistory(String url, String title) {
        if (url == null || url.startsWith("file://")) return;
        try {
            JSONArray arr = new JSONArray(prefs.getString("history", "[]"));
            JSONArray out = new JSONArray();
            JSONObject o = new JSONObject();
            o.put("url", url);
            o.put("title", title == null ? url : title);
            out.put(o);
            for (int i = 0; i < arr.length() && i < 199; i++) {
                JSONObject old = arr.getJSONObject(i);
                if (!url.equals(old.optString("url"))) out.put(old);
            }
            prefs.edit().putString("history", out.toString()).apply();
        } catch (Exception ignored) { }
    }

    private void showHistory() {
        try {
            JSONArray arr = new JSONArray(prefs.getString("history", "[]"));
            if (arr.length() == 0) { toast("History is empty"); return; }
            final String[] urls = new String[arr.length()];
            final String[] titles = new String[arr.length()];
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                urls[i] = o.optString("url");
                titles[i] = o.optString("title");
            }
            new AlertDialog.Builder(this)
                    .setTitle("History")
                    .setItems(titles, new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface d, int which) { go(urls[which]); }
                    })
                    .setNegativeButton("Close", null)
                    .show();
        } catch (Exception e) { toast("History unavailable"); }
    }

    /* ---------------- menu ---------------- */
    private void showMenu() {
        String[] items = {"New tab", "History", "Clear browsing data", "About Mercy Pro"};
        new AlertDialog.Builder(this)
                .setTitle("Mercy Pro")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        switch (which) {
                            case 0: newTab(HOME); break;
                            case 1: showHistory(); break;
                            case 2:
                                prefs.edit().clear().apply();
                                if (active != null) active.session.reload();
                                toast("Cleared");
                                break;
                            case 3: about(); break;
                        }
                    }
                })
                .setNegativeButton("Close", null)
                .show();
    }

    private void about() {
        new AlertDialog.Builder(this)
                .setTitle("Mercy Pro 2.0")
                .setMessage("A full-featured browser for Android, powered by GeckoView — "
                        + "the same engine Firefox for Android uses.\n\n"
                        + "Tabs, content blocking (ads, analytics, social, trackers), "
                        + "history, HTTPS-first loading.\n\n"
                        + "This build is large because the engine ships inside the app.")
                .setPositiveButton("OK", null)
                .show();
    }

    /* ---------------- helpers ---------------- */
    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }
    private void toast(String m) { Toast.makeText(this, m, Toast.LENGTH_SHORT).show(); }
    private void hideKeyboard() {
        InputMethodManager im = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (im != null) im.hideSoftInputFromWindow(urlBar.getWindowToken(), 0);
        urlBar.clearFocus();
    }

    @Override
    public void onBackPressed() {
        if (active != null && Boolean.TRUE.equals(active.session.canGoBack())) {
            active.session.goBack();
            return;
        }
        if (tabs.size() > 1) { closeTab(active); return; }
        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        for (Tab t : tabs) t.session.close();
        tabs.clear();
        super.onDestroy();
    }
}
