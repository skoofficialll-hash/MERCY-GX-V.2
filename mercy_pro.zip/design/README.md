# design references — not shipped in the APK

`chrome.html` and `newtab.html` were the native-shell interface from before the
HTML interface (`assets/ui.html`) took over every screen. Nothing loads them:

* `chrome.html` calls `MercyNative.*`, `paintEngine()`, `closeSug()`, `closePops()`,
  `engineById()`, `store()`, `syncTyping()` — none of those functions exist anywhere
  in the project, so the page is dead *and* broken.
* `newtab.html` is a design mock of the home screen; `ui.html` has its own.

They were 49 KB of dead weight inside every APK, and a reviewer opening the zip would
find a broken page in it. Kept here as design references instead.

`assets/kaam.json` stays: `ui.html` fetches it at runtime.
