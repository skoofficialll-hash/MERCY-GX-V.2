# Device-aware site options

The rule you gave, implemented exactly:

| The device you are on | What the menu offers |
|---|---|
| Phone (under 600 dp) | **Desktop site** + **Tablet site** |
| Tablet (600–839 dp) | **Desktop site** + **Mobile site** |
| Desktop / ChromeOS (840 dp and up) | **Mobile site** + **Tablet site** |

The version you are already on is never listed — it would be a dead option.

How it decides: `deviceClass()` reads `screenWidthDp` from the current
configuration, so it follows rotation and folding, and the menu is rebuilt every time
it opens. The choice itself lives in `uaMode` (mobile / tablet / desktop), is applied
to the engine straight away, reloads the page in place, and survives a restart.

First run now defaults to the site version that matches the device — a tablet opens
tablet sites, a phone opens phone sites — instead of always "mobile".

Each row toggles: tapping "Desktop site" on a phone switches to the desktop user-agent
and the row reads ON; tapping again returns to the phone version. The same for tablet.

Glyphs are distinct per row (▤ desktop, ▭ tablet, ▯ mobile) — no two menu rows share a
symbol.
