# Missing and half-finished features — with the fix for each

Status legend: **done** · **half** (exists but limited) · **missing** · **fixed now**

| # | Feature | Status | What is actually there |
|---|---|---|---|
| 1 | Privacy proof | **fixed now** | the bridge showed "coming later" while `showProof()` already existed |
| 2 | Offline pages | **fixed now** | same — `showOfflinePages()` existed, the button was dead |
| 3 | Site rules / filters | **fixed now** | `showFilterList()` existed, the button was dead |
| 4 | OCR, Latin, clean text | **half** | rebuilt: templates from the device font, 90 % on rendered text |
| 5 | OCR, Hindi / Devanagari | **missing** | charset is A–Z a–z 0–9 only |
| 6 | OCR on camera photos | **missing** | template matching needs straight, even lighting |
| 7 | Speech (read aloud) | **half** | formant buzz, not speech |
| 8 | Translation | **half** | 23-word transliteration table |
| 9 | GeckoView engine | **half** | code present, never run; the switch was dead twice |
| 10 | Voice search (Vosk) | **half** | needs a model download |
| 11 | Menu size | **half** | ~35 rows, many for developers |
| 12 | First-run flow | **half** | four questions before browsing |

## Fix for #5 and #6 — Hindi OCR

**Option A — ML Kit, Devanagari (fastest to ship, but it is Google).**
`com.google.mlkit:text-recognition-devanagari:16.0.1` — about 4 MB per script per
architecture when bundled, or ~260 KB if the model is fetched through Google Play
Services. Runs on the device, offline, requires minSdk 23. Hindi, Marathi, Nepali and
Sanskrit are all covered by the Devanagari model.
Source: developers.google.com/ml-kit/vision/text-recognition/v2/android

**Option B — Tesseract4Android (independent, heavier).**
`cz.adaptech.tesseract4android:tesseract4android:4.9.0` from JitPack, plus
`hin.traineddata` in a `tessdata` folder the app can read (on API 29+ that means the
app's own files dir, copied out of assets on first run). Devanagari needs the shiro-rekha
splitter: `pageseg_devanagari_split_strategy 1`. Slower on low-end phones, but fully
offline and not Google.
Source: github.com/adaptech-cz/Tesseract4Android · deepwiki.com/tesseract-ocr/tessdata

**Option C — keep it ours.** Improve the template matcher for Devanagari: the line model
has to handle the shiro rekha and matras, which means segmentation by the headline row
first, then per-glyph matching below it. Doable, but it is a real project, not an
afternoon.

## Fix for #7 — speech that people can understand

Use the phone's own engine, no library:
`TextToSpeech`, and only trust a voice after checking all three:
`isLanguageAvailable()` returns AVAILABLE, `getVoice().getFeatures()` does **not**
contain `KEY_FEATURE_NOT_INSTALLED`, and `isNetworkConnectionRequired()` is false.
Set the language only after `onInit()` returns SUCCESS — Hindi (hi-IN) offline voices are
common but not universal, so keep a "this phone has no Hindi voice" message instead of
falling back to a buzz.
Source: developer.android.com/reference/android/speech/tts/TextToSpeech

## Fix for #8 — translation
There is no honest offline translator small enough to bundle. Either remove the claim,
or ship a dictionary of a few thousand common words and call it a dictionary.

## Fix for #9 — the second engine
Remove GeckoView. It is ~60 MB, needs a separate Maven repo, and it is the feature that
has failed the testers twice. The system WebView is already in the app and is the one
users' phones are tuned for.

## Fix for #10 — voice search
Vosk needs a model file in assets or a first-run download. If the model is not there,
say "voice search needs a one-time download" instead of failing silently.

## Order I would ship in
1. The three dead buttons — done in this build.
2. Drop GeckoView, shrink the menu to ten rows, two-step first run.
3. Hindi OCR — Option A if Google is acceptable, Option B if not.
4. Speech through the phone's own engine.
5. Remove the translation claim.
