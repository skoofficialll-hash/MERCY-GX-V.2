const {JSDOM, VirtualConsole} = require('jsdom');
const fs = require('fs');
const path = process.argv[2];
const html = fs.readFileSync(path, 'utf8');
const errors = [];
const vc = new VirtualConsole();
vc.on('jsdomError', e => errors.push('jsdomError: ' + (e.detail && e.detail.stack ? e.detail.stack.split('\n').slice(0,3).join(' | ') : e.message)));
vc.on('error', (...a) => errors.push('console.error: ' + a.join(' ')));
const calls = new Set();
const mercy = new Proxy({}, {get: (t, k) => { if (k === 'then') return undefined; return (...args) => { calls.add(String(k)); return ''; }; }});
const dom = new JSDOM(html, {runScripts: 'dangerously', pretendToBeVisual: true, virtualConsole: vc,
  beforeParse(win) {
    win.Mercy = mercy;
    win.addEventListener('error', e => errors.push('window.error: ' + e.message));
    win.navigator.vibrate = () => {};
    win.matchMedia = win.matchMedia || (() => ({matches:false, addEventListener(){}, addListener(){}}));
    win.requestAnimationFrame = cb => setTimeout(() => cb(Date.now()), 0);
  }});
const win = dom.window, doc = win.document;
setTimeout(()=>{},0);
// inline handlers referencing undefined functions
const bad = new Set();
doc.querySelectorAll('*').forEach(el => {
  for (const attr of el.getAttributeNames()) {
    if (!/^on/.test(attr)) continue;
    const code = el.getAttribute(attr);
    const ids = [...code.matchAll(/(^|[^.\w$])([A-Za-z_$][\w$]*)\s*\(/g)].map(m => m[2]);
    for (const id of ids) {
      if (['if','for','while','switch','catch','return','typeof','function','parseInt','parseFloat','String','Number','alert','confirm','console','setTimeout','setInterval','encodeURIComponent','decodeURIComponent','JSON','Math','Object','Array','Promise','RegExp','Date','Boolean'].includes(id)) continue;
      if (typeof win[id] !== 'function') bad.add(attr + ' -> ' + id);
    }
  }
});
// getElementById targets that do not exist
const missing = new Set();
const scriptText = [...doc.querySelectorAll('script')].map(s => s.textContent).join('\n');
for (const m of scriptText.matchAll(/getElementById\(['"]([^'"]+)['"]\)/g)) {
  if (!doc.getElementById(m[1])) missing.add(m[1]);
}
for (const m of scriptText.matchAll(/querySelector(?:All)?\(['"]#([\w-]+)['"]\)/g)) {
  if (!doc.getElementById(m[1])) missing.add('#' + m[1]);
}
// declared function names in script
const declared = new Set([...scriptText.matchAll(/function\s+([A-Za-z_$][\w$]*)/g)].map(m=>m[1]));
console.log(JSON.stringify({file: path, errors: errors.slice(0,20), errorCount: errors.length,
  badHandlers: [...bad], missingIds: [...missing], mercyCalls: [...calls].sort(), declaredFunctions: declared.size}, null, 1));

dom.window.close();
process.exit(0);
