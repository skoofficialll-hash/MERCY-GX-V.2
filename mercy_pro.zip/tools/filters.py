#!/usr/bin/env python3
"""Ten filters that the earlier passes did not run. Prints one findings table."""
import re, os, glob, json, sys
from collections import defaultdict, Counter

ROOT = 'mercy/app/src/main'
JAVA = glob.glob(ROOT + '/java/**/*.java', recursive=True)
ASSETS = ROOT + '/assets'
out = []
def add(sev, tag, detail):
    out.append((sev, tag, detail))

java = {f: open(f).read() for f in JAVA}
alljava = '\n'.join(java.values())

# ---------- A. prefs keys: read but never written (the "daily" bug class) ----------
reads = set(re.findall(r'prefs\.get\w+\("([\w_]+)"', alljava))
writes = set(re.findall(r'prefs\.edit\(\)[\s\S]{0,200}?\.put\w+\("([\w_]+)"', alljava))
writes |= set(re.findall(r'\.put\w+\("([\w_]+)"', alljava))
writes |= set(re.findall(r'remove\("([\w_]+)"', alljava))
for k in sorted(reads - writes):
    add('P1', 'prefs-read-never-written', k)
# other prefs objects (Updater uses its own)
up = java.get(ROOT + '/java/com/skinventor/mercypro/Updater.java', '')
u_reads = set(re.findall(r'p\.get\w+\("([\w_]+)"', up)); u_writes = set(re.findall(r'put\w+\("([\w_]+)"', up))
for k in sorted(u_reads - u_writes):
    add('P1', 'prefs-read-never-written(updater)', k)

# ---------- B. asset references vs files ----------
refs = set(re.findall(r'getAssets\(\)\.open\("([^"]+)"', alljava))
refs |= set(re.findall(r'resource://android/assets/([^"\\]+)', alljava))
refs |= set(re.findall(r'android_asset/([^"\\]+)', alljava))
refs |= set(re.findall(r'Io\.readAsset(?:Bytes)?\([^,]+,\s*"([^"]+)"', alljava))
for r in sorted(refs):
    if not os.path.exists(os.path.join(ASSETS, r)):
        add('P0', 'asset-missing', r)
on_disk = set()
for p in glob.glob(ASSETS + '/**/*', recursive=True):
    if os.path.isfile(p):
        on_disk.add(os.path.relpath(p, ASSETS))
unused = sorted(d for d in on_disk if not any(d in r or r in d for r in refs))
for d in unused:
    add('P2', 'asset-never-loaded', '%s (%d KB)' % (d, os.path.getsize(os.path.join(ASSETS, d)) // 1024))

# ---------- C/D. duplicate ids and duplicate JS function names ----------
for f in glob.glob(ASSETS + '/*.html'):
    src = open(f).read()
    ids = re.findall(r'\sid="([\w-]+)"', src)
    for i, c in Counter(ids).items():
        if c > 1:
            add('P1', 'duplicate-html-id', '%s: %s x%d' % (os.path.basename(f), i, c))
    fns = re.findall(r'function\s+([A-Za-z_$][\w$]*)', src)
    for n, c in Counter(fns).items():
        if c > 1:
            add('P1', 'duplicate-js-function', '%s: %s x%d' % (os.path.basename(f), n, c))

# ---------- E. CSS selectors declared twice with different bodies ----------
for f in glob.glob(ASSETS + '/*.html'):
    src = open(f).read()
    m = re.search(r'<style[^>]*>(.*?)</style>', src, re.S)
    if not m: continue
    body = m.group(1)
    decl = defaultdict(list)
    for sel, block in re.findall(r'([^{}@/]+)\{([^{}]*)\}', body):
        sel = ' '.join(sel.split())
        if not sel or sel.startswith(('from', 'to', '0%', '100%', '50%', '60%')): continue
        decl[sel].append(' '.join(block.split()))
    for sel, blocks in decl.items():
        if len(blocks) > 1 and len(set(blocks)) > 1:
            add('P3', 'css-selector-drift', '%s: %s (%d versions)' % (os.path.basename(f), sel[:40], len(blocks)))

# ---------- F. hardcoded user-facing English in Java ----------
lit = re.findall(r'(?:toast|setTitle|setMessage|setHint|setText)\("([^"]{12,})"', alljava)
add('P3', 'java-hardcoded-ui-strings', '%d strings (localisation gap)' % len(lit))

# ---------- G. clickable views without contentDescription ----------
clicks = len(re.findall(r'setOnClickListener', alljava))
descs = len(re.findall(r'setContentDescription', alljava))
add('P2', 'a11y-missing-contentDescription', '%d click listeners, %d contentDescription' % (clicks, descs))

# ---------- H. silent catch blocks ----------
silent = 0
for f, s in java.items():
    for m in re.finditer(r'catch\s*\([^)]*\)\s*\{([^{}]{0,200})\}', s):
        b = m.group(1).strip()
        if b == '' or b in ('// ignore', '/* ignore */', ';'):
            silent += 1
add('P2', 'silent-catch', '%d empty catch blocks' % silent)

# ---------- I. TODO / fake / unimplemented markers ----------
for f, s in java.items():
    for i, line in enumerate(s.split('\n'), 1):
        if re.search(r'\b(TODO|FIXME|XXX|HACK|not implemented|pseudo-random|fake)\b', line, re.I):
            add('P2', 'marker', '%s:%d %s' % (os.path.basename(f), i, line.strip()[:80]))

# ---------- J. very long methods ----------
for f, s in java.items():
    lines = s.split('\n')
    for i, line in enumerate(lines):
        m = re.match(r'\s{4}(?:public|private|protected)[\w\s<>,\[\]\.]*\s(\w+)\([^;]*\)\s*\{', line)
        if not m: continue
        depth = 0
        for j in range(i, len(lines)):
            depth += lines[j].count('{') - lines[j].count('}')
            if depth == 0:
                if j - i > 150:
                    add('P3', 'long-method', '%s:%d %s() = %d lines' % (os.path.basename(f), i + 1, m.group(1), j - i))
                break

# ---------- K. dead JS functions (no reference anywhere in that page) ----------
for f in glob.glob(ASSETS + '/*.html'):
    src = open(f).read()
    for name in set(re.findall(r'function\s+([A-Za-z_$][\w$]*)', src)):
        uses = len(re.findall(r'(?<![\w$.])' + re.escape(name) + r'\b', src))
        if uses <= 1:
            add('P2', 'dead-js-function', '%s: %s()' % (os.path.basename(f), name))

# ---------- L. suspicious hardcoded counts in UI text ----------
for f, s in java.items():
    for i, line in enumerate(s.split('\n'), 1):
        if re.search(r'"[^"]*\b(7\d\d|44 ?373|4\d{4})\b[^"]*"', line) and 'String.format' not in line:
            add('P2', 'hardcoded-count', '%s:%d %s' % (os.path.basename(f), i, line.strip()[:80]))

# ---------- O. threads ----------
add('P3', 'threads', '%d raw Thread() calls, %d named' % (
    len(re.findall(r'new Thread\(', alljava)), len(re.findall(r'setName\(', alljava))))

# ---------- print ----------
sev_order = {'P0': 0, 'P1': 1, 'P2': 2, 'P3': 3}
out.sort(key=lambda r: (sev_order[r[0]], r[1], r[2]))
print('%-4s %-34s %s' % ('SEV', 'FILTER', 'FINDING'))
for sev, tag, d in out:
    print('%-4s %-34s %s' % (sev, tag, d))
print('\nTOTAL %d  |  ' % len(out) + ', '.join('%s=%d' % (k, v) for k, v in sorted(Counter(s for s, _, _ in out).items())))
