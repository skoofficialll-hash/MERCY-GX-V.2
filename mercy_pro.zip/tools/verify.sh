#!/bin/bash
# One command that checks everything this sandbox can check.
# Usage: bash harness/verify.sh
set -u
cd /scratch/work
ROOT=mercy/app/src/main
CP=$(cat cp.txt)
fail=0

echo "== 1. Java compile (javac 17, android.jar API 35, real dependency jars)"
./jdk/bin/javac -nowarn -proc:none -d out -cp "$CP" \
  -sourcepath "$ROOT/java:stubs:harness/gen" \
  $(find $ROOT/java stubs harness/gen -name "*.java") 2>&1 | grep -v "^Picked up\|^Note:" | head -20
[ ${PIPESTATUS[0]} -eq 0 ] && echo "   OK" || { echo "   FAIL"; fail=1; }

echo "== 2. XML well-formed"
python3 - <<'PY'
import glob, xml.etree.ElementTree as ET, sys
bad=0
for f in glob.glob('mercy/app/src/main/**/*.xml', recursive=True):
    try: ET.parse(f)
    except Exception as e: print("   BAD", f, e); bad=1
print("   OK" if not bad else "   FAIL"); sys.exit(bad)
PY
[ $? -ne 0 ] && fail=1

echo "== 3. JSON assets parse"
python3 - <<'PY'
import json, glob, sys
bad=0
for f in glob.glob('mercy/app/src/main/assets/**/*.json', recursive=True):
    try: json.load(open(f))
    except Exception as e: print("   BAD", f, e); bad=1
print("   OK" if not bad else "   FAIL"); sys.exit(bad)
PY
[ $? -ne 0 ] && fail=1

echo "== 4. HTML/JS loads with no errors, every inline handler resolves"
for f in ui chrome newtab brand; do
  out=$(timeout 90 node harness/htmlcheck.js $ROOT/assets/$f.html 2>/dev/null)
  errs=$(echo "$out" | python3 -c "import json,sys; d=json.load(sys.stdin); print(d['errorCount'], len(d['badHandlers']), len(d['missingIds']))")
  echo "   $f: errors/badHandlers/missingIds = $errs"
  [ "$errs" != "0 0 0" ] && fail=1
done

echo "== 4b. CSS parses with no error rules"
python3 - <<'PY2'
import tinycss2, glob, re, sys
bad=0
for f in sorted(glob.glob('mercy/app/src/main/assets/*.html')):
    src=open(f).read()
    for m in re.finditer(r'<style[^>]*>(.*?)</style>', src, re.S):
        for r in tinycss2.parse_stylesheet(m.group(1), skip_whitespace=True, skip_comments=True):
            if r.type=='error':
                bad+=1; print("   BAD", f, r)
print("   OK" if not bad else "   FAIL"); sys.exit(1 if bad else 0)
PY2
[ $? -ne 0 ] && fail=1

echo "== 5. 100+ clicks through the interface, no exception"
out=$(timeout 120 node harness/exercise.js $ROOT/assets/ui.html 2>/dev/null)
echo "$out" | python3 -c "import json,sys; d=json.load(sys.stdin); print('   clicked', d['clicked'], 'errors', d['errorCount']); sys.exit(1 if d['errorCount'] else 0)"
[ $? -ne 0 ] && fail=1

echo "== 6. page <-> bridge contract (both directions)"
python3 - <<'PY'
import re, glob, sys
ui=open('mercy/app/src/main/assets/ui.html').read()
bridge=open('mercy/app/src/main/java/com/skinventor/mercypro/UiBridge.java').read()
methods=set(re.findall(r'@JavascriptInterface public void (\w+)', bridge))
calls={m.group(1).split(':')[0] for m in re.finditer(r"bridge\(\s*'([\w:]+)'", ui)}
missing=sorted(calls-methods)
act=open('mercy/app/src/main/java/com/skinventor/mercypro/MainActivity.java').read()
handled=set(re.findall(r'a\.equals\("([\w:]+)"\)', act))
direct={'open','search','tabs','menu','reload','reader','share','free','scan','voice','settings','diag',
        'selftest','about','ledger','report','update','budget','tariff','cats','lang','introDone','lib','theme','wipe'}
nohandler=sorted(calls-handled-direct)
exp=re.search(r'window\.MercyUI = \{(.*?)\};', ui, re.S).group(1)
keys=set(re.findall(r'(\w+)\s*:', exp))
jcalls=set()
for f in glob.glob('mercy/app/src/main/java/**/*.java', recursive=True):
    jcalls |= set(re.findall(r'MercyUI\.(\w+)\s*\(', open(f).read()))
jmissing=sorted(jcalls-keys)
print("   page calls with no bridge method:", missing or "none")
print("   bridge calls with no Java handler:", nohandler or "none")
print("   Java calls with no JS function:", jmissing or "none")
sys.exit(1 if (missing or nohandler or jmissing) else 0)
PY
[ $? -ne 0 ] && fail=1

echo "== 7. UiHash matches the shipped ui.html"
python3 - <<'PY'
import hashlib, re, sys
h=hashlib.sha256(open('mercy/app/src/main/assets/ui.html','rb').read()).hexdigest()
src=open('mercy/app/src/main/java/com/skinventor/mercypro/UiHash.java').read()
want=re.search(r'SHA256 = "([0-9a-f]+)"', src).group(1)
print("   file", h[:16], "constant", want[:16])
print("   OK" if h==want else "   FAIL"); sys.exit(0 if h==want else 1)
PY
[ $? -ne 0 ] && fail=1

echo "== 8. R references: every R.id / R.string / R.drawable used in Java exists"
python3 - <<'PY'
import re, glob, sys
gen=open('harness/gen/com/skinventor/mercypro/R.java').read()
have={}
cur=None
for line in gen.split('\n'):
    m=re.match(r'  public static final class (\w+)', line)
    if m: cur=m.group(1); have.setdefault(cur,set()); continue
    m=re.match(r'    public static final int (\w+)', line)
    if m and cur: have[cur].add(m.group(1))
bad=[]
for f in glob.glob('mercy/app/src/main/java/**/*.java', recursive=True):
    src = re.sub(r'android\.R\.', 'ANDROID_R.', open(f).read())
    for t,n in re.findall(r'(?<!ANDROID_)\bR\.(\w+)\.(\w+)', src):
        if n not in have.get(t,set()): bad.append(f"{f}: R.{t}.{n}")
print("   missing:", bad or "none"); sys.exit(1 if bad else 0)
PY
[ $? -ne 0 ] && fail=1

echo "== 9. theme tables: Java and ui.html agree, six rows each"
python3 - <<'PY'
import re, sys
j=open('mercy/app/src/main/java/com/skinventor/mercypro/MainActivity.java').read()
jt=re.search(r'THEMES = \{(.*?)\n    \};', j, re.S).group(1)
jrows=re.findall(r'\{"(\w+)",\s*"([^"]+)",\s*"([^"]+)","([^"]+)","([^"]+)","([^"]+)","([^"]+)"\}', jt)
u=open('mercy/app/src/main/assets/ui.html').read()
ut=re.search(r'const THEMES = \[(.*?)\n\];', u, re.S).group(1)
urows=re.findall(r"\['([^']+)','([^']+)','([^']+)','([^']+)','([^']+)','([^']+)'", ut)
print("   java rows", len(jrows), "html rows", len(urows))
ok = len(jrows)==6 and len(urows)==6
for a,b in zip(jrows,urows):
    if a[1].replace('&amp;','&')!=b[0] or a[2].lower()!=b[1].lower() or a[6].lower()!=b[5].lower():
        print("   MISMATCH", a[1], b[0]); ok=False
print("   OK" if ok else "   FAIL"); sys.exit(0 if ok else 1)
PY
[ $? -ne 0 ] && fail=1

echo
[ $fail -eq 0 ] && echo "ALL CHECKS PASSED" || echo "SOME CHECKS FAILED"
exit $fail
