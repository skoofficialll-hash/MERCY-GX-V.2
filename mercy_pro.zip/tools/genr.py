import os, re, sys, xml.etree.ElementTree as ET
root = sys.argv[1]           # app/src/main
res = os.path.join(root, 'res')
out = sys.argv[2]
types = {}
def add(t, n):
    types.setdefault(t, set()).add(n)
for d in sorted(os.listdir(res)):
    p = os.path.join(res, d)
    if not os.path.isdir(p): continue
    kind = d.split('-')[0]
    for f in sorted(os.listdir(p)):
        name, ext = os.path.splitext(f)
        if kind == 'values':
            tree = ET.parse(os.path.join(p, f))
            for el in tree.getroot():
                tag = el.tag
                nm = el.get('name')
                if not nm: continue
                if tag == 'string': add('string', nm)
                elif tag == 'color': add('color', nm)
                elif tag == 'style': add('style', nm)
                elif tag == 'bool': add('bool', nm)
                elif tag == 'integer': add('integer', nm)
                elif tag == 'dimen': add('dimen', nm)
                elif tag == 'string-array': add('array', nm)
                elif tag == 'integer-array': add('array', nm)
                elif tag == 'attr': add('attr', nm)
        elif kind == 'layout':
            add('layout', name)
            tree = ET.parse(os.path.join(p, f))
            for el in tree.iter():
                for k, v in el.attrib.items():
                    if v.startswith('@+id/'):
                        add('id', v[5:])
                    elif k == 'android:id' and v.startswith('@id/'):
                        add('id', v[4:])
        elif kind in ('drawable','mipmap','xml','menu','raw','anim','color','font','navigation'):
            if ext in ('.xml','.png','.jpg','.webp','.9.png'): add(kind, name)
        elif kind == 'mipmap-anydpi-v26':
            add('mipmap', name)
lines = ['package com.skinventor.mercypro;', 'public final class R {']
for t in sorted(types):
    lines.append('  public static final class %s {' % t)
    for i, n in enumerate(sorted(types[t])):
        lines.append('    public static final int %s = 0x%08x;' % (n, 0x7f000000 + i + 1))
    lines.append('  }')
lines.append('}')
os.makedirs(os.path.dirname(out), exist_ok=True)
open(out,'w').write('\n'.join(lines))
print({t: len(v) for t, v in sorted(types.items())})
