const {JSDOM, VirtualConsole} = require('jsdom');
const fs = require('fs');
const file = process.argv[2];
const errs = [];
const vc = new VirtualConsole();
vc.on('jsdomError', e => { const m=(e.detail && e.detail.message) || e.message || ''; if (/Not implemented/.test(m)) return; errs.push('jsdomError: ' + m); });
const calls = [];
const mercy = new Proxy({}, {get: (t,k) => k==='then' ? undefined : ((...a) => { calls.push(String(k)); return ''; })});
const dom = new JSDOM(fs.readFileSync(file,'utf8'), {runScripts:'dangerously', pretendToBeVisual:true, virtualConsole:vc,
  beforeParse(w){
    w.Mercy = mercy;
    w.addEventListener('error', e => errs.push('window.error: ' + (e.error && e.error.message || e.message)));
    w.matchMedia = w.matchMedia || (()=>({matches:false, addEventListener(){}, addListener(){}}));
  }});
const w = dom.window, d = w.document;
function run(label, fn){ try { fn(); } catch(e) { errs.push(label + ': ' + e.message); } }

const M = w.MercyUI;
run('setStats', () => M.setStats({used:'1.2 MB',cost:'₹0.02',pct:3,blocked:12,offline:2,lastUrl:'https://example.com',week:[1,2,3,4,5,6,7],sites:[['a.com','1 MB'],['b.com','2 MB']]}));
run('setStats empty', () => M.setStats({}));
run('setStats junk', () => M.setStats(null));
run('showData', () => M.showData({}));
run('showData raw', () => M.showData({used:'9 MB',pct:44}));
for (const k of ['offline','timeout','notfound','cert','blocked','crashed','nonsense'])
  run('showError '+k, () => w.showError(k));
run('setTabs', () => M.setTabs([{id:'t1',title:'A',url:'https://a.com',active:true},{id:'t2',title:'B',url:'https://b.com',incognito:true}]));
run('setTabs empty', () => M.setTabs([]));
run('setTabs junk', () => M.setTabs('x'));
run('setNotes', () => M.setNotes([{id:'1',title:'T',body:'B',at:'now'}]));
run('setNotes junk', () => M.setNotes(null));
run('showReader', () => M.showReader({title:'T',byline:'B',text:'Para one.\n\nPara two.'}));
run('showReader empty', () => M.showReader({}));
run('showSearch', () => M.showSearch('irctc'));
run('showSearch empty', () => M.showSearch(''));
run('openMenu', () => M.openMenu());
run('openThemes', () => M.openThemes());
run('setLang hi', () => M.setLang('hi'));
run('setLang ta', () => M.setLang('ta'));
run('setLang bogus', () => M.setLang('zz'));
run('applyTheme 0..6', () => { for (let i=0;i<7;i++) M.applyTheme(i); });
run('applyTheme junk', () => M.applyTheme('x'));
run('go each page', () => { ['home','library','search','settings','data','kaam','launch','hidethem','reader','notes','study','tabspage','error','intro','step','receipt'].forEach(p => M.go(p)); });
run('paintSettings', () => w.paintSettings());
run('showIntro', () => M.showIntro());
run('kaam', () => { w.kaamLoad({kaam:[{id:'k1',naam:{en:'Passport'},steps:[{kaam:{en:'Fill form'},site:'https://x.com'}],cost:'₹1'}]}); M.kaamStart('k1'); M.kaamDone(); });
run('kaamLoad junk', () => w.kaamLoad(null));
run('studyToggle x2', () => { M.studyToggle(); M.studyToggle(); });
run('hidePaint', () => { w.hidePaint(); w.hideToggle(); w.hideFind(); });
run('hideResult', () => w.hideResult('{"host":"x.com","reason":"no","alts":["https://y.com"]}'));
run('hideResult junk', () => w.hideResult('not json'));
run('readerFont', () => { w.readerFont(1); w.readerFont(-1); w.readerProgress(); });
run('noteSave', () => { const t=d.getElementById('noteTitle'), b=d.getElementById('noteBody'); if(t)t.value='T'; if(b)b.value='B'; w.newNote(); w.noteSave(); });
run('paintRecent', () => w.paintRecent());
run('paintSites', () => w.paintSites());
run('siteRow', () => w.siteRow('A','https://a.com','x','1','bridge(\'open\',\'https://a.com\')'));

// click every element that has an onclick handler
const clickable = [...d.querySelectorAll('[onclick]')];
let clicked = 0;
for (const el of clickable) {
  run('click ' + (el.getAttribute('onclick')||'').slice(0,40), () => { el.dispatchEvent(new w.MouseEvent('click', {bubbles:true})); clicked++; });
}
console.log(JSON.stringify({file, clicked, errors: errs.slice(0,25), errorCount: errs.length,
  bridgeCalls: [...new Set(calls)].sort()}, null, 1));
dom.window.close(); process.exit(0);
