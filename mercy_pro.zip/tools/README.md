# tools — how this build was checked

These are the scripts used to verify 14.5.0. They are not part of the APK.

Requirements (all free, no Android SDK needed):

* JDK 17
* `android.jar` from the Android platform 35 package (`platform-35_r02.zip` on
  dl.google.com)
* dependency jars: androidx webkit / swiperefreshlayout / core, ZXing core,
  vosk-android, JNA
* node + `jsdom` for the interface tests
* python3 + `tinycss2` for the CSS test
* GeckoView classes are stubbed in the harness (maven.mozilla.org is not reachable from
  the build sandbox); the stubs follow the published API, so a GeckoView signature
  change would not be caught here.

`bash tools/verify.sh` runs nine checks: compile, XML, JSON, HTML/JS, CSS, 104 clicks,
the page↔bridge contract, R references and the theme tables.

`python3 tools/genr.py app/src/main <out>/R.java` generates R.java from `res/` so a
missing id or string becomes a compile error instead of a runtime crash.

`node tools/htmlcheck.js <file.html>` — loads a page in jsdom and reports JS errors,
unresolved inline handlers and `getElementById` targets that do not exist.

`node tools/exercise.js <file.html>` — calls every exported function with real and junk
arguments, then fires every `onclick`, and reports anything that throws.

`python3 tools/filters.py` — the 14 custom filters that the off-the-shelf linters miss:
prefs keys read but never written, asset references vs files on disk, duplicate ids,
duplicate JS function names, CSS selector drift, a11y labels, silent catches, TODO
markers, long methods, dead JS, hardcoded counts, threads, unreachable methods.
