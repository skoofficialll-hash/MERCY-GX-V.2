# Round 8 — six themes, one brand, no drift

## 1. Why the theme never matched the browser (the real bug)
There were **two different theme tables**: the interface had 14 palettes, the native
chrome had 8, and the interface told the app which theme was picked **by index**. Index 3
meant "Mehendi" in the page and "Paper" in the chrome. Picking a theme changed half the
app.

Worse, `pushChromeConfig()` never sent the theme back, so after a restart the chrome
remembered the saved theme and the interface reset to index 0. That is the "browser theme
doesn't call the site theme" complaint, exactly.

Both are fixed: the two tables are now identical (verified line by line, all six names
and all thirty colour values), and the saved theme is pushed into the interface on every
config sync.

## 2. Six themes, three dark and three light, on the brand
| # | Theme | Kind | Accent |
|---|---|---|---|
| 1 | **Obsidian** | dark | lime `#C6F24E` |
| 2 | **Ink & Amber** | dark | amber `#E08A3C` |
| 3 | **Midnight** | dark | mint `#8FD5BE` |
| 4 | **Paper** | light | deep lime `#7FA61E` |
| 5 | **Chalk** | light | burnt amber `#C2761E` |
| 6 | **Sand** | light | teal `#2E6F5E` |

Every one uses the Mercy GX ink and the brand accents. `THEME_COUNT` is 6 and the in-app
self-test now checks for exactly 6 instead of "at least 8" (it was checking a number the
table never had — it claimed 14 while only 8 existed).

Old saved names still resolve: amoled / terminal / contrast / forest / black / soft fall
back to Obsidian, paper / doodh / rat to Paper, mitti / chandan to Sand. Nobody's saved
theme breaks.

## 3. Branding check — three inconsistencies found
| Where | Was | Now |
|---|---|---|
| `strings.xml` app name | Mercy Pro | **Mercy GX** |
| Intro screen wordmark | MERCY | **MERCY GX** |
| BUILD_INFO.txt | version 9.3.0 (103) | **14.4.0 (110)**, matching build.gradle |

New tab, launch screen, about dialog and the class header already said Mercy GX and were
left alone. The search-engine row that says "Mercy" is the engine's name, not the app's —
correct as it is.

## Verified this round
- 19 Java files parse; no duplicate method signatures or fields.
- Both theme tables compared programmatically: 6 rows each, identical order and colours.
- `UiHash` re-synced (the app compares it on launch).
- All four HTML pages at 320 px and 800 px: 0 overflow, 0 JavaScript errors,
  theme grid renders exactly 6 swatches.
- Not verified: the APK. No JDK or Android SDK in this environment, so the build, the
  GeckoView path and anything that needs a camera or a voice must be tested on a phone.
