# Round 9 — the pass that actually compiled the app

You said there were more than a hundred errors and more than a thousand glitches.
I stopped guessing this time. I built a real toolchain in the sandbox:

* **Temurin JDK 17**
* **android.jar, API 35** (Google's own platform jar)
* the real dependency jars: androidx webkit / swiperefreshlayout / core, ZXing core,
  vosk-android, JNA
* a generated `R.java` from `res/`, so a missing id or string is a compile error
* small GeckoView stubs (maven.mozilla.org is not reachable from here, so the six
  GeckoView classes this app touches are stubbed to the published API)

Then: `javac` on all 19 files, PMD 7.9, jsdom for the four HTML pages, tinycss2 for
the CSS, and a click-runner that fires every `onclick` in the interface.

## What that found, in the order it was fixed

The 25 rounds below are the actual order of the passes. Each one was re-checked
with `bash harness/verify.sh` before moving on.

| # | Round | What was broken |
|---|---|---|
| 1 | Interface boot | `applyTheme(8)` ran at the end of the page script; the theme table has **six** rows. Every launch threw `TypeError`, and everything after that line — the kaam loader — never ran. |
| 2 | Page → app contract | **25 actions** the page sends (`bridge('save')`, `bridge('offline')`, `bridge('studyStart')`, `bridge('noteAdd')`, `bridge('tab')`, …) had **no method in `UiBridge`**. `bridge()` swallows the TypeError, so the buttons did nothing at all, silently. All 25 added, plus the six Java handlers that were missing behind them. |
| 3 | Launch crash | `newTab()` built a `GeckoSession` and called `session.open(runtime)` **even in WebView mode**, where `runtime` is null. That is a crash on the first tab of the default engine. Tabs now own a session only when GeckoView is the engine. |
| 4 | Every tab action | `closeTab`, `goForward`, `onDestroy`, `onPause`, `reopenActive` dereferenced `tab.session` — null in WebView mode. All null-safe and engine-aware now. |
| 5 | Data ledger | `todayBytes()` read a `"daily"` preference that **nothing ever wrote**, so TODAY, the budget ring, "spent today" and the week bars were always zero. `recordLedger` now writes the day bucket. |
| 6 | Continue row | `lastUrl` / `lastTitle` were read in three places and written in none — "Continue" always said "nothing to continue yet". Written on every finished page load. |
| 7 | Budget ring | `pushBudget()` used a hardcoded 200 MB and ignored the saved `budgetMb`. Now reads the setting. |
| 8 | Theme classification | `lightTheme()` returned true for theme **2 (Midnight, a dark theme)** and false for Sand. Wrong light/dark colour everywhere that asked. |
| 9 | Accent picker | `pickAccent()` called `pickAccent()` — the accent dialog reopened itself for ever. Replaced with a real six-accent + custom-hex picker. |
| 10 | Library overlay | `openLibrary()` stored the page in `menuOverlay`, not `libraryPage`, so closing Notes left the library on screen. |
| 11 | Settings "Theme" row | It wrote a `"light"` boolean that nothing read. Now switches to the matching real theme. |
| 12 | Menu tab count | `buildMenu()` declared a local `tabs` that shadowed the browser's tab list; the "Tabs" row showed the number of **menu tabs** (5). |
| 13 | Session restore | Restored tabs were added next to the blank tab, so every restart grew the strip by one. |
| 14 | Back button | Notes, library and the god-reader overlay were not handled; the intro branch was duplicated. |
| 15 | Exit | `onDestroy` called `t.session.close()` on null sessions and never released the WebView, the interface WebView or the GeckoRuntime. |
| 16 | QR scanner | The `SurfaceTextureListener` was attached **after** `dialog.show()`, so `onSurfaceTextureAvailable` never fired — black preview. The permission check also ran after the HandlerThread and ImageReader were allocated, and nothing stopped the camera on pause. |
| 17 | Offline pages | A saved page opened with `engineLoad("file://…")`, which *shows* the interface — the page rendered behind it. Now loads as a page. |
| 18 | Error screens | Timeout / not-found / certificate / crashed bodies were Hinglish regardless of language. All four go through `L(hi, en, hinglish)`. |
| 19 | Asset reads | Eight places did `new byte[in.available()]; in.read(buf);`. `available()` is a hint and `read()` may return less, so a 63 KB JSON could arrive truncated. One `Io.readAll()` / `Io.readAsset()` now, everywhere. |
| 20 | Notes with a PIN | `seal()` XORed **chars** and then called `getBytes()`: results above 0xFF became `?`. A locked note came back corrupted. Byte-level XOR now. |
| 21 | Recursion | `note()` called `note()` from its own catch block; `CrashGuard` did the same. Both are plain swallows now. |
| 22 | Update download | `setDestinationInExternalPublicDir` needs WRITE_EXTERNAL_STORAGE below API 29, which the app never asked for — downloads failed on Android 5–8. App-private folder there; `REQUEST_INSTALL_PACKAGES` added to the manifest. |
| 23 | Interface ↔ app state | `pushChromeConfig()` — the only thing that sends the saved theme and language to the page — was reachable **only** from a `Bridge` class that is never registered on the WebView. It now runs on `onPageFinished`. |
| 24 | Two intros | The native five-screen intro and the HTML intro both ran on a first launch. The native one is no longer started. |
| 25 | CSS and honesty | ~30 lines of JavaScript (a second `const ERRORS`, `const WEEK`) were sitting **inside the `<style>` block**, where a CSS parser eats rules until the braces balance — real styles after it were lost. Removed; the sheet now parses with 0 error rules. Alongside: "713 sites work offline", "0 KB per page", "74 hosts blocked", invented "recent" rows and invented week bars are gone — every number on screen now comes from the phone or is not shown. |

## Also fixed in this pass

* **`Lang.ui()` never used `labels.json`** — it asked for `"hi:ui_5"` / `"en:ui_5"` and the
  shipped table has flat keys (`"ui_5"`), so 69 labels were read and thrown away. Native
  labels now follow the language.
* **Excused sites** ("turn blocking off for this site") were saved and never read back.
* **"Save data mode"** changed a preference and reloaded; the engine never blocked an image.
  It now answers image requests with a 1×1 transparent GIF.
* **Security level "pro"** (JavaScript off) only reached GeckoView. Applied to WebView too.
* **Back onto the interface** loaded `ui.html` into the engine behind a hidden chrome layer,
  which reads as a blank screen. It now brings the interface back.
* **`Images`** search always opened with an empty query.
* **GeckoView delegates** touched views from the engine's own thread — every one now posts
  to the UI thread. `pushBudget()` does too.
* **Downloads, report card, history, ledger, about, proof, tabs dialogs** used the light
  system dialog theme inside a dark app; all use `MercyDialog`.
* **`onDestroy` / wipe** now release both engines and delete the saved page, the downloaded
  site list and the Tor config.
* **Self test** gained three checks that would have caught this pass's bugs:
  interface hash, page↔bridge contract (every `bridge('x')` against the real
  `@JavascriptInterface` methods), and the real size of the site index.
* **Library counters** (`1 ›`, `0 ›`) were hardcoded; they are painted from real numbers.
* **Version** 14.4.0 (110) → **14.5.0 (111)**, `BUILD_INFO.txt` and `UiHash` re-synced.

## How this was verified (and what is still not verified)

`bash harness/verify.sh` — nine checks, all green:

1. `javac 17` over all 19 files against android.jar 35 and the real jars — 0 errors
2. every XML file well-formed
3. every JSON asset parses
4. all four HTML pages load in jsdom: 0 JS errors, 0 unresolved inline handlers, 0 missing ids
5. CSS parses with 0 error rules (tinycss2)
6. 104 clicks through the interface: 0 exceptions
7. page↔bridge contract in both directions: nothing missing
8. every `R.id` / `R.string` / `R.drawable` used in Java exists
9. the six theme rows in Java and in `ui.html` are identical

PMD 7.9 over the sources: no error-prone findings left except the style rules
(literals in `if`, `run()` without `@Override`, one-line declarations).

**Not verified:** the APK itself. There is no Android SDK build-tools or Gradle here,
so nothing was installed on a phone. Compilation, resources, the interface, the CSS
and the app↔page contract are proven; the camera, the microphone, the installer and
GeckoView's native path still need one run on a device.
