# Mercy Pro — fix pass

Build blockers removed and runtime defects fixed. Details and evidence below.

## Build blockers (3)

1. **GeckoView version was a literal placeholder**
   `implementation 'org.mozilla.geckoview:geckoview:GECKOVIEW_VERSION'` could never resolve.
   Now `implementation "org.mozilla.geckoview:geckoview:${geckoviewVersion}"`, with
   `geckoviewVersion=+` in gradle.properties (resolves the newest published release).
   Pin an exact version for reproducible builds.

2. **`package` attribute in AndroidManifest.xml**
   AGP 8.x rejects it. Removed — `namespace` in app/build.gradle is the only source now.
   Also removed the duplicate versionCode/versionName from the manifest (gradle owns them).

3. **No Gradle wrapper**
   `gradle/wrapper/gradle-wrapper.properties` added (Gradle 8.9). The wrapper JAR is a
   binary, so run once from the project root:
       gradle wrapper --gradle-version 8.9
   or open the project in Android Studio, which generates it.

## Runtime defects (2)

4. **chrome.html — one null killed the whole toolbar**
   The script assigned handlers to 8 ids that are not in the layout
   (btnClear, btnScan, badge, menuBox, mercySave, mercyUrl, miClear, miEngine).
   `btnClear.onclick = ...` threw at line 546 and every assignment after it — menu,
   new tab, tab list, data ring, scan close, Escape handler — never ran (36 statements).
   A guarded `getElementById` now returns a harmless stub for those ids.
   Result: 0 console errors (was 1 fatal).

5. **ui.html — Kaam tasks never loaded**
   `fetch('kaam.json')` is blocked for file:// pages inside WebView, so the task list
   stayed empty. The bundle is now embedded in the page as
   `<script type="application/json" id="kaamData">` and used whenever fetch fails.
   Result: task list renders ("Electricity bill — BESCOM", 521 chars of markup; was 0).

## Hardening

- `network_security.xml` was never referenced; the manifest now points at it.
- `roundIcon` pointed at `ic_launcher`; now `ic_launcher_round`.
- `enableOnBackInvokedCallback="true"` for Android 13+ predictive back.
- `document.querySelectorAll('.skip')[0]` in ui.html was unguarded; now null-checked.

## Still open (not changed)

- `usesCleartextTraffic="true"` is deliberate for a browser (users open http:// pages),
  but it means the app accepts plaintext. Consider scoping it.
- `largeHeap="true"` hides memory pressure rather than fixing it.
- `abiFilters 'arm64-v8a'` — 32-bit devices cannot install this build.
- easylist.txt (843 KB) is parsed line by line into a HashSet on every launch with no
  cache. Precompile it to a binary/JSON hash and load on a background thread.
- The 8 stub ids still have no real UI. The guards stop the crash; the buttons
  (clear, scan, menu box) should be added to chrome.html to actually appear.
