# Status — 15.0.0 (113), upload-ready

Nine checks pass, the ledger has **no P0/P1 open except the device run**.

## Verified in this sandbox
compile (android.jar 35, real deps) · XML · JSON · ui.html + brand.html in jsdom ·
CSS · 104 clicks · page↔bridge contract · R references · theme tables · ESLint 0 errors ·
html-validate 0 · UiHash synced.

## The one open P0
The APK has never been built or run. `RELEASE.md` step 4 is the 15-item list to walk on
a phone; that closes it. Camera, mic, the APK installer and the GeckoView path can only
be proven there.

## To upload
1. `keytool` once → `keystore.properties` (see `RELEASE.md`)
2. `bash tools/verify.sh` and `python3 tools/filters.py` — both clean
3. `./gradlew bundleRelease -Pgecko=<version>`
4. Play Console → privacy policy URL (host `PRIVACY.md`) → data safety: no data collected
5. Direct download: `assembleRelease` + update `latest.json`

## Deliberately not changed
- dead native intro (~300 lines): removing UI code untested on a device is risk without gain
- 99 English-only toasts/dialogs: menu and settings are translated; the rest needs a table
- CSS selectors declared several times: cleanup needs visual regression testing
- path-based EasyList rules and the reader engine's OCR: features, not defects
