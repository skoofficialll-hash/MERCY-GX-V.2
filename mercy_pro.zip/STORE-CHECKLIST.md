# STORE-CHECKLIST.md — what Play will ask you for

Code side is done (see `BUGS.md`). These are the account and listing items only you can
do, with what the app actually is in each answer.

## Before you can upload

| item | status | note |
|---|---|---|
| Signed AAB | you | `RELEASE.md` step 3. AAB, not APK, for Play |
| `versionCode` 113 / `versionName` 15.0.0 | done | bump every upload |
| targetSdk 35 | done | Play requires 34+ in 2026 |
| 64-bit | done | `abiFilters 'arm64-v8a'` |
| App icon 512×512 | you | `assets/brand.html` has the marks to export from |
| Feature graphic 1024×500 | you | Play requires it for the store listing |
| At least 2 phone screenshots | you | home, search, data screen, settings |
| Privacy policy URL | you | host `PRIVACY.md`, put the link in the console |
| Data safety form | you | answer: **no data collected, no data shared** |

## Data safety answers that match this build

- Does your app collect or share user data? **No.**
  (History, notes and the ledger never leave the device; there is no analytics SDK.)
- Is data encrypted in transit? **Yes** — https, with cleartext allowed only because a
  user can type `http://` themselves.
- Do you provide a way to delete data? **Yes** — Settings → Clear everything.
- Independent security review? **No.**

## Permissions Play will show a note about

| permission | Play's question | honest answer |
|---|---|---|
| `REQUEST_INSTALL_PACKAGES` | why does a browser install apps? | to install its own updates, because it is not distributed through Play-only channels |
| `CAMERA` | — | QR scanning, optional, only on tap |
| `RECORD_AUDIO` | — | offline voice search, optional |
| `usesCleartextTraffic=true` | why? | it is a browser: a user may type `http://` |

If Play's review objects to `REQUEST_INSTALL_PACKAGES`, the update path can be reduced to
"open the download page in the browser" by deleting `Updater.install()`. Say the word and
that is a small patch.

## Content rating questionnaire

- Category: **Utility / Communication**
- Violence, sex, profanity, drugs, gambling: **none**
- User-generated content: **no** (a browser displays the web; the app hosts nothing)
- Shares location: **no**
- Digital purchases: **no**

## What to write in the listing (short)

> **Mercy GX — a browser that shows you the bill.**
> Fast, ad-blocking browser with a data ledger: every page shows what it cost in rupees.
> Six themes, thirteen Indian languages, offline pages, notes that stay on the phone,
> and no account, no analytics, no tracking.
> Works on Android 5 and up.

## Review risk, stated plainly

The three things a reviewer is most likely to flag, and where each stands:

1. **"It says offline but needs internet."** Fixed in 14.5.0 — the app now says
   "popular sites are listed on your phone", never "works without a network".
2. **"Numbers look made up."** Fixed — the ledger, week bars and top sites come from the
   device or the screen says there is nothing yet.
3. **"GeckoView engine"** — the default engine is the phone's WebView; Settings → About
   and Privacy proof now name the engine that is actually running.
