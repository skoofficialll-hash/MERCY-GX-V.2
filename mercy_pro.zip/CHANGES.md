# 15.0.0 (113) — upload-ready

Release-level fixes (the code was already clean from 14.6.0):
- `proguard-rules.pro` was **empty** — R8 would have stripped every `@JavascriptInterface`
  method. Keep rules added for the bridge, GeckoView, Vosk and JNA.
- signing: `keystore.properties` (with example + .gitignore), env fallback, unsigned
  instead of failing when there is no key
- `-Pgecko=…` pins the engine; `packagingOptions` → `packaging`; lint on release builds
- 53 native menu/settings labels translated (Hindi / English / Hinglish)
- `PRIVACY.md`, `STORE-CHECKLIST.md`, `RELEASE.md` — the store paperwork
- `BUGS.md` is the ledger: 52 fixed rows, 8 open, 1 P0 (the device run)

---

# 14.5.0 (111) — compiled, then fixed

Round 9 is the first pass that actually built the sources: JDK 17, android.jar API 35,
the real dependency jars, a generated R.java, PMD, jsdom and a click-runner. 25 rounds
of check → fix → re-check. Full list in `FIXES-9.md`. The short version:

- the interface threw `TypeError` on every launch (`applyTheme(8)` on a six-row table)
- 25 page actions had no bridge method — those buttons did nothing, silently
- WebView mode (the default) built a GeckoSession with a null runtime: crash on first tab
- the data ledger's day bucket and the Continue row were never written: always 0 / empty
- `lightTheme()` classified Midnight as light and Sand as dark
- the accent picker called itself; the library page was stored as the menu overlay
- QR preview never opened (listener attached after `show()`); camera never released
- saved pages opened behind the interface; notes with a PIN came back corrupted
- ~30 lines of JavaScript were sitting inside `<style>`, breaking the CSS after them
- "713 sites work offline", "0 KB", "74 hosts" and invented recents/week bars removed —
  every number on screen is now measured or absent
- `Lang.ui()` never read `labels.json`; excused sites were never restored; "Save data
  mode" and security level "pro" did nothing in WebView mode

---

# Mercy GX — brand drop + bug fixes

## Added
- `assets/brand.html` — offline brand sheet: 8 marks, wordmark lockups, favicons,
  8 profile marks, 6 animated artworks (pure CSS + SVG, stops under reduced-motion).
- `MercyMark.java` — the 8 marks drawn on the same 24x24 grid as `MercyIcon`,
  plus `toBitmap()` for notifications and shortcuts.
- `drawable/mark_blade.xml` — primary mark as a vector.
- `drawable/ic_launcher_foreground.xml` — adaptive icon foreground (72dp safe zone);
  `mipmap-anydpi-v26/ic_launcher.xml` and `_round.xml` now use it instead of the PNG.
- Library screen: "Brand & artwork" row -> native dialog showing `brand.html`.
- `SelfTest`: two new checks — "Brand page" and "Brand artwork".

## Replaced
- `newtab.html` — letter "M" tile -> Blade M mark.
- `ui.html` — both "M E R C Y" text brands -> mark + wordmark lockup.
- `chrome.html` — `MERCY_LOGO` (purple circles) -> Blade M mark.

## Fixed
1. **Self-test reported a false failure.** `SelfTest.count()` counted top-level JSON
   keys, so the tracker list showed "3 hosts" (its real count is 81) and engines
   showed 4 (real count 9). Added `size(json, key)` and used it for both.
2. **Plain http:// sites could not load.** The manifest said `usesCleartextTraffic="true"`
   but `xml/network_security.xml` said `cleartextTrafficPermitted="false"`, and the
   config wins — every http:// URL failed even though the app accepts them.
3. **Notes could not be created.** The "New note" button calls `newNote()`, which
   looks for `#noteEditor`, `#noteTitle` and `#noteBody` — none of them existed in the
   page, and the null guards made it fail silently. The editor markup and its styles
   are now in `ui.html`.
