# Independent by default — what changed

You said: stay independent, depend on nobody. So I did not reach for ML Kit or
Tesseract. I rebuilt the OCR inside the engine you supplied so that it uses nothing
but the phone itself.

## The problem with the engine as supplied

`initTopologicalGlyphSignatures()` filled its glyph templates like this:

```java
int seed = c * 31 + 17;
vec[k] = ((seed >> (k % 8)) & 1) == 1 ? 0.68f : 0.18f;
seed = (seed * 1103515245 + 12345) & 0x7fffffff;
```

A pseudo-random generator seeded from the character code. No letter was ever seen, so
the classifier could not read anything — it only looked confident.

## What it does now

**Templates are drawn, not invented.** At start-up the engine renders each supported
character with the device's own system font (`Paint` + `Typeface.SANS_SERIF`, 64 px),
finds the ink bounding box, and fingerprints it. No model file, no download, no
library, no network.

**The fingerprint is a 20 × 20 ink map.** The glyph is cropped to its ink box, divided
into 400 cells, and each cell becomes 1 or 0 depending on whether more than 43 % of it
is ink.

**Matching is cosine similarity.** Nearest neighbour over all templates; below 0.55 it
returns a space instead of a confident wrong letter.

## Proof, before writing a line of Java

I rebuilt the exact algorithm in Python and measured it on rendered words:

| word | read as |
|---|---|
| Mercy | Mercv |
| GX2026 | GX2026 |
| Browser | Browser |
| Hello | HeIIo |
| abc123 | abc123 |
| Settings | Settinos |
| Tor | Tor |

**36 of 40 characters correct — 90 %**, on clean rendered text.

## What it honestly cannot do

- **Photographs of real-world text.** Lighting, perspective and unknown fonts break
  template matching. It works on screenshots, screen captures and clean scans.
- **Devanagari.** Segmentation of matras (ि ी ो) needs a different line model; the
  charset is A–Z, a–z, 0–9. Hindi is not claimed.
- **Translation.** The 23-entry transliteration table is still not a translator, and
  the speech synthesiser still produces a formant buzz rather than speech. Neither is
  wired to a button.

## The dependency ledger

| Dependency | What it does | Yours? | Independent alternative |
|---|---|---|---|
| `org.mozilla.geckoview` | second engine | no, ~60 MB | the system WebView (already in the app) |
| `com.google.zxing:core` | QR decoding | no, small | writing a QR decoder is weeks of work |
| `com.alphacephei:vosk-android` | offline speech | no, heavy + model | Android `SpeechRecognizer` (OS API) |
| `androidx.webkit`, `swiperefreshlayout` | UI helpers | no, light | removable with small edits |

Everything else in this app is already yours: `MercyIcon`, `MercyMark`, `Mascot`,
`Blocker`, `Reader`, `Notes`, `Lang`, `BudgetRing`, the whole HTML interface, the site
index and the brand artwork.

## Verified

All 18 Java files parse clean. The engine still exposes the same public API, so the
Reader mode row added last round keeps working.
