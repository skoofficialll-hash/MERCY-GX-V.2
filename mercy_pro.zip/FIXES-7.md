# Round 7 — GeckoView stays, the rest gets fixed

## 1. GeckoView ignored the tablet mode
The session was created with `.userAgentOverride(uaFor(nextDesktop))` — a true/false
flag that only knew desktop and mobile. Choosing "Tablet site" in GeckoView mode did
nothing at all. It now passes `uaForMode(uaMode())`, so all three site versions work on
both engines, and the two older call sites were moved to the same function.

## 2. The menu was a 19-row wall
The last section held Settings, New tab, Incognito, Bookmark, Bookmarks, History,
Security, Privacy proof, Diagnostics, Console, Dev panel, Self test, Updates, About and
Panic wipe in one list. It is now two sections: everyday actions first, then
**Advanced** (privacy proof, diagnostics, console, dev panel, self test, updates, about,
panic wipe). Nothing was removed — only grouped.

## 3. First run asked four questions
Language → data plan → "what do you open most" → "713 sites". Two of those can wait
until the person is actually browsing. The intro now ends after the data plan, and the
progress dots show two instead of four. The two later screens are still in the file if
you ever want them back.

## 4. Read aloud — new, and it uses the phone, not a library
`MercyVoice.java`: the OS `TextToSpeech` API, nothing else. A voice is used only after
three checks, because `isLanguageAvailable()` alone is unreliable — it can answer
AVAILABLE while the voice data is missing and the engine quietly speaks another
language:
1. `isLanguageAvailable()` is not MISSING_DATA / NOT_SUPPORTED;
2. `getVoice().getFeatures()` does not contain `KEY_FEATURE_NOT_INSTALLED`;
3. `isNetworkConnectionRequired()` is false — so it never needs data.

New menu row **Read aloud** reads the article currently open in Reader. If no article is
open it says so instead of doing nothing. The engine is released in `onDestroy()`.

## 5. A duplicate method that would have broken the build
Adding `onDestroy()` created a second one — two methods with the same signature is a
compile error in Java. Found it with a member scan and merged the voice release into the
existing `onDestroy()`. That scan now runs on every check (`newTab` and `uiAction` also
appear twice but those are legal overloads with different parameters).

## Verified
- 19 Java files parse; no duplicate fields; no duplicate method signatures.
- `UiHash` re-synced after the `ui.html` change (the app compares it on every launch).
- All four HTML pages: 0 horizontal overflow and 0 JavaScript errors at 320 px and
  800 px; the intro now shows 2 progress dots.
- Not verified: the APK itself — no JDK or Android SDK here. GeckoView behaviour,
  the speech engine and the camera all need a device run.
