# RELEASE.md — how to build and upload 15.0.0

Two paths: a **signed APK** (direct download, what you have been shipping) and an
**AAB** (Play Store). Both come from the same source.

## 0. What the source tree must look like before you build

```
Mercy GX/
├── app/
│   ├── build.gradle          versionCode 113, versionName 15.0.0
│   ├── proguard-rules.pro    keep rules for the JS bridge and GeckoView
│   └── src/main/…
├── keystore.properties       ← you create this (git-ignored)
├── keystore.properties.example
├── PRIVACY.md                ← host this, Play needs the URL
├── BUGS.md                   ← the ledger; no P0/P1 may be open
└── tools/                    ← verify.sh, filters.py, genr.py, htmlcheck.js, exercise.js
```

## 1. Make the signing key (once, keep it safe)

```bash
keytool -genkeypair -v -keystore mercy-release.jks -alias mercy \
        -keyalg RSA -keysize 4096 -validity 10000
cp keystore.properties.example keystore.properties   # then edit the passwords
```

Lose this file and you can never update the app again — Play will not accept a build
signed with a different key. Keep two copies off the machine.

## 2. Check the build before you build it

```bash
bash tools/verify.sh          # 9 checks: compile, XML, JSON, JS, CSS, 104 clicks,
                              # bridge contract, R references, theme tables
python3 tools/filters.py      # 14 custom filters; read the P0/P1 rows
```

Both must be clean. `verify.sh` needs a JDK 17, `android.jar` (platform 35), the
dependency jars, node + jsdom and python3 + tinycss2 — see `tools/README.md`.

## 3. Build

```bash
# signed APK for direct download
./gradlew clean assembleRelease -Pgecko=131.0.20240930150155
#   → app/build/outputs/apk/release/app-release.apk

# Android App Bundle for Play
./gradlew clean bundleRelease -Pgecko=131.0.20240930150155
#   → app/build/outputs/bundle/release/app-release.aab
```

`-Pgecko=…` pins the engine so the same source gives the same binary. Without it,
`geckoviewVersion=+` in `gradle.properties` resolves to whatever Mozilla published that
day. To see the versions available:

```bash
curl -s https://maven.mozilla.org/maven2/org/mozilla/geckoview/geckoview/maven-metadata.xml | grep -o '<version>[^<]*' | tail -5
```

## 4. Test the artifact on a phone (this is the only step that cannot be done in CI)

Install the release APK and walk this list. It is the same list that is open in
`BUGS.md` as O-01:

- [ ] first launch: language screen → data plan → start (no crash, no double intro)
- [ ] type `https://example.com` → page opens, address bar shows the URL
- [ ] type `http://neverssl.com` → opens (cleartext is allowed on purpose)
- [ ] type a random word → search opens on the chosen engine
- [ ] Desktop site toggle → page reloads as desktop
- [ ] mic button → offline voice asks for the model, or the system voice opens
- [ ] long-press mic → QR scanner shows a camera preview (not black)
- [ ] Save page offline → open it from Library → the page appears (not a blank screen)
- [ ] Settings → theme: all six, and the HTML page changes with the native chrome
- [ ] Settings → language: Hindi, English, Hinglish at least
- [ ] Settings → Darken pages, Site list pack, Tab limit, Text size, Accent colour
- [ ] Settings → Privacy proof shows the signer fingerprint (not "unavailable")
- [ ] Settings → Clear everything → ERASE → hold 3s → app comes back empty
- [ ] airplane mode → "no internet" screen, saved pages still open
- [ ] back button: menu → settings → page history → exits in that order

Anything that fails goes into `BUGS.md` with the screen and the error text.

## 5. Upload

**Play Store** (AAB):

1. Play Console → your app → *Production* → *Create new release*
2. Upload `app-release.aab`
3. Release notes: copy the top section of `CHANGES.md`
4. Data safety form: "no data collected, no data shared" — the app has no analytics
   and no account. Declare the four permissions from `PRIVACY.md`.
5. Privacy policy URL: where you hosted `PRIVACY.md`
6. Content rating questionnaire, screenshots, icon — Play requires these once

**Direct download** (APK): attach `app-release.apk` to a GitHub release. The in-app
updater reads `latest.json` from `skoofficialll-hash.github.io/MERCY-GX-V.2`, so update
that file with the new `tag` and `download` URL, or the update check will keep
offering the old build.

## 6. After upload

- bump `versionCode` before the next build (Play refuses a reused code)
- add the new `latest.json` URL to `Updater.LATEST_JSON` if the repo moved
- keep the `-Pgecko` value in the release notes so the build is reproducible
