# Round 11 — 15.0.0: the build you can upload

This round was not about finding new crashes. It was about the gap between "the code is
fixed" and "a store will accept this and a reviewer can install it". Nine release-level
defects were sitting in that gap.

## Fixed

1. **`proguard-rules.pro` was empty.** Shrinking is off today, so nothing breaks today —
   but the moment anyone turns `minifyEnabled` on, R8 renames every
   `@JavascriptInterface` method. `bridge('save')` would call a method that no longer
   exists, silently, exactly like round 9's R9-02. Keep rules for the bridge, GeckoView,
   Vosk and JNA are in place, with the reason written next to each one.
2. **Signing was an `export`-or-nothing ritual.** A release build now reads
   `keystore.properties` (with `keystore.properties.example` to copy) and falls back to
   the environment; with neither it stays *unsigned* instead of failing, so a reviewer
   can still build and test.
3. **`geckoviewVersion=+`** made every build a different binary. `-Pgecko=…` pins it, and
   `RELEASE.md` shows how to list the versions Mozilla has published.
4. **`packagingOptions`** → `packaging` (AGP 8.7), `lint { checkReleaseBuilds true }`,
   `bundle { language { enableSplit false } }` because the app carries its own 13
   languages.
5. **53 native menu and settings labels were English** in a 13-language app. They now go
   through `Lang.m(key, english)` with Hindi and Hinglish columns; a missing key falls
   back to the English literal, so nothing can turn into a raw key name on screen.
6. **The store paperwork that is actually code-shaped:** `PRIVACY.md` (the exact text to
   host, matching what the app does), `STORE-CHECKLIST.md` (data-safety answers,
   permission justifications, content rating), `RELEASE.md` (build → test → upload, with
   the 15-item device list).

## Verified in this build

```
javac (android.jar 35, real deps) ....... 0 errors
XML / JSON ............................... 0 errors
ui.html + brand.html in jsdom ............ 0 JS errors, 0 unresolved handlers
CSS (tinycss2) ........................... 0 error rules
104 clicks through the interface ......... 0 exceptions
page <-> bridge contract ................. closed both ways
R.id / R.string / R.drawable ............ every reference resolves
theme tables Java <-> HTML ............... 6 rows, identical
ESLint ................................... 0 errors (21 warnings, all inline-handler false positives)
html-validate ............................ 0 on both shipped pages
UiHash ................................... matches ui.html
```

## Not verified — and it is the one that matters

**The APK has never been built or run** (`O-01`). Everything above is a proxy for that
one run. `RELEASE.md` step 4 is the list: first launch, https and http, search,
desktop site, mic, QR camera, offline save, six themes, three languages, clear-all,
airplane mode, back order. Fifteen minutes on a phone closes the last P0.
