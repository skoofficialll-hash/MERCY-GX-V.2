# Mercy — read as a first-time user

I went through the app the way a person would who reads a little, does not read
Hindi comfortably, and does not know what a "browser engine" is. Below is what
confused me, what I changed, and what still needs your call.

## What I changed in this build

**1. The first question asked me to choose an "engine".**
The screen said *"Which engine?"* with two boxes: *GeckoView — its own engine, no
Google, heavier* and *WebView — the system engine, light, but it is Google's*. I
have no idea what that means. I cannot answer it, so I would tap anything and hope.
Now it asks a question I can answer:

- **Fast and light** — pages open quickly, battery lasts longer (this one is
  picked for me already)
- **More private** — blocks more trackers, a little slower

The words "WebView" and "GeckoView" are still there, small and grey, for anyone who
wants them. The default is now the light engine, so a slow phone gets the fast one
unless the user chooses otherwise.

**2. The app told me 713 sites work without internet. They do not.**
Three places said "713 sites are on your phone — those will open" and
"No data, no network". Those 713 are only a list of addresses; opening one still
needs a connection. That is why it feels like "nothing opens". I changed the words
to the truth:

- "713 popular sites are ready — tap one to open it."
- offline message: "No internet. Pages you saved will open. Everything else needs
  a connection."

**3. The data-plan question was written in Hindi only.**
The chips said ₹239 / 1.5 GB दिन, Wi-Fi ज़्यादा, पता नहीं. If I cannot read Hindi I
cannot pick one. Now: `₹239 · 1.5 GB a day`, `Mostly Wi-Fi`, `Not sure`.

**4. Twenty messages used words I do not know.** Examples:
- "Engine did not start — switching to the system engine" → "The page engine
  failed. Trying the phone's engine."
- "Console needs the Mercy Core extension…" → "This tool is not in this version."
- "Interface check failed — reinstall the app" → "The app files are damaged.
  Install Mercy again."
- "This page has no host" → "That address is not complete."
- "Find works in the system engine" → "Find on page works only in Fast and light
  mode."

## What still needs your decision (I did not change these)

**a. Four questions before I can browse.** Language → data plan → what I open most
→ a 713-sites claim. A user in a hurry quits at question two. I would cut this to
one screen: language, then Start. Data plan and categories can live in Settings
where I can find them later. Say the word and I will do it — it is a flow change,
not a one-line fix, so I did not do it silently.

**b. The word "offline" is used for two different things** — the 713-site list and
the pages you actually saved. Two names would help: "Saved pages" for what the user
saved, "Popular sites" for the bundled list.

**c. Nothing tells me what the app is for.** The first screen shows a logo and a
language grid. One line under the logo — "Fast browser. Blocks ads. Saves data." —
would tell me in five seconds.

**d. The menu has ~15 rows.** For someone who reads slowly, that is a wall. The
four that matter to a first-time user are: Search, Tabs, Downloads, Settings. The
rest can sit under "More".

**e. I cannot tell which pages are saved.** If a page is saved for offline, it
should say so on the row, in words, not an icon.

## Code notes

- `UiHash.SHA256` must be re-computed whenever `assets/ui.html` changes, or the app
  shows "app files are damaged" on every launch. I re-synced it; the build checks
  it and passes.
- I could not compile the APK here (no JDK/Android SDK in this sandbox). All 17
  Java files parse clean, all XML is well-formed, no missing resources, and the four
  HTML pages load with zero JavaScript errors.
