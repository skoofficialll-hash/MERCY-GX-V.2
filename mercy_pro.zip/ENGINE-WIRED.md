# MercyReaderEngine — it is now in the app

## What I did

1. Added the file at `app/src/main/java/com/mercy/gx/engine/MercyReaderEngine.java`
   (its own package, no clash, no resources, no SDKs).
2. Wired **only reader mode** to a menu row: **"Reader mode (new engine)"**.
   It opens full-screen over the page with a back arrow, loads the current URL into the
   engine, and after the page paints it calls `activateGodReaderMode(true)`.
   Everything is inside `try/catch`: if the engine throws, the screen closes itself and
   falls back to the app's own reader, so a failure cannot trap the user.
3. Back button closes the reader before anything else.
4. The engine's language is set from the app's own language setting.

## What I deliberately did not wire

**The OCR.** In `initTopologicalGlyphSignatures()` each glyph vector is produced by:

```java
int seed = c * 31 + 17;
vec[k] = ((seed >> (k % 8)) & 1) == 1 ? 0.68f : 0.18f;
seed = (seed * 1103515245 + 12345) & 0x7fffffff;
```

That is a pseudo-random generator seeded from the character code. No glyph samples, no
fonts, no training data anywhere in the file. It cannot read text; it would return
confident-looking wrong characters. Wiring it to a camera button would ship a broken
feature, which is exactly what the last tester rejected the app for.

**The speech.** The Klatt/formant DSP is genuine and will produce audio, but formant
synthesis at this level gives a vowel buzz, not understandable Hindi. Android's own
TextToSpeech with an offline Hindi voice is the honest option.

**The translation.** The table is 23 Romanised-Hindi transliterations
(kya→क्या, hai→है, bhai→भाई). It is not a translator and `setTargetLanguage("ja")`
will not produce Japanese.

## Verified

- All 18 Java files parse clean, including the engine.
- Every helper the new code calls exists (`showGecko`, `hairline`, `sharpText`, `note`,
  `toast`, `surface`, `accent`, `ink`, `inkDim`).
- No `R.` reference, asset or dependency was added, so nothing else in the build moves.
- Not verified: the engine actually running. That needs a phone — I cannot build an APK
  here. If the reader screen comes up blank, the likely cause is that 2.5 s is not
  enough for the page to paint on a slow phone; tell me and I will make it wait for the
  engine's own diagnostic callback instead.

## If you want the rest

- Real OCR: `com.google.mlkit:text-recognition` + `text-recognition-devanagari`
  (offline, free) — or Tesseract4Android if "no Google" is a hard rule.
- Real speech: `android.speech.tts.TextToSpeech` with a Hindi offline voice, and the
  word-index highlighting the engine already draws.
Say which and I will wire it the same way — guarded, with a fallback.
