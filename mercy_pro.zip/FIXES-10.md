# Round 10 — six more filters, and the number you asked for

Round 9 built the toolchain. This round added the filters that were still missing and
ran everything at once, because "four or five errors per chat" does not converge.

## The filters, and what each one found

| filter | scope | findings | real |
|---|---|---|---|
| `javac -Xlint:all` | 19 files, android.jar 35 | 57 warnings | 0 errors, all deprecations |
| PMD 7.9 | 4 rulesets | 763 | ~15 (style-heavy) |
| **SpotBugs 4.9.8** (effort max) | compiled classes + aux classpath | 189 | ~35 |
| **ESLint 10** | extracted JS from 4 pages | 25 errors + 60 warnings | 8 |
| **html-validate 10** | 4 pages | 90 | 5 + 23 a11y |
| tinycss2 | `<style>` in 4 pages | 0 error rules | 0 |
| jsdom load + 104 clicks | ui.html | 0 exceptions | 0 |
| **filters.py** (14 custom) | sources + assets | 61 | 12 |

The custom filters are the ones that found things no off-the-shelf linter looks for:

* **unreachable methods** — 22 private methods with no caller. This is the single most
  expensive class of bug in a browser shell: the code is there, tested by eye, and the
  user has no way to reach it.
* **prefs read but never written** — found `forceDark` and `indexPack` (the same shape
  of bug as `"daily"` in round 9).
* **asset references vs files** — found a licence text that shipped and could not be
  opened, and 49 KB of dead pages.
* duplicate ids / duplicate JS names / dead JS functions / CSS selector drift /
  hardcoded counts / silent catches / threads / long methods.

## Fixed in this build

Twenty-five rows — the full table is in `BUGS.md` (R10-01 … R10-25). The ones a
reviewer would have hit first:

1. **Eleven features had no door.** Find on page, Images, Search by picture, Site
   information, "If this site is broken", Text size, Accent colour, Tab limit,
   Tor via Orbot, and the app's own caught errors in Diagnostics. All are menu rows now.
2. **Two settings that did not exist.** `forceDark` and `indexPack` were read by the
   engine and written by nobody. Both are real rows now.
3. **The licence was unreachable.** EasyList is CC BY-SA; the attribution file was in
   the APK and no screen could show it. "Licence text" button added.
4. **The app was silent to TalkBack.** 57 click listeners, zero content descriptions.
5. **49 KB of dead, broken pages** (`chrome.html` called eight functions that do not
   exist anywhere) moved out of the APK into `design/`.
6. **Locale bugs.** 12 `toLowerCase()` calls without `Locale.ROOT`: on a Turkish phone
   `"I"` lowercases to `"ı"`, so host matching and URL checks quietly failed.
7. **Thread safety** in the label table, a reader leak in the updater, null fields in
   `Note`, a null `listFiles()` in the voice-model unzip.

## Numbers, this build

```
javac errors ......... 0
ESLint errors ........ 0   (was 25)
html-validate ........ 0   on the shipped pages (was 90)
CSS error rules ...... 0
JS errors on load .... 0
exceptions in 104 clicks .. 0
bridge contract ...... closed both ways
P0 open .............. 1   (the APK itself: never built, never run)
P1 open .............. 1   (GeckoView path needs a real link)
```

## What I will not claim

The app is not "error free" and no build is. What changed is the *kind* of claim:
everything above is either fixed and re-checked, or written down in `BUGS.md` with the
reason it is still open. `O-01` is the one that matters most — every static filter in
this sandbox is a proxy for one real run on a phone.

## How to run all of it

```
bash tools/verify.sh                 # 9 checks, must be all green
python3 tools/filters.py             # 14 custom filters, findings table
python3 tools/genr.py app/src/main <out>/R.java
node tools/htmlcheck.js <page.html>
node tools/exercise.js <page.html>
```
