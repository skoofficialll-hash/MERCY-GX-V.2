# What the tester saw, and what changed

## 1. "App keeps throwing me out" — found it
`AndroidManifest.xml` had `android:enableOnBackInvokedCallback="true"`. On Android 13
and newer that switches the system to predictive back, and because this Activity never
registers an `OnBackInvokedCallback`, the system finishes the Activity directly —
`onBackPressed()` is skipped, so all the careful back handling (close menu → close
sheet → page back → tab back) never ran. Back closed the app from anywhere.
The flag is removed; back now walks out of a menu, a sheet, the page history, then the
tab, and only then leaves the app.

## 2. "Engine switch does not work" — found it
The launch screen saved the choice to `useWebView` and showed a toast, but the engine
is only built in `onCreate`. Nothing changed until the app was killed and reopened.
Now: if the choice differs from the running engine, the Activity rebuilds immediately
with a plain message ("Fast and light — starting").

## 3. "Theme mismatch — browser theme does not reach the page" — partly found it
The page area was never given a background colour, so every navigation painted white
before the site arrived. That white flash is what reads as "the theme is wrong".
The WebView now paints in the app's own surface colour and uses a hardware layer.

## 4. "The same logo shows on different options" — found it
The menu used the same glyph for unrelated rows: ↻ for Reload, Update site list and
Check for updates; ✓ for Self test and Privacy proof; ⟷ for Open tabs, Bookmarks and
History. Each row now has its own glyph. The brand mark is also no longer printed on
both the intro and the launch screen — only the intro.

## 5. "The UI overflows" — measured, not guessed
I rendered every HTML page at 320 px and 360 px and compared `scrollWidth` with
`clientWidth`. `brand.html` overflowed by 10 px at 320 (the lockup cell). Fixed, and
overflow guards added to `ui.html` (long site names, long language names, menu rows).
Result now: 0 px overflow on all four pages at both widths, 0 JavaScript errors.

## 6. "Features do not work although we claim them" — the worst one was a lie
Three places told the user that 713 sites work with no internet. They are an index of
addresses; opening one still needs a connection. The words are now true:
"713 popular sites are ready — tap one to open it", and the offline screen says
"Pages you saved will open. Everything else needs a connection."
The first-run question "Which engine?" is also gone — it now asks "Fast and light" or
"More private", with the light engine already selected.

## What I could not do here
- No APK build in this sandbox (no JDK / Android SDK). All 17 Java files parse, the
  manifest and every XML resource are valid, no resource is missing, and the interface
  hash the app checks on launch matches the shipped `ui.html`.
- Anything that needs a real phone — actual page loading, GeckoView behaviour, the QR
  camera — must be checked on a device. If a page still fails, the text on the error
  screen (the `ERR_…` code) tells me exactly which layer is refusing it.
